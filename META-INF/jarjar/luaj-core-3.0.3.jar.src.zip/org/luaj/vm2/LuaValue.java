/*      */ package org.luaj.vm2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class LuaValue
/*      */   extends Varargs
/*      */ {
/*      */   public static final int TINT = -2;
/*      */   public static final int TNONE = -1;
/*      */   public static final int TNIL = 0;
/*      */   public static final int TBOOLEAN = 1;
/*      */   public static final int TLIGHTUSERDATA = 2;
/*      */   public static final int TNUMBER = 3;
/*      */   public static final int TSTRING = 4;
/*      */   public static final int TTABLE = 5;
/*      */   public static final int TFUNCTION = 6;
/*      */   public static final int TUSERDATA = 7;
/*      */   public static final int TTHREAD = 8;
/*      */   public static final int TVALUE = 9;
/*  188 */   public static final String[] TYPE_NAMES = new String[] { "nil", "boolean", "lightuserdata", "number", "string", "table", "function", "userdata", "thread", "value" };
/*      */ 
/*      */ 
/*      */   
/*  192 */   public static final LuaValue NIL = LuaNil._NIL;
/*      */ 
/*      */   
/*  195 */   public static final LuaBoolean TRUE = LuaBoolean._TRUE;
/*      */ 
/*      */   
/*  198 */   public static final LuaBoolean FALSE = LuaBoolean._FALSE;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  203 */   public static final LuaValue NONE = None._NONE;
/*      */ 
/*      */   
/*  206 */   public static final LuaNumber ZERO = LuaInteger.valueOf(0);
/*      */ 
/*      */   
/*  209 */   public static final LuaNumber ONE = LuaInteger.valueOf(1);
/*      */ 
/*      */   
/*  212 */   public static final LuaNumber MINUSONE = LuaInteger.valueOf(-1);
/*      */ 
/*      */   
/*  215 */   public static final LuaValue[] NOVALS = new LuaValue[0];
/*      */ 
/*      */   
/*  218 */   public static LuaString ENV = valueOf("_ENV");
/*      */ 
/*      */   
/*  221 */   public static final LuaString INDEX = valueOf("__index");
/*      */ 
/*      */   
/*  224 */   public static final LuaString NEWINDEX = valueOf("__newindex");
/*      */ 
/*      */   
/*  227 */   public static final LuaString CALL = valueOf("__call");
/*      */ 
/*      */   
/*  230 */   public static final LuaString MODE = valueOf("__mode");
/*      */ 
/*      */   
/*  233 */   public static final LuaString METATABLE = valueOf("__metatable");
/*      */ 
/*      */   
/*  236 */   public static final LuaString ADD = valueOf("__add");
/*      */ 
/*      */   
/*  239 */   public static final LuaString SUB = valueOf("__sub");
/*      */ 
/*      */   
/*  242 */   public static final LuaString DIV = valueOf("__div");
/*      */ 
/*      */   
/*  245 */   public static final LuaString MUL = valueOf("__mul");
/*      */ 
/*      */   
/*  248 */   public static final LuaString POW = valueOf("__pow");
/*      */ 
/*      */   
/*  251 */   public static final LuaString MOD = valueOf("__mod");
/*      */ 
/*      */   
/*  254 */   public static final LuaString UNM = valueOf("__unm");
/*      */ 
/*      */   
/*  257 */   public static final LuaString LEN = valueOf("__len");
/*      */ 
/*      */   
/*  260 */   public static final LuaString EQ = valueOf("__eq");
/*      */ 
/*      */   
/*  263 */   public static final LuaString LT = valueOf("__lt");
/*      */ 
/*      */   
/*  266 */   public static final LuaString LE = valueOf("__le");
/*      */ 
/*      */   
/*  269 */   public static final LuaString TOSTRING = valueOf("__tostring");
/*      */ 
/*      */   
/*  272 */   public static final LuaString CONCAT = valueOf("__concat");
/*      */ 
/*      */   
/*  275 */   public static final LuaString EMPTYSTRING = valueOf("");
/*      */ 
/*      */   
/*  278 */   private static int MAXSTACK = 250;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  284 */   public static final LuaValue[] NILS = new LuaValue[MAXSTACK];
/*      */   static {
/*  286 */     for (int i = 0; i < MAXSTACK; i++) {
/*  287 */       NILS[i] = NIL;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int MAXTAGLOOP = 100;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isboolean() {
/*  322 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isclosure() {
/*  334 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isfunction() {
/*  345 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isint() {
/*  362 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isinttype() {
/*  375 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean islong() {
/*  390 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isnil() {
/*  404 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isnumber() {
/*  417 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isstring() {
/*  429 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isthread() {
/*  439 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean istable() {
/*  449 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isuserdata() {
/*  461 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isuserdata(Class c) {
/*  475 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean toboolean() {
/*  488 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte tobyte() {
/*  501 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char tochar() {
/*  514 */     return Character.MIN_VALUE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double todouble() {
/*  532 */     return 0.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float tofloat() {
/*  545 */     return 0.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int toint() {
/*  563 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long tolong() {
/*  579 */     return 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short toshort() {
/*  592 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String tojstring() {
/*  605 */     return typename() + ": " + Integer.toHexString(hashCode());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object touserdata() {
/*  616 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object touserdata(Class c) {
/*  628 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  641 */     return tojstring();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue tonumber() {
/*  663 */     return NIL;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue tostring() {
/*  683 */     return NIL;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean optboolean(boolean defval) {
/*  696 */     argerror("boolean"); return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaClosure optclosure(LuaClosure defval) {
/*  713 */     argerror("closure"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double optdouble(double defval) {
/*  731 */     argerror("number"); return 0.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaFunction optfunction(LuaFunction defval) {
/*  750 */     argerror("function"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int optint(int defval) {
/*  769 */     argerror("int"); return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaInteger optinteger(LuaInteger defval) {
/*  788 */     argerror("integer"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long optlong(long defval) {
/*  806 */     argerror("long"); return 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaNumber optnumber(LuaNumber defval) {
/*  825 */     argerror("number"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String optjstring(String defval) {
/*  842 */     argerror("string"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaString optstring(LuaString defval) {
/*  859 */     argerror("string"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaTable opttable(LuaTable defval) {
/*  872 */     argerror("table"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaThread optthread(LuaThread defval) {
/*  885 */     argerror("thread"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object optuserdata(Object defval) {
/*  900 */     argerror("object"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object optuserdata(Class c, Object defval) {
/*  918 */     argerror(c.getName()); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue optvalue(LuaValue defval) {
/*  932 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean checkboolean() {
/*  943 */     argerror("boolean"); return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaClosure checkclosure() {
/*  959 */     argerror("function"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double checkdouble() {
/*  977 */     argerror("number"); return 0.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaFunction checkfunction() {
/*  990 */     argerror("function"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Globals checkglobals() {
/* 1002 */     argerror("globals"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int checkint() {
/* 1021 */     argerror("number"); return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaInteger checkinteger() {
/* 1040 */     argerror("integer"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long checklong() {
/* 1059 */     argerror("long"); return 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaNumber checknumber() {
/* 1078 */     argerror("number"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaNumber checknumber(String msg) {
/* 1098 */     throw new LuaError(msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String checkjstring() {
/* 1114 */     argerror("string"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaString checkstring() {
/* 1132 */     argerror("string"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaTable checktable() {
/* 1144 */     argerror("table"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaThread checkthread() {
/* 1156 */     argerror("thread"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object checkuserdata() {
/* 1169 */     argerror("userdata"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object checkuserdata(Class c) {
/* 1182 */     argerror("userdata"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue checknotnil() {
/* 1192 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isvalidkey() {
/* 1201 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaValue error(String message) {
/* 1209 */     throw new LuaError(message);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assert_(boolean b, String msg) {
/* 1221 */     if (!b) {
/* 1222 */       throw new LuaError(msg);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LuaValue argerror(String expected) {
/* 1233 */     throw new LuaError("bad argument: " + expected + " expected, got " + typename());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaValue argerror(int iarg, String msg) {
/* 1245 */     throw new LuaError("bad argument #" + iarg + ": " + msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LuaValue typerror(String expected) {
/* 1255 */     throw new LuaError(expected + " expected, got " + typename());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LuaValue unimplemented(String fun) {
/* 1263 */     throw new LuaError("'" + fun + "' not implemented for " + typename());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LuaValue illegal(String op, String typename) {
/* 1273 */     throw new LuaError("illegal operation '" + op + "' for " + typename);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LuaValue lenerror() {
/* 1282 */     throw new LuaError("attempt to get length of " + typename());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LuaValue aritherror() {
/* 1290 */     throw new LuaError("attempt to perform arithmetic on " + typename());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LuaValue aritherror(String fun) {
/* 1300 */     throw new LuaError("attempt to perform arithmetic '" + fun + "' on " + typename());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LuaValue compareerror(String rhs) {
/* 1312 */     throw new LuaError("attempt to compare " + typename() + " with " + rhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LuaValue compareerror(LuaValue rhs) {
/* 1323 */     throw new LuaError("attempt to compare " + typename() + " with " + rhs.typename());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue get(LuaValue key) {
/* 1338 */     return gettable(this, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue get(int key) {
/* 1350 */     return get(LuaInteger.valueOf(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue get(String key) {
/* 1362 */     return get(valueOf(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void set(LuaValue key, LuaValue value) {
/* 1373 */     settable(this, key, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void set(int key, LuaValue value) {
/* 1384 */     set(LuaInteger.valueOf(key), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void set(int key, String value) {
/* 1395 */     set(key, valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void set(String key, LuaValue value) {
/* 1406 */     set(valueOf(key), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void set(String key, double value) {
/* 1417 */     set(valueOf(key), valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void set(String key, int value) {
/* 1428 */     set(valueOf(key), valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void set(String key, String value) {
/* 1439 */     set(valueOf(key), valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue rawget(LuaValue key) {
/* 1448 */     return unimplemented("rawget");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue rawget(int key) {
/* 1457 */     return rawget(valueOf(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue rawget(String key) {
/* 1466 */     return rawget(valueOf(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rawset(LuaValue key, LuaValue value) {
/* 1475 */     unimplemented("rawset");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rawset(int key, LuaValue value) {
/* 1484 */     rawset(valueOf(key), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rawset(int key, String value) {
/* 1493 */     rawset(key, valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rawset(String key, LuaValue value) {
/* 1502 */     rawset(valueOf(key), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rawset(String key, double value) {
/* 1511 */     rawset(valueOf(key), valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rawset(String key, int value) {
/* 1520 */     rawset(valueOf(key), valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rawset(String key, String value) {
/* 1529 */     rawset(valueOf(key), valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rawsetlist(int key0, Varargs values) {
/* 1541 */     for (int i = 0, n = values.narg(); i < n; i++) {
/* 1542 */       rawset(key0 + i, values.arg(i + 1));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void presize(int i) {
/* 1553 */     typerror("table");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs next(LuaValue index) {
/* 1587 */     return typerror("table");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs inext(LuaValue index) {
/* 1622 */     return typerror("table");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue load(LuaValue library) {
/* 1633 */     return library.call(EMPTYSTRING, this);
/*      */   }
/*      */   
/*      */   public LuaValue arg(int index) {
/* 1637 */     return (index == 1) ? this : NIL;
/*      */   }
/*      */   public int narg() {
/* 1640 */     return 1;
/*      */   }
/*      */   public LuaValue arg1() {
/* 1643 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue getmetatable() {
/* 1659 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue setmetatable(LuaValue metatable) {
/* 1677 */     return argerror("table");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue call() {
/* 1705 */     return callmt().call(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue call(LuaValue arg) {
/* 1734 */     return callmt().call(this, arg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue call(String arg) {
/* 1745 */     return call(valueOf(arg));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue call(LuaValue arg1, LuaValue arg2) {
/* 1775 */     return callmt().call(this, arg1, arg2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue call(LuaValue arg1, LuaValue arg2, LuaValue arg3) {
/* 1807 */     return callmt().invoke(new LuaValue[] { this, arg1, arg2, arg3 }).arg1();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue method(String name) {
/* 1836 */     return get(name).call(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue method(LuaValue name) {
/* 1864 */     return get(name).call(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue method(String name, LuaValue arg) {
/* 1894 */     return get(name).call(this, arg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue method(LuaValue name, LuaValue arg) {
/* 1924 */     return get(name).call(this, arg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue method(String name, LuaValue arg1, LuaValue arg2) {
/* 1955 */     return get(name).call(this, arg1, arg2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue method(LuaValue name, LuaValue arg1, LuaValue arg2) {
/* 1987 */     return get(name).call(this, arg1, arg2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs invoke() {
/* 2011 */     return invoke(NONE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs invoke(Varargs args) {
/* 2038 */     return callmt().invoke(this, args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs invoke(LuaValue arg, Varargs varargs) {
/* 2065 */     return invoke(varargsOf(arg, varargs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs invoke(LuaValue arg1, LuaValue arg2, Varargs varargs) {
/* 2094 */     return invoke(varargsOf(arg1, arg2, varargs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs invoke(LuaValue[] args) {
/* 2120 */     return invoke(varargsOf(args));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs invoke(LuaValue[] args, Varargs varargs) {
/* 2149 */     return invoke(varargsOf(args, varargs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs invokemethod(String name) {
/* 2179 */     return get(name).invoke(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs invokemethod(LuaValue name) {
/* 2209 */     return get(name).invoke(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs invokemethod(String name, Varargs args) {
/* 2242 */     return get(name).invoke(varargsOf(this, args));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs invokemethod(LuaValue name, Varargs args) {
/* 2275 */     return get(name).invoke(varargsOf(this, args));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs invokemethod(String name, LuaValue[] args) {
/* 2310 */     return get(name).invoke(varargsOf(this, varargsOf(args)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs invokemethod(LuaValue name, LuaValue[] args) {
/* 2346 */     return get(name).invoke(varargsOf(this, varargsOf(args)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LuaValue callmt() {
/* 2356 */     return checkmetatag(CALL, "attempt to call ");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue not() {
/* 2366 */     return FALSE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue neg() {
/* 2378 */     return checkmetatag(UNM, "attempt to perform arithmetic on ").call(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue len() {
/* 2389 */     return checkmetatag(LEN, "attempt to get length of ").call(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int length() {
/* 2400 */     return len().toint();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int rawlen() {
/* 2408 */     typerror("table or string"); return 0;
/*      */   }
/*      */   
/*      */   public boolean equals(Object obj) {
/* 2412 */     return (this == obj);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue eq(LuaValue val) {
/* 2428 */     return eq_b(val) ? TRUE : FALSE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eq_b(LuaValue val) {
/* 2444 */     return (this == val);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue neq(LuaValue val) {
/* 2460 */     return eq_b(val) ? FALSE : TRUE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean neq_b(LuaValue val) {
/* 2475 */     return !eq_b(val);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean raweq(LuaValue val) {
/* 2490 */     return (this == val);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean raweq(LuaUserdata val) {
/* 2503 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean raweq(LuaString val) {
/* 2513 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean raweq(double val) {
/* 2523 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean raweq(int val) {
/* 2533 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean eqmtcall(LuaValue lhs, LuaValue lhsmt, LuaValue rhs, LuaValue rhsmt) {
/* 2551 */     LuaValue h = lhsmt.rawget(EQ);
/* 2552 */     return (h.isnil() || h != rhsmt.rawget(EQ)) ? false : h.call(lhs, rhs).toboolean();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue add(LuaValue rhs) {
/* 2570 */     return arithmt(ADD, rhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue add(double rhs) {
/* 2585 */     return arithmtwith(ADD, rhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue add(int rhs) {
/* 2600 */     return add(rhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue sub(LuaValue rhs) {
/* 2617 */     return arithmt(SUB, rhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue sub(double rhs) {
/* 2632 */     return aritherror("sub");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue sub(int rhs) {
/* 2647 */     return aritherror("sub");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue subFrom(double lhs) {
/* 2664 */     return arithmtwith(SUB, lhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue subFrom(int lhs) {
/* 2683 */     return subFrom(lhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue mul(LuaValue rhs) {
/* 2700 */     return arithmt(MUL, rhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue mul(double rhs) {
/* 2715 */     return arithmtwith(MUL, rhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue mul(int rhs) {
/* 2730 */     return mul(rhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue pow(LuaValue rhs) {
/* 2746 */     return arithmt(POW, rhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue pow(double rhs) {
/* 2761 */     return aritherror("pow");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue pow(int rhs) {
/* 2776 */     return aritherror("pow");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue powWith(double lhs) {
/* 2793 */     return arithmtwith(POW, lhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue powWith(int lhs) {
/* 2810 */     return powWith(lhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue div(LuaValue rhs) {
/* 2827 */     return arithmt(DIV, rhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue div(double rhs) {
/* 2844 */     return aritherror("div");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue div(int rhs) {
/* 2861 */     return aritherror("div");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue divInto(double lhs) {
/* 2878 */     return arithmtwith(DIV, lhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue mod(LuaValue rhs) {
/* 2895 */     return arithmt(MOD, rhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue mod(double rhs) {
/* 2912 */     return aritherror("mod");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue mod(int rhs) {
/* 2929 */     return aritherror("mod");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue modFrom(double lhs) {
/* 2946 */     return arithmtwith(MOD, lhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LuaValue arithmt(LuaValue tag, LuaValue op2) {
/* 2972 */     LuaValue h = metatag(tag);
/* 2973 */     if (h.isnil()) {
/* 2974 */       h = op2.metatag(tag);
/* 2975 */       if (h.isnil())
/* 2976 */         error("attempt to perform arithmetic " + tag + " on " + typename() + " and " + op2.typename()); 
/*      */     } 
/* 2978 */     return h.call(this, op2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LuaValue arithmtwith(LuaValue tag, double op1) {
/* 3006 */     LuaValue h = metatag(tag);
/* 3007 */     if (h.isnil())
/* 3008 */       error("attempt to perform arithmetic " + tag + " on number and " + typename()); 
/* 3009 */     return h.call(valueOf(op1), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue lt(LuaValue rhs) {
/* 3028 */     return comparemt(LT, rhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue lt(double rhs) {
/* 3044 */     return compareerror("number");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue lt(int rhs) {
/* 3060 */     return compareerror("number");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lt_b(LuaValue rhs) {
/* 3077 */     return comparemt(LT, rhs).toboolean();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lt_b(int rhs) {
/* 3093 */     compareerror("number"); return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lt_b(double rhs) {
/* 3110 */     compareerror("number"); return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue lteq(LuaValue rhs) {
/* 3128 */     return comparemt(LE, rhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue lteq(double rhs) {
/* 3145 */     return compareerror("number");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue lteq(int rhs) {
/* 3161 */     return compareerror("number");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteq_b(LuaValue rhs) {
/* 3179 */     return comparemt(LE, rhs).toboolean();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteq_b(int rhs) {
/* 3195 */     compareerror("number"); return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteq_b(double rhs) {
/* 3211 */     compareerror("number"); return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue gt(LuaValue rhs) {
/* 3229 */     return rhs.comparemt(LE, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue gt(double rhs) {
/* 3245 */     return compareerror("number");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue gt(int rhs) {
/* 3261 */     return compareerror("number");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gt_b(LuaValue rhs) {
/* 3278 */     return rhs.comparemt(LE, this).toboolean();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gt_b(int rhs) {
/* 3294 */     compareerror("number"); return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gt_b(double rhs) {
/* 3311 */     compareerror("number"); return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue gteq(LuaValue rhs) {
/* 3329 */     return rhs.comparemt(LT, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue gteq(double rhs) {
/* 3346 */     return compareerror("number");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue gteq(int rhs) {
/* 3362 */     return valueOf((todouble() >= rhs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteq_b(LuaValue rhs) {
/* 3380 */     return rhs.comparemt(LT, this).toboolean();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteq_b(int rhs) {
/* 3396 */     compareerror("number"); return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteq_b(double rhs) {
/* 3412 */     compareerror("number"); return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue comparemt(LuaValue tag, LuaValue op1) {
/*      */     LuaValue h;
/* 3433 */     if (!(h = metatag(tag)).isnil() || !(h = op1.metatag(tag)).isnil())
/* 3434 */       return h.call(this, op1); 
/* 3435 */     if (LE.raweq(tag) && (!(h = metatag(LT)).isnil() || !(h = op1.metatag(LT)).isnil()))
/* 3436 */       return h.call(op1, this).not(); 
/* 3437 */     return error("bad argument: attempt to compare " + tag + " on " + typename() + " and " + op1.typename());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int strcmp(LuaValue rhs) {
/* 3452 */     error("attempt to compare " + typename()); return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int strcmp(LuaString rhs) {
/* 3466 */     error("attempt to compare " + typename()); return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue concat(LuaValue rhs) {
/* 3481 */     return concatmt(rhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue concatTo(LuaValue lhs) {
/* 3498 */     return lhs.concatmt(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue concatTo(LuaNumber lhs) {
/* 3515 */     return lhs.concatmt(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue concatTo(LuaString lhs) {
/* 3532 */     return lhs.concatmt(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Buffer buffer() {
/* 3540 */     return new Buffer(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Buffer concat(Buffer rhs) {
/* 3555 */     return rhs.concatTo(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue concatmt(LuaValue rhs) {
/* 3569 */     LuaValue h = metatag(CONCAT);
/* 3570 */     if (h.isnil() && (h = rhs.metatag(CONCAT)).isnil())
/* 3571 */       error("attempt to concatenate " + typename() + " and " + rhs.typename()); 
/* 3572 */     return h.call(this, rhs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue and(LuaValue rhs) {
/* 3584 */     return toboolean() ? rhs : this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue or(LuaValue rhs) {
/* 3595 */     return toboolean() ? this : rhs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean testfor_b(LuaValue limit, LuaValue step) {
/* 3606 */     return step.gt_b(0) ? lteq_b(limit) : gteq_b(limit);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaString strvalue() {
/* 3616 */     typerror("string or number"); return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue strongvalue() {
/* 3626 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaBoolean valueOf(boolean b) {
/* 3634 */     return b ? TRUE : FALSE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaInteger valueOf(int i) {
/* 3642 */     return LuaInteger.valueOf(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaNumber valueOf(double d) {
/* 3651 */     return LuaDouble.valueOf(d);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaString valueOf(String s) {
/* 3659 */     return LuaString.valueOf(s);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaString valueOf(byte[] bytes) {
/* 3668 */     return LuaString.valueOf(bytes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaString valueOf(byte[] bytes, int off, int len) {
/* 3680 */     return LuaString.valueOf(bytes, off, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaTable tableOf() {
/* 3688 */     return new LuaTable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaTable tableOf(Varargs varargs, int firstarg) {
/* 3700 */     return new LuaTable(varargs, firstarg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaTable tableOf(int narray, int nhash) {
/* 3711 */     return new LuaTable(narray, nhash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaTable listOf(LuaValue[] unnamedValues) {
/* 3721 */     return new LuaTable(null, unnamedValues, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaTable listOf(LuaValue[] unnamedValues, Varargs lastarg) {
/* 3735 */     return new LuaTable(null, unnamedValues, lastarg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaTable tableOf(LuaValue[] namedValues) {
/* 3747 */     return new LuaTable(namedValues, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaTable tableOf(LuaValue[] namedValues, LuaValue[] unnamedValues) {
/* 3766 */     return new LuaTable(namedValues, unnamedValues, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaTable tableOf(LuaValue[] namedValues, LuaValue[] unnamedValues, Varargs lastarg) {
/* 3790 */     return new LuaTable(namedValues, unnamedValues, lastarg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaUserdata userdataOf(Object o) {
/* 3799 */     return new LuaUserdata(o);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaUserdata userdataOf(Object o, LuaValue metatable) {
/* 3808 */     return new LuaUserdata(o, metatable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static LuaValue gettable(LuaValue t, LuaValue key) {
/* 3830 */     int loop = 0; while (true) {
/*      */       LuaValue tm;
/* 3832 */       if (t.istable()) {
/* 3833 */         LuaValue res = t.rawget(key);
/* 3834 */         if (!res.isnil() || (tm = t.metatag(INDEX)).isnil())
/* 3835 */           return res; 
/* 3836 */       } else if ((tm = t.metatag(INDEX)).isnil()) {
/* 3837 */         t.indexerror(key.tojstring());
/* 3838 */       }  if (tm.isfunction())
/* 3839 */         return tm.call(t, key); 
/* 3840 */       t = tm;
/* 3841 */       if (++loop >= 100) {
/* 3842 */         error("loop in gettable");
/* 3843 */         return NIL;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static boolean settable(LuaValue t, LuaValue key, LuaValue value) {
/* 3860 */     int loop = 0; while (true) {
/*      */       LuaValue tm;
/* 3862 */       if (t.istable()) {
/* 3863 */         if (!t.rawget(key).isnil() || (tm = t.metatag(NEWINDEX)).isnil()) {
/* 3864 */           t.rawset(key, value);
/* 3865 */           return true;
/*      */         } 
/* 3867 */       } else if ((tm = t.metatag(NEWINDEX)).isnil()) {
/* 3868 */         throw new LuaError("table expected for set index ('" + key + "') value, got " + t.typename());
/* 3869 */       }  if (tm.isfunction()) {
/* 3870 */         tm.call(t, key, value);
/* 3871 */         return true;
/*      */       } 
/* 3873 */       t = tm;
/* 3874 */       if (++loop >= 100) {
/* 3875 */         error("loop in settable");
/* 3876 */         return false;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue metatag(LuaValue tag) {
/* 3888 */     LuaValue mt = getmetatable();
/* 3889 */     if (mt == null)
/* 3890 */       return NIL; 
/* 3891 */     return mt.rawget(tag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LuaValue checkmetatag(LuaValue tag, String reason) {
/* 3904 */     LuaValue h = metatag(tag);
/* 3905 */     if (h.isnil())
/* 3906 */       throw new LuaError(reason + "a " + typename() + " value"); 
/* 3907 */     return h;
/*      */   }
/*      */ 
/*      */   
/*      */   protected static Metatable metatableOf(LuaValue mt) {
/* 3912 */     if (mt != null && mt.istable()) {
/* 3913 */       LuaValue mode = mt.rawget(MODE);
/* 3914 */       if (mode.isstring()) {
/* 3915 */         String m = mode.tojstring();
/* 3916 */         boolean weakkeys = (m.indexOf('k') >= 0);
/* 3917 */         boolean weakvalues = (m.indexOf('v') >= 0);
/* 3918 */         if (weakkeys || weakvalues) {
/* 3919 */           return new WeakTable(weakkeys, weakvalues, mt);
/*      */         }
/*      */       } 
/* 3922 */       return (LuaTable)mt;
/* 3923 */     }  if (mt != null) {
/* 3924 */       return new NonTableMetatable(mt);
/*      */     }
/* 3926 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void indexerror(String key) {
/* 3936 */     error("attempt to index ? (a " + typename() + " value) with key '" + key + "'");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Varargs varargsOf(LuaValue[] v) {
/* 3948 */     switch (v.length) {
/*      */       case 0:
/* 3950 */         return NONE;
/*      */       case 1:
/* 3952 */         return v[0];
/*      */       case 2:
/* 3954 */         return new Varargs.PairVarargs(v[0], v[1]);
/*      */     } 
/* 3956 */     return new Varargs.ArrayVarargs(v, NONE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Varargs varargsOf(LuaValue[] v, Varargs r) {
/* 3970 */     switch (v.length) {
/*      */       case 0:
/* 3972 */         return r;
/*      */       case 1:
/* 3974 */         return (r.narg() > 0) ? new Varargs.PairVarargs(v[0], r) : v[0];
/*      */       case 2:
/* 3976 */         return (r.narg() > 0) ? new Varargs.ArrayVarargs(v, r) : new Varargs.PairVarargs(v[0], v[1]);
/*      */     } 
/*      */     
/* 3979 */     return new Varargs.ArrayVarargs(v, r);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Varargs varargsOf(LuaValue[] v, int offset, int length) {
/* 3994 */     switch (length) {
/*      */       case 0:
/* 3996 */         return NONE;
/*      */       case 1:
/* 3998 */         return v[offset];
/*      */       case 2:
/* 4000 */         return new Varargs.PairVarargs(v[offset + 0], v[offset + 1]);
/*      */     } 
/* 4002 */     return new Varargs.ArrayPartVarargs(v, offset, length, NONE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Varargs varargsOf(LuaValue[] v, int offset, int length, Varargs more) {
/* 4021 */     switch (length) {
/*      */       case 0:
/* 4023 */         return more;
/*      */       case 1:
/* 4025 */         return (more.narg() > 0) ? new Varargs.PairVarargs(v[offset], more) : v[offset];
/*      */       case 2:
/* 4027 */         return (more.narg() > 0) ? new Varargs.ArrayPartVarargs(v, offset, length, more) : new Varargs.PairVarargs(v[offset], v[offset + 1]);
/*      */     } 
/*      */     
/* 4030 */     return new Varargs.ArrayPartVarargs(v, offset, length, more);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Varargs varargsOf(LuaValue v, Varargs r) {
/* 4046 */     switch (r.narg()) {
/*      */       case 0:
/* 4048 */         return v;
/*      */     } 
/* 4050 */     return new Varargs.PairVarargs(v, r);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Varargs varargsOf(LuaValue v1, LuaValue v2, Varargs v3) {
/* 4067 */     switch (v3.narg()) {
/*      */       case 0:
/* 4069 */         return new Varargs.PairVarargs(v1, v2);
/*      */     } 
/* 4071 */     return new Varargs.ArrayPartVarargs(new LuaValue[] { v1, v2 }, 0, 2, v3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Varargs tailcallOf(LuaValue func, Varargs args) {
/* 4093 */     return new TailcallVarargs(func, args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs onInvoke(Varargs args) {
/* 4112 */     return invoke(args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initupvalue1(LuaValue env) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class None
/*      */     extends LuaNil
/*      */   {
/* 4134 */     static None _NONE = new None();
/*      */     
/*      */     public LuaValue arg(int i) {
/* 4137 */       return NIL;
/*      */     }
/*      */     public int narg() {
/* 4140 */       return 0;
/*      */     }
/*      */     public LuaValue arg1() {
/* 4143 */       return NIL;
/*      */     }
/*      */     public String tojstring() {
/* 4146 */       return "none";
/*      */     }
/*      */     public Varargs subargs(int start) {
/* 4149 */       return (start > 0) ? this : argerror(1, "start must be > 0");
/*      */     }
/*      */     
/*      */     void copyto(LuaValue[] dest, int offset, int length) {
/* 4153 */       for (; length > 0; length--) {
/* 4154 */         dest[offset++] = NIL;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs subargs(int start) {
/* 4169 */     if (start == 1)
/* 4170 */       return this; 
/* 4171 */     if (start > 1)
/* 4172 */       return NONE; 
/* 4173 */     return argerror(1, "start must be > 0");
/*      */   }
/*      */   
/*      */   public abstract int type();
/*      */   
/*      */   public abstract String typename();
/*      */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-core-3.0.3.jar!\org\luaj\vm2\LuaValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */