/*      */ package org.luaj.vm2.lib;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import org.luaj.vm2.Buffer;
/*      */ import org.luaj.vm2.LuaClosure;
/*      */ import org.luaj.vm2.LuaFunction;
/*      */ import org.luaj.vm2.LuaString;
/*      */ import org.luaj.vm2.LuaTable;
/*      */ import org.luaj.vm2.LuaValue;
/*      */ import org.luaj.vm2.Varargs;
/*      */ import org.luaj.vm2.compiler.DumpState;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StringLib
/*      */   extends TwoArgFunction
/*      */ {
/*      */   private static final String FLAGS = "-+ #0";
/*      */   private static final int L_ESC = 37;
/*      */   
/*      */   public LuaValue call(LuaValue modname, LuaValue env) {
/*  103 */     LuaTable string = new LuaTable();
/*  104 */     string.set("byte", (LuaValue)new _byte());
/*  105 */     string.set("char", (LuaValue)new _char());
/*  106 */     string.set("dump", (LuaValue)new dump());
/*  107 */     string.set("find", (LuaValue)new find());
/*  108 */     string.set("format", (LuaValue)new format());
/*  109 */     string.set("gmatch", (LuaValue)new gmatch());
/*  110 */     string.set("gsub", (LuaValue)new gsub());
/*  111 */     string.set("len", (LuaValue)new len());
/*  112 */     string.set("lower", (LuaValue)new lower());
/*  113 */     string.set("match", (LuaValue)new match());
/*  114 */     string.set("rep", (LuaValue)new rep());
/*  115 */     string.set("reverse", (LuaValue)new reverse());
/*  116 */     string.set("sub", (LuaValue)new sub());
/*  117 */     string.set("upper", (LuaValue)new upper());
/*      */     
/*  119 */     env.set("string", (LuaValue)string);
/*  120 */     if (!env.get("package").isnil())
/*  121 */       env.get("package").get("loaded").set("string", (LuaValue)string); 
/*  122 */     if (LuaString.s_metatable == null) {
/*  123 */       LuaString.s_metatable = (LuaValue)LuaValue.tableOf(new LuaValue[] { (LuaValue)INDEX, (LuaValue)string });
/*      */     }
/*  125 */     return (LuaValue)string;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class _byte
/*      */     extends VarArgFunction
/*      */   {
/*      */     public Varargs invoke(Varargs args) {
/*  141 */       LuaString s = args.checkstring(1);
/*  142 */       int l = s.m_length;
/*  143 */       int posi = StringLib.posrelat(args.optint(2, 1), l);
/*  144 */       int pose = StringLib.posrelat(args.optint(3, posi), l);
/*      */       
/*  146 */       if (posi <= 0)
/*  147 */         posi = 1; 
/*  148 */       if (pose > l)
/*  149 */         pose = l; 
/*  150 */       if (posi > pose)
/*  151 */         return (Varargs)NONE; 
/*  152 */       int n = pose - posi + 1;
/*  153 */       if (posi + n <= pose)
/*  154 */         error("string slice too long"); 
/*  155 */       LuaValue[] v = new LuaValue[n];
/*  156 */       for (int i = 0; i < n; i++)
/*  157 */         v[i] = (LuaValue)valueOf(s.luaByte(posi + i - 1)); 
/*  158 */       return varargsOf(v);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class _char
/*      */     extends VarArgFunction
/*      */   {
/*      */     public Varargs invoke(Varargs args) {
/*  176 */       int n = args.narg();
/*  177 */       byte[] bytes = new byte[n];
/*  178 */       for (int i = 0, a = 1; i < n; i++, a++) {
/*  179 */         int c = args.checkint(a);
/*  180 */         if (c < 0 || c >= 256)
/*  181 */           argerror(a, "invalid value for string.char [0; 255]: " + c); 
/*  182 */         bytes[i] = (byte)c;
/*      */       } 
/*  184 */       return (Varargs)LuaString.valueUsing(bytes);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class dump
/*      */     extends VarArgFunction
/*      */   {
/*      */     public Varargs invoke(Varargs args) {
/*  202 */       LuaFunction luaFunction = args.checkfunction(1);
/*  203 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*      */       try {
/*  205 */         DumpState.dump(((LuaClosure)luaFunction).p, baos, args.optboolean(2, true));
/*  206 */         return (Varargs)LuaString.valueUsing(baos.toByteArray());
/*  207 */       } catch (IOException e) {
/*  208 */         return (Varargs)error(e.getMessage());
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class find
/*      */     extends VarArgFunction
/*      */   {
/*      */     public Varargs invoke(Varargs args) {
/*  231 */       return StringLib.str_find_aux(args, true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final class format
/*      */     extends VarArgFunction
/*      */   {
/*      */     public Varargs invoke(Varargs args) {
/*  260 */       LuaString fmt = args.checkstring(1);
/*  261 */       int n = fmt.length();
/*  262 */       Buffer result = new Buffer(n);
/*  263 */       int arg = 1;
/*      */ 
/*      */       
/*  266 */       for (int i = 0; i < n;) {
/*  267 */         switch (c = fmt.luaByte(i++)) {
/*      */           case 10:
/*  269 */             result.append("\n");
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 37:
/*  275 */             if (i < n) {
/*  276 */               LuaString s; if ((c = fmt.luaByte(i)) == 37) {
/*  277 */                 i++;
/*  278 */                 result.append((byte)37); break;
/*      */               } 
/*  280 */               arg++;
/*  281 */               StringLib.FormatDesc fdsc = new StringLib.FormatDesc(args, fmt, i);
/*  282 */               i += fdsc.length;
/*  283 */               switch (fdsc.conversion) {
/*      */                 case 99:
/*  285 */                   fdsc.format(result, (byte)args.checkint(arg));
/*      */                   break;
/*      */                 case 100:
/*      */                 case 105:
/*  289 */                   fdsc.format(result, args.checklong(arg));
/*      */                   break;
/*      */                 case 88:
/*      */                 case 111:
/*      */                 case 117:
/*      */                 case 120:
/*  295 */                   fdsc.format(result, args.checklong(arg));
/*      */                   break;
/*      */                 case 69:
/*      */                 case 71:
/*      */                 case 101:
/*      */                 case 102:
/*      */                 case 103:
/*  302 */                   fdsc.format(result, args.checkdouble(arg));
/*      */                   break;
/*      */                 case 113:
/*  305 */                   StringLib.addquoted(result, args.checkstring(arg));
/*      */                   break;
/*      */                 case 115:
/*  308 */                   s = args.checkstring(arg);
/*  309 */                   if (fdsc.precision == -1 && s.length() >= 100) {
/*  310 */                     result.append(s); break;
/*      */                   } 
/*  312 */                   fdsc.format(result, s);
/*      */                   break;
/*      */               } 
/*      */ 
/*      */               
/*  317 */               error("invalid option '%" + (char)fdsc.conversion + "' to 'format'");
/*      */             } 
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       } 
/*  325 */       return (Varargs)result.tostring();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static void addquoted(Buffer buf, LuaString s) {
/*  331 */     buf.append((byte)34);
/*  332 */     for (int i = 0, n = s.length(); i < n; i++) {
/*  333 */       int c; switch (c = s.luaByte(i)) {
/*      */         case 10:
/*      */         case 34:
/*      */         case 92:
/*  337 */           buf.append((byte)92);
/*  338 */           buf.append((byte)c);
/*      */           break;
/*      */         default:
/*  341 */           if (c <= 31 || c == 127) {
/*  342 */             buf.append((byte)92);
/*  343 */             if (i + 1 == n || s.luaByte(i + 1) < 48 || s.luaByte(i + 1) > 57) {
/*  344 */               buf.append(Integer.toString(c)); break;
/*      */             } 
/*  346 */             buf.append((byte)48);
/*  347 */             buf.append((byte)(char)(48 + c / 10));
/*  348 */             buf.append((byte)(char)(48 + c % 10));
/*      */             break;
/*      */           } 
/*  351 */           buf.append((byte)c);
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/*  356 */     buf.append((byte)34);
/*      */   }
/*      */ 
/*      */   
/*      */   class FormatDesc
/*      */   {
/*      */     private boolean leftAdjust;
/*      */     
/*      */     private boolean zeroPad;
/*      */     
/*      */     private boolean explicitPlus;
/*      */     
/*      */     private boolean space;
/*      */     
/*      */     private boolean alternateForm;
/*      */     private static final int MAX_FLAGS = 5;
/*      */     private int width;
/*      */     int precision;
/*      */     public final int conversion;
/*      */     public final int length;
/*      */     public final String src;
/*      */     
/*      */     public FormatDesc(Varargs args, LuaString strfrmt, int start) {
/*  379 */       int p = start, n = strfrmt.length();
/*  380 */       int c = 0;
/*      */       
/*  382 */       boolean moreFlags = true;
/*  383 */       while (moreFlags) {
/*  384 */         switch (c = (p < n) ? strfrmt.luaByte(p++) : 0) {
/*      */           case 45:
/*  386 */             this.leftAdjust = true;
/*      */             continue;
/*      */           case 43:
/*  389 */             this.explicitPlus = true;
/*      */             continue;
/*      */           case 32:
/*  392 */             this.space = true;
/*      */             continue;
/*      */           case 35:
/*  395 */             this.alternateForm = true;
/*      */             continue;
/*      */           case 48:
/*  398 */             this.zeroPad = true;
/*      */             continue;
/*      */         } 
/*  401 */         moreFlags = false;
/*      */       } 
/*      */ 
/*      */       
/*  405 */       if (p - start > 5) {
/*  406 */         LuaValue.error("invalid format (repeated flags)");
/*      */       }
/*  408 */       this.width = -1;
/*  409 */       if (Character.isDigit((char)c)) {
/*  410 */         this.width = c - 48;
/*  411 */         c = (p < n) ? strfrmt.luaByte(p++) : 0;
/*  412 */         if (Character.isDigit((char)c)) {
/*  413 */           this.width = this.width * 10 + c - 48;
/*  414 */           c = (p < n) ? strfrmt.luaByte(p++) : 0;
/*      */         } 
/*      */       } 
/*      */       
/*  418 */       this.precision = -1;
/*  419 */       if (c == 46) {
/*  420 */         c = (p < n) ? strfrmt.luaByte(p++) : 0;
/*  421 */         if (Character.isDigit((char)c)) {
/*  422 */           this.precision = c - 48;
/*  423 */           c = (p < n) ? strfrmt.luaByte(p++) : 0;
/*  424 */           if (Character.isDigit((char)c)) {
/*  425 */             this.precision = this.precision * 10 + c - 48;
/*  426 */             c = (p < n) ? strfrmt.luaByte(p++) : 0;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  431 */       if (Character.isDigit((char)c)) {
/*  432 */         LuaValue.error("invalid format (width or precision too long)");
/*      */       }
/*  434 */       this.zeroPad &= !this.leftAdjust ? 1 : 0;
/*  435 */       this.conversion = c;
/*  436 */       this.length = p - start;
/*  437 */       this.src = strfrmt.substring(start - 1, p).tojstring();
/*      */     }
/*      */ 
/*      */     
/*      */     public void format(Buffer buf, byte c) {
/*  442 */       buf.append(c);
/*      */     }
/*      */     
/*      */     public void format(Buffer buf, long number) {
/*      */       String digits;
/*      */       int nzeros;
/*  448 */       if (number == 0L && this.precision == 0) {
/*  449 */         digits = "";
/*      */       } else {
/*      */         int radix;
/*  452 */         switch (this.conversion) {
/*      */           case 88:
/*      */           case 120:
/*  455 */             radix = 16;
/*      */             break;
/*      */           case 111:
/*  458 */             radix = 8;
/*      */             break;
/*      */           default:
/*  461 */             radix = 10;
/*      */             break;
/*      */         } 
/*  464 */         digits = Long.toString(number, radix);
/*  465 */         if (this.conversion == 88) {
/*  466 */           digits = digits.toUpperCase();
/*      */         }
/*      */       } 
/*  469 */       int minwidth = digits.length();
/*  470 */       int ndigits = minwidth;
/*      */ 
/*      */       
/*  473 */       if (number < 0L) {
/*  474 */         ndigits--;
/*  475 */       } else if (this.explicitPlus || this.space) {
/*  476 */         minwidth++;
/*      */       } 
/*      */       
/*  479 */       if (this.precision > ndigits) {
/*  480 */         nzeros = this.precision - ndigits;
/*  481 */       } else if (this.precision == -1 && this.zeroPad && this.width > minwidth) {
/*  482 */         nzeros = this.width - minwidth;
/*      */       } else {
/*  484 */         nzeros = 0;
/*      */       } 
/*  486 */       minwidth += nzeros;
/*  487 */       int nspaces = (this.width > minwidth) ? (this.width - minwidth) : 0;
/*      */       
/*  489 */       if (!this.leftAdjust) {
/*  490 */         pad(buf, ' ', nspaces);
/*      */       }
/*  492 */       if (number < 0L) {
/*  493 */         if (nzeros > 0) {
/*  494 */           buf.append((byte)45);
/*  495 */           digits = digits.substring(1);
/*      */         } 
/*  497 */       } else if (this.explicitPlus) {
/*  498 */         buf.append((byte)43);
/*  499 */       } else if (this.space) {
/*  500 */         buf.append((byte)32);
/*      */       } 
/*      */       
/*  503 */       if (nzeros > 0) {
/*  504 */         pad(buf, '0', nzeros);
/*      */       }
/*  506 */       buf.append(digits);
/*      */       
/*  508 */       if (this.leftAdjust)
/*  509 */         pad(buf, ' ', nspaces); 
/*      */     }
/*      */     
/*      */     public void format(Buffer buf, double x) {
/*  513 */       buf.append(StringLib.this.format(this.src, x));
/*      */     }
/*      */     
/*      */     public void format(Buffer buf, LuaString s) {
/*  517 */       int nullindex = s.indexOf((byte)0, 0);
/*  518 */       if (nullindex != -1)
/*  519 */         s = s.substring(0, nullindex); 
/*  520 */       buf.append(s);
/*      */     }
/*      */     
/*      */     public final void pad(Buffer buf, char c, int n) {
/*  524 */       byte b = (byte)c;
/*  525 */       while (n-- > 0)
/*  526 */         buf.append(b); 
/*      */     }
/*      */   }
/*      */   
/*      */   protected String format(String src, double x) {
/*  531 */     return String.valueOf(x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class gmatch
/*      */     extends VarArgFunction
/*      */   {
/*      */     public Varargs invoke(Varargs args) {
/*  555 */       LuaString src = args.checkstring(1);
/*  556 */       LuaString pat = args.checkstring(2);
/*  557 */       return (Varargs)new StringLib.GMatchAux(args, src, pat);
/*      */     }
/*      */   }
/*      */   
/*      */   static class GMatchAux extends VarArgFunction {
/*      */     private final int srclen;
/*      */     private final StringLib.MatchState ms;
/*      */     private int soffset;
/*      */     private int lastmatch;
/*      */     
/*      */     public GMatchAux(Varargs args, LuaString src, LuaString pat) {
/*  568 */       this.srclen = src.length();
/*  569 */       this.ms = new StringLib.MatchState(args, src, pat);
/*  570 */       this.soffset = 0;
/*  571 */       this.lastmatch = -1;
/*      */     }
/*      */ 
/*      */     
/*      */     public Varargs invoke(Varargs args) {
/*  576 */       for (; this.soffset <= this.srclen; this.soffset++) {
/*  577 */         this.ms.reset();
/*  578 */         int res = this.ms.match(this.soffset, 0);
/*  579 */         if (res >= 0 && res != this.lastmatch) {
/*  580 */           int soff = this.soffset;
/*  581 */           this.lastmatch = this.soffset = res;
/*  582 */           return this.ms.push_captures(true, soff, res);
/*      */         } 
/*      */       } 
/*  585 */       return (Varargs)NIL;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class gsub
/*      */     extends VarArgFunction
/*      */   {
/*      */     public Varargs invoke(Varargs args) {
/*  637 */       LuaString src = args.checkstring(1);
/*  638 */       int srclen = src.length();
/*  639 */       LuaString p = args.checkstring(2);
/*  640 */       int lastmatch = -1;
/*  641 */       LuaValue repl = args.arg(3);
/*  642 */       int max_s = args.optint(4, srclen + 1);
/*  643 */       if (max_s < 0)
/*  644 */         max_s = srclen + 1; 
/*  645 */       boolean anchor = (p.length() > 0 && p.charAt(0) == 94);
/*      */       
/*  647 */       Buffer lbuf = new Buffer(srclen);
/*  648 */       StringLib.MatchState ms = new StringLib.MatchState(args, src, p);
/*      */       
/*  650 */       int soffset = 0;
/*  651 */       int n = 0;
/*  652 */       while (n < max_s) {
/*  653 */         ms.reset();
/*  654 */         int res = ms.match(soffset, anchor ? 1 : 0);
/*  655 */         if (res != -1 && res != lastmatch) {
/*  656 */           n++;
/*  657 */           ms.add_value(lbuf, soffset, res, repl);
/*  658 */           soffset = lastmatch = res;
/*  659 */         } else if (soffset < srclen) {
/*  660 */           lbuf.append((byte)src.luaByte(soffset++));
/*      */         } else {
/*      */           break;
/*  663 */         }  if (anchor)
/*      */           break; 
/*      */       } 
/*  666 */       lbuf.append(src.substring(soffset, srclen));
/*  667 */       return varargsOf((LuaValue)lbuf.tostring(), (Varargs)valueOf(n));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class len
/*      */     extends OneArgFunction
/*      */   {
/*      */     public LuaValue call(LuaValue arg) {
/*  680 */       return arg.checkstring().len();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class lower
/*      */     extends OneArgFunction
/*      */   {
/*      */     public LuaValue call(LuaValue arg) {
/*  695 */       return (LuaValue)valueOf(arg.checkjstring().toLowerCase());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class match
/*      */     extends VarArgFunction
/*      */   {
/*      */     public Varargs invoke(Varargs args) {
/*  711 */       return StringLib.str_find_aux(args, false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class rep
/*      */     extends VarArgFunction
/*      */   {
/*      */     public Varargs invoke(Varargs args) {
/*  723 */       LuaString s = args.checkstring(1);
/*  724 */       int n = args.checkint(2);
/*  725 */       byte[] bytes = new byte[s.length() * n];
/*  726 */       int len = s.length(); int offset;
/*  727 */       for (offset = 0; offset < bytes.length; offset += len) {
/*  728 */         s.copyInto(0, bytes, offset, len);
/*      */       }
/*  730 */       return (Varargs)LuaString.valueUsing(bytes);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class reverse
/*      */     extends OneArgFunction
/*      */   {
/*      */     public LuaValue call(LuaValue arg) {
/*  742 */       LuaString s = arg.checkstring();
/*  743 */       int n = s.length();
/*  744 */       byte[] b = new byte[n];
/*  745 */       for (int i = 0, j = n - 1; i < n; i++, j--)
/*  746 */         b[j] = (byte)s.luaByte(i); 
/*  747 */       return (LuaValue)LuaString.valueUsing(b);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class sub
/*      */     extends VarArgFunction
/*      */   {
/*      */     public Varargs invoke(Varargs args) {
/*  763 */       LuaString s = args.checkstring(1);
/*  764 */       int l = s.length();
/*      */       
/*  766 */       int start = StringLib.posrelat(args.checkint(2), l);
/*  767 */       int end = StringLib.posrelat(args.optint(3, -1), l);
/*      */       
/*  769 */       if (start < 1)
/*  770 */         start = 1; 
/*  771 */       if (end > l) {
/*  772 */         end = l;
/*      */       }
/*  774 */       if (start <= end) {
/*  775 */         return (Varargs)s.substring(start - 1, end);
/*      */       }
/*  777 */       return (Varargs)EMPTYSTRING;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class upper
/*      */     extends OneArgFunction
/*      */   {
/*      */     public LuaValue call(LuaValue arg) {
/*  793 */       return (LuaValue)valueOf(arg.checkjstring().toUpperCase());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Varargs str_find_aux(Varargs args, boolean find) {
/*  801 */     LuaString s = args.checkstring(1);
/*  802 */     LuaString pat = args.checkstring(2);
/*  803 */     int init = args.optint(3, 1);
/*      */     
/*  805 */     if (init > 0) {
/*  806 */       init = Math.min(init - 1, s.length());
/*  807 */     } else if (init < 0) {
/*  808 */       init = Math.max(0, s.length() + init);
/*      */     } 
/*      */     
/*  811 */     boolean fastMatch = (find && (args.arg(4).toboolean() || pat.indexOfAny(SPECIALS) == -1));
/*      */     
/*  813 */     if (fastMatch) {
/*  814 */       int result = s.indexOf(pat, init);
/*  815 */       if (result != -1) {
/*  816 */         return varargsOf((LuaValue)valueOf(result + 1), (Varargs)valueOf(result + pat.length()));
/*      */       }
/*      */     } else {
/*  819 */       MatchState ms = new MatchState(args, s, pat);
/*      */       
/*  821 */       boolean anchor = false;
/*  822 */       int poff = 0;
/*  823 */       if (pat.length() > 0 && pat.luaByte(0) == 94) {
/*  824 */         anchor = true;
/*  825 */         poff = 1;
/*      */       } 
/*      */       
/*  828 */       int soff = init;
/*      */       
/*      */       do {
/*  831 */         ms.reset(); int res;
/*  832 */         if ((res = ms.match(soff, poff)) != -1) {
/*  833 */           if (find) {
/*  834 */             return varargsOf((LuaValue)valueOf(soff + 1), (LuaValue)valueOf(res), ms.push_captures(false, soff, res));
/*      */           }
/*  836 */           return ms.push_captures(true, soff, res);
/*      */         }
/*      */       
/*  839 */       } while (soff++ < s.length() && !anchor);
/*      */     } 
/*  841 */     return (Varargs)NIL;
/*      */   }
/*      */   
/*      */   static int posrelat(int pos, int len) {
/*  845 */     return (pos >= 0) ? pos : (len + pos + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  851 */   private static final LuaString SPECIALS = valueOf("^$*+?.([%-");
/*      */   
/*      */   private static final int MAX_CAPTURES = 32;
/*      */   
/*      */   private static final int MAXCCALLS = 200;
/*      */   
/*      */   private static final int CAP_UNFINISHED = -1;
/*      */   
/*      */   private static final int CAP_POSITION = -2;
/*      */   
/*      */   private static final byte MASK_ALPHA = 1;
/*      */   
/*      */   private static final byte MASK_LOWERCASE = 2;
/*      */   
/*      */   private static final byte MASK_UPPERCASE = 4;
/*      */   private static final byte MASK_DIGIT = 8;
/*      */   private static final byte MASK_PUNCT = 16;
/*      */   private static final byte MASK_SPACE = 32;
/*      */   private static final byte MASK_CONTROL = 64;
/*      */   private static final byte MASK_HEXDIGIT = -128;
/*  871 */   static final byte[] CHAR_TABLE = new byte[256];
/*      */   static {
/*  873 */     for (int i = 0; i < 128; i++) {
/*  874 */       char c = (char)i;
/*  875 */       CHAR_TABLE[i] = 
/*  876 */         (byte)((Character.isDigit(c) ? true : false) | (Character.isLowerCase(c) ? true : false) | (Character.isUpperCase(c) ? 4 : 0) | ((c < ' ' || c == '') ? 64 : 0));
/*      */       
/*  878 */       if ((c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F') || (c >= '0' && c <= '9')) {
/*  879 */         CHAR_TABLE[i] = (byte)(CHAR_TABLE[i] | Byte.MIN_VALUE);
/*      */       }
/*  881 */       if ((c >= '!' && c <= '/') || (c >= ':' && c <= '@') || (c >= '[' && c <= '`') || (c >= '{' && c <= '~')) {
/*  882 */         CHAR_TABLE[i] = (byte)(CHAR_TABLE[i] | 0x10);
/*      */       }
/*  884 */       if ((CHAR_TABLE[i] & 0x6) != 0) {
/*  885 */         CHAR_TABLE[i] = (byte)(CHAR_TABLE[i] | 0x1);
/*      */       }
/*      */     } 
/*      */     
/*  889 */     CHAR_TABLE[32] = 32;
/*  890 */     CHAR_TABLE[13] = (byte)(CHAR_TABLE[13] | 0x20);
/*  891 */     CHAR_TABLE[10] = (byte)(CHAR_TABLE[10] | 0x20);
/*  892 */     CHAR_TABLE[9] = (byte)(CHAR_TABLE[9] | 0x20);
/*  893 */     CHAR_TABLE[11] = (byte)(CHAR_TABLE[11] | 0x20);
/*  894 */     CHAR_TABLE[12] = (byte)(CHAR_TABLE[12] | 0x20);
/*      */   }
/*      */   
/*      */   static class MatchState {
/*      */     int matchdepth;
/*      */     final LuaString s;
/*      */     final LuaString p;
/*      */     final Varargs args;
/*      */     int level;
/*      */     int[] cinit;
/*      */     int[] clen;
/*      */     
/*      */     MatchState(Varargs args, LuaString s, LuaString pattern) {
/*  907 */       this.s = s;
/*  908 */       this.p = pattern;
/*  909 */       this.args = args;
/*  910 */       this.level = 0;
/*  911 */       this.cinit = new int[32];
/*  912 */       this.clen = new int[32];
/*  913 */       this.matchdepth = 200;
/*      */     }
/*      */     
/*      */     void reset() {
/*  917 */       this.level = 0;
/*  918 */       this.matchdepth = 200;
/*      */     }
/*      */     
/*      */     private void add_s(Buffer lbuf, LuaString news, int soff, int e) {
/*  922 */       int l = news.length();
/*  923 */       for (int i = 0; i < l; i++) {
/*  924 */         byte b = (byte)news.luaByte(i);
/*  925 */         if (b != 37) {
/*  926 */           lbuf.append(b);
/*      */         } else {
/*  928 */           i++;
/*  929 */           b = (byte)((i < l) ? news.luaByte(i) : 0);
/*  930 */           if (!Character.isDigit((char)b)) {
/*  931 */             if (b != 37) {
/*  932 */               LuaValue.error("invalid use of '%' in replacement string: after '%' must be '0'-'9' or '%', but found " + ((i < l) ? ("symbol '" + (char)b + "' with code " + b + " at pos " + (i + 1)) : "end of string"));
/*      */             }
/*      */ 
/*      */             
/*  936 */             lbuf.append(b);
/*  937 */           } else if (b == 48) {
/*  938 */             lbuf.append(this.s.substring(soff, e));
/*      */           } else {
/*  940 */             lbuf.append(push_onecapture(b - 49, soff, e).strvalue());
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */     public void add_value(Buffer lbuf, int soffset, int end, LuaValue repl) {
/*      */       LuaString luaString;
/*  947 */       switch (repl.type()) {
/*      */         case 3:
/*      */         case 4:
/*  950 */           add_s(lbuf, repl.strvalue(), soffset, end);
/*      */           return;
/*      */         
/*      */         case 6:
/*  954 */           repl = repl.invoke(push_captures(true, soffset, end)).arg1();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 5:
/*  959 */           repl = repl.get(push_onecapture(0, soffset, end));
/*      */           break;
/*      */         
/*      */         default:
/*  963 */           LuaValue.error("bad argument: string/function/table expected");
/*      */           return;
/*      */       } 
/*      */       
/*  967 */       if (!repl.toboolean()) {
/*  968 */         luaString = this.s.substring(soffset, end);
/*  969 */       } else if (!luaString.isstring()) {
/*  970 */         LuaValue.error("invalid replacement value (a " + luaString.typename() + ")");
/*      */       } 
/*  972 */       lbuf.append(luaString.strvalue());
/*      */     }
/*      */     
/*      */     Varargs push_captures(boolean wholeMatch, int soff, int end) {
/*  976 */       int nlevels = (this.level == 0 && wholeMatch) ? 1 : this.level;
/*  977 */       switch (nlevels) {
/*      */         case 0:
/*  979 */           return (Varargs)LuaValue.NONE;
/*      */         case 1:
/*  981 */           return (Varargs)push_onecapture(0, soff, end);
/*      */       } 
/*  983 */       LuaValue[] v = new LuaValue[nlevels];
/*  984 */       for (int i = 0; i < nlevels; i++)
/*  985 */         v[i] = push_onecapture(i, soff, end); 
/*  986 */       return LuaValue.varargsOf(v);
/*      */     }
/*      */     
/*      */     private LuaValue push_onecapture(int i, int soff, int end) {
/*  990 */       if (i >= this.level) {
/*  991 */         if (i == 0) {
/*  992 */           return (LuaValue)this.s.substring(soff, end);
/*      */         }
/*  994 */         return LuaValue.error("invalid capture index %" + (i + 1));
/*      */       } 
/*      */       
/*  997 */       int l = this.clen[i];
/*  998 */       if (l == -1) {
/*  999 */         return LuaValue.error("unfinished capture");
/*      */       }
/* 1001 */       if (l == -2) {
/* 1002 */         return (LuaValue)LuaValue.valueOf(this.cinit[i] + 1);
/*      */       }
/* 1004 */       int begin = this.cinit[i];
/* 1005 */       return (LuaValue)this.s.substring(begin, begin + l);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private int check_capture(int l) {
/* 1011 */       l -= 49;
/* 1012 */       if (l < 0 || l >= this.level || this.clen[l] == -1) {
/* 1013 */         LuaValue.error("invalid capture index %" + (l + 1));
/*      */       }
/* 1015 */       return l;
/*      */     }
/*      */     
/*      */     private int capture_to_close() {
/* 1019 */       int level = this.level;
/* 1020 */       for (; --level >= 0; level--) {
/* 1021 */         if (this.clen[level] == -1)
/* 1022 */           return level; 
/* 1023 */       }  LuaValue.error("invalid pattern capture");
/* 1024 */       return 0;
/*      */     }
/*      */     
/*      */     int classend(int poffset) {
/* 1028 */       switch (this.p.luaByte(poffset++)) {
/*      */         case 37:
/* 1030 */           if (poffset == this.p.length()) {
/* 1031 */             LuaValue.error("malformed pattern (ends with '%')");
/*      */           }
/* 1033 */           return poffset + 1;
/*      */         
/*      */         case 91:
/* 1036 */           if (poffset != this.p.length() && this.p.luaByte(poffset) == 94)
/* 1037 */             poffset++; 
/*      */           while (true) {
/* 1039 */             if (poffset == this.p.length()) {
/* 1040 */               LuaValue.error("malformed pattern (missing ']')");
/*      */             }
/* 1042 */             if (this.p.luaByte(poffset++) == 37 && poffset < this.p.length())
/* 1043 */               poffset++; 
/* 1044 */             if (poffset != this.p.length() && this.p.luaByte(poffset) == 93)
/* 1045 */               return poffset + 1; 
/*      */           } 
/* 1047 */       }  return poffset;
/*      */     }
/*      */     
/*      */     static boolean match_class(int c, int cl) {
/*      */       boolean res;
/* 1052 */       char lcl = Character.toLowerCase((char)cl);
/* 1053 */       int cdata = StringLib.CHAR_TABLE[c];
/*      */ 
/*      */       
/* 1056 */       switch (lcl) {
/*      */         case 'a':
/* 1058 */           res = ((cdata & 0x1) != 0);
/*      */           break;
/*      */         case 'd':
/* 1061 */           res = ((cdata & 0x8) != 0);
/*      */           break;
/*      */         case 'l':
/* 1064 */           res = ((cdata & 0x2) != 0);
/*      */           break;
/*      */         case 'u':
/* 1067 */           res = ((cdata & 0x4) != 0);
/*      */           break;
/*      */         case 'c':
/* 1070 */           res = ((cdata & 0x40) != 0);
/*      */           break;
/*      */         case 'p':
/* 1073 */           res = ((cdata & 0x10) != 0);
/*      */           break;
/*      */         case 's':
/* 1076 */           res = ((cdata & 0x20) != 0);
/*      */           break;
/*      */         case 'g':
/* 1079 */           res = ((cdata & 0x19) != 0);
/*      */           break;
/*      */         case 'w':
/* 1082 */           res = ((cdata & 0x9) != 0);
/*      */           break;
/*      */         case 'x':
/* 1085 */           res = ((cdata & 0xFFFFFF80) != 0);
/*      */           break;
/*      */         case 'z':
/* 1088 */           res = (c == 0);
/*      */           break;
/*      */         default:
/* 1091 */           return (cl == c);
/*      */       } 
/* 1093 */       return (((lcl == cl)) == res);
/*      */     }
/*      */     
/*      */     boolean matchbracketclass(int c, int poff, int ec) {
/* 1097 */       boolean sig = true;
/* 1098 */       if (this.p.luaByte(poff + 1) == 94) {
/* 1099 */         sig = false;
/* 1100 */         poff++;
/*      */       } 
/* 1102 */       while (++poff < ec) {
/* 1103 */         if (this.p.luaByte(poff) == 37) {
/* 1104 */           poff++;
/* 1105 */           if (match_class(c, this.p.luaByte(poff)))
/* 1106 */             return sig;  continue;
/* 1107 */         }  if (this.p.luaByte(poff + 1) == 45 && poff + 2 < ec) {
/* 1108 */           poff += 2;
/* 1109 */           if (this.p.luaByte(poff - 2) <= c && c <= this.p.luaByte(poff))
/* 1110 */             return sig;  continue;
/* 1111 */         }  if (this.p.luaByte(poff) == c)
/* 1112 */           return sig; 
/*      */       } 
/* 1114 */       return !sig;
/*      */     }
/*      */     
/*      */     boolean singlematch(int c, int poff, int ep) {
/* 1118 */       switch (this.p.luaByte(poff)) {
/*      */         case 46:
/* 1120 */           return true;
/*      */         case 37:
/* 1122 */           return match_class(c, this.p.luaByte(poff + 1));
/*      */         case 91:
/* 1124 */           return matchbracketclass(c, poff, ep - 1);
/*      */       } 
/* 1126 */       return (this.p.luaByte(poff) == c);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int match(int soffset, int poffset) {
/*      */       // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: dup
/*      */       //   2: getfield matchdepth : I
/*      */       //   5: dup_x1
/*      */       //   6: iconst_1
/*      */       //   7: isub
/*      */       //   8: putfield matchdepth : I
/*      */       //   11: ifne -> 20
/*      */       //   14: ldc 'pattern too complex'
/*      */       //   16: invokestatic error : (Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
/*      */       //   19: pop
/*      */       //   20: iload_2
/*      */       //   21: aload_0
/*      */       //   22: getfield p : Lorg/luaj/vm2/LuaString;
/*      */       //   25: invokevirtual length : ()I
/*      */       //   28: if_icmpne -> 45
/*      */       //   31: iload_1
/*      */       //   32: istore_3
/*      */       //   33: aload_0
/*      */       //   34: dup
/*      */       //   35: getfield matchdepth : I
/*      */       //   38: iconst_1
/*      */       //   39: iadd
/*      */       //   40: putfield matchdepth : I
/*      */       //   43: iload_3
/*      */       //   44: ireturn
/*      */       //   45: aload_0
/*      */       //   46: getfield p : Lorg/luaj/vm2/LuaString;
/*      */       //   49: iload_2
/*      */       //   50: invokevirtual luaByte : (I)I
/*      */       //   53: tableswitch default -> 517, 36 -> 475, 37 -> 183, 38 -> 517, 39 -> 517, 40 -> 92, 41 -> 162
/*      */       //   92: iinc #2, 1
/*      */       //   95: iload_2
/*      */       //   96: aload_0
/*      */       //   97: getfield p : Lorg/luaj/vm2/LuaString;
/*      */       //   100: invokevirtual length : ()I
/*      */       //   103: if_icmpge -> 142
/*      */       //   106: aload_0
/*      */       //   107: getfield p : Lorg/luaj/vm2/LuaString;
/*      */       //   110: iload_2
/*      */       //   111: invokevirtual luaByte : (I)I
/*      */       //   114: bipush #41
/*      */       //   116: if_icmpne -> 142
/*      */       //   119: aload_0
/*      */       //   120: iload_1
/*      */       //   121: iload_2
/*      */       //   122: iconst_1
/*      */       //   123: iadd
/*      */       //   124: bipush #-2
/*      */       //   126: invokevirtual start_capture : (III)I
/*      */       //   129: istore_3
/*      */       //   130: aload_0
/*      */       //   131: dup
/*      */       //   132: getfield matchdepth : I
/*      */       //   135: iconst_1
/*      */       //   136: iadd
/*      */       //   137: putfield matchdepth : I
/*      */       //   140: iload_3
/*      */       //   141: ireturn
/*      */       //   142: aload_0
/*      */       //   143: iload_1
/*      */       //   144: iload_2
/*      */       //   145: iconst_m1
/*      */       //   146: invokevirtual start_capture : (III)I
/*      */       //   149: istore_3
/*      */       //   150: aload_0
/*      */       //   151: dup
/*      */       //   152: getfield matchdepth : I
/*      */       //   155: iconst_1
/*      */       //   156: iadd
/*      */       //   157: putfield matchdepth : I
/*      */       //   160: iload_3
/*      */       //   161: ireturn
/*      */       //   162: aload_0
/*      */       //   163: iload_1
/*      */       //   164: iload_2
/*      */       //   165: iconst_1
/*      */       //   166: iadd
/*      */       //   167: invokevirtual end_capture : (II)I
/*      */       //   170: istore_3
/*      */       //   171: aload_0
/*      */       //   172: dup
/*      */       //   173: getfield matchdepth : I
/*      */       //   176: iconst_1
/*      */       //   177: iadd
/*      */       //   178: putfield matchdepth : I
/*      */       //   181: iload_3
/*      */       //   182: ireturn
/*      */       //   183: iload_2
/*      */       //   184: iconst_1
/*      */       //   185: iadd
/*      */       //   186: aload_0
/*      */       //   187: getfield p : Lorg/luaj/vm2/LuaString;
/*      */       //   190: invokevirtual length : ()I
/*      */       //   193: if_icmpne -> 202
/*      */       //   196: ldc 'malformed pattern (ends with '%')'
/*      */       //   198: invokestatic error : (Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
/*      */       //   201: pop
/*      */       //   202: aload_0
/*      */       //   203: getfield p : Lorg/luaj/vm2/LuaString;
/*      */       //   206: iload_2
/*      */       //   207: iconst_1
/*      */       //   208: iadd
/*      */       //   209: invokevirtual luaByte : (I)I
/*      */       //   212: lookupswitch default -> 405, 98 -> 240, 102 -> 274
/*      */       //   240: aload_0
/*      */       //   241: iload_1
/*      */       //   242: iload_2
/*      */       //   243: iconst_2
/*      */       //   244: iadd
/*      */       //   245: invokevirtual matchbalance : (II)I
/*      */       //   248: istore_1
/*      */       //   249: iload_1
/*      */       //   250: iconst_m1
/*      */       //   251: if_icmpne -> 268
/*      */       //   254: iconst_m1
/*      */       //   255: istore_3
/*      */       //   256: aload_0
/*      */       //   257: dup
/*      */       //   258: getfield matchdepth : I
/*      */       //   261: iconst_1
/*      */       //   262: iadd
/*      */       //   263: putfield matchdepth : I
/*      */       //   266: iload_3
/*      */       //   267: ireturn
/*      */       //   268: iinc #2, 4
/*      */       //   271: goto -> 20
/*      */       //   274: iinc #2, 2
/*      */       //   277: iload_2
/*      */       //   278: aload_0
/*      */       //   279: getfield p : Lorg/luaj/vm2/LuaString;
/*      */       //   282: invokevirtual length : ()I
/*      */       //   285: if_icmpeq -> 301
/*      */       //   288: aload_0
/*      */       //   289: getfield p : Lorg/luaj/vm2/LuaString;
/*      */       //   292: iload_2
/*      */       //   293: invokevirtual luaByte : (I)I
/*      */       //   296: bipush #91
/*      */       //   298: if_icmpeq -> 307
/*      */       //   301: ldc 'missing '[' after '%f' in pattern'
/*      */       //   303: invokestatic error : (Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
/*      */       //   306: pop
/*      */       //   307: aload_0
/*      */       //   308: iload_2
/*      */       //   309: invokevirtual classend : (I)I
/*      */       //   312: istore_3
/*      */       //   313: iload_1
/*      */       //   314: ifne -> 321
/*      */       //   317: iconst_0
/*      */       //   318: goto -> 331
/*      */       //   321: aload_0
/*      */       //   322: getfield s : Lorg/luaj/vm2/LuaString;
/*      */       //   325: iload_1
/*      */       //   326: iconst_1
/*      */       //   327: isub
/*      */       //   328: invokevirtual luaByte : (I)I
/*      */       //   331: istore #4
/*      */       //   333: iload_1
/*      */       //   334: aload_0
/*      */       //   335: getfield s : Lorg/luaj/vm2/LuaString;
/*      */       //   338: invokevirtual length : ()I
/*      */       //   341: if_icmpne -> 348
/*      */       //   344: iconst_0
/*      */       //   345: goto -> 356
/*      */       //   348: aload_0
/*      */       //   349: getfield s : Lorg/luaj/vm2/LuaString;
/*      */       //   352: iload_1
/*      */       //   353: invokevirtual luaByte : (I)I
/*      */       //   356: istore #5
/*      */       //   358: aload_0
/*      */       //   359: iload #4
/*      */       //   361: iload_2
/*      */       //   362: iload_3
/*      */       //   363: iconst_1
/*      */       //   364: isub
/*      */       //   365: invokevirtual matchbracketclass : (III)Z
/*      */       //   368: ifne -> 384
/*      */       //   371: aload_0
/*      */       //   372: iload #5
/*      */       //   374: iload_2
/*      */       //   375: iload_3
/*      */       //   376: iconst_1
/*      */       //   377: isub
/*      */       //   378: invokevirtual matchbracketclass : (III)Z
/*      */       //   381: ifne -> 400
/*      */       //   384: iconst_m1
/*      */       //   385: istore #6
/*      */       //   387: aload_0
/*      */       //   388: dup
/*      */       //   389: getfield matchdepth : I
/*      */       //   392: iconst_1
/*      */       //   393: iadd
/*      */       //   394: putfield matchdepth : I
/*      */       //   397: iload #6
/*      */       //   399: ireturn
/*      */       //   400: iload_3
/*      */       //   401: istore_2
/*      */       //   402: goto -> 20
/*      */       //   405: aload_0
/*      */       //   406: getfield p : Lorg/luaj/vm2/LuaString;
/*      */       //   409: iload_2
/*      */       //   410: iconst_1
/*      */       //   411: iadd
/*      */       //   412: invokevirtual luaByte : (I)I
/*      */       //   415: istore_3
/*      */       //   416: iload_3
/*      */       //   417: i2c
/*      */       //   418: invokestatic isDigit : (C)Z
/*      */       //   421: ifeq -> 475
/*      */       //   424: aload_0
/*      */       //   425: iload_1
/*      */       //   426: iload_3
/*      */       //   427: invokevirtual match_capture : (II)I
/*      */       //   430: istore_1
/*      */       //   431: iload_1
/*      */       //   432: iconst_m1
/*      */       //   433: if_icmpne -> 452
/*      */       //   436: iconst_m1
/*      */       //   437: istore #4
/*      */       //   439: aload_0
/*      */       //   440: dup
/*      */       //   441: getfield matchdepth : I
/*      */       //   444: iconst_1
/*      */       //   445: iadd
/*      */       //   446: putfield matchdepth : I
/*      */       //   449: iload #4
/*      */       //   451: ireturn
/*      */       //   452: aload_0
/*      */       //   453: iload_1
/*      */       //   454: iload_2
/*      */       //   455: iconst_2
/*      */       //   456: iadd
/*      */       //   457: invokevirtual match : (II)I
/*      */       //   460: istore #4
/*      */       //   462: aload_0
/*      */       //   463: dup
/*      */       //   464: getfield matchdepth : I
/*      */       //   467: iconst_1
/*      */       //   468: iadd
/*      */       //   469: putfield matchdepth : I
/*      */       //   472: iload #4
/*      */       //   474: ireturn
/*      */       //   475: iload_2
/*      */       //   476: iconst_1
/*      */       //   477: iadd
/*      */       //   478: aload_0
/*      */       //   479: getfield p : Lorg/luaj/vm2/LuaString;
/*      */       //   482: invokevirtual length : ()I
/*      */       //   485: if_icmpne -> 517
/*      */       //   488: iload_1
/*      */       //   489: aload_0
/*      */       //   490: getfield s : Lorg/luaj/vm2/LuaString;
/*      */       //   493: invokevirtual length : ()I
/*      */       //   496: if_icmpne -> 503
/*      */       //   499: iload_1
/*      */       //   500: goto -> 504
/*      */       //   503: iconst_m1
/*      */       //   504: istore_3
/*      */       //   505: aload_0
/*      */       //   506: dup
/*      */       //   507: getfield matchdepth : I
/*      */       //   510: iconst_1
/*      */       //   511: iadd
/*      */       //   512: putfield matchdepth : I
/*      */       //   515: iload_3
/*      */       //   516: ireturn
/*      */       //   517: aload_0
/*      */       //   518: iload_2
/*      */       //   519: invokevirtual classend : (I)I
/*      */       //   522: istore_3
/*      */       //   523: iload_1
/*      */       //   524: aload_0
/*      */       //   525: getfield s : Lorg/luaj/vm2/LuaString;
/*      */       //   528: invokevirtual length : ()I
/*      */       //   531: if_icmpge -> 555
/*      */       //   534: aload_0
/*      */       //   535: aload_0
/*      */       //   536: getfield s : Lorg/luaj/vm2/LuaString;
/*      */       //   539: iload_1
/*      */       //   540: invokevirtual luaByte : (I)I
/*      */       //   543: iload_2
/*      */       //   544: iload_3
/*      */       //   545: invokevirtual singlematch : (III)Z
/*      */       //   548: ifeq -> 555
/*      */       //   551: iconst_1
/*      */       //   552: goto -> 556
/*      */       //   555: iconst_0
/*      */       //   556: istore #4
/*      */       //   558: iload_3
/*      */       //   559: aload_0
/*      */       //   560: getfield p : Lorg/luaj/vm2/LuaString;
/*      */       //   563: invokevirtual length : ()I
/*      */       //   566: if_icmpge -> 580
/*      */       //   569: aload_0
/*      */       //   570: getfield p : Lorg/luaj/vm2/LuaString;
/*      */       //   573: iload_3
/*      */       //   574: invokevirtual luaByte : (I)I
/*      */       //   577: goto -> 581
/*      */       //   580: iconst_0
/*      */       //   581: istore #5
/*      */       //   583: iload #5
/*      */       //   585: lookupswitch default -> 751, 42 -> 674, 43 -> 696, 45 -> 729, 63 -> 628
/*      */       //   628: iload #4
/*      */       //   630: ifeq -> 667
/*      */       //   633: aload_0
/*      */       //   634: iload_1
/*      */       //   635: iconst_1
/*      */       //   636: iadd
/*      */       //   637: iload_3
/*      */       //   638: iconst_1
/*      */       //   639: iadd
/*      */       //   640: invokevirtual match : (II)I
/*      */       //   643: dup
/*      */       //   644: istore #6
/*      */       //   646: iconst_m1
/*      */       //   647: if_icmpeq -> 667
/*      */       //   650: iload #6
/*      */       //   652: istore #7
/*      */       //   654: aload_0
/*      */       //   655: dup
/*      */       //   656: getfield matchdepth : I
/*      */       //   659: iconst_1
/*      */       //   660: iadd
/*      */       //   661: putfield matchdepth : I
/*      */       //   664: iload #7
/*      */       //   666: ireturn
/*      */       //   667: iload_3
/*      */       //   668: iconst_1
/*      */       //   669: iadd
/*      */       //   670: istore_2
/*      */       //   671: goto -> 20
/*      */       //   674: aload_0
/*      */       //   675: iload_1
/*      */       //   676: iload_2
/*      */       //   677: iload_3
/*      */       //   678: invokevirtual max_expand : (III)I
/*      */       //   681: istore #7
/*      */       //   683: aload_0
/*      */       //   684: dup
/*      */       //   685: getfield matchdepth : I
/*      */       //   688: iconst_1
/*      */       //   689: iadd
/*      */       //   690: putfield matchdepth : I
/*      */       //   693: iload #7
/*      */       //   695: ireturn
/*      */       //   696: iload #4
/*      */       //   698: ifeq -> 713
/*      */       //   701: aload_0
/*      */       //   702: iload_1
/*      */       //   703: iconst_1
/*      */       //   704: iadd
/*      */       //   705: iload_2
/*      */       //   706: iload_3
/*      */       //   707: invokevirtual max_expand : (III)I
/*      */       //   710: goto -> 714
/*      */       //   713: iconst_m1
/*      */       //   714: istore #7
/*      */       //   716: aload_0
/*      */       //   717: dup
/*      */       //   718: getfield matchdepth : I
/*      */       //   721: iconst_1
/*      */       //   722: iadd
/*      */       //   723: putfield matchdepth : I
/*      */       //   726: iload #7
/*      */       //   728: ireturn
/*      */       //   729: aload_0
/*      */       //   730: iload_1
/*      */       //   731: iload_2
/*      */       //   732: iload_3
/*      */       //   733: invokevirtual min_expand : (III)I
/*      */       //   736: istore #7
/*      */       //   738: aload_0
/*      */       //   739: dup
/*      */       //   740: getfield matchdepth : I
/*      */       //   743: iconst_1
/*      */       //   744: iadd
/*      */       //   745: putfield matchdepth : I
/*      */       //   748: iload #7
/*      */       //   750: ireturn
/*      */       //   751: iload #4
/*      */       //   753: ifne -> 772
/*      */       //   756: iconst_m1
/*      */       //   757: istore #7
/*      */       //   759: aload_0
/*      */       //   760: dup
/*      */       //   761: getfield matchdepth : I
/*      */       //   764: iconst_1
/*      */       //   765: iadd
/*      */       //   766: putfield matchdepth : I
/*      */       //   769: iload #7
/*      */       //   771: ireturn
/*      */       //   772: iinc #1, 1
/*      */       //   775: iload_3
/*      */       //   776: istore_2
/*      */       //   777: goto -> 20
/*      */       //   780: astore #8
/*      */       //   782: aload_0
/*      */       //   783: dup
/*      */       //   784: getfield matchdepth : I
/*      */       //   787: iconst_1
/*      */       //   788: iadd
/*      */       //   789: putfield matchdepth : I
/*      */       //   792: aload #8
/*      */       //   794: athrow
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #1135	-> 0
/*      */       //   #1136	-> 14
/*      */       //   #1142	-> 20
/*      */       //   #1143	-> 31
/*      */       //   #1214	-> 33
/*      */       //   #1143	-> 43
/*      */       //   #1144	-> 45
/*      */       //   #1146	-> 92
/*      */       //   #1147	-> 119
/*      */       //   #1214	-> 130
/*      */       //   #1147	-> 140
/*      */       //   #1149	-> 142
/*      */       //   #1214	-> 150
/*      */       //   #1149	-> 160
/*      */       //   #1151	-> 162
/*      */       //   #1214	-> 171
/*      */       //   #1151	-> 181
/*      */       //   #1153	-> 183
/*      */       //   #1154	-> 196
/*      */       //   #1155	-> 202
/*      */       //   #1157	-> 240
/*      */       //   #1158	-> 249
/*      */       //   #1159	-> 254
/*      */       //   #1214	-> 256
/*      */       //   #1159	-> 266
/*      */       //   #1160	-> 268
/*      */       //   #1161	-> 271
/*      */       //   #1163	-> 274
/*      */       //   #1164	-> 277
/*      */       //   #1165	-> 301
/*      */       //   #1167	-> 307
/*      */       //   #1168	-> 313
/*      */       //   #1169	-> 333
/*      */       //   #1170	-> 358
/*      */       //   #1171	-> 384
/*      */       //   #1214	-> 387
/*      */       //   #1171	-> 397
/*      */       //   #1172	-> 400
/*      */       //   #1173	-> 402
/*      */       //   #1176	-> 405
/*      */       //   #1177	-> 416
/*      */       //   #1178	-> 424
/*      */       //   #1179	-> 431
/*      */       //   #1180	-> 436
/*      */       //   #1214	-> 439
/*      */       //   #1180	-> 449
/*      */       //   #1181	-> 452
/*      */       //   #1214	-> 462
/*      */       //   #1181	-> 472
/*      */       //   #1186	-> 475
/*      */       //   #1187	-> 488
/*      */       //   #1214	-> 505
/*      */       //   #1187	-> 515
/*      */       //   #1189	-> 517
/*      */       //   #1190	-> 523
/*      */       //   #1191	-> 558
/*      */       //   #1193	-> 583
/*      */       //   #1196	-> 628
/*      */       //   #1197	-> 650
/*      */       //   #1214	-> 654
/*      */       //   #1197	-> 664
/*      */       //   #1198	-> 667
/*      */       //   #1199	-> 671
/*      */       //   #1201	-> 674
/*      */       //   #1214	-> 683
/*      */       //   #1201	-> 693
/*      */       //   #1203	-> 696
/*      */       //   #1214	-> 716
/*      */       //   #1203	-> 726
/*      */       //   #1205	-> 729
/*      */       //   #1214	-> 738
/*      */       //   #1205	-> 748
/*      */       //   #1207	-> 751
/*      */       //   #1208	-> 756
/*      */       //   #1214	-> 759
/*      */       //   #1208	-> 769
/*      */       //   #1209	-> 772
/*      */       //   #1210	-> 775
/*      */       //   #1212	-> 777
/*      */       //   #1214	-> 780
/*      */       //   #1215	-> 792
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   313	92	3	ep	I
/*      */       //   333	72	4	previous	I
/*      */       //   358	47	5	next	I
/*      */       //   416	59	3	c	I
/*      */       //   646	21	6	res	I
/*      */       //   523	254	3	ep	I
/*      */       //   558	219	4	m	Z
/*      */       //   583	194	5	pc	I
/*      */       //   0	795	0	this	Lorg/luaj/vm2/lib/StringLib$MatchState;
/*      */       //   0	795	1	soffset	I
/*      */       //   0	795	2	poffset	I
/*      */       // Exception table:
/*      */       //   from	to	target	type
/*      */       //   20	33	780	finally
/*      */       //   45	130	780	finally
/*      */       //   142	150	780	finally
/*      */       //   162	171	780	finally
/*      */       //   183	256	780	finally
/*      */       //   268	387	780	finally
/*      */       //   400	439	780	finally
/*      */       //   452	462	780	finally
/*      */       //   475	505	780	finally
/*      */       //   517	654	780	finally
/*      */       //   667	683	780	finally
/*      */       //   696	716	780	finally
/*      */       //   729	738	780	finally
/*      */       //   751	759	780	finally
/*      */       //   772	782	780	finally
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int max_expand(int soff, int poff, int ep) {
/* 1219 */       int i = 0;
/* 1220 */       while (soff + i < this.s.length() && singlematch(this.s.luaByte(soff + i), poff, ep))
/* 1221 */         i++; 
/* 1222 */       while (i >= 0) {
/* 1223 */         int res = match(soff + i, ep + 1);
/* 1224 */         if (res != -1)
/* 1225 */           return res; 
/* 1226 */         i--;
/*      */       } 
/* 1228 */       return -1;
/*      */     }
/*      */     
/*      */     int min_expand(int soff, int poff, int ep) {
/*      */       while (true) {
/* 1233 */         int res = match(soff, ep + 1);
/* 1234 */         if (res != -1)
/* 1235 */           return res; 
/* 1236 */         if (soff < this.s.length() && singlematch(this.s.luaByte(soff), poff, ep)) {
/* 1237 */           soff++; continue;
/*      */         }  break;
/* 1239 */       }  return -1;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     int start_capture(int soff, int poff, int what) {
/* 1245 */       int level = this.level;
/* 1246 */       if (level >= 32) {
/* 1247 */         LuaValue.error("too many captures");
/*      */       }
/* 1249 */       this.cinit[level] = soff;
/* 1250 */       this.clen[level] = what;
/* 1251 */       this.level = level + 1; int res;
/* 1252 */       if ((res = match(soff, poff)) == -1)
/* 1253 */         this.level--; 
/* 1254 */       return res;
/*      */     }
/*      */     
/*      */     int end_capture(int soff, int poff) {
/* 1258 */       int l = capture_to_close();
/*      */       
/* 1260 */       this.clen[l] = soff - this.cinit[l]; int res;
/* 1261 */       if ((res = match(soff, poff)) == -1)
/* 1262 */         this.clen[l] = -1; 
/* 1263 */       return res;
/*      */     }
/*      */     
/*      */     int match_capture(int soff, int l) {
/* 1267 */       l = check_capture(l);
/* 1268 */       int len = this.clen[l];
/* 1269 */       if (this.s.length() - soff >= len && LuaString.equals(this.s, this.cinit[l], this.s, soff, len)) {
/* 1270 */         return soff + len;
/*      */       }
/* 1272 */       return -1;
/*      */     }
/*      */     
/*      */     int matchbalance(int soff, int poff) {
/* 1276 */       int plen = this.p.length();
/* 1277 */       if (poff == plen || poff + 1 == plen) {
/* 1278 */         LuaValue.error("malformed pattern (missing arguments to '%b')");
/*      */       }
/* 1280 */       int slen = this.s.length();
/* 1281 */       if (soff >= slen)
/* 1282 */         return -1; 
/* 1283 */       int b = this.p.luaByte(poff);
/* 1284 */       if (this.s.luaByte(soff) != b)
/* 1285 */         return -1; 
/* 1286 */       int e = this.p.luaByte(poff + 1);
/* 1287 */       int cont = 1;
/* 1288 */       while (++soff < slen) {
/* 1289 */         if (this.s.luaByte(soff) == e) {
/* 1290 */           if (--cont == 0)
/* 1291 */             return soff + 1;  continue;
/* 1292 */         }  if (this.s.luaByte(soff) == b)
/* 1293 */           cont++; 
/*      */       } 
/* 1295 */       return -1;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-core-3.0.3.jar!\org\luaj\vm2\lib\StringLib.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */