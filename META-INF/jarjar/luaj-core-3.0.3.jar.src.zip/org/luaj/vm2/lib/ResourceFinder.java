package org.luaj.vm2.lib;

import java.io.InputStream;

public interface ResourceFinder {
  InputStream findResource(String paramString);
}


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-core-3.0.3.jar!\org\luaj\vm2\lib\ResourceFinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */