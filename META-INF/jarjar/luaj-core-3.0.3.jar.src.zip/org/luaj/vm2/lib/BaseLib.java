/*     */ package org.luaj.vm2.lib;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.luaj.vm2.Globals;
/*     */ import org.luaj.vm2.LuaError;
/*     */ import org.luaj.vm2.LuaString;
/*     */ import org.luaj.vm2.LuaTable;
/*     */ import org.luaj.vm2.LuaThread;
/*     */ import org.luaj.vm2.LuaValue;
/*     */ import org.luaj.vm2.Varargs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseLib
/*     */   extends TwoArgFunction
/*     */   implements ResourceFinder
/*     */ {
/*     */   Globals globals;
/*     */   
/*     */   public LuaValue call(LuaValue modname, LuaValue env) {
/* 103 */     this.globals = env.checkglobals();
/* 104 */     this.globals.finder = this;
/* 105 */     this.globals.baselib = this;
/* 106 */     env.set("_G", env);
/* 107 */     env.set("_VERSION", "Luaj 0.0");
/* 108 */     env.set("assert", (LuaValue)new _assert());
/* 109 */     env.set("collectgarbage", (LuaValue)new collectgarbage());
/* 110 */     env.set("dofile", (LuaValue)new dofile());
/* 111 */     env.set("error", (LuaValue)new error());
/* 112 */     env.set("getmetatable", (LuaValue)new getmetatable());
/* 113 */     env.set("load", (LuaValue)new load());
/* 114 */     env.set("loadfile", (LuaValue)new loadfile());
/* 115 */     env.set("pcall", (LuaValue)new pcall());
/* 116 */     env.set("print", (LuaValue)new print(this));
/* 117 */     env.set("rawequal", (LuaValue)new rawequal());
/* 118 */     env.set("rawget", (LuaValue)new rawget());
/* 119 */     env.set("rawlen", (LuaValue)new rawlen());
/* 120 */     env.set("rawset", (LuaValue)new rawset());
/* 121 */     env.set("select", (LuaValue)new select());
/* 122 */     env.set("setmetatable", (LuaValue)new setmetatable());
/* 123 */     env.set("tonumber", (LuaValue)new tonumber());
/* 124 */     env.set("tostring", (LuaValue)new tostring());
/* 125 */     env.set("type", (LuaValue)new type());
/* 126 */     env.set("xpcall", (LuaValue)new xpcall());
/*     */     
/*     */     next next;
/* 129 */     env.set("next", (LuaValue)(next = new next()));
/* 130 */     env.set("pairs", (LuaValue)new pairs(next));
/* 131 */     env.set("ipairs", (LuaValue)new ipairs());
/*     */     
/* 133 */     return env;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream findResource(String filename) {
/* 143 */     return getClass().getResourceAsStream(filename.startsWith("/") ? filename : ("/" + filename));
/*     */   }
/*     */   
/*     */   static final class _assert
/*     */     extends VarArgFunction
/*     */   {
/*     */     public Varargs invoke(Varargs args) {
/* 150 */       if (!args.arg1().toboolean())
/* 151 */         error((args.narg() > 1) ? args.optjstring(2, "assertion failed!") : "assertion failed!"); 
/* 152 */       return args;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class collectgarbage
/*     */     extends VarArgFunction
/*     */   {
/*     */     public Varargs invoke(Varargs args) {
/* 160 */       String s = args.optjstring(1, "collect");
/* 161 */       if ("collect".equals(s)) {
/* 162 */         System.gc();
/* 163 */         return (Varargs)ZERO;
/* 164 */       }  if ("count".equals(s)) {
/* 165 */         Runtime rt = Runtime.getRuntime();
/* 166 */         long used = rt.totalMemory() - rt.freeMemory();
/* 167 */         return varargsOf((LuaValue)valueOf(used / 1024.0D), (Varargs)valueOf((used % 1024L)));
/* 168 */       }  if ("step".equals(s)) {
/* 169 */         System.gc();
/* 170 */         return (Varargs)LuaValue.TRUE;
/*     */       } 
/* 172 */       argerror(1, "invalid option '" + s + "'");
/*     */       
/* 174 */       return (Varargs)NIL;
/*     */     }
/*     */   }
/*     */   
/*     */   final class dofile
/*     */     extends VarArgFunction
/*     */   {
/*     */     public Varargs invoke(Varargs args) {
/* 182 */       args.argcheck((args.isstring(1) || args.isnil(1)), 1, "filename must be string or nil");
/* 183 */       String filename = args.isstring(1) ? args.tojstring(1) : null;
/*     */       
/* 185 */       Varargs v = (filename == null) ? BaseLib.this.loadStream(BaseLib.this.globals.STDIN, "=stdin", "bt", (LuaValue)BaseLib.this.globals) : BaseLib.this.loadFile(args.checkjstring(1), "bt", (LuaValue)BaseLib.this.globals);
/* 186 */       return v.isnil(1) ? (Varargs)error(v.tojstring(2)) : v.arg1().invoke();
/*     */     }
/*     */   }
/*     */   
/*     */   static final class error
/*     */     extends TwoArgFunction
/*     */   {
/*     */     public LuaValue call(LuaValue arg1, LuaValue arg2) {
/* 194 */       if (arg1.isnil())
/* 195 */         throw new LuaError(NIL); 
/* 196 */       if (!arg1.isstring() || arg2.optint(1) == 0)
/* 197 */         throw new LuaError(arg1); 
/* 198 */       throw new LuaError(arg1.tojstring(), arg2.optint(1));
/*     */     }
/*     */   }
/*     */   
/*     */   static final class getmetatable
/*     */     extends LibFunction
/*     */   {
/*     */     public LuaValue call() {
/* 206 */       return argerror(1, "value expected");
/*     */     }
/*     */ 
/*     */     
/*     */     public LuaValue call(LuaValue arg) {
/* 211 */       LuaValue mt = arg.getmetatable();
/* 212 */       return (mt != null) ? mt.rawget((LuaValue)METATABLE).optvalue(mt) : NIL;
/*     */     }
/*     */   }
/*     */   
/*     */   final class load
/*     */     extends VarArgFunction
/*     */   {
/*     */     public Varargs invoke(Varargs args) {
/* 220 */       LuaValue ld = args.arg1();
/* 221 */       if (!ld.isstring() && !ld.isfunction()) {
/* 222 */         throw new LuaError("bad argument #1 to 'load' (string or function expected, got " + ld
/* 223 */             .typename() + ")");
/*     */       }
/* 225 */       String source = args.optjstring(2, ld.isstring() ? ld.tojstring() : "=(load)");
/* 226 */       String mode = args.optjstring(3, "bt");
/* 227 */       LuaValue env = args.optvalue(4, (LuaValue)BaseLib.this.globals);
/* 228 */       return BaseLib.this.loadStream(ld.isstring() ? ld.strvalue().toInputStream() : new BaseLib.StringInputStream((LuaValue)ld.checkfunction()), source, mode, env);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   final class loadfile
/*     */     extends VarArgFunction
/*     */   {
/*     */     public Varargs invoke(Varargs args) {
/* 237 */       args.argcheck((args.isstring(1) || args.isnil(1)), 1, "filename must be string or nil");
/* 238 */       String filename = args.isstring(1) ? args.tojstring(1) : null;
/* 239 */       String mode = args.optjstring(2, "bt");
/* 240 */       LuaValue env = args.optvalue(3, (LuaValue)BaseLib.this.globals);
/* 241 */       return (filename == null) ? BaseLib.this.loadStream(BaseLib.this.globals.STDIN, "=stdin", mode, env) : BaseLib.this.loadFile(filename, mode, env);
/*     */     }
/*     */   }
/*     */   
/*     */   final class pcall
/*     */     extends VarArgFunction
/*     */   {
/*     */     public Varargs invoke(Varargs args) {
/* 249 */       LuaValue func = args.checkvalue(1);
/* 250 */       if (BaseLib.this.globals != null && BaseLib.this.globals.debuglib != null)
/* 251 */         BaseLib.this.globals.debuglib.onCall(this); 
/*     */       try {
/* 253 */         return varargsOf((LuaValue)TRUE, func.invoke(args.subargs(2)));
/* 254 */       } catch (LuaError le) {
/* 255 */         LuaValue m = le.getMessageObject();
/* 256 */         return varargsOf((LuaValue)FALSE, (m != null) ? (Varargs)m : (Varargs)NIL);
/* 257 */       } catch (Exception e) {
/* 258 */         String m = e.getMessage();
/* 259 */         return varargsOf((LuaValue)FALSE, (Varargs)valueOf((m != null) ? m : e.toString()));
/*     */       } finally {
/* 261 */         if (BaseLib.this.globals != null && BaseLib.this.globals.debuglib != null)
/* 262 */           BaseLib.this.globals.debuglib.onReturn(); 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   final class print
/*     */     extends VarArgFunction {
/*     */     final BaseLib baselib;
/*     */     
/*     */     print(BaseLib baselib) {
/* 272 */       this.baselib = baselib;
/*     */     }
/*     */ 
/*     */     
/*     */     public Varargs invoke(Varargs args) {
/* 277 */       LuaValue tostring = BaseLib.this.globals.get("tostring");
/* 278 */       for (int i = 1, n = args.narg(); i <= n; i++) {
/* 279 */         if (i > 1)
/* 280 */           BaseLib.this.globals.STDOUT.print('\t'); 
/* 281 */         LuaString s = tostring.call(args.arg(i)).strvalue();
/* 282 */         BaseLib.this.globals.STDOUT.print(s.tojstring());
/*     */       } 
/* 284 */       BaseLib.this.globals.STDOUT.print('\n');
/* 285 */       return (Varargs)NONE;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class rawequal
/*     */     extends LibFunction
/*     */   {
/*     */     public LuaValue call() {
/* 293 */       return argerror(1, "value expected");
/*     */     }
/*     */ 
/*     */     
/*     */     public LuaValue call(LuaValue arg) {
/* 298 */       return argerror(2, "value expected");
/*     */     }
/*     */ 
/*     */     
/*     */     public LuaValue call(LuaValue arg1, LuaValue arg2) {
/* 303 */       return (LuaValue)valueOf(arg1.raweq(arg2));
/*     */     }
/*     */   }
/*     */   
/*     */   static final class rawget
/*     */     extends TableLibFunction
/*     */   {
/*     */     public LuaValue call(LuaValue arg) {
/* 311 */       return argerror(2, "value expected");
/*     */     }
/*     */ 
/*     */     
/*     */     public LuaValue call(LuaValue arg1, LuaValue arg2) {
/* 316 */       return arg1.checktable().rawget(arg2);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class rawlen
/*     */     extends LibFunction
/*     */   {
/*     */     public LuaValue call(LuaValue arg) {
/* 324 */       return (LuaValue)valueOf(arg.rawlen());
/*     */     }
/*     */   }
/*     */   
/*     */   static final class rawset
/*     */     extends TableLibFunction
/*     */   {
/*     */     public LuaValue call(LuaValue table) {
/* 332 */       return argerror(2, "value expected");
/*     */     }
/*     */ 
/*     */     
/*     */     public LuaValue call(LuaValue table, LuaValue index) {
/* 337 */       return argerror(3, "value expected");
/*     */     }
/*     */ 
/*     */     
/*     */     public LuaValue call(LuaValue table, LuaValue index, LuaValue value) {
/* 342 */       LuaTable t = table.checktable();
/* 343 */       if (!index.isvalidkey())
/* 344 */         argerror(2, "table index is nil"); 
/* 345 */       t.rawset(index, value);
/* 346 */       return (LuaValue)t;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class select
/*     */     extends VarArgFunction
/*     */   {
/*     */     public Varargs invoke(Varargs args) {
/* 354 */       int n = args.narg() - 1;
/* 355 */       if (args.arg1().equals(valueOf("#")))
/* 356 */         return (Varargs)valueOf(n); 
/* 357 */       int i = args.checkint(1);
/* 358 */       if (i == 0 || i < -n)
/* 359 */         argerror(1, "index out of range"); 
/* 360 */       return args.subargs((i < 0) ? (n + i + 2) : (i + 1));
/*     */     }
/*     */   }
/*     */   
/*     */   static final class setmetatable
/*     */     extends TableLibFunction
/*     */   {
/*     */     public LuaValue call(LuaValue table) {
/* 368 */       return argerror(2, "nil or table expected");
/*     */     }
/*     */ 
/*     */     
/*     */     public LuaValue call(LuaValue table, LuaValue metatable) {
/* 373 */       LuaValue mt0 = table.checktable().getmetatable();
/* 374 */       if (mt0 != null && !mt0.rawget((LuaValue)METATABLE).isnil())
/* 375 */         error("cannot change a protected metatable"); 
/* 376 */       return table.setmetatable(metatable.isnil() ? null : (LuaValue)metatable.checktable());
/*     */     }
/*     */   }
/*     */   
/*     */   static final class tonumber
/*     */     extends LibFunction
/*     */   {
/*     */     public LuaValue call(LuaValue e) {
/* 384 */       return e.tonumber();
/*     */     }
/*     */ 
/*     */     
/*     */     public LuaValue call(LuaValue e, LuaValue base) {
/* 389 */       if (base.isnil())
/* 390 */         return e.tonumber(); 
/* 391 */       int b = base.checkint();
/* 392 */       if (b < 2 || b > 36)
/* 393 */         argerror(2, "base out of range"); 
/* 394 */       return e.checkstring().tonumber(b);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class tostring
/*     */     extends LibFunction
/*     */   {
/*     */     public LuaValue call(LuaValue arg) {
/* 402 */       LuaValue h = arg.metatag((LuaValue)TOSTRING);
/* 403 */       if (!h.isnil())
/* 404 */         return h.call(arg); 
/* 405 */       LuaValue v = arg.tostring();
/* 406 */       if (!v.isnil())
/* 407 */         return v; 
/* 408 */       return (LuaValue)valueOf(arg.tojstring());
/*     */     }
/*     */   }
/*     */   
/*     */   static final class type
/*     */     extends LibFunction
/*     */   {
/*     */     public LuaValue call(LuaValue arg) {
/* 416 */       return (LuaValue)valueOf(arg.typename());
/*     */     }
/*     */   }
/*     */   
/*     */   final class xpcall
/*     */     extends VarArgFunction
/*     */   {
/*     */     public Varargs invoke(Varargs args) {
/* 424 */       LuaThread t = BaseLib.this.globals.running;
/* 425 */       LuaValue preverror = t.errorfunc;
/* 426 */       t.errorfunc = args.checkvalue(2);
/*     */       try {
/* 428 */         if (BaseLib.this.globals != null && BaseLib.this.globals.debuglib != null) {
/* 429 */           BaseLib.this.globals.debuglib.onCall(this);
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       finally {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 443 */         t.errorfunc = preverror;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static final class pairs
/*     */     extends VarArgFunction {
/*     */     final BaseLib.next next;
/*     */     
/*     */     pairs(BaseLib.next next1) {
/* 453 */       this.next = next1;
/*     */     }
/*     */ 
/*     */     
/*     */     public Varargs invoke(Varargs args) {
/* 458 */       return varargsOf((LuaValue)this.next, (LuaValue)args.checktable(1), (Varargs)NIL);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class ipairs
/*     */     extends VarArgFunction {
/* 464 */     BaseLib.inext inext = new BaseLib.inext();
/*     */ 
/*     */     
/*     */     public Varargs invoke(Varargs args) {
/* 468 */       return varargsOf((LuaValue)this.inext, (LuaValue)args.checktable(1), (Varargs)ZERO);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class next
/*     */     extends VarArgFunction
/*     */   {
/*     */     public Varargs invoke(Varargs args) {
/* 476 */       return args.checktable(1).next(args.arg(2));
/*     */     }
/*     */   }
/*     */   
/*     */   static final class inext
/*     */     extends VarArgFunction
/*     */   {
/*     */     public Varargs invoke(Varargs args) {
/* 484 */       return args.checktable(1).inext(args.arg(2));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Varargs loadFile(String filename, String mode, LuaValue env) {
/* 496 */     InputStream is = this.globals.finder.findResource(filename);
/* 497 */     if (is == null)
/* 498 */       return varargsOf(NIL, (Varargs)valueOf("cannot open " + filename + ": No such file or directory")); 
/*     */     try {
/* 500 */       return loadStream(is, "@" + filename, mode, env);
/*     */     } finally {
/*     */       try {
/* 503 */         is.close();
/* 504 */       } catch (Exception e) {
/* 505 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Varargs loadStream(InputStream is, String chunkname, String mode, LuaValue env) {
/*     */     try {
/* 512 */       if (is == null)
/* 513 */         return varargsOf(NIL, (Varargs)valueOf("not found: " + chunkname)); 
/* 514 */       return (Varargs)this.globals.load(is, chunkname, mode, env);
/* 515 */     } catch (Exception e) {
/* 516 */       return varargsOf(NIL, (Varargs)valueOf(e.getMessage()));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class StringInputStream extends InputStream { final LuaValue func;
/*     */     byte[] bytes;
/*     */     int offset;
/* 523 */     int remaining = 0;
/*     */     
/*     */     StringInputStream(LuaValue func) {
/* 526 */       this.func = func;
/*     */     }
/*     */ 
/*     */     
/*     */     public int read() throws IOException {
/* 531 */       if (this.remaining < 0)
/* 532 */         return -1; 
/* 533 */       if (this.remaining == 0) {
/* 534 */         LuaValue s = this.func.call();
/* 535 */         if (s.isnil())
/* 536 */           return this.remaining = -1; 
/* 537 */         LuaString ls = s.strvalue();
/* 538 */         this.bytes = ls.m_bytes;
/* 539 */         this.offset = ls.m_offset;
/* 540 */         this.remaining = ls.m_length;
/* 541 */         if (this.remaining <= 0)
/* 542 */           return -1; 
/*     */       } 
/* 544 */       this.remaining--;
/* 545 */       return 0xFF & this.bytes[this.offset++];
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-core-3.0.3.jar!\org\luaj\vm2\lib\BaseLib.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */