/*    */ package org.luaj.vm2.lib;
/*    */ 
/*    */ import org.luaj.vm2.LuaValue;
/*    */ import org.luaj.vm2.Varargs;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TwoArgFunction
/*    */   extends LibFunction
/*    */ {
/*    */   public abstract LuaValue call(LuaValue paramLuaValue1, LuaValue paramLuaValue2);
/*    */   
/*    */   public final LuaValue call() {
/* 63 */     return call(NIL, NIL);
/*    */   }
/*    */ 
/*    */   
/*    */   public final LuaValue call(LuaValue arg) {
/* 68 */     return call(arg, NIL);
/*    */   }
/*    */ 
/*    */   
/*    */   public LuaValue call(LuaValue arg1, LuaValue arg2, LuaValue arg3) {
/* 73 */     return call(arg1, arg2);
/*    */   }
/*    */ 
/*    */   
/*    */   public Varargs invoke(Varargs varargs) {
/* 78 */     return (Varargs)call(varargs.arg1(), varargs.arg(2));
/*    */   }
/*    */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-core-3.0.3.jar!\org\luaj\vm2\lib\TwoArgFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */