/*   */ package org.luaj.vm2.lib;
/*   */ 
/*   */ import org.luaj.vm2.LuaValue;
/*   */ 
/*   */ class TableLibFunction
/*   */   extends LibFunction {
/*   */   public LuaValue call() {
/* 8 */     return argerror(1, "table expected, got no value");
/*   */   }
/*   */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-core-3.0.3.jar!\org\luaj\vm2\lib\TableLibFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */