/*     */ package org.luaj.vm2;
/*     */ 
/*     */ import org.luaj.vm2.lib.DebugLib;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LuaClosure
/*     */   extends LuaFunction
/*     */ {
/* 100 */   private static final UpValue[] NOUPVALUES = new UpValue[0];
/*     */ 
/*     */ 
/*     */   
/*     */   public final Prototype p;
/*     */ 
/*     */ 
/*     */   
/*     */   public UpValue[] upValues;
/*     */ 
/*     */ 
/*     */   
/*     */   final Globals globals;
/*     */ 
/*     */ 
/*     */   
/*     */   public LuaClosure(Prototype p, LuaValue env) {
/* 117 */     this.p = p;
/* 118 */     initupvalue1(env);
/* 119 */     this.globals = (env instanceof Globals) ? (Globals)env : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initupvalue1(LuaValue env) {
/* 124 */     if (this.p.upvalues == null || this.p.upvalues.length == 0) {
/* 125 */       this.upValues = NOUPVALUES;
/*     */     } else {
/* 127 */       this.upValues = new UpValue[this.p.upvalues.length];
/* 128 */       this.upValues[0] = new UpValue(new LuaValue[] { env }, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isclosure() {
/* 134 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public LuaClosure optclosure(LuaClosure defval) {
/* 139 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LuaClosure checkclosure() {
/* 144 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String tojstring() {
/* 149 */     return "function: " + this.p.toString();
/*     */   }
/*     */   
/*     */   private LuaValue[] getNewStack() {
/* 153 */     int max = this.p.maxstacksize;
/* 154 */     LuaValue[] stack = new LuaValue[max];
/* 155 */     System.arraycopy(NILS, 0, stack, 0, max);
/* 156 */     return stack;
/*     */   }
/*     */ 
/*     */   
/*     */   public final LuaValue call() {
/* 161 */     LuaValue[] stack = getNewStack();
/* 162 */     return execute(stack, NONE).arg1();
/*     */   }
/*     */ 
/*     */   
/*     */   public final LuaValue call(LuaValue arg) {
/* 167 */     LuaValue[] stack = getNewStack();
/* 168 */     switch (this.p.numparams)
/*     */     { default:
/* 170 */         stack[0] = arg;
/* 171 */         return execute(stack, NONE).arg1();
/*     */       case 0:
/* 173 */         break; }  return execute(stack, arg).arg1();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final LuaValue call(LuaValue arg1, LuaValue arg2) {
/* 179 */     LuaValue[] stack = getNewStack();
/* 180 */     switch (this.p.numparams)
/*     */     { default:
/* 182 */         stack[0] = arg1;
/* 183 */         stack[1] = arg2;
/* 184 */         return execute(stack, NONE).arg1();
/*     */       case 1:
/* 186 */         stack[0] = arg1;
/* 187 */         return execute(stack, arg2).arg1();
/*     */       case 0:
/* 189 */         break; }  return execute(stack, (this.p.is_vararg != 0) ? varargsOf(arg1, arg2) : NONE).arg1();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final LuaValue call(LuaValue arg1, LuaValue arg2, LuaValue arg3) {
/* 195 */     LuaValue[] stack = getNewStack();
/* 196 */     switch (this.p.numparams)
/*     */     { default:
/* 198 */         stack[0] = arg1;
/* 199 */         stack[1] = arg2;
/* 200 */         stack[2] = arg3;
/* 201 */         return execute(stack, NONE).arg1();
/*     */       case 2:
/* 203 */         stack[0] = arg1;
/* 204 */         stack[1] = arg2;
/* 205 */         return execute(stack, arg3).arg1();
/*     */       case 1:
/* 207 */         stack[0] = arg1;
/* 208 */         return execute(stack, (this.p.is_vararg != 0) ? varargsOf(arg2, arg3) : NONE).arg1();
/*     */       case 0:
/* 210 */         break; }  return execute(stack, (this.p.is_vararg != 0) ? varargsOf(arg1, arg2, arg3) : NONE).arg1();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Varargs invoke(Varargs varargs) {
/* 216 */     return onInvoke(varargs).eval();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Varargs onInvoke(Varargs varargs) {
/* 221 */     LuaValue[] stack = getNewStack();
/* 222 */     for (int i = 0; i < this.p.numparams; i++)
/* 223 */       stack[i] = varargs.arg(i + 1); 
/* 224 */     return execute(stack, (this.p.is_vararg != 0) ? varargs.subargs(this.p.numparams + 1) : NONE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Varargs execute(LuaValue[] stack, Varargs varargs) {
/*     */     // Byte code:
/*     */     //   0: iconst_0
/*     */     //   1: istore #7
/*     */     //   3: iconst_0
/*     */     //   4: istore #8
/*     */     //   6: getstatic org/luaj/vm2/LuaClosure.NONE : Lorg/luaj/vm2/LuaValue;
/*     */     //   9: astore #10
/*     */     //   11: aload_0
/*     */     //   12: getfield p : Lorg/luaj/vm2/Prototype;
/*     */     //   15: getfield code : [I
/*     */     //   18: astore #11
/*     */     //   20: aload_0
/*     */     //   21: getfield p : Lorg/luaj/vm2/Prototype;
/*     */     //   24: getfield k : [Lorg/luaj/vm2/LuaValue;
/*     */     //   27: astore #12
/*     */     //   29: aload_0
/*     */     //   30: getfield p : Lorg/luaj/vm2/Prototype;
/*     */     //   33: getfield p : [Lorg/luaj/vm2/Prototype;
/*     */     //   36: arraylength
/*     */     //   37: ifle -> 48
/*     */     //   40: aload_1
/*     */     //   41: arraylength
/*     */     //   42: anewarray org/luaj/vm2/UpValue
/*     */     //   45: goto -> 49
/*     */     //   48: aconst_null
/*     */     //   49: astore #13
/*     */     //   51: aload_0
/*     */     //   52: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   55: ifnull -> 81
/*     */     //   58: aload_0
/*     */     //   59: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   62: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   65: ifnull -> 81
/*     */     //   68: aload_0
/*     */     //   69: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   72: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   75: aload_0
/*     */     //   76: aload_2
/*     */     //   77: aload_1
/*     */     //   78: invokevirtual onCall : (Lorg/luaj/vm2/LuaClosure;Lorg/luaj/vm2/Varargs;[Lorg/luaj/vm2/LuaValue;)V
/*     */     //   81: aload_0
/*     */     //   82: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   85: ifnull -> 114
/*     */     //   88: aload_0
/*     */     //   89: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   92: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   95: ifnull -> 114
/*     */     //   98: aload_0
/*     */     //   99: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   102: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   105: iload #7
/*     */     //   107: aload #10
/*     */     //   109: iload #8
/*     */     //   111: invokevirtual onInstruction : (ILorg/luaj/vm2/Varargs;I)V
/*     */     //   114: aload #11
/*     */     //   116: iload #7
/*     */     //   118: iaload
/*     */     //   119: istore_3
/*     */     //   120: iload_3
/*     */     //   121: bipush #6
/*     */     //   123: ishr
/*     */     //   124: sipush #255
/*     */     //   127: iand
/*     */     //   128: istore #4
/*     */     //   130: iload_3
/*     */     //   131: bipush #63
/*     */     //   133: iand
/*     */     //   134: tableswitch default -> 3819, 0 -> 308, 1 -> 321, 2 -> 335, 3 -> 439, 4 -> 472, 5 -> 499, 6 -> 518, 7 -> 573, 8 -> 622, 9 -> 700, 10 -> 719, 11 -> 791, 12 -> 817, 13 -> 877, 14 -> 949, 15 -> 1021, 16 -> 1093, 17 -> 1165, 18 -> 1237, 19 -> 1309, 20 -> 1325, 21 -> 1341, 22 -> 1357, 23 -> 1446, 24 -> 1517, 25 -> 1601, 26 -> 1685, 27 -> 1769, 28 -> 1797, 29 -> 1839, 30 -> 2274, 31 -> 2818, 32 -> 3164, 33 -> 3252, 34 -> 3331, 35 -> 3402, 36 -> 3439, 37 -> 3622, 38 -> 3746, 39 -> 3809
/*     */     //   308: aload_1
/*     */     //   309: iload #4
/*     */     //   311: aload_1
/*     */     //   312: iload_3
/*     */     //   313: bipush #23
/*     */     //   315: iushr
/*     */     //   316: aaload
/*     */     //   317: aastore
/*     */     //   318: goto -> 3849
/*     */     //   321: aload_1
/*     */     //   322: iload #4
/*     */     //   324: aload #12
/*     */     //   326: iload_3
/*     */     //   327: bipush #14
/*     */     //   329: iushr
/*     */     //   330: aaload
/*     */     //   331: aastore
/*     */     //   332: goto -> 3849
/*     */     //   335: iinc #7, 1
/*     */     //   338: aload #11
/*     */     //   340: iload #7
/*     */     //   342: iaload
/*     */     //   343: istore_3
/*     */     //   344: iload_3
/*     */     //   345: bipush #63
/*     */     //   347: iand
/*     */     //   348: bipush #39
/*     */     //   350: if_icmpeq -> 425
/*     */     //   353: iload_3
/*     */     //   354: bipush #63
/*     */     //   356: iand
/*     */     //   357: istore #14
/*     */     //   359: new org/luaj/vm2/LuaError
/*     */     //   362: dup
/*     */     //   363: new java/lang/StringBuilder
/*     */     //   366: dup
/*     */     //   367: invokespecial <init> : ()V
/*     */     //   370: ldc 'OP_EXTRAARG expected after OP_LOADKX, got '
/*     */     //   372: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   375: iload #14
/*     */     //   377: getstatic org/luaj/vm2/Print.OPNAMES : [Ljava/lang/String;
/*     */     //   380: arraylength
/*     */     //   381: iconst_1
/*     */     //   382: isub
/*     */     //   383: if_icmpge -> 395
/*     */     //   386: getstatic org/luaj/vm2/Print.OPNAMES : [Ljava/lang/String;
/*     */     //   389: iload #14
/*     */     //   391: aaload
/*     */     //   392: goto -> 415
/*     */     //   395: new java/lang/StringBuilder
/*     */     //   398: dup
/*     */     //   399: invokespecial <init> : ()V
/*     */     //   402: ldc 'UNKNOWN_OP_'
/*     */     //   404: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   407: iload #14
/*     */     //   409: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   412: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   415: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   418: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   421: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   424: athrow
/*     */     //   425: aload_1
/*     */     //   426: iload #4
/*     */     //   428: aload #12
/*     */     //   430: iload_3
/*     */     //   431: bipush #6
/*     */     //   433: iushr
/*     */     //   434: aaload
/*     */     //   435: aastore
/*     */     //   436: goto -> 3849
/*     */     //   439: aload_1
/*     */     //   440: iload #4
/*     */     //   442: iload_3
/*     */     //   443: bipush #23
/*     */     //   445: iushr
/*     */     //   446: ifeq -> 455
/*     */     //   449: getstatic org/luaj/vm2/LuaValue.TRUE : Lorg/luaj/vm2/LuaBoolean;
/*     */     //   452: goto -> 458
/*     */     //   455: getstatic org/luaj/vm2/LuaValue.FALSE : Lorg/luaj/vm2/LuaBoolean;
/*     */     //   458: aastore
/*     */     //   459: iload_3
/*     */     //   460: ldc 8372224
/*     */     //   462: iand
/*     */     //   463: ifeq -> 3849
/*     */     //   466: iinc #7, 1
/*     */     //   469: goto -> 3849
/*     */     //   472: iload_3
/*     */     //   473: bipush #23
/*     */     //   475: iushr
/*     */     //   476: istore #5
/*     */     //   478: iload #5
/*     */     //   480: iinc #5, -1
/*     */     //   483: iflt -> 3849
/*     */     //   486: aload_1
/*     */     //   487: iload #4
/*     */     //   489: iinc #4, 1
/*     */     //   492: getstatic org/luaj/vm2/LuaValue.NIL : Lorg/luaj/vm2/LuaValue;
/*     */     //   495: aastore
/*     */     //   496: goto -> 478
/*     */     //   499: aload_1
/*     */     //   500: iload #4
/*     */     //   502: aload_0
/*     */     //   503: getfield upValues : [Lorg/luaj/vm2/UpValue;
/*     */     //   506: iload_3
/*     */     //   507: bipush #23
/*     */     //   509: iushr
/*     */     //   510: aaload
/*     */     //   511: invokevirtual getValue : ()Lorg/luaj/vm2/LuaValue;
/*     */     //   514: aastore
/*     */     //   515: goto -> 3849
/*     */     //   518: aload_1
/*     */     //   519: iload #4
/*     */     //   521: aload_0
/*     */     //   522: getfield upValues : [Lorg/luaj/vm2/UpValue;
/*     */     //   525: iload_3
/*     */     //   526: bipush #23
/*     */     //   528: iushr
/*     */     //   529: aaload
/*     */     //   530: invokevirtual getValue : ()Lorg/luaj/vm2/LuaValue;
/*     */     //   533: iload_3
/*     */     //   534: bipush #14
/*     */     //   536: ishr
/*     */     //   537: sipush #511
/*     */     //   540: iand
/*     */     //   541: dup
/*     */     //   542: istore #6
/*     */     //   544: sipush #255
/*     */     //   547: if_icmple -> 562
/*     */     //   550: aload #12
/*     */     //   552: iload #6
/*     */     //   554: sipush #255
/*     */     //   557: iand
/*     */     //   558: aaload
/*     */     //   559: goto -> 566
/*     */     //   562: aload_1
/*     */     //   563: iload #6
/*     */     //   565: aaload
/*     */     //   566: invokevirtual get : (Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   569: aastore
/*     */     //   570: goto -> 3849
/*     */     //   573: aload_1
/*     */     //   574: iload #4
/*     */     //   576: aload_1
/*     */     //   577: iload_3
/*     */     //   578: bipush #23
/*     */     //   580: iushr
/*     */     //   581: aaload
/*     */     //   582: iload_3
/*     */     //   583: bipush #14
/*     */     //   585: ishr
/*     */     //   586: sipush #511
/*     */     //   589: iand
/*     */     //   590: dup
/*     */     //   591: istore #6
/*     */     //   593: sipush #255
/*     */     //   596: if_icmple -> 611
/*     */     //   599: aload #12
/*     */     //   601: iload #6
/*     */     //   603: sipush #255
/*     */     //   606: iand
/*     */     //   607: aaload
/*     */     //   608: goto -> 615
/*     */     //   611: aload_1
/*     */     //   612: iload #6
/*     */     //   614: aaload
/*     */     //   615: invokevirtual get : (Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   618: aastore
/*     */     //   619: goto -> 3849
/*     */     //   622: aload_0
/*     */     //   623: getfield upValues : [Lorg/luaj/vm2/UpValue;
/*     */     //   626: iload #4
/*     */     //   628: aaload
/*     */     //   629: invokevirtual getValue : ()Lorg/luaj/vm2/LuaValue;
/*     */     //   632: iload_3
/*     */     //   633: bipush #23
/*     */     //   635: iushr
/*     */     //   636: dup
/*     */     //   637: istore #5
/*     */     //   639: sipush #255
/*     */     //   642: if_icmple -> 657
/*     */     //   645: aload #12
/*     */     //   647: iload #5
/*     */     //   649: sipush #255
/*     */     //   652: iand
/*     */     //   653: aaload
/*     */     //   654: goto -> 661
/*     */     //   657: aload_1
/*     */     //   658: iload #5
/*     */     //   660: aaload
/*     */     //   661: iload_3
/*     */     //   662: bipush #14
/*     */     //   664: ishr
/*     */     //   665: sipush #511
/*     */     //   668: iand
/*     */     //   669: dup
/*     */     //   670: istore #6
/*     */     //   672: sipush #255
/*     */     //   675: if_icmple -> 690
/*     */     //   678: aload #12
/*     */     //   680: iload #6
/*     */     //   682: sipush #255
/*     */     //   685: iand
/*     */     //   686: aaload
/*     */     //   687: goto -> 694
/*     */     //   690: aload_1
/*     */     //   691: iload #6
/*     */     //   693: aaload
/*     */     //   694: invokevirtual set : (Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V
/*     */     //   697: goto -> 3849
/*     */     //   700: aload_0
/*     */     //   701: getfield upValues : [Lorg/luaj/vm2/UpValue;
/*     */     //   704: iload_3
/*     */     //   705: bipush #23
/*     */     //   707: iushr
/*     */     //   708: aaload
/*     */     //   709: aload_1
/*     */     //   710: iload #4
/*     */     //   712: aaload
/*     */     //   713: invokevirtual setValue : (Lorg/luaj/vm2/LuaValue;)V
/*     */     //   716: goto -> 3849
/*     */     //   719: aload_1
/*     */     //   720: iload #4
/*     */     //   722: aaload
/*     */     //   723: iload_3
/*     */     //   724: bipush #23
/*     */     //   726: iushr
/*     */     //   727: dup
/*     */     //   728: istore #5
/*     */     //   730: sipush #255
/*     */     //   733: if_icmple -> 748
/*     */     //   736: aload #12
/*     */     //   738: iload #5
/*     */     //   740: sipush #255
/*     */     //   743: iand
/*     */     //   744: aaload
/*     */     //   745: goto -> 752
/*     */     //   748: aload_1
/*     */     //   749: iload #5
/*     */     //   751: aaload
/*     */     //   752: iload_3
/*     */     //   753: bipush #14
/*     */     //   755: ishr
/*     */     //   756: sipush #511
/*     */     //   759: iand
/*     */     //   760: dup
/*     */     //   761: istore #6
/*     */     //   763: sipush #255
/*     */     //   766: if_icmple -> 781
/*     */     //   769: aload #12
/*     */     //   771: iload #6
/*     */     //   773: sipush #255
/*     */     //   776: iand
/*     */     //   777: aaload
/*     */     //   778: goto -> 785
/*     */     //   781: aload_1
/*     */     //   782: iload #6
/*     */     //   784: aaload
/*     */     //   785: invokevirtual set : (Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V
/*     */     //   788: goto -> 3849
/*     */     //   791: aload_1
/*     */     //   792: iload #4
/*     */     //   794: new org/luaj/vm2/LuaTable
/*     */     //   797: dup
/*     */     //   798: iload_3
/*     */     //   799: bipush #23
/*     */     //   801: iushr
/*     */     //   802: iload_3
/*     */     //   803: bipush #14
/*     */     //   805: ishr
/*     */     //   806: sipush #511
/*     */     //   809: iand
/*     */     //   810: invokespecial <init> : (II)V
/*     */     //   813: aastore
/*     */     //   814: goto -> 3849
/*     */     //   817: aload_1
/*     */     //   818: iload #4
/*     */     //   820: iconst_1
/*     */     //   821: iadd
/*     */     //   822: aload_1
/*     */     //   823: iload_3
/*     */     //   824: bipush #23
/*     */     //   826: iushr
/*     */     //   827: aaload
/*     */     //   828: dup
/*     */     //   829: astore #9
/*     */     //   831: aastore
/*     */     //   832: aload_1
/*     */     //   833: iload #4
/*     */     //   835: aload #9
/*     */     //   837: iload_3
/*     */     //   838: bipush #14
/*     */     //   840: ishr
/*     */     //   841: sipush #511
/*     */     //   844: iand
/*     */     //   845: dup
/*     */     //   846: istore #6
/*     */     //   848: sipush #255
/*     */     //   851: if_icmple -> 866
/*     */     //   854: aload #12
/*     */     //   856: iload #6
/*     */     //   858: sipush #255
/*     */     //   861: iand
/*     */     //   862: aaload
/*     */     //   863: goto -> 870
/*     */     //   866: aload_1
/*     */     //   867: iload #6
/*     */     //   869: aaload
/*     */     //   870: invokevirtual get : (Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   873: aastore
/*     */     //   874: goto -> 3849
/*     */     //   877: aload_1
/*     */     //   878: iload #4
/*     */     //   880: iload_3
/*     */     //   881: bipush #23
/*     */     //   883: iushr
/*     */     //   884: dup
/*     */     //   885: istore #5
/*     */     //   887: sipush #255
/*     */     //   890: if_icmple -> 905
/*     */     //   893: aload #12
/*     */     //   895: iload #5
/*     */     //   897: sipush #255
/*     */     //   900: iand
/*     */     //   901: aaload
/*     */     //   902: goto -> 909
/*     */     //   905: aload_1
/*     */     //   906: iload #5
/*     */     //   908: aaload
/*     */     //   909: iload_3
/*     */     //   910: bipush #14
/*     */     //   912: ishr
/*     */     //   913: sipush #511
/*     */     //   916: iand
/*     */     //   917: dup
/*     */     //   918: istore #6
/*     */     //   920: sipush #255
/*     */     //   923: if_icmple -> 938
/*     */     //   926: aload #12
/*     */     //   928: iload #6
/*     */     //   930: sipush #255
/*     */     //   933: iand
/*     */     //   934: aaload
/*     */     //   935: goto -> 942
/*     */     //   938: aload_1
/*     */     //   939: iload #6
/*     */     //   941: aaload
/*     */     //   942: invokevirtual add : (Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   945: aastore
/*     */     //   946: goto -> 3849
/*     */     //   949: aload_1
/*     */     //   950: iload #4
/*     */     //   952: iload_3
/*     */     //   953: bipush #23
/*     */     //   955: iushr
/*     */     //   956: dup
/*     */     //   957: istore #5
/*     */     //   959: sipush #255
/*     */     //   962: if_icmple -> 977
/*     */     //   965: aload #12
/*     */     //   967: iload #5
/*     */     //   969: sipush #255
/*     */     //   972: iand
/*     */     //   973: aaload
/*     */     //   974: goto -> 981
/*     */     //   977: aload_1
/*     */     //   978: iload #5
/*     */     //   980: aaload
/*     */     //   981: iload_3
/*     */     //   982: bipush #14
/*     */     //   984: ishr
/*     */     //   985: sipush #511
/*     */     //   988: iand
/*     */     //   989: dup
/*     */     //   990: istore #6
/*     */     //   992: sipush #255
/*     */     //   995: if_icmple -> 1010
/*     */     //   998: aload #12
/*     */     //   1000: iload #6
/*     */     //   1002: sipush #255
/*     */     //   1005: iand
/*     */     //   1006: aaload
/*     */     //   1007: goto -> 1014
/*     */     //   1010: aload_1
/*     */     //   1011: iload #6
/*     */     //   1013: aaload
/*     */     //   1014: invokevirtual sub : (Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   1017: aastore
/*     */     //   1018: goto -> 3849
/*     */     //   1021: aload_1
/*     */     //   1022: iload #4
/*     */     //   1024: iload_3
/*     */     //   1025: bipush #23
/*     */     //   1027: iushr
/*     */     //   1028: dup
/*     */     //   1029: istore #5
/*     */     //   1031: sipush #255
/*     */     //   1034: if_icmple -> 1049
/*     */     //   1037: aload #12
/*     */     //   1039: iload #5
/*     */     //   1041: sipush #255
/*     */     //   1044: iand
/*     */     //   1045: aaload
/*     */     //   1046: goto -> 1053
/*     */     //   1049: aload_1
/*     */     //   1050: iload #5
/*     */     //   1052: aaload
/*     */     //   1053: iload_3
/*     */     //   1054: bipush #14
/*     */     //   1056: ishr
/*     */     //   1057: sipush #511
/*     */     //   1060: iand
/*     */     //   1061: dup
/*     */     //   1062: istore #6
/*     */     //   1064: sipush #255
/*     */     //   1067: if_icmple -> 1082
/*     */     //   1070: aload #12
/*     */     //   1072: iload #6
/*     */     //   1074: sipush #255
/*     */     //   1077: iand
/*     */     //   1078: aaload
/*     */     //   1079: goto -> 1086
/*     */     //   1082: aload_1
/*     */     //   1083: iload #6
/*     */     //   1085: aaload
/*     */     //   1086: invokevirtual mul : (Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   1089: aastore
/*     */     //   1090: goto -> 3849
/*     */     //   1093: aload_1
/*     */     //   1094: iload #4
/*     */     //   1096: iload_3
/*     */     //   1097: bipush #23
/*     */     //   1099: iushr
/*     */     //   1100: dup
/*     */     //   1101: istore #5
/*     */     //   1103: sipush #255
/*     */     //   1106: if_icmple -> 1121
/*     */     //   1109: aload #12
/*     */     //   1111: iload #5
/*     */     //   1113: sipush #255
/*     */     //   1116: iand
/*     */     //   1117: aaload
/*     */     //   1118: goto -> 1125
/*     */     //   1121: aload_1
/*     */     //   1122: iload #5
/*     */     //   1124: aaload
/*     */     //   1125: iload_3
/*     */     //   1126: bipush #14
/*     */     //   1128: ishr
/*     */     //   1129: sipush #511
/*     */     //   1132: iand
/*     */     //   1133: dup
/*     */     //   1134: istore #6
/*     */     //   1136: sipush #255
/*     */     //   1139: if_icmple -> 1154
/*     */     //   1142: aload #12
/*     */     //   1144: iload #6
/*     */     //   1146: sipush #255
/*     */     //   1149: iand
/*     */     //   1150: aaload
/*     */     //   1151: goto -> 1158
/*     */     //   1154: aload_1
/*     */     //   1155: iload #6
/*     */     //   1157: aaload
/*     */     //   1158: invokevirtual div : (Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   1161: aastore
/*     */     //   1162: goto -> 3849
/*     */     //   1165: aload_1
/*     */     //   1166: iload #4
/*     */     //   1168: iload_3
/*     */     //   1169: bipush #23
/*     */     //   1171: iushr
/*     */     //   1172: dup
/*     */     //   1173: istore #5
/*     */     //   1175: sipush #255
/*     */     //   1178: if_icmple -> 1193
/*     */     //   1181: aload #12
/*     */     //   1183: iload #5
/*     */     //   1185: sipush #255
/*     */     //   1188: iand
/*     */     //   1189: aaload
/*     */     //   1190: goto -> 1197
/*     */     //   1193: aload_1
/*     */     //   1194: iload #5
/*     */     //   1196: aaload
/*     */     //   1197: iload_3
/*     */     //   1198: bipush #14
/*     */     //   1200: ishr
/*     */     //   1201: sipush #511
/*     */     //   1204: iand
/*     */     //   1205: dup
/*     */     //   1206: istore #6
/*     */     //   1208: sipush #255
/*     */     //   1211: if_icmple -> 1226
/*     */     //   1214: aload #12
/*     */     //   1216: iload #6
/*     */     //   1218: sipush #255
/*     */     //   1221: iand
/*     */     //   1222: aaload
/*     */     //   1223: goto -> 1230
/*     */     //   1226: aload_1
/*     */     //   1227: iload #6
/*     */     //   1229: aaload
/*     */     //   1230: invokevirtual mod : (Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   1233: aastore
/*     */     //   1234: goto -> 3849
/*     */     //   1237: aload_1
/*     */     //   1238: iload #4
/*     */     //   1240: iload_3
/*     */     //   1241: bipush #23
/*     */     //   1243: iushr
/*     */     //   1244: dup
/*     */     //   1245: istore #5
/*     */     //   1247: sipush #255
/*     */     //   1250: if_icmple -> 1265
/*     */     //   1253: aload #12
/*     */     //   1255: iload #5
/*     */     //   1257: sipush #255
/*     */     //   1260: iand
/*     */     //   1261: aaload
/*     */     //   1262: goto -> 1269
/*     */     //   1265: aload_1
/*     */     //   1266: iload #5
/*     */     //   1268: aaload
/*     */     //   1269: iload_3
/*     */     //   1270: bipush #14
/*     */     //   1272: ishr
/*     */     //   1273: sipush #511
/*     */     //   1276: iand
/*     */     //   1277: dup
/*     */     //   1278: istore #6
/*     */     //   1280: sipush #255
/*     */     //   1283: if_icmple -> 1298
/*     */     //   1286: aload #12
/*     */     //   1288: iload #6
/*     */     //   1290: sipush #255
/*     */     //   1293: iand
/*     */     //   1294: aaload
/*     */     //   1295: goto -> 1302
/*     */     //   1298: aload_1
/*     */     //   1299: iload #6
/*     */     //   1301: aaload
/*     */     //   1302: invokevirtual pow : (Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   1305: aastore
/*     */     //   1306: goto -> 3849
/*     */     //   1309: aload_1
/*     */     //   1310: iload #4
/*     */     //   1312: aload_1
/*     */     //   1313: iload_3
/*     */     //   1314: bipush #23
/*     */     //   1316: iushr
/*     */     //   1317: aaload
/*     */     //   1318: invokevirtual neg : ()Lorg/luaj/vm2/LuaValue;
/*     */     //   1321: aastore
/*     */     //   1322: goto -> 3849
/*     */     //   1325: aload_1
/*     */     //   1326: iload #4
/*     */     //   1328: aload_1
/*     */     //   1329: iload_3
/*     */     //   1330: bipush #23
/*     */     //   1332: iushr
/*     */     //   1333: aaload
/*     */     //   1334: invokevirtual not : ()Lorg/luaj/vm2/LuaValue;
/*     */     //   1337: aastore
/*     */     //   1338: goto -> 3849
/*     */     //   1341: aload_1
/*     */     //   1342: iload #4
/*     */     //   1344: aload_1
/*     */     //   1345: iload_3
/*     */     //   1346: bipush #23
/*     */     //   1348: iushr
/*     */     //   1349: aaload
/*     */     //   1350: invokevirtual len : ()Lorg/luaj/vm2/LuaValue;
/*     */     //   1353: aastore
/*     */     //   1354: goto -> 3849
/*     */     //   1357: iload_3
/*     */     //   1358: bipush #23
/*     */     //   1360: iushr
/*     */     //   1361: istore #5
/*     */     //   1363: iload_3
/*     */     //   1364: bipush #14
/*     */     //   1366: ishr
/*     */     //   1367: sipush #511
/*     */     //   1370: iand
/*     */     //   1371: istore #6
/*     */     //   1373: iload #6
/*     */     //   1375: iload #5
/*     */     //   1377: iconst_1
/*     */     //   1378: iadd
/*     */     //   1379: if_icmple -> 1426
/*     */     //   1382: aload_1
/*     */     //   1383: iload #6
/*     */     //   1385: aaload
/*     */     //   1386: invokevirtual buffer : ()Lorg/luaj/vm2/Buffer;
/*     */     //   1389: astore #14
/*     */     //   1391: iinc #6, -1
/*     */     //   1394: iload #6
/*     */     //   1396: iload #5
/*     */     //   1398: if_icmplt -> 1414
/*     */     //   1401: aload #14
/*     */     //   1403: aload_1
/*     */     //   1404: iload #6
/*     */     //   1406: aaload
/*     */     //   1407: invokevirtual concatTo : (Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/Buffer;
/*     */     //   1410: pop
/*     */     //   1411: goto -> 1391
/*     */     //   1414: aload_1
/*     */     //   1415: iload #4
/*     */     //   1417: aload #14
/*     */     //   1419: invokevirtual value : ()Lorg/luaj/vm2/LuaValue;
/*     */     //   1422: aastore
/*     */     //   1423: goto -> 3849
/*     */     //   1426: aload_1
/*     */     //   1427: iload #4
/*     */     //   1429: aload_1
/*     */     //   1430: iload #6
/*     */     //   1432: iconst_1
/*     */     //   1433: isub
/*     */     //   1434: aaload
/*     */     //   1435: aload_1
/*     */     //   1436: iload #6
/*     */     //   1438: aaload
/*     */     //   1439: invokevirtual concat : (Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   1442: aastore
/*     */     //   1443: goto -> 3849
/*     */     //   1446: iload #7
/*     */     //   1448: iload_3
/*     */     //   1449: bipush #14
/*     */     //   1451: iushr
/*     */     //   1452: ldc 131071
/*     */     //   1454: isub
/*     */     //   1455: iadd
/*     */     //   1456: istore #7
/*     */     //   1458: iload #4
/*     */     //   1460: ifle -> 3849
/*     */     //   1463: iinc #4, -1
/*     */     //   1466: aload #13
/*     */     //   1468: arraylength
/*     */     //   1469: istore #5
/*     */     //   1471: iinc #5, -1
/*     */     //   1474: iload #5
/*     */     //   1476: iflt -> 3849
/*     */     //   1479: aload #13
/*     */     //   1481: iload #5
/*     */     //   1483: aaload
/*     */     //   1484: ifnull -> 1471
/*     */     //   1487: aload #13
/*     */     //   1489: iload #5
/*     */     //   1491: aaload
/*     */     //   1492: getfield index : I
/*     */     //   1495: iload #4
/*     */     //   1497: if_icmplt -> 1471
/*     */     //   1500: aload #13
/*     */     //   1502: iload #5
/*     */     //   1504: aaload
/*     */     //   1505: invokevirtual close : ()V
/*     */     //   1508: aload #13
/*     */     //   1510: iload #5
/*     */     //   1512: aconst_null
/*     */     //   1513: aastore
/*     */     //   1514: goto -> 1471
/*     */     //   1517: iload_3
/*     */     //   1518: bipush #23
/*     */     //   1520: iushr
/*     */     //   1521: dup
/*     */     //   1522: istore #5
/*     */     //   1524: sipush #255
/*     */     //   1527: if_icmple -> 1542
/*     */     //   1530: aload #12
/*     */     //   1532: iload #5
/*     */     //   1534: sipush #255
/*     */     //   1537: iand
/*     */     //   1538: aaload
/*     */     //   1539: goto -> 1546
/*     */     //   1542: aload_1
/*     */     //   1543: iload #5
/*     */     //   1545: aaload
/*     */     //   1546: iload_3
/*     */     //   1547: bipush #14
/*     */     //   1549: ishr
/*     */     //   1550: sipush #511
/*     */     //   1553: iand
/*     */     //   1554: dup
/*     */     //   1555: istore #6
/*     */     //   1557: sipush #255
/*     */     //   1560: if_icmple -> 1575
/*     */     //   1563: aload #12
/*     */     //   1565: iload #6
/*     */     //   1567: sipush #255
/*     */     //   1570: iand
/*     */     //   1571: aaload
/*     */     //   1572: goto -> 1579
/*     */     //   1575: aload_1
/*     */     //   1576: iload #6
/*     */     //   1578: aaload
/*     */     //   1579: invokevirtual eq_b : (Lorg/luaj/vm2/LuaValue;)Z
/*     */     //   1582: iload #4
/*     */     //   1584: ifeq -> 1591
/*     */     //   1587: iconst_1
/*     */     //   1588: goto -> 1592
/*     */     //   1591: iconst_0
/*     */     //   1592: if_icmpeq -> 3849
/*     */     //   1595: iinc #7, 1
/*     */     //   1598: goto -> 3849
/*     */     //   1601: iload_3
/*     */     //   1602: bipush #23
/*     */     //   1604: iushr
/*     */     //   1605: dup
/*     */     //   1606: istore #5
/*     */     //   1608: sipush #255
/*     */     //   1611: if_icmple -> 1626
/*     */     //   1614: aload #12
/*     */     //   1616: iload #5
/*     */     //   1618: sipush #255
/*     */     //   1621: iand
/*     */     //   1622: aaload
/*     */     //   1623: goto -> 1630
/*     */     //   1626: aload_1
/*     */     //   1627: iload #5
/*     */     //   1629: aaload
/*     */     //   1630: iload_3
/*     */     //   1631: bipush #14
/*     */     //   1633: ishr
/*     */     //   1634: sipush #511
/*     */     //   1637: iand
/*     */     //   1638: dup
/*     */     //   1639: istore #6
/*     */     //   1641: sipush #255
/*     */     //   1644: if_icmple -> 1659
/*     */     //   1647: aload #12
/*     */     //   1649: iload #6
/*     */     //   1651: sipush #255
/*     */     //   1654: iand
/*     */     //   1655: aaload
/*     */     //   1656: goto -> 1663
/*     */     //   1659: aload_1
/*     */     //   1660: iload #6
/*     */     //   1662: aaload
/*     */     //   1663: invokevirtual lt_b : (Lorg/luaj/vm2/LuaValue;)Z
/*     */     //   1666: iload #4
/*     */     //   1668: ifeq -> 1675
/*     */     //   1671: iconst_1
/*     */     //   1672: goto -> 1676
/*     */     //   1675: iconst_0
/*     */     //   1676: if_icmpeq -> 3849
/*     */     //   1679: iinc #7, 1
/*     */     //   1682: goto -> 3849
/*     */     //   1685: iload_3
/*     */     //   1686: bipush #23
/*     */     //   1688: iushr
/*     */     //   1689: dup
/*     */     //   1690: istore #5
/*     */     //   1692: sipush #255
/*     */     //   1695: if_icmple -> 1710
/*     */     //   1698: aload #12
/*     */     //   1700: iload #5
/*     */     //   1702: sipush #255
/*     */     //   1705: iand
/*     */     //   1706: aaload
/*     */     //   1707: goto -> 1714
/*     */     //   1710: aload_1
/*     */     //   1711: iload #5
/*     */     //   1713: aaload
/*     */     //   1714: iload_3
/*     */     //   1715: bipush #14
/*     */     //   1717: ishr
/*     */     //   1718: sipush #511
/*     */     //   1721: iand
/*     */     //   1722: dup
/*     */     //   1723: istore #6
/*     */     //   1725: sipush #255
/*     */     //   1728: if_icmple -> 1743
/*     */     //   1731: aload #12
/*     */     //   1733: iload #6
/*     */     //   1735: sipush #255
/*     */     //   1738: iand
/*     */     //   1739: aaload
/*     */     //   1740: goto -> 1747
/*     */     //   1743: aload_1
/*     */     //   1744: iload #6
/*     */     //   1746: aaload
/*     */     //   1747: invokevirtual lteq_b : (Lorg/luaj/vm2/LuaValue;)Z
/*     */     //   1750: iload #4
/*     */     //   1752: ifeq -> 1759
/*     */     //   1755: iconst_1
/*     */     //   1756: goto -> 1760
/*     */     //   1759: iconst_0
/*     */     //   1760: if_icmpeq -> 3849
/*     */     //   1763: iinc #7, 1
/*     */     //   1766: goto -> 3849
/*     */     //   1769: aload_1
/*     */     //   1770: iload #4
/*     */     //   1772: aaload
/*     */     //   1773: invokevirtual toboolean : ()Z
/*     */     //   1776: iload_3
/*     */     //   1777: ldc 8372224
/*     */     //   1779: iand
/*     */     //   1780: ifeq -> 1787
/*     */     //   1783: iconst_1
/*     */     //   1784: goto -> 1788
/*     */     //   1787: iconst_0
/*     */     //   1788: if_icmpeq -> 3849
/*     */     //   1791: iinc #7, 1
/*     */     //   1794: goto -> 3849
/*     */     //   1797: aload_1
/*     */     //   1798: iload_3
/*     */     //   1799: bipush #23
/*     */     //   1801: iushr
/*     */     //   1802: aaload
/*     */     //   1803: dup
/*     */     //   1804: astore #9
/*     */     //   1806: invokevirtual toboolean : ()Z
/*     */     //   1809: iload_3
/*     */     //   1810: ldc 8372224
/*     */     //   1812: iand
/*     */     //   1813: ifeq -> 1820
/*     */     //   1816: iconst_1
/*     */     //   1817: goto -> 1821
/*     */     //   1820: iconst_0
/*     */     //   1821: if_icmpeq -> 1830
/*     */     //   1824: iinc #7, 1
/*     */     //   1827: goto -> 3849
/*     */     //   1830: aload_1
/*     */     //   1831: iload #4
/*     */     //   1833: aload #9
/*     */     //   1835: aastore
/*     */     //   1836: goto -> 3849
/*     */     //   1839: iload_3
/*     */     //   1840: sipush #-16384
/*     */     //   1843: iand
/*     */     //   1844: lookupswitch default -> 2161, 8388608 -> 1936, 8404992 -> 1989, 8421376 -> 2069, 16777216 -> 1961, 16793600 -> 2000, 16809984 -> 2083, 25182208 -> 2017, 25198592 -> 2103, 33570816 -> 2040, 33587200 -> 2129
/*     */     //   1936: aload_1
/*     */     //   1937: iload #4
/*     */     //   1939: aaload
/*     */     //   1940: getstatic org/luaj/vm2/LuaClosure.NONE : Lorg/luaj/vm2/LuaValue;
/*     */     //   1943: invokevirtual invoke : (Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
/*     */     //   1946: astore #10
/*     */     //   1948: iload #4
/*     */     //   1950: aload #10
/*     */     //   1952: invokevirtual narg : ()I
/*     */     //   1955: iadd
/*     */     //   1956: istore #8
/*     */     //   1958: goto -> 3849
/*     */     //   1961: aload_1
/*     */     //   1962: iload #4
/*     */     //   1964: aaload
/*     */     //   1965: aload_1
/*     */     //   1966: iload #4
/*     */     //   1968: iconst_1
/*     */     //   1969: iadd
/*     */     //   1970: aaload
/*     */     //   1971: invokevirtual invoke : (Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
/*     */     //   1974: astore #10
/*     */     //   1976: iload #4
/*     */     //   1978: aload #10
/*     */     //   1980: invokevirtual narg : ()I
/*     */     //   1983: iadd
/*     */     //   1984: istore #8
/*     */     //   1986: goto -> 3849
/*     */     //   1989: aload_1
/*     */     //   1990: iload #4
/*     */     //   1992: aaload
/*     */     //   1993: invokevirtual call : ()Lorg/luaj/vm2/LuaValue;
/*     */     //   1996: pop
/*     */     //   1997: goto -> 3849
/*     */     //   2000: aload_1
/*     */     //   2001: iload #4
/*     */     //   2003: aaload
/*     */     //   2004: aload_1
/*     */     //   2005: iload #4
/*     */     //   2007: iconst_1
/*     */     //   2008: iadd
/*     */     //   2009: aaload
/*     */     //   2010: invokevirtual call : (Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   2013: pop
/*     */     //   2014: goto -> 3849
/*     */     //   2017: aload_1
/*     */     //   2018: iload #4
/*     */     //   2020: aaload
/*     */     //   2021: aload_1
/*     */     //   2022: iload #4
/*     */     //   2024: iconst_1
/*     */     //   2025: iadd
/*     */     //   2026: aaload
/*     */     //   2027: aload_1
/*     */     //   2028: iload #4
/*     */     //   2030: iconst_2
/*     */     //   2031: iadd
/*     */     //   2032: aaload
/*     */     //   2033: invokevirtual call : (Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   2036: pop
/*     */     //   2037: goto -> 3849
/*     */     //   2040: aload_1
/*     */     //   2041: iload #4
/*     */     //   2043: aaload
/*     */     //   2044: aload_1
/*     */     //   2045: iload #4
/*     */     //   2047: iconst_1
/*     */     //   2048: iadd
/*     */     //   2049: aaload
/*     */     //   2050: aload_1
/*     */     //   2051: iload #4
/*     */     //   2053: iconst_2
/*     */     //   2054: iadd
/*     */     //   2055: aaload
/*     */     //   2056: aload_1
/*     */     //   2057: iload #4
/*     */     //   2059: iconst_3
/*     */     //   2060: iadd
/*     */     //   2061: aaload
/*     */     //   2062: invokevirtual call : (Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   2065: pop
/*     */     //   2066: goto -> 3849
/*     */     //   2069: aload_1
/*     */     //   2070: iload #4
/*     */     //   2072: aload_1
/*     */     //   2073: iload #4
/*     */     //   2075: aaload
/*     */     //   2076: invokevirtual call : ()Lorg/luaj/vm2/LuaValue;
/*     */     //   2079: aastore
/*     */     //   2080: goto -> 3849
/*     */     //   2083: aload_1
/*     */     //   2084: iload #4
/*     */     //   2086: aload_1
/*     */     //   2087: iload #4
/*     */     //   2089: aaload
/*     */     //   2090: aload_1
/*     */     //   2091: iload #4
/*     */     //   2093: iconst_1
/*     */     //   2094: iadd
/*     */     //   2095: aaload
/*     */     //   2096: invokevirtual call : (Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   2099: aastore
/*     */     //   2100: goto -> 3849
/*     */     //   2103: aload_1
/*     */     //   2104: iload #4
/*     */     //   2106: aload_1
/*     */     //   2107: iload #4
/*     */     //   2109: aaload
/*     */     //   2110: aload_1
/*     */     //   2111: iload #4
/*     */     //   2113: iconst_1
/*     */     //   2114: iadd
/*     */     //   2115: aaload
/*     */     //   2116: aload_1
/*     */     //   2117: iload #4
/*     */     //   2119: iconst_2
/*     */     //   2120: iadd
/*     */     //   2121: aaload
/*     */     //   2122: invokevirtual call : (Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   2125: aastore
/*     */     //   2126: goto -> 3849
/*     */     //   2129: aload_1
/*     */     //   2130: iload #4
/*     */     //   2132: aload_1
/*     */     //   2133: iload #4
/*     */     //   2135: aaload
/*     */     //   2136: aload_1
/*     */     //   2137: iload #4
/*     */     //   2139: iconst_1
/*     */     //   2140: iadd
/*     */     //   2141: aaload
/*     */     //   2142: aload_1
/*     */     //   2143: iload #4
/*     */     //   2145: iconst_2
/*     */     //   2146: iadd
/*     */     //   2147: aaload
/*     */     //   2148: aload_1
/*     */     //   2149: iload #4
/*     */     //   2151: iconst_3
/*     */     //   2152: iadd
/*     */     //   2153: aaload
/*     */     //   2154: invokevirtual call : (Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   2157: aastore
/*     */     //   2158: goto -> 3849
/*     */     //   2161: iload_3
/*     */     //   2162: bipush #23
/*     */     //   2164: iushr
/*     */     //   2165: istore #5
/*     */     //   2167: iload_3
/*     */     //   2168: bipush #14
/*     */     //   2170: ishr
/*     */     //   2171: sipush #511
/*     */     //   2174: iand
/*     */     //   2175: istore #6
/*     */     //   2177: aload_1
/*     */     //   2178: iload #4
/*     */     //   2180: aaload
/*     */     //   2181: iload #5
/*     */     //   2183: ifle -> 2201
/*     */     //   2186: aload_1
/*     */     //   2187: iload #4
/*     */     //   2189: iconst_1
/*     */     //   2190: iadd
/*     */     //   2191: iload #5
/*     */     //   2193: iconst_1
/*     */     //   2194: isub
/*     */     //   2195: invokestatic varargsOf : ([Lorg/luaj/vm2/LuaValue;II)Lorg/luaj/vm2/Varargs;
/*     */     //   2198: goto -> 2224
/*     */     //   2201: aload_1
/*     */     //   2202: iload #4
/*     */     //   2204: iconst_1
/*     */     //   2205: iadd
/*     */     //   2206: iload #8
/*     */     //   2208: aload #10
/*     */     //   2210: invokevirtual narg : ()I
/*     */     //   2213: isub
/*     */     //   2214: iload #4
/*     */     //   2216: iconst_1
/*     */     //   2217: iadd
/*     */     //   2218: isub
/*     */     //   2219: aload #10
/*     */     //   2221: invokestatic varargsOf : ([Lorg/luaj/vm2/LuaValue;IILorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
/*     */     //   2224: invokevirtual invoke : (Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
/*     */     //   2227: astore #10
/*     */     //   2229: iload #6
/*     */     //   2231: ifle -> 2254
/*     */     //   2234: aload #10
/*     */     //   2236: aload_1
/*     */     //   2237: iload #4
/*     */     //   2239: iload #6
/*     */     //   2241: iconst_1
/*     */     //   2242: isub
/*     */     //   2243: invokevirtual copyto : ([Lorg/luaj/vm2/LuaValue;II)V
/*     */     //   2246: getstatic org/luaj/vm2/LuaClosure.NONE : Lorg/luaj/vm2/LuaValue;
/*     */     //   2249: astore #10
/*     */     //   2251: goto -> 3849
/*     */     //   2254: iload #4
/*     */     //   2256: aload #10
/*     */     //   2258: invokevirtual narg : ()I
/*     */     //   2261: iadd
/*     */     //   2262: istore #8
/*     */     //   2264: aload #10
/*     */     //   2266: invokevirtual dealias : ()Lorg/luaj/vm2/Varargs;
/*     */     //   2269: astore #10
/*     */     //   2271: goto -> 3849
/*     */     //   2274: iload_3
/*     */     //   2275: ldc -8388608
/*     */     //   2277: iand
/*     */     //   2278: lookupswitch default -> 2685, 8388608 -> 2320, 16777216 -> 2403, 25165824 -> 2489, 33554432 -> 2584
/*     */     //   2320: new org/luaj/vm2/TailcallVarargs
/*     */     //   2323: dup
/*     */     //   2324: aload_1
/*     */     //   2325: iload #4
/*     */     //   2327: aaload
/*     */     //   2328: getstatic org/luaj/vm2/LuaClosure.NONE : Lorg/luaj/vm2/LuaValue;
/*     */     //   2331: invokespecial <init> : (Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/Varargs;)V
/*     */     //   2334: astore #14
/*     */     //   2336: aload #13
/*     */     //   2338: ifnull -> 2373
/*     */     //   2341: aload #13
/*     */     //   2343: arraylength
/*     */     //   2344: istore #15
/*     */     //   2346: iinc #15, -1
/*     */     //   2349: iload #15
/*     */     //   2351: iflt -> 2373
/*     */     //   2354: aload #13
/*     */     //   2356: iload #15
/*     */     //   2358: aaload
/*     */     //   2359: ifnull -> 2346
/*     */     //   2362: aload #13
/*     */     //   2364: iload #15
/*     */     //   2366: aaload
/*     */     //   2367: invokevirtual close : ()V
/*     */     //   2370: goto -> 2346
/*     */     //   2373: aload_0
/*     */     //   2374: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2377: ifnull -> 2400
/*     */     //   2380: aload_0
/*     */     //   2381: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2384: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   2387: ifnull -> 2400
/*     */     //   2390: aload_0
/*     */     //   2391: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2394: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   2397: invokevirtual onReturn : ()V
/*     */     //   2400: aload #14
/*     */     //   2402: areturn
/*     */     //   2403: new org/luaj/vm2/TailcallVarargs
/*     */     //   2406: dup
/*     */     //   2407: aload_1
/*     */     //   2408: iload #4
/*     */     //   2410: aaload
/*     */     //   2411: aload_1
/*     */     //   2412: iload #4
/*     */     //   2414: iconst_1
/*     */     //   2415: iadd
/*     */     //   2416: aaload
/*     */     //   2417: invokespecial <init> : (Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/Varargs;)V
/*     */     //   2420: astore #14
/*     */     //   2422: aload #13
/*     */     //   2424: ifnull -> 2459
/*     */     //   2427: aload #13
/*     */     //   2429: arraylength
/*     */     //   2430: istore #15
/*     */     //   2432: iinc #15, -1
/*     */     //   2435: iload #15
/*     */     //   2437: iflt -> 2459
/*     */     //   2440: aload #13
/*     */     //   2442: iload #15
/*     */     //   2444: aaload
/*     */     //   2445: ifnull -> 2432
/*     */     //   2448: aload #13
/*     */     //   2450: iload #15
/*     */     //   2452: aaload
/*     */     //   2453: invokevirtual close : ()V
/*     */     //   2456: goto -> 2432
/*     */     //   2459: aload_0
/*     */     //   2460: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2463: ifnull -> 2486
/*     */     //   2466: aload_0
/*     */     //   2467: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2470: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   2473: ifnull -> 2486
/*     */     //   2476: aload_0
/*     */     //   2477: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2480: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   2483: invokevirtual onReturn : ()V
/*     */     //   2486: aload #14
/*     */     //   2488: areturn
/*     */     //   2489: new org/luaj/vm2/TailcallVarargs
/*     */     //   2492: dup
/*     */     //   2493: aload_1
/*     */     //   2494: iload #4
/*     */     //   2496: aaload
/*     */     //   2497: aload_1
/*     */     //   2498: iload #4
/*     */     //   2500: iconst_1
/*     */     //   2501: iadd
/*     */     //   2502: aaload
/*     */     //   2503: aload_1
/*     */     //   2504: iload #4
/*     */     //   2506: iconst_2
/*     */     //   2507: iadd
/*     */     //   2508: aaload
/*     */     //   2509: invokestatic varargsOf : (Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
/*     */     //   2512: invokespecial <init> : (Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/Varargs;)V
/*     */     //   2515: astore #14
/*     */     //   2517: aload #13
/*     */     //   2519: ifnull -> 2554
/*     */     //   2522: aload #13
/*     */     //   2524: arraylength
/*     */     //   2525: istore #15
/*     */     //   2527: iinc #15, -1
/*     */     //   2530: iload #15
/*     */     //   2532: iflt -> 2554
/*     */     //   2535: aload #13
/*     */     //   2537: iload #15
/*     */     //   2539: aaload
/*     */     //   2540: ifnull -> 2527
/*     */     //   2543: aload #13
/*     */     //   2545: iload #15
/*     */     //   2547: aaload
/*     */     //   2548: invokevirtual close : ()V
/*     */     //   2551: goto -> 2527
/*     */     //   2554: aload_0
/*     */     //   2555: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2558: ifnull -> 2581
/*     */     //   2561: aload_0
/*     */     //   2562: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2565: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   2568: ifnull -> 2581
/*     */     //   2571: aload_0
/*     */     //   2572: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2575: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   2578: invokevirtual onReturn : ()V
/*     */     //   2581: aload #14
/*     */     //   2583: areturn
/*     */     //   2584: new org/luaj/vm2/TailcallVarargs
/*     */     //   2587: dup
/*     */     //   2588: aload_1
/*     */     //   2589: iload #4
/*     */     //   2591: aaload
/*     */     //   2592: aload_1
/*     */     //   2593: iload #4
/*     */     //   2595: iconst_1
/*     */     //   2596: iadd
/*     */     //   2597: aaload
/*     */     //   2598: aload_1
/*     */     //   2599: iload #4
/*     */     //   2601: iconst_2
/*     */     //   2602: iadd
/*     */     //   2603: aaload
/*     */     //   2604: aload_1
/*     */     //   2605: iload #4
/*     */     //   2607: iconst_3
/*     */     //   2608: iadd
/*     */     //   2609: aaload
/*     */     //   2610: invokestatic varargsOf : (Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
/*     */     //   2613: invokespecial <init> : (Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/Varargs;)V
/*     */     //   2616: astore #14
/*     */     //   2618: aload #13
/*     */     //   2620: ifnull -> 2655
/*     */     //   2623: aload #13
/*     */     //   2625: arraylength
/*     */     //   2626: istore #15
/*     */     //   2628: iinc #15, -1
/*     */     //   2631: iload #15
/*     */     //   2633: iflt -> 2655
/*     */     //   2636: aload #13
/*     */     //   2638: iload #15
/*     */     //   2640: aaload
/*     */     //   2641: ifnull -> 2628
/*     */     //   2644: aload #13
/*     */     //   2646: iload #15
/*     */     //   2648: aaload
/*     */     //   2649: invokevirtual close : ()V
/*     */     //   2652: goto -> 2628
/*     */     //   2655: aload_0
/*     */     //   2656: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2659: ifnull -> 2682
/*     */     //   2662: aload_0
/*     */     //   2663: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2666: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   2669: ifnull -> 2682
/*     */     //   2672: aload_0
/*     */     //   2673: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2676: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   2679: invokevirtual onReturn : ()V
/*     */     //   2682: aload #14
/*     */     //   2684: areturn
/*     */     //   2685: iload_3
/*     */     //   2686: bipush #23
/*     */     //   2688: iushr
/*     */     //   2689: istore #5
/*     */     //   2691: iload #5
/*     */     //   2693: ifle -> 2711
/*     */     //   2696: aload_1
/*     */     //   2697: iload #4
/*     */     //   2699: iconst_1
/*     */     //   2700: iadd
/*     */     //   2701: iload #5
/*     */     //   2703: iconst_1
/*     */     //   2704: isub
/*     */     //   2705: invokestatic varargsOf : ([Lorg/luaj/vm2/LuaValue;II)Lorg/luaj/vm2/Varargs;
/*     */     //   2708: goto -> 2734
/*     */     //   2711: aload_1
/*     */     //   2712: iload #4
/*     */     //   2714: iconst_1
/*     */     //   2715: iadd
/*     */     //   2716: iload #8
/*     */     //   2718: aload #10
/*     */     //   2720: invokevirtual narg : ()I
/*     */     //   2723: isub
/*     */     //   2724: iload #4
/*     */     //   2726: iconst_1
/*     */     //   2727: iadd
/*     */     //   2728: isub
/*     */     //   2729: aload #10
/*     */     //   2731: invokestatic varargsOf : ([Lorg/luaj/vm2/LuaValue;IILorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
/*     */     //   2734: astore #10
/*     */     //   2736: new org/luaj/vm2/TailcallVarargs
/*     */     //   2739: dup
/*     */     //   2740: aload_1
/*     */     //   2741: iload #4
/*     */     //   2743: aaload
/*     */     //   2744: aload #10
/*     */     //   2746: invokespecial <init> : (Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/Varargs;)V
/*     */     //   2749: astore #14
/*     */     //   2751: aload #13
/*     */     //   2753: ifnull -> 2788
/*     */     //   2756: aload #13
/*     */     //   2758: arraylength
/*     */     //   2759: istore #15
/*     */     //   2761: iinc #15, -1
/*     */     //   2764: iload #15
/*     */     //   2766: iflt -> 2788
/*     */     //   2769: aload #13
/*     */     //   2771: iload #15
/*     */     //   2773: aaload
/*     */     //   2774: ifnull -> 2761
/*     */     //   2777: aload #13
/*     */     //   2779: iload #15
/*     */     //   2781: aaload
/*     */     //   2782: invokevirtual close : ()V
/*     */     //   2785: goto -> 2761
/*     */     //   2788: aload_0
/*     */     //   2789: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2792: ifnull -> 2815
/*     */     //   2795: aload_0
/*     */     //   2796: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2799: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   2802: ifnull -> 2815
/*     */     //   2805: aload_0
/*     */     //   2806: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2809: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   2812: invokevirtual onReturn : ()V
/*     */     //   2815: aload #14
/*     */     //   2817: areturn
/*     */     //   2818: iload_3
/*     */     //   2819: bipush #23
/*     */     //   2821: iushr
/*     */     //   2822: istore #5
/*     */     //   2824: iload #5
/*     */     //   2826: tableswitch default -> 3085, 0 -> 2852, 1 -> 2940, 2 -> 3012
/*     */     //   2852: aload_1
/*     */     //   2853: iload #4
/*     */     //   2855: iload #8
/*     */     //   2857: aload #10
/*     */     //   2859: invokevirtual narg : ()I
/*     */     //   2862: isub
/*     */     //   2863: iload #4
/*     */     //   2865: isub
/*     */     //   2866: aload #10
/*     */     //   2868: invokestatic varargsOf : ([Lorg/luaj/vm2/LuaValue;IILorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
/*     */     //   2871: astore #14
/*     */     //   2873: aload #13
/*     */     //   2875: ifnull -> 2910
/*     */     //   2878: aload #13
/*     */     //   2880: arraylength
/*     */     //   2881: istore #15
/*     */     //   2883: iinc #15, -1
/*     */     //   2886: iload #15
/*     */     //   2888: iflt -> 2910
/*     */     //   2891: aload #13
/*     */     //   2893: iload #15
/*     */     //   2895: aaload
/*     */     //   2896: ifnull -> 2883
/*     */     //   2899: aload #13
/*     */     //   2901: iload #15
/*     */     //   2903: aaload
/*     */     //   2904: invokevirtual close : ()V
/*     */     //   2907: goto -> 2883
/*     */     //   2910: aload_0
/*     */     //   2911: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2914: ifnull -> 2937
/*     */     //   2917: aload_0
/*     */     //   2918: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2921: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   2924: ifnull -> 2937
/*     */     //   2927: aload_0
/*     */     //   2928: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2931: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   2934: invokevirtual onReturn : ()V
/*     */     //   2937: aload #14
/*     */     //   2939: areturn
/*     */     //   2940: getstatic org/luaj/vm2/LuaClosure.NONE : Lorg/luaj/vm2/LuaValue;
/*     */     //   2943: astore #14
/*     */     //   2945: aload #13
/*     */     //   2947: ifnull -> 2982
/*     */     //   2950: aload #13
/*     */     //   2952: arraylength
/*     */     //   2953: istore #15
/*     */     //   2955: iinc #15, -1
/*     */     //   2958: iload #15
/*     */     //   2960: iflt -> 2982
/*     */     //   2963: aload #13
/*     */     //   2965: iload #15
/*     */     //   2967: aaload
/*     */     //   2968: ifnull -> 2955
/*     */     //   2971: aload #13
/*     */     //   2973: iload #15
/*     */     //   2975: aaload
/*     */     //   2976: invokevirtual close : ()V
/*     */     //   2979: goto -> 2955
/*     */     //   2982: aload_0
/*     */     //   2983: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2986: ifnull -> 3009
/*     */     //   2989: aload_0
/*     */     //   2990: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   2993: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   2996: ifnull -> 3009
/*     */     //   2999: aload_0
/*     */     //   3000: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   3003: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   3006: invokevirtual onReturn : ()V
/*     */     //   3009: aload #14
/*     */     //   3011: areturn
/*     */     //   3012: aload_1
/*     */     //   3013: iload #4
/*     */     //   3015: aaload
/*     */     //   3016: astore #14
/*     */     //   3018: aload #13
/*     */     //   3020: ifnull -> 3055
/*     */     //   3023: aload #13
/*     */     //   3025: arraylength
/*     */     //   3026: istore #15
/*     */     //   3028: iinc #15, -1
/*     */     //   3031: iload #15
/*     */     //   3033: iflt -> 3055
/*     */     //   3036: aload #13
/*     */     //   3038: iload #15
/*     */     //   3040: aaload
/*     */     //   3041: ifnull -> 3028
/*     */     //   3044: aload #13
/*     */     //   3046: iload #15
/*     */     //   3048: aaload
/*     */     //   3049: invokevirtual close : ()V
/*     */     //   3052: goto -> 3028
/*     */     //   3055: aload_0
/*     */     //   3056: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   3059: ifnull -> 3082
/*     */     //   3062: aload_0
/*     */     //   3063: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   3066: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   3069: ifnull -> 3082
/*     */     //   3072: aload_0
/*     */     //   3073: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   3076: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   3079: invokevirtual onReturn : ()V
/*     */     //   3082: aload #14
/*     */     //   3084: areturn
/*     */     //   3085: aload_1
/*     */     //   3086: iload #4
/*     */     //   3088: iload #5
/*     */     //   3090: iconst_1
/*     */     //   3091: isub
/*     */     //   3092: invokestatic varargsOf : ([Lorg/luaj/vm2/LuaValue;II)Lorg/luaj/vm2/Varargs;
/*     */     //   3095: astore #14
/*     */     //   3097: aload #13
/*     */     //   3099: ifnull -> 3134
/*     */     //   3102: aload #13
/*     */     //   3104: arraylength
/*     */     //   3105: istore #15
/*     */     //   3107: iinc #15, -1
/*     */     //   3110: iload #15
/*     */     //   3112: iflt -> 3134
/*     */     //   3115: aload #13
/*     */     //   3117: iload #15
/*     */     //   3119: aaload
/*     */     //   3120: ifnull -> 3107
/*     */     //   3123: aload #13
/*     */     //   3125: iload #15
/*     */     //   3127: aaload
/*     */     //   3128: invokevirtual close : ()V
/*     */     //   3131: goto -> 3107
/*     */     //   3134: aload_0
/*     */     //   3135: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   3138: ifnull -> 3161
/*     */     //   3141: aload_0
/*     */     //   3142: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   3145: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   3148: ifnull -> 3161
/*     */     //   3151: aload_0
/*     */     //   3152: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   3155: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   3158: invokevirtual onReturn : ()V
/*     */     //   3161: aload #14
/*     */     //   3163: areturn
/*     */     //   3164: aload_1
/*     */     //   3165: iload #4
/*     */     //   3167: iconst_1
/*     */     //   3168: iadd
/*     */     //   3169: aaload
/*     */     //   3170: astore #14
/*     */     //   3172: aload_1
/*     */     //   3173: iload #4
/*     */     //   3175: iconst_2
/*     */     //   3176: iadd
/*     */     //   3177: aaload
/*     */     //   3178: astore #15
/*     */     //   3180: aload_1
/*     */     //   3181: iload #4
/*     */     //   3183: aaload
/*     */     //   3184: aload #15
/*     */     //   3186: invokevirtual add : (Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   3189: astore #16
/*     */     //   3191: aload #15
/*     */     //   3193: iconst_0
/*     */     //   3194: invokevirtual gt_b : (I)Z
/*     */     //   3197: ifeq -> 3213
/*     */     //   3200: aload #16
/*     */     //   3202: aload #14
/*     */     //   3204: invokevirtual lteq_b : (Lorg/luaj/vm2/LuaValue;)Z
/*     */     //   3207: ifeq -> 3249
/*     */     //   3210: goto -> 3223
/*     */     //   3213: aload #16
/*     */     //   3215: aload #14
/*     */     //   3217: invokevirtual gteq_b : (Lorg/luaj/vm2/LuaValue;)Z
/*     */     //   3220: ifeq -> 3249
/*     */     //   3223: aload_1
/*     */     //   3224: iload #4
/*     */     //   3226: aload #16
/*     */     //   3228: aastore
/*     */     //   3229: aload_1
/*     */     //   3230: iload #4
/*     */     //   3232: iconst_3
/*     */     //   3233: iadd
/*     */     //   3234: aload #16
/*     */     //   3236: aastore
/*     */     //   3237: iload #7
/*     */     //   3239: iload_3
/*     */     //   3240: bipush #14
/*     */     //   3242: iushr
/*     */     //   3243: ldc 131071
/*     */     //   3245: isub
/*     */     //   3246: iadd
/*     */     //   3247: istore #7
/*     */     //   3249: goto -> 3849
/*     */     //   3252: aload_1
/*     */     //   3253: iload #4
/*     */     //   3255: aaload
/*     */     //   3256: ldc ''for' initial value must be a number'
/*     */     //   3258: invokevirtual checknumber : (Ljava/lang/String;)Lorg/luaj/vm2/LuaNumber;
/*     */     //   3261: astore #14
/*     */     //   3263: aload_1
/*     */     //   3264: iload #4
/*     */     //   3266: iconst_1
/*     */     //   3267: iadd
/*     */     //   3268: aaload
/*     */     //   3269: ldc ''for' limit must be a number'
/*     */     //   3271: invokevirtual checknumber : (Ljava/lang/String;)Lorg/luaj/vm2/LuaNumber;
/*     */     //   3274: astore #15
/*     */     //   3276: aload_1
/*     */     //   3277: iload #4
/*     */     //   3279: iconst_2
/*     */     //   3280: iadd
/*     */     //   3281: aaload
/*     */     //   3282: ldc ''for' step must be a number'
/*     */     //   3284: invokevirtual checknumber : (Ljava/lang/String;)Lorg/luaj/vm2/LuaNumber;
/*     */     //   3287: astore #16
/*     */     //   3289: aload_1
/*     */     //   3290: iload #4
/*     */     //   3292: aload #14
/*     */     //   3294: aload #16
/*     */     //   3296: invokevirtual sub : (Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
/*     */     //   3299: aastore
/*     */     //   3300: aload_1
/*     */     //   3301: iload #4
/*     */     //   3303: iconst_1
/*     */     //   3304: iadd
/*     */     //   3305: aload #15
/*     */     //   3307: aastore
/*     */     //   3308: aload_1
/*     */     //   3309: iload #4
/*     */     //   3311: iconst_2
/*     */     //   3312: iadd
/*     */     //   3313: aload #16
/*     */     //   3315: aastore
/*     */     //   3316: iload #7
/*     */     //   3318: iload_3
/*     */     //   3319: bipush #14
/*     */     //   3321: iushr
/*     */     //   3322: ldc 131071
/*     */     //   3324: isub
/*     */     //   3325: iadd
/*     */     //   3326: istore #7
/*     */     //   3328: goto -> 3849
/*     */     //   3331: aload_1
/*     */     //   3332: iload #4
/*     */     //   3334: aaload
/*     */     //   3335: aload_1
/*     */     //   3336: iload #4
/*     */     //   3338: iconst_1
/*     */     //   3339: iadd
/*     */     //   3340: aaload
/*     */     //   3341: aload_1
/*     */     //   3342: iload #4
/*     */     //   3344: iconst_2
/*     */     //   3345: iadd
/*     */     //   3346: aaload
/*     */     //   3347: invokestatic varargsOf : (Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
/*     */     //   3350: invokevirtual invoke : (Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
/*     */     //   3353: astore #10
/*     */     //   3355: iload_3
/*     */     //   3356: bipush #14
/*     */     //   3358: ishr
/*     */     //   3359: sipush #511
/*     */     //   3362: iand
/*     */     //   3363: istore #6
/*     */     //   3365: iinc #6, -1
/*     */     //   3368: iload #6
/*     */     //   3370: iflt -> 3394
/*     */     //   3373: aload_1
/*     */     //   3374: iload #4
/*     */     //   3376: iconst_3
/*     */     //   3377: iadd
/*     */     //   3378: iload #6
/*     */     //   3380: iadd
/*     */     //   3381: aload #10
/*     */     //   3383: iload #6
/*     */     //   3385: iconst_1
/*     */     //   3386: iadd
/*     */     //   3387: invokevirtual arg : (I)Lorg/luaj/vm2/LuaValue;
/*     */     //   3390: aastore
/*     */     //   3391: goto -> 3365
/*     */     //   3394: getstatic org/luaj/vm2/LuaClosure.NONE : Lorg/luaj/vm2/LuaValue;
/*     */     //   3397: astore #10
/*     */     //   3399: goto -> 3849
/*     */     //   3402: aload_1
/*     */     //   3403: iload #4
/*     */     //   3405: iconst_1
/*     */     //   3406: iadd
/*     */     //   3407: aaload
/*     */     //   3408: invokevirtual isnil : ()Z
/*     */     //   3411: ifne -> 3849
/*     */     //   3414: aload_1
/*     */     //   3415: iload #4
/*     */     //   3417: aload_1
/*     */     //   3418: iload #4
/*     */     //   3420: iconst_1
/*     */     //   3421: iadd
/*     */     //   3422: aaload
/*     */     //   3423: aastore
/*     */     //   3424: iload #7
/*     */     //   3426: iload_3
/*     */     //   3427: bipush #14
/*     */     //   3429: iushr
/*     */     //   3430: ldc 131071
/*     */     //   3432: isub
/*     */     //   3433: iadd
/*     */     //   3434: istore #7
/*     */     //   3436: goto -> 3849
/*     */     //   3439: iload_3
/*     */     //   3440: bipush #14
/*     */     //   3442: ishr
/*     */     //   3443: sipush #511
/*     */     //   3446: iand
/*     */     //   3447: dup
/*     */     //   3448: istore #6
/*     */     //   3450: ifne -> 3463
/*     */     //   3453: aload #11
/*     */     //   3455: iinc #7, 1
/*     */     //   3458: iload #7
/*     */     //   3460: iaload
/*     */     //   3461: istore #6
/*     */     //   3463: iload #6
/*     */     //   3465: iconst_1
/*     */     //   3466: isub
/*     */     //   3467: bipush #50
/*     */     //   3469: imul
/*     */     //   3470: istore #14
/*     */     //   3472: aload_1
/*     */     //   3473: iload #4
/*     */     //   3475: aaload
/*     */     //   3476: astore #9
/*     */     //   3478: iload_3
/*     */     //   3479: bipush #23
/*     */     //   3481: iushr
/*     */     //   3482: dup
/*     */     //   3483: istore #5
/*     */     //   3485: ifne -> 3576
/*     */     //   3488: iload #8
/*     */     //   3490: iload #4
/*     */     //   3492: isub
/*     */     //   3493: iconst_1
/*     */     //   3494: isub
/*     */     //   3495: istore #5
/*     */     //   3497: iload #5
/*     */     //   3499: aload #10
/*     */     //   3501: invokevirtual narg : ()I
/*     */     //   3504: isub
/*     */     //   3505: istore #15
/*     */     //   3507: iconst_1
/*     */     //   3508: istore #16
/*     */     //   3510: iload #16
/*     */     //   3512: iload #15
/*     */     //   3514: if_icmpgt -> 3540
/*     */     //   3517: aload #9
/*     */     //   3519: iload #14
/*     */     //   3521: iload #16
/*     */     //   3523: iadd
/*     */     //   3524: aload_1
/*     */     //   3525: iload #4
/*     */     //   3527: iload #16
/*     */     //   3529: iadd
/*     */     //   3530: aaload
/*     */     //   3531: invokevirtual set : (ILorg/luaj/vm2/LuaValue;)V
/*     */     //   3534: iinc #16, 1
/*     */     //   3537: goto -> 3510
/*     */     //   3540: iload #16
/*     */     //   3542: iload #5
/*     */     //   3544: if_icmpgt -> 3573
/*     */     //   3547: aload #9
/*     */     //   3549: iload #14
/*     */     //   3551: iload #16
/*     */     //   3553: iadd
/*     */     //   3554: aload #10
/*     */     //   3556: iload #16
/*     */     //   3558: iload #15
/*     */     //   3560: isub
/*     */     //   3561: invokevirtual arg : (I)Lorg/luaj/vm2/LuaValue;
/*     */     //   3564: invokevirtual set : (ILorg/luaj/vm2/LuaValue;)V
/*     */     //   3567: iinc #16, 1
/*     */     //   3570: goto -> 3540
/*     */     //   3573: goto -> 3619
/*     */     //   3576: aload #9
/*     */     //   3578: iload #14
/*     */     //   3580: iload #5
/*     */     //   3582: iadd
/*     */     //   3583: invokevirtual presize : (I)V
/*     */     //   3586: iconst_1
/*     */     //   3587: istore #15
/*     */     //   3589: iload #15
/*     */     //   3591: iload #5
/*     */     //   3593: if_icmpgt -> 3619
/*     */     //   3596: aload #9
/*     */     //   3598: iload #14
/*     */     //   3600: iload #15
/*     */     //   3602: iadd
/*     */     //   3603: aload_1
/*     */     //   3604: iload #4
/*     */     //   3606: iload #15
/*     */     //   3608: iadd
/*     */     //   3609: aaload
/*     */     //   3610: invokevirtual set : (ILorg/luaj/vm2/LuaValue;)V
/*     */     //   3613: iinc #15, 1
/*     */     //   3616: goto -> 3589
/*     */     //   3619: goto -> 3849
/*     */     //   3622: aload_0
/*     */     //   3623: getfield p : Lorg/luaj/vm2/Prototype;
/*     */     //   3626: getfield p : [Lorg/luaj/vm2/Prototype;
/*     */     //   3629: iload_3
/*     */     //   3630: bipush #14
/*     */     //   3632: iushr
/*     */     //   3633: aaload
/*     */     //   3634: astore #14
/*     */     //   3636: new org/luaj/vm2/LuaClosure
/*     */     //   3639: dup
/*     */     //   3640: aload #14
/*     */     //   3642: aload_0
/*     */     //   3643: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   3646: invokespecial <init> : (Lorg/luaj/vm2/Prototype;Lorg/luaj/vm2/LuaValue;)V
/*     */     //   3649: astore #15
/*     */     //   3651: aload #14
/*     */     //   3653: getfield upvalues : [Lorg/luaj/vm2/Upvaldesc;
/*     */     //   3656: astore #16
/*     */     //   3658: iconst_0
/*     */     //   3659: istore #17
/*     */     //   3661: aload #16
/*     */     //   3663: arraylength
/*     */     //   3664: istore #18
/*     */     //   3666: iload #17
/*     */     //   3668: iload #18
/*     */     //   3670: if_icmpge -> 3737
/*     */     //   3673: aload #16
/*     */     //   3675: iload #17
/*     */     //   3677: aaload
/*     */     //   3678: getfield instack : Z
/*     */     //   3681: ifeq -> 3710
/*     */     //   3684: aload #15
/*     */     //   3686: getfield upValues : [Lorg/luaj/vm2/UpValue;
/*     */     //   3689: iload #17
/*     */     //   3691: aload_0
/*     */     //   3692: aload_1
/*     */     //   3693: aload #16
/*     */     //   3695: iload #17
/*     */     //   3697: aaload
/*     */     //   3698: getfield idx : S
/*     */     //   3701: aload #13
/*     */     //   3703: invokespecial findupval : ([Lorg/luaj/vm2/LuaValue;S[Lorg/luaj/vm2/UpValue;)Lorg/luaj/vm2/UpValue;
/*     */     //   3706: aastore
/*     */     //   3707: goto -> 3731
/*     */     //   3710: aload #15
/*     */     //   3712: getfield upValues : [Lorg/luaj/vm2/UpValue;
/*     */     //   3715: iload #17
/*     */     //   3717: aload_0
/*     */     //   3718: getfield upValues : [Lorg/luaj/vm2/UpValue;
/*     */     //   3721: aload #16
/*     */     //   3723: iload #17
/*     */     //   3725: aaload
/*     */     //   3726: getfield idx : S
/*     */     //   3729: aaload
/*     */     //   3730: aastore
/*     */     //   3731: iinc #17, 1
/*     */     //   3734: goto -> 3666
/*     */     //   3737: aload_1
/*     */     //   3738: iload #4
/*     */     //   3740: aload #15
/*     */     //   3742: aastore
/*     */     //   3743: goto -> 3849
/*     */     //   3746: iload_3
/*     */     //   3747: bipush #23
/*     */     //   3749: iushr
/*     */     //   3750: istore #5
/*     */     //   3752: iload #5
/*     */     //   3754: ifne -> 3775
/*     */     //   3757: iload #4
/*     */     //   3759: aload_2
/*     */     //   3760: invokevirtual narg : ()I
/*     */     //   3763: dup
/*     */     //   3764: istore #5
/*     */     //   3766: iadd
/*     */     //   3767: istore #8
/*     */     //   3769: aload_2
/*     */     //   3770: astore #10
/*     */     //   3772: goto -> 3849
/*     */     //   3775: iconst_1
/*     */     //   3776: istore #14
/*     */     //   3778: iload #14
/*     */     //   3780: iload #5
/*     */     //   3782: if_icmpge -> 3806
/*     */     //   3785: aload_1
/*     */     //   3786: iload #4
/*     */     //   3788: iload #14
/*     */     //   3790: iadd
/*     */     //   3791: iconst_1
/*     */     //   3792: isub
/*     */     //   3793: aload_2
/*     */     //   3794: iload #14
/*     */     //   3796: invokevirtual arg : (I)Lorg/luaj/vm2/LuaValue;
/*     */     //   3799: aastore
/*     */     //   3800: iinc #14, 1
/*     */     //   3803: goto -> 3778
/*     */     //   3806: goto -> 3849
/*     */     //   3809: new java/lang/IllegalArgumentException
/*     */     //   3812: dup
/*     */     //   3813: ldc 'Uexecutable opcode: OP_EXTRAARG'
/*     */     //   3815: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   3818: athrow
/*     */     //   3819: new java/lang/IllegalArgumentException
/*     */     //   3822: dup
/*     */     //   3823: new java/lang/StringBuilder
/*     */     //   3826: dup
/*     */     //   3827: invokespecial <init> : ()V
/*     */     //   3830: ldc 'Illegal opcode: '
/*     */     //   3832: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   3835: iload_3
/*     */     //   3836: bipush #63
/*     */     //   3838: iand
/*     */     //   3839: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   3842: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   3845: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   3848: athrow
/*     */     //   3849: iinc #7, 1
/*     */     //   3852: goto -> 81
/*     */     //   3855: astore #14
/*     */     //   3857: aload #14
/*     */     //   3859: getfield traceback : Ljava/lang/String;
/*     */     //   3862: ifnonnull -> 3877
/*     */     //   3865: aload_0
/*     */     //   3866: aload #14
/*     */     //   3868: aload_0
/*     */     //   3869: getfield p : Lorg/luaj/vm2/Prototype;
/*     */     //   3872: iload #7
/*     */     //   3874: invokespecial processErrorHooks : (Lorg/luaj/vm2/LuaError;Lorg/luaj/vm2/Prototype;I)V
/*     */     //   3877: aload #14
/*     */     //   3879: athrow
/*     */     //   3880: astore #14
/*     */     //   3882: new org/luaj/vm2/LuaError
/*     */     //   3885: dup
/*     */     //   3886: aload #14
/*     */     //   3888: invokespecial <init> : (Ljava/lang/Throwable;)V
/*     */     //   3891: astore #15
/*     */     //   3893: aload_0
/*     */     //   3894: aload #15
/*     */     //   3896: aload_0
/*     */     //   3897: getfield p : Lorg/luaj/vm2/Prototype;
/*     */     //   3900: iload #7
/*     */     //   3902: invokespecial processErrorHooks : (Lorg/luaj/vm2/LuaError;Lorg/luaj/vm2/Prototype;I)V
/*     */     //   3905: aload #15
/*     */     //   3907: athrow
/*     */     //   3908: astore #19
/*     */     //   3910: aload #13
/*     */     //   3912: ifnull -> 3947
/*     */     //   3915: aload #13
/*     */     //   3917: arraylength
/*     */     //   3918: istore #20
/*     */     //   3920: iinc #20, -1
/*     */     //   3923: iload #20
/*     */     //   3925: iflt -> 3947
/*     */     //   3928: aload #13
/*     */     //   3930: iload #20
/*     */     //   3932: aaload
/*     */     //   3933: ifnull -> 3920
/*     */     //   3936: aload #13
/*     */     //   3938: iload #20
/*     */     //   3940: aaload
/*     */     //   3941: invokevirtual close : ()V
/*     */     //   3944: goto -> 3920
/*     */     //   3947: aload_0
/*     */     //   3948: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   3951: ifnull -> 3974
/*     */     //   3954: aload_0
/*     */     //   3955: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   3958: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   3961: ifnull -> 3974
/*     */     //   3964: aload_0
/*     */     //   3965: getfield globals : Lorg/luaj/vm2/Globals;
/*     */     //   3968: getfield debuglib : Lorg/luaj/vm2/lib/DebugLib;
/*     */     //   3971: invokevirtual onReturn : ()V
/*     */     //   3974: aload #19
/*     */     //   3976: athrow
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #229	-> 0
/*     */     //   #231	-> 6
/*     */     //   #232	-> 11
/*     */     //   #233	-> 20
/*     */     //   #237	-> 29
/*     */     //   #240	-> 51
/*     */     //   #241	-> 68
/*     */     //   #246	-> 81
/*     */     //   #247	-> 98
/*     */     //   #250	-> 114
/*     */     //   #251	-> 120
/*     */     //   #254	-> 130
/*     */     //   #257	-> 308
/*     */     //   #258	-> 318
/*     */     //   #261	-> 321
/*     */     //   #262	-> 332
/*     */     //   #265	-> 335
/*     */     //   #266	-> 338
/*     */     //   #267	-> 344
/*     */     //   #268	-> 353
/*     */     //   #269	-> 359
/*     */     //   #272	-> 425
/*     */     //   #273	-> 436
/*     */     //   #276	-> 439
/*     */     //   #277	-> 459
/*     */     //   #278	-> 466
/*     */     //   #282	-> 472
/*     */     //   #283	-> 486
/*     */     //   #287	-> 499
/*     */     //   #288	-> 515
/*     */     //   #291	-> 518
/*     */     //   #292	-> 570
/*     */     //   #295	-> 573
/*     */     //   #296	-> 619
/*     */     //   #299	-> 622
/*     */     //   #301	-> 697
/*     */     //   #304	-> 700
/*     */     //   #305	-> 716
/*     */     //   #308	-> 719
/*     */     //   #310	-> 788
/*     */     //   #313	-> 791
/*     */     //   #314	-> 814
/*     */     //   #317	-> 817
/*     */     //   #318	-> 832
/*     */     //   #319	-> 874
/*     */     //   #322	-> 877
/*     */     //   #323	-> 942
/*     */     //   #324	-> 946
/*     */     //   #327	-> 949
/*     */     //   #328	-> 1014
/*     */     //   #329	-> 1018
/*     */     //   #332	-> 1021
/*     */     //   #333	-> 1086
/*     */     //   #334	-> 1090
/*     */     //   #337	-> 1093
/*     */     //   #338	-> 1158
/*     */     //   #339	-> 1162
/*     */     //   #342	-> 1165
/*     */     //   #343	-> 1230
/*     */     //   #344	-> 1234
/*     */     //   #347	-> 1237
/*     */     //   #348	-> 1302
/*     */     //   #349	-> 1306
/*     */     //   #352	-> 1309
/*     */     //   #353	-> 1322
/*     */     //   #356	-> 1325
/*     */     //   #357	-> 1338
/*     */     //   #360	-> 1341
/*     */     //   #361	-> 1354
/*     */     //   #364	-> 1357
/*     */     //   #365	-> 1363
/*     */     //   #366	-> 1373
/*     */     //   #367	-> 1382
/*     */     //   #368	-> 1391
/*     */     //   #369	-> 1401
/*     */     //   #370	-> 1414
/*     */     //   #371	-> 1423
/*     */     //   #372	-> 1426
/*     */     //   #375	-> 1443
/*     */     //   #378	-> 1446
/*     */     //   #379	-> 1458
/*     */     //   #380	-> 1463
/*     */     //   #381	-> 1479
/*     */     //   #382	-> 1500
/*     */     //   #383	-> 1508
/*     */     //   #389	-> 1517
/*     */     //   #390	-> 1579
/*     */     //   #391	-> 1595
/*     */     //   #395	-> 1601
/*     */     //   #396	-> 1663
/*     */     //   #397	-> 1679
/*     */     //   #401	-> 1685
/*     */     //   #402	-> 1747
/*     */     //   #403	-> 1763
/*     */     //   #407	-> 1769
/*     */     //   #408	-> 1791
/*     */     //   #413	-> 1797
/*     */     //   #414	-> 1824
/*     */     //   #416	-> 1830
/*     */     //   #417	-> 1836
/*     */     //   #420	-> 1839
/*     */     //   #422	-> 1936
/*     */     //   #423	-> 1948
/*     */     //   #424	-> 1958
/*     */     //   #426	-> 1961
/*     */     //   #427	-> 1976
/*     */     //   #428	-> 1986
/*     */     //   #430	-> 1989
/*     */     //   #431	-> 1997
/*     */     //   #433	-> 2000
/*     */     //   #434	-> 2014
/*     */     //   #436	-> 2017
/*     */     //   #437	-> 2037
/*     */     //   #439	-> 2040
/*     */     //   #440	-> 2066
/*     */     //   #442	-> 2069
/*     */     //   #443	-> 2080
/*     */     //   #445	-> 2083
/*     */     //   #446	-> 2100
/*     */     //   #448	-> 2103
/*     */     //   #449	-> 2126
/*     */     //   #451	-> 2129
/*     */     //   #452	-> 2158
/*     */     //   #454	-> 2161
/*     */     //   #455	-> 2167
/*     */     //   #456	-> 2177
/*     */     //   #457	-> 2210
/*     */     //   #456	-> 2224
/*     */     //   #458	-> 2229
/*     */     //   #459	-> 2234
/*     */     //   #460	-> 2246
/*     */     //   #462	-> 2254
/*     */     //   #463	-> 2264
/*     */     //   #465	-> 2271
/*     */     //   #469	-> 2274
/*     */     //   #471	-> 2320
/*     */     //   #602	-> 2336
/*     */     //   #603	-> 2341
/*     */     //   #604	-> 2354
/*     */     //   #605	-> 2362
/*     */     //   #606	-> 2373
/*     */     //   #607	-> 2390
/*     */     //   #471	-> 2400
/*     */     //   #473	-> 2403
/*     */     //   #602	-> 2422
/*     */     //   #603	-> 2427
/*     */     //   #604	-> 2440
/*     */     //   #605	-> 2448
/*     */     //   #606	-> 2459
/*     */     //   #607	-> 2476
/*     */     //   #473	-> 2486
/*     */     //   #475	-> 2489
/*     */     //   #602	-> 2517
/*     */     //   #603	-> 2522
/*     */     //   #604	-> 2535
/*     */     //   #605	-> 2543
/*     */     //   #606	-> 2554
/*     */     //   #607	-> 2571
/*     */     //   #475	-> 2581
/*     */     //   #477	-> 2584
/*     */     //   #602	-> 2618
/*     */     //   #603	-> 2623
/*     */     //   #604	-> 2636
/*     */     //   #605	-> 2644
/*     */     //   #606	-> 2655
/*     */     //   #607	-> 2672
/*     */     //   #477	-> 2682
/*     */     //   #479	-> 2685
/*     */     //   #480	-> 2691
/*     */     //   #481	-> 2720
/*     */     //   #482	-> 2736
/*     */     //   #602	-> 2751
/*     */     //   #603	-> 2756
/*     */     //   #604	-> 2769
/*     */     //   #605	-> 2777
/*     */     //   #606	-> 2788
/*     */     //   #607	-> 2805
/*     */     //   #482	-> 2815
/*     */     //   #486	-> 2818
/*     */     //   #487	-> 2824
/*     */     //   #489	-> 2852
/*     */     //   #602	-> 2873
/*     */     //   #603	-> 2878
/*     */     //   #604	-> 2891
/*     */     //   #605	-> 2899
/*     */     //   #606	-> 2910
/*     */     //   #607	-> 2927
/*     */     //   #489	-> 2937
/*     */     //   #491	-> 2940
/*     */     //   #602	-> 2945
/*     */     //   #603	-> 2950
/*     */     //   #604	-> 2963
/*     */     //   #605	-> 2971
/*     */     //   #606	-> 2982
/*     */     //   #607	-> 2999
/*     */     //   #491	-> 3009
/*     */     //   #493	-> 3012
/*     */     //   #602	-> 3018
/*     */     //   #603	-> 3023
/*     */     //   #604	-> 3036
/*     */     //   #605	-> 3044
/*     */     //   #606	-> 3055
/*     */     //   #607	-> 3072
/*     */     //   #493	-> 3082
/*     */     //   #495	-> 3085
/*     */     //   #602	-> 3097
/*     */     //   #603	-> 3102
/*     */     //   #604	-> 3115
/*     */     //   #605	-> 3123
/*     */     //   #606	-> 3134
/*     */     //   #607	-> 3151
/*     */     //   #495	-> 3161
/*     */     //   #500	-> 3164
/*     */     //   #501	-> 3172
/*     */     //   #502	-> 3180
/*     */     //   #503	-> 3191
/*     */     //   #504	-> 3223
/*     */     //   #505	-> 3229
/*     */     //   #506	-> 3237
/*     */     //   #509	-> 3249
/*     */     //   #513	-> 3252
/*     */     //   #514	-> 3263
/*     */     //   #515	-> 3276
/*     */     //   #516	-> 3289
/*     */     //   #517	-> 3300
/*     */     //   #518	-> 3308
/*     */     //   #519	-> 3316
/*     */     //   #521	-> 3328
/*     */     //   #524	-> 3331
/*     */     //   #525	-> 3355
/*     */     //   #526	-> 3365
/*     */     //   #527	-> 3373
/*     */     //   #528	-> 3394
/*     */     //   #529	-> 3399
/*     */     //   #532	-> 3402
/*     */     //   #533	-> 3414
/*     */     //   #534	-> 3424
/*     */     //   #540	-> 3439
/*     */     //   #541	-> 3453
/*     */     //   #542	-> 3463
/*     */     //   #543	-> 3472
/*     */     //   #544	-> 3478
/*     */     //   #545	-> 3488
/*     */     //   #546	-> 3497
/*     */     //   #547	-> 3507
/*     */     //   #548	-> 3510
/*     */     //   #549	-> 3517
/*     */     //   #548	-> 3534
/*     */     //   #550	-> 3540
/*     */     //   #551	-> 3547
/*     */     //   #550	-> 3567
/*     */     //   #552	-> 3573
/*     */     //   #553	-> 3576
/*     */     //   #554	-> 3586
/*     */     //   #555	-> 3596
/*     */     //   #554	-> 3613
/*     */     //   #558	-> 3619
/*     */     //   #562	-> 3622
/*     */     //   #563	-> 3636
/*     */     //   #564	-> 3651
/*     */     //   #565	-> 3658
/*     */     //   #566	-> 3673
/*     */     //   #567	-> 3684
/*     */     //   #569	-> 3710
/*     */     //   #565	-> 3731
/*     */     //   #571	-> 3737
/*     */     //   #573	-> 3743
/*     */     //   #576	-> 3746
/*     */     //   #577	-> 3752
/*     */     //   #578	-> 3757
/*     */     //   #579	-> 3769
/*     */     //   #581	-> 3775
/*     */     //   #582	-> 3785
/*     */     //   #581	-> 3800
/*     */     //   #584	-> 3806
/*     */     //   #587	-> 3809
/*     */     //   #590	-> 3819
/*     */     //   #245	-> 3849
/*     */     //   #593	-> 3855
/*     */     //   #594	-> 3857
/*     */     //   #595	-> 3865
/*     */     //   #596	-> 3877
/*     */     //   #597	-> 3880
/*     */     //   #598	-> 3882
/*     */     //   #599	-> 3893
/*     */     //   #600	-> 3905
/*     */     //   #602	-> 3908
/*     */     //   #603	-> 3915
/*     */     //   #604	-> 3928
/*     */     //   #605	-> 3936
/*     */     //   #606	-> 3947
/*     */     //   #607	-> 3964
/*     */     //   #608	-> 3974
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   359	66	14	op	I
/*     */     //   478	21	5	b	I
/*     */     //   544	29	6	c	I
/*     */     //   593	29	6	c	I
/*     */     //   639	61	5	b	I
/*     */     //   672	28	6	c	I
/*     */     //   730	61	5	b	I
/*     */     //   763	28	6	c	I
/*     */     //   848	29	6	c	I
/*     */     //   831	46	9	o	Lorg/luaj/vm2/LuaValue;
/*     */     //   887	62	5	b	I
/*     */     //   920	29	6	c	I
/*     */     //   959	62	5	b	I
/*     */     //   992	29	6	c	I
/*     */     //   1031	62	5	b	I
/*     */     //   1064	29	6	c	I
/*     */     //   1103	62	5	b	I
/*     */     //   1136	29	6	c	I
/*     */     //   1175	62	5	b	I
/*     */     //   1208	29	6	c	I
/*     */     //   1247	62	5	b	I
/*     */     //   1280	29	6	c	I
/*     */     //   1391	32	14	sb	Lorg/luaj/vm2/Buffer;
/*     */     //   1363	83	5	b	I
/*     */     //   1373	73	6	c	I
/*     */     //   1471	46	5	b	I
/*     */     //   1524	77	5	b	I
/*     */     //   1557	44	6	c	I
/*     */     //   1608	77	5	b	I
/*     */     //   1641	44	6	c	I
/*     */     //   1692	77	5	b	I
/*     */     //   1725	44	6	c	I
/*     */     //   1806	33	9	o	Lorg/luaj/vm2/LuaValue;
/*     */     //   2167	107	5	b	I
/*     */     //   2177	97	6	c	I
/*     */     //   2346	27	15	u	I
/*     */     //   2432	27	15	u	I
/*     */     //   2527	27	15	u	I
/*     */     //   2628	27	15	u	I
/*     */     //   2761	27	15	u	I
/*     */     //   2691	127	5	b	I
/*     */     //   2883	27	15	u	I
/*     */     //   2955	27	15	u	I
/*     */     //   3028	27	15	u	I
/*     */     //   3107	27	15	u	I
/*     */     //   2824	340	5	b	I
/*     */     //   3172	77	14	limit	Lorg/luaj/vm2/LuaValue;
/*     */     //   3180	69	15	step	Lorg/luaj/vm2/LuaValue;
/*     */     //   3191	58	16	idx	Lorg/luaj/vm2/LuaValue;
/*     */     //   3263	65	14	init	Lorg/luaj/vm2/LuaValue;
/*     */     //   3276	52	15	limit	Lorg/luaj/vm2/LuaValue;
/*     */     //   3289	39	16	step	Lorg/luaj/vm2/LuaValue;
/*     */     //   3365	37	6	c	I
/*     */     //   3507	66	15	m	I
/*     */     //   3510	63	16	j	I
/*     */     //   3589	30	15	j	I
/*     */     //   3472	147	14	offset	I
/*     */     //   3485	137	5	b	I
/*     */     //   3450	172	6	c	I
/*     */     //   3478	144	9	o	Lorg/luaj/vm2/LuaValue;
/*     */     //   3661	76	17	j	I
/*     */     //   3666	71	18	nup	I
/*     */     //   3636	107	14	newp	Lorg/luaj/vm2/Prototype;
/*     */     //   3651	92	15	ncl	Lorg/luaj/vm2/LuaClosure;
/*     */     //   3658	85	16	uv	[Lorg/luaj/vm2/Upvaldesc;
/*     */     //   3778	28	14	j	I
/*     */     //   3752	57	5	b	I
/*     */     //   120	3735	3	i	I
/*     */     //   130	3725	4	a	I
/*     */     //   3857	23	14	le	Lorg/luaj/vm2/LuaError;
/*     */     //   3893	15	15	le	Lorg/luaj/vm2/LuaError;
/*     */     //   3882	26	14	e	Ljava/lang/Exception;
/*     */     //   3920	27	20	u	I
/*     */     //   0	3977	0	this	Lorg/luaj/vm2/LuaClosure;
/*     */     //   0	3977	1	stack	[Lorg/luaj/vm2/LuaValue;
/*     */     //   0	3977	2	varargs	Lorg/luaj/vm2/Varargs;
/*     */     //   3	3974	7	pc	I
/*     */     //   6	3971	8	top	I
/*     */     //   11	3966	10	v	Lorg/luaj/vm2/Varargs;
/*     */     //   20	3957	11	code	[I
/*     */     //   29	3948	12	k	[Lorg/luaj/vm2/LuaValue;
/*     */     //   51	3926	13	openups	[Lorg/luaj/vm2/UpValue;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   81	2336	3855	org/luaj/vm2/LuaError
/*     */     //   81	2336	3880	java/lang/Exception
/*     */     //   81	2336	3908	finally
/*     */     //   2403	2422	3855	org/luaj/vm2/LuaError
/*     */     //   2403	2422	3880	java/lang/Exception
/*     */     //   2403	2422	3908	finally
/*     */     //   2489	2517	3855	org/luaj/vm2/LuaError
/*     */     //   2489	2517	3880	java/lang/Exception
/*     */     //   2489	2517	3908	finally
/*     */     //   2584	2618	3855	org/luaj/vm2/LuaError
/*     */     //   2584	2618	3880	java/lang/Exception
/*     */     //   2584	2618	3908	finally
/*     */     //   2685	2751	3855	org/luaj/vm2/LuaError
/*     */     //   2685	2751	3880	java/lang/Exception
/*     */     //   2685	2751	3908	finally
/*     */     //   2818	2873	3855	org/luaj/vm2/LuaError
/*     */     //   2818	2873	3880	java/lang/Exception
/*     */     //   2818	2873	3908	finally
/*     */     //   2940	2945	3855	org/luaj/vm2/LuaError
/*     */     //   2940	2945	3880	java/lang/Exception
/*     */     //   2940	2945	3908	finally
/*     */     //   3012	3018	3855	org/luaj/vm2/LuaError
/*     */     //   3012	3018	3880	java/lang/Exception
/*     */     //   3012	3018	3908	finally
/*     */     //   3085	3097	3855	org/luaj/vm2/LuaError
/*     */     //   3085	3097	3880	java/lang/Exception
/*     */     //   3085	3097	3908	finally
/*     */     //   3164	3855	3855	org/luaj/vm2/LuaError
/*     */     //   3164	3855	3880	java/lang/Exception
/*     */     //   3164	3910	3908	finally
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String errorHook(String msg, int level) {
/* 617 */     if (this.globals == null)
/* 618 */       return msg; 
/* 619 */     LuaThread r = this.globals.running;
/* 620 */     if (r.errorfunc == null)
/* 621 */       return (this.globals.debuglib != null) ? (msg + "\n" + this.globals.debuglib.traceback(level)) : msg; 
/* 622 */     LuaValue e = r.errorfunc;
/* 623 */     r.errorfunc = null;
/*     */     try {
/* 625 */       return e.call(LuaValue.valueOf(msg)).tojstring();
/* 626 */     } catch (Throwable t) {
/* 627 */       return "error in error handling";
/*     */     } finally {
/* 629 */       r.errorfunc = e;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void processErrorHooks(LuaError le, Prototype p, int pc) {
/* 634 */     String file = "?";
/* 635 */     int line = -1;
/*     */     
/* 637 */     DebugLib.CallFrame frame = null;
/* 638 */     if (this.globals != null && this.globals.debuglib != null) {
/* 639 */       frame = this.globals.debuglib.getCallFrame(le.level);
/* 640 */       if (frame != null) {
/* 641 */         String src = frame.shortsource();
/* 642 */         file = (src != null) ? src : "?";
/* 643 */         line = frame.currentline();
/*     */       } 
/*     */     } 
/* 646 */     if (frame == null) {
/* 647 */       file = (p.source != null) ? p.source.tojstring() : "?";
/* 648 */       line = (p.lineinfo != null && pc >= 0 && pc < p.lineinfo.length) ? p.lineinfo[pc] : -1;
/*     */     } 
/*     */     
/* 651 */     le.fileline = file + ":" + line;
/* 652 */     le.traceback = errorHook(le.getMessage(), le.level);
/*     */   }
/*     */   
/*     */   private UpValue findupval(LuaValue[] stack, short idx, UpValue[] openups) {
/* 656 */     int n = openups.length; int i;
/* 657 */     for (i = 0; i < n; i++) {
/* 658 */       if (openups[i] != null && (openups[i]).index == idx)
/* 659 */         return openups[i]; 
/* 660 */     }  for (i = 0; i < n; i++) {
/* 661 */       if (openups[i] == null)
/* 662 */       { openups[i] = new UpValue(stack, idx); return new UpValue(stack, idx); } 
/* 663 */     }  error("No space for upvalue");
/* 664 */     return null;
/*     */   }
/*     */   
/*     */   protected LuaValue getUpvalue(int i) {
/* 668 */     return this.upValues[i].getValue();
/*     */   }
/*     */   
/*     */   protected void setUpvalue(int i, LuaValue v) {
/* 672 */     this.upValues[i].setValue(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public String name() {
/* 677 */     return "<" + this.p.shortsource() + ":" + this.p.linedefined + ">";
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-core-3.0.3.jar!\org\luaj\vm2\LuaClosure.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */