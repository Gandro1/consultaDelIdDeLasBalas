/*      */ package org.luaj.vm2;
/*      */ 
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LuaTable
/*      */   extends LuaValue
/*      */   implements Metatable
/*      */ {
/*      */   private static final int MIN_HASH_CAPACITY = 2;
/*   81 */   private static final LuaString N = valueOf("n");
/*      */ 
/*      */   
/*      */   protected LuaValue[] array;
/*      */ 
/*      */   
/*      */   protected Slot[] hash;
/*      */ 
/*      */   
/*      */   protected int hashEntries;
/*      */ 
/*      */   
/*      */   protected Metatable m_metatable;
/*      */ 
/*      */   
/*      */   public LuaTable() {
/*   97 */     this.array = NOVALS;
/*   98 */     this.hash = NOBUCKETS;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaTable(int narray, int nhash) {
/*  108 */     presize(narray, nhash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaTable(LuaValue[] named, LuaValue[] unnamed, Varargs lastarg) {
/*  120 */     int nn = (named != null) ? named.length : 0;
/*  121 */     int nu = (unnamed != null) ? unnamed.length : 0;
/*  122 */     int nl = (lastarg != null) ? lastarg.narg() : 0;
/*  123 */     presize(nu + nl, nn >> 1); int i;
/*  124 */     for (i = 0; i < nu; i++)
/*  125 */       rawset(i + 1, unnamed[i]); 
/*  126 */     if (lastarg != null) {
/*  127 */       int n; for (i = 1, n = lastarg.narg(); i <= n; i++)
/*  128 */         rawset(nu + i, lastarg.arg(i)); 
/*  129 */     }  for (i = 0; i < nn; i += 2) {
/*  130 */       if (!named[i + 1].isnil()) {
/*  131 */         rawset(named[i], named[i + 1]);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaTable(Varargs varargs) {
/*  140 */     this(varargs, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaTable(Varargs varargs, int firstarg) {
/*  151 */     int nskip = firstarg - 1;
/*  152 */     int n = Math.max(varargs.narg() - nskip, 0);
/*  153 */     presize(n, 1);
/*  154 */     set(N, valueOf(n));
/*  155 */     for (int i = 1; i <= n; i++) {
/*  156 */       set(i, varargs.arg(i + nskip));
/*      */     }
/*      */   }
/*      */   
/*      */   public int type() {
/*  161 */     return 5;
/*      */   }
/*      */ 
/*      */   
/*      */   public String typename() {
/*  166 */     return "table";
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean istable() {
/*  171 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaTable checktable() {
/*  176 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaTable opttable(LuaTable defval) {
/*  181 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public void presize(int narray) {
/*  186 */     if (narray > this.array.length)
/*  187 */       this.array = resize(this.array, 1 << log2(narray)); 
/*      */   }
/*      */   
/*      */   public void presize(int narray, int nhash) {
/*  191 */     if (nhash > 0 && nhash < 2) {
/*  192 */       nhash = 2;
/*      */     }
/*  194 */     this.array = (narray > 0) ? new LuaValue[1 << log2(narray)] : NOVALS;
/*  195 */     this.hash = (nhash > 0) ? new Slot[1 << log2(nhash)] : NOBUCKETS;
/*  196 */     this.hashEntries = 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private static LuaValue[] resize(LuaValue[] old, int n) {
/*  201 */     LuaValue[] v = new LuaValue[n];
/*  202 */     System.arraycopy(old, 0, v, 0, old.length);
/*  203 */     return v;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getArrayLength() {
/*  212 */     return this.array.length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getHashLength() {
/*  220 */     return this.hash.length;
/*      */   }
/*      */   
/*      */   public LuaValue getmetatable() {
/*  224 */     return (this.m_metatable != null) ? this.m_metatable.toLuaValue() : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaValue setmetatable(LuaValue metatable) {
/*  229 */     boolean hadWeakKeys = (this.m_metatable != null && this.m_metatable.useWeakKeys());
/*  230 */     boolean hadWeakValues = (this.m_metatable != null && this.m_metatable.useWeakValues());
/*  231 */     this.m_metatable = metatableOf(metatable);
/*  232 */     if (hadWeakKeys != ((this.m_metatable != null && this.m_metatable.useWeakKeys())) || hadWeakValues != ((this.m_metatable != null && this.m_metatable
/*  233 */       .useWeakValues())))
/*      */     {
/*  235 */       rehash(0);
/*      */     }
/*  237 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaValue get(int key) {
/*  242 */     LuaValue v = rawget(key);
/*  243 */     return (v.isnil() && this.m_metatable != null) ? gettable(this, valueOf(key)) : v;
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaValue get(LuaValue key) {
/*  248 */     LuaValue v = rawget(key);
/*  249 */     return (v.isnil() && this.m_metatable != null) ? gettable(this, key) : v;
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaValue rawget(int key) {
/*  254 */     if (key > 0 && key <= this.array.length) {
/*  255 */       LuaValue v = (this.m_metatable == null) ? this.array[key - 1] : this.m_metatable.arrayget(this.array, key - 1);
/*  256 */       return (v != null) ? v : NIL;
/*      */     } 
/*  258 */     return hashget(LuaInteger.valueOf(key));
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaValue rawget(LuaValue key) {
/*  263 */     if (key.isinttype()) {
/*  264 */       int ikey = key.toint();
/*  265 */       if (ikey > 0 && ikey <= this.array.length) {
/*  266 */         LuaValue v = (this.m_metatable == null) ? this.array[ikey - 1] : this.m_metatable.arrayget(this.array, ikey - 1);
/*  267 */         return (v != null) ? v : NIL;
/*      */       } 
/*      */     } 
/*  270 */     return hashget(key);
/*      */   }
/*      */   
/*      */   protected LuaValue hashget(LuaValue key) {
/*  274 */     if (this.hashEntries > 0) {
/*  275 */       for (Slot slot = this.hash[hashSlot(key)]; slot != null; slot = slot.rest()) {
/*      */         StrongSlot foundSlot;
/*  277 */         if ((foundSlot = slot.find(key)) != null) {
/*  278 */           return foundSlot.value();
/*      */         }
/*      */       } 
/*      */     }
/*  282 */     return NIL;
/*      */   }
/*      */ 
/*      */   
/*      */   public void set(int key, LuaValue value) {
/*  287 */     if (this.m_metatable == null || !rawget(key).isnil() || !settable(this, LuaInteger.valueOf(key), value)) {
/*  288 */       rawset(key, value);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void set(LuaValue key, LuaValue value) {
/*  294 */     if (key == null || (!key.isvalidkey() && !metatag(NEWINDEX).isfunction()))
/*  295 */       throw new LuaError("value ('" + key + "') can not be used as a table index"); 
/*  296 */     if (this.m_metatable == null || !rawget(key).isnil() || !settable(this, key, value)) {
/*  297 */       rawset(key, value);
/*      */     }
/*      */   }
/*      */   
/*      */   public void rawset(int key, LuaValue value) {
/*  302 */     if (!arrayset(key, value)) {
/*  303 */       hashset(LuaInteger.valueOf(key), value);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void rawset(LuaValue key, LuaValue value) {
/*  309 */     if (!key.isinttype() || !arrayset(key.toint(), value)) {
/*  310 */       hashset(key, value);
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean arrayset(int key, LuaValue value) {
/*  315 */     if (key > 0 && key <= this.array.length) {
/*  316 */       this.array[key - 1] = value.isnil() ? null : ((this.m_metatable != null) ? this.m_metatable.wrap(value) : value);
/*  317 */       return true;
/*      */     } 
/*  319 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue remove(int pos) {
/*  329 */     int n = length();
/*  330 */     if (pos == 0) {
/*  331 */       pos = n;
/*  332 */     } else if (pos > n) {
/*  333 */       return NONE;
/*  334 */     }  LuaValue v = get(pos);
/*  335 */     for (LuaValue r = v; !r.isnil(); ) {
/*  336 */       r = get(pos + 1);
/*  337 */       set(pos++, r);
/*      */     } 
/*  339 */     return v.isnil() ? NONE : v;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void insert(int pos, LuaValue value) {
/*  349 */     if (pos == 0)
/*  350 */       pos = length() + 1; 
/*  351 */     while (!value.isnil()) {
/*  352 */       LuaValue v = get(pos);
/*  353 */       set(pos++, value);
/*  354 */       value = v;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue concat(LuaString sep, int i, int j) {
/*  367 */     Buffer sb = new Buffer();
/*  368 */     if (i <= j) {
/*  369 */       sb.append(get(i).checkstring());
/*  370 */       while (++i <= j) {
/*  371 */         sb.append(sep);
/*  372 */         sb.append(get(i).checkstring());
/*      */       } 
/*      */     } 
/*  375 */     return sb.tostring();
/*      */   }
/*      */ 
/*      */   
/*      */   public int length() {
/*  380 */     if (this.m_metatable != null) {
/*  381 */       LuaValue len = len();
/*  382 */       if (!len.isint())
/*  383 */         throw new LuaError("table length is not an integer: " + len); 
/*  384 */       return len.toint();
/*      */     } 
/*  386 */     return rawlen();
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaValue len() {
/*  391 */     LuaValue h = metatag(LEN);
/*  392 */     if (h.toboolean())
/*  393 */       return h.call(this); 
/*  394 */     return LuaInteger.valueOf(rawlen());
/*      */   }
/*      */ 
/*      */   
/*      */   public int rawlen() {
/*  399 */     int a = getArrayLength();
/*  400 */     int n = a + 1, m = 0;
/*  401 */     while (!rawget(n).isnil()) {
/*  402 */       m = n;
/*  403 */       n += a + getHashLength() + 1;
/*      */     } 
/*  405 */     while (n > m + 1) {
/*  406 */       int k = (n + m) / 2;
/*  407 */       if (!rawget(k).isnil()) {
/*  408 */         m = k; continue;
/*      */       } 
/*  410 */       n = k;
/*      */     } 
/*  412 */     return m;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs next(LuaValue key) {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore_2
/*      */     //   2: aload_1
/*      */     //   3: invokevirtual isnil : ()Z
/*      */     //   6: ifne -> 180
/*      */     //   9: aload_1
/*      */     //   10: invokevirtual isinttype : ()Z
/*      */     //   13: ifeq -> 37
/*      */     //   16: aload_1
/*      */     //   17: invokevirtual toint : ()I
/*      */     //   20: istore_2
/*      */     //   21: iload_2
/*      */     //   22: ifle -> 37
/*      */     //   25: iload_2
/*      */     //   26: aload_0
/*      */     //   27: getfield array : [Lorg/luaj/vm2/LuaValue;
/*      */     //   30: arraylength
/*      */     //   31: if_icmpgt -> 37
/*      */     //   34: goto -> 180
/*      */     //   37: aload_0
/*      */     //   38: getfield hash : [Lorg/luaj/vm2/LuaTable$Slot;
/*      */     //   41: arraylength
/*      */     //   42: ifne -> 68
/*      */     //   45: new java/lang/StringBuilder
/*      */     //   48: dup
/*      */     //   49: invokespecial <init> : ()V
/*      */     //   52: ldc 'invalid key to 'next' 1: '
/*      */     //   54: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   57: aload_1
/*      */     //   58: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   61: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   64: invokestatic error : (Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
/*      */     //   67: pop
/*      */     //   68: aload_0
/*      */     //   69: aload_1
/*      */     //   70: invokespecial hashSlot : (Lorg/luaj/vm2/LuaValue;)I
/*      */     //   73: istore_2
/*      */     //   74: iconst_0
/*      */     //   75: istore_3
/*      */     //   76: aload_0
/*      */     //   77: getfield hash : [Lorg/luaj/vm2/LuaTable$Slot;
/*      */     //   80: iload_2
/*      */     //   81: aaload
/*      */     //   82: astore #4
/*      */     //   84: aload #4
/*      */     //   86: ifnull -> 143
/*      */     //   89: iload_3
/*      */     //   90: ifeq -> 118
/*      */     //   93: aload #4
/*      */     //   95: invokeinterface first : ()Lorg/luaj/vm2/LuaTable$StrongSlot;
/*      */     //   100: astore #5
/*      */     //   102: aload #5
/*      */     //   104: ifnull -> 115
/*      */     //   107: aload #5
/*      */     //   109: invokeinterface toVarargs : ()Lorg/luaj/vm2/Varargs;
/*      */     //   114: areturn
/*      */     //   115: goto -> 131
/*      */     //   118: aload #4
/*      */     //   120: aload_1
/*      */     //   121: invokeinterface keyeq : (Lorg/luaj/vm2/LuaValue;)Z
/*      */     //   126: ifeq -> 131
/*      */     //   129: iconst_1
/*      */     //   130: istore_3
/*      */     //   131: aload #4
/*      */     //   133: invokeinterface rest : ()Lorg/luaj/vm2/LuaTable$Slot;
/*      */     //   138: astore #4
/*      */     //   140: goto -> 84
/*      */     //   143: iload_3
/*      */     //   144: ifne -> 170
/*      */     //   147: new java/lang/StringBuilder
/*      */     //   150: dup
/*      */     //   151: invokespecial <init> : ()V
/*      */     //   154: ldc 'invalid key to 'next' 2: '
/*      */     //   156: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   159: aload_1
/*      */     //   160: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   163: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   166: invokestatic error : (Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
/*      */     //   169: pop
/*      */     //   170: iload_2
/*      */     //   171: iconst_1
/*      */     //   172: aload_0
/*      */     //   173: getfield array : [Lorg/luaj/vm2/LuaValue;
/*      */     //   176: arraylength
/*      */     //   177: iadd
/*      */     //   178: iadd
/*      */     //   179: istore_2
/*      */     //   180: iload_2
/*      */     //   181: aload_0
/*      */     //   182: getfield array : [Lorg/luaj/vm2/LuaValue;
/*      */     //   185: arraylength
/*      */     //   186: if_icmpge -> 250
/*      */     //   189: aload_0
/*      */     //   190: getfield array : [Lorg/luaj/vm2/LuaValue;
/*      */     //   193: iload_2
/*      */     //   194: aaload
/*      */     //   195: ifnull -> 244
/*      */     //   198: aload_0
/*      */     //   199: getfield m_metatable : Lorg/luaj/vm2/Metatable;
/*      */     //   202: ifnonnull -> 214
/*      */     //   205: aload_0
/*      */     //   206: getfield array : [Lorg/luaj/vm2/LuaValue;
/*      */     //   209: iload_2
/*      */     //   210: aaload
/*      */     //   211: goto -> 228
/*      */     //   214: aload_0
/*      */     //   215: getfield m_metatable : Lorg/luaj/vm2/Metatable;
/*      */     //   218: aload_0
/*      */     //   219: getfield array : [Lorg/luaj/vm2/LuaValue;
/*      */     //   222: iload_2
/*      */     //   223: invokeinterface arrayget : ([Lorg/luaj/vm2/LuaValue;I)Lorg/luaj/vm2/LuaValue;
/*      */     //   228: astore_3
/*      */     //   229: aload_3
/*      */     //   230: ifnull -> 244
/*      */     //   233: iload_2
/*      */     //   234: iconst_1
/*      */     //   235: iadd
/*      */     //   236: invokestatic valueOf : (I)Lorg/luaj/vm2/LuaInteger;
/*      */     //   239: aload_3
/*      */     //   240: invokestatic varargsOf : (Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
/*      */     //   243: areturn
/*      */     //   244: iinc #2, 1
/*      */     //   247: goto -> 180
/*      */     //   250: iload_2
/*      */     //   251: aload_0
/*      */     //   252: getfield array : [Lorg/luaj/vm2/LuaValue;
/*      */     //   255: arraylength
/*      */     //   256: isub
/*      */     //   257: istore_2
/*      */     //   258: iload_2
/*      */     //   259: aload_0
/*      */     //   260: getfield hash : [Lorg/luaj/vm2/LuaTable$Slot;
/*      */     //   263: arraylength
/*      */     //   264: if_icmpge -> 315
/*      */     //   267: aload_0
/*      */     //   268: getfield hash : [Lorg/luaj/vm2/LuaTable$Slot;
/*      */     //   271: iload_2
/*      */     //   272: aaload
/*      */     //   273: astore_3
/*      */     //   274: aload_3
/*      */     //   275: ifnull -> 309
/*      */     //   278: aload_3
/*      */     //   279: invokeinterface first : ()Lorg/luaj/vm2/LuaTable$StrongSlot;
/*      */     //   284: astore #4
/*      */     //   286: aload #4
/*      */     //   288: ifnull -> 299
/*      */     //   291: aload #4
/*      */     //   293: invokeinterface toVarargs : ()Lorg/luaj/vm2/Varargs;
/*      */     //   298: areturn
/*      */     //   299: aload_3
/*      */     //   300: invokeinterface rest : ()Lorg/luaj/vm2/LuaTable$Slot;
/*      */     //   305: astore_3
/*      */     //   306: goto -> 274
/*      */     //   309: iinc #2, 1
/*      */     //   312: goto -> 258
/*      */     //   315: getstatic org/luaj/vm2/LuaTable.NIL : Lorg/luaj/vm2/LuaValue;
/*      */     //   318: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #422	-> 0
/*      */     //   #425	-> 2
/*      */     //   #426	-> 9
/*      */     //   #427	-> 16
/*      */     //   #428	-> 21
/*      */     //   #429	-> 34
/*      */     //   #432	-> 37
/*      */     //   #433	-> 45
/*      */     //   #434	-> 68
/*      */     //   #435	-> 74
/*      */     //   #436	-> 76
/*      */     //   #437	-> 89
/*      */     //   #438	-> 93
/*      */     //   #439	-> 102
/*      */     //   #440	-> 107
/*      */     //   #442	-> 115
/*      */     //   #443	-> 129
/*      */     //   #436	-> 131
/*      */     //   #446	-> 143
/*      */     //   #447	-> 147
/*      */     //   #449	-> 170
/*      */     //   #454	-> 180
/*      */     //   #455	-> 189
/*      */     //   #456	-> 198
/*      */     //   #457	-> 229
/*      */     //   #458	-> 233
/*      */     //   #454	-> 244
/*      */     //   #464	-> 250
/*      */     //   #465	-> 267
/*      */     //   #466	-> 274
/*      */     //   #467	-> 278
/*      */     //   #468	-> 286
/*      */     //   #469	-> 291
/*      */     //   #470	-> 299
/*      */     //   #471	-> 306
/*      */     //   #464	-> 309
/*      */     //   #475	-> 315
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   102	13	5	nextEntry	Lorg/luaj/vm2/LuaTable$StrongSlot;
/*      */     //   84	59	4	slot	Lorg/luaj/vm2/LuaTable$Slot;
/*      */     //   76	104	3	found	Z
/*      */     //   229	15	3	value	Lorg/luaj/vm2/LuaValue;
/*      */     //   286	20	4	first	Lorg/luaj/vm2/LuaTable$StrongSlot;
/*      */     //   274	35	3	slot	Lorg/luaj/vm2/LuaTable$Slot;
/*      */     //   0	319	0	this	Lorg/luaj/vm2/LuaTable;
/*      */     //   0	319	1	key	Lorg/luaj/vm2/LuaValue;
/*      */     //   2	317	2	i	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Varargs inext(LuaValue key) {
/*  486 */     int k = key.checkint() + 1;
/*  487 */     LuaValue v = rawget(k);
/*  488 */     return v.isnil() ? NONE : varargsOf(LuaInteger.valueOf(k), v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void hashset(LuaValue key, LuaValue value) {
/*  498 */     if (value.isnil()) {
/*  499 */       hashRemove(key);
/*      */     } else {
/*  501 */       int index = 0;
/*  502 */       if (this.hash.length > 0) {
/*  503 */         index = hashSlot(key);
/*  504 */         for (Slot slot = this.hash[index]; slot != null; slot = slot.rest()) {
/*      */           StrongSlot foundSlot;
/*  506 */           if ((foundSlot = slot.find(key)) != null) {
/*  507 */             this.hash[index] = this.hash[index].set(foundSlot, value);
/*      */             return;
/*      */           } 
/*      */         } 
/*      */       } 
/*  512 */       if (checkLoadFactor()) {
/*  513 */         if ((this.m_metatable == null || !this.m_metatable.useWeakValues()) && key.isinttype() && key.toint() > 0) {
/*      */           
/*  515 */           rehash(key.toint());
/*  516 */           if (arrayset(key.toint(), value))
/*      */             return; 
/*      */         } else {
/*  519 */           rehash(-1);
/*      */         } 
/*  521 */         index = hashSlot(key);
/*      */       } 
/*  523 */       Slot entry = (this.m_metatable != null) ? this.m_metatable.entry(key, value) : defaultEntry(key, value);
/*  524 */       this.hash[index] = (this.hash[index] != null) ? this.hash[index].add(entry) : entry;
/*  525 */       this.hashEntries++;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static int hashpow2(int hashCode, int mask) {
/*  530 */     return hashCode & mask;
/*      */   }
/*      */   
/*      */   public static int hashmod(int hashCode, int mask) {
/*  534 */     return (hashCode & Integer.MAX_VALUE) % mask;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int hashSlot(LuaValue key, int hashMask) {
/*  546 */     switch (key.type()) {
/*      */       case 2:
/*      */       case 3:
/*      */       case 5:
/*      */       case 7:
/*      */       case 8:
/*  552 */         return hashmod(key.hashCode(), hashMask);
/*      */     } 
/*  554 */     return hashpow2(key.hashCode(), hashMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int hashSlot(LuaValue key) {
/*  565 */     return hashSlot(key, this.hash.length - 1);
/*      */   }
/*      */   
/*      */   private void hashRemove(LuaValue key) {
/*  569 */     if (this.hash.length > 0) {
/*  570 */       int index = hashSlot(key);
/*  571 */       for (Slot slot = this.hash[index]; slot != null; slot = slot.rest()) {
/*      */         StrongSlot foundSlot;
/*  573 */         if ((foundSlot = slot.find(key)) != null) {
/*  574 */           this.hash[index] = this.hash[index].remove(foundSlot);
/*  575 */           this.hashEntries--;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean checkLoadFactor() {
/*  583 */     return (this.hashEntries >= this.hash.length);
/*      */   }
/*      */   
/*      */   private int countHashKeys() {
/*  587 */     int keys = 0;
/*  588 */     for (Slot element : this.hash) {
/*  589 */       for (Slot slot = element; slot != null; slot = slot.rest()) {
/*  590 */         if (slot.first() != null)
/*  591 */           keys++; 
/*      */       } 
/*      */     } 
/*  594 */     return keys;
/*      */   }
/*      */   
/*      */   private void dropWeakArrayValues() {
/*  598 */     for (int i = 0; i < this.array.length; i++) {
/*  599 */       this.m_metatable.arrayget(this.array, i);
/*      */     }
/*      */   }
/*      */   
/*      */   private int countIntKeys(int[] nums) {
/*  604 */     int total = 0;
/*  605 */     int i = 1;
/*      */ 
/*      */     
/*  608 */     for (int bit = 0; bit < 31 && 
/*  609 */       i <= this.array.length; bit++) {
/*      */       
/*  611 */       int j = Math.min(this.array.length, 1 << bit);
/*  612 */       int c = 0;
/*  613 */       while (i <= j) {
/*  614 */         if (this.array[i++ - 1] != null)
/*  615 */           c++; 
/*      */       } 
/*  617 */       nums[bit] = c;
/*  618 */       total += c;
/*      */     } 
/*      */ 
/*      */     
/*  622 */     for (i = 0; i < this.hash.length; i++) {
/*  623 */       for (Slot s = this.hash[i]; s != null; s = s.rest()) {
/*      */         int k;
/*  625 */         if ((k = s.arraykey(2147483647)) > 0) {
/*  626 */           nums[log2(k)] = nums[log2(k)] + 1;
/*  627 */           total++;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  632 */     return total;
/*      */   }
/*      */ 
/*      */   
/*      */   static int log2(int x) {
/*  637 */     int lg = 0;
/*  638 */     x--;
/*  639 */     if (x < 0)
/*      */     {
/*  641 */       return Integer.MIN_VALUE; } 
/*  642 */     if ((x & 0xFFFF0000) != 0) {
/*  643 */       lg = 16;
/*  644 */       x >>>= 16;
/*      */     } 
/*  646 */     if ((x & 0xFF00) != 0) {
/*  647 */       lg += 8;
/*  648 */       x >>>= 8;
/*      */     } 
/*  650 */     if ((x & 0xF0) != 0) {
/*  651 */       lg += 4;
/*  652 */       x >>>= 4;
/*      */     } 
/*  654 */     switch (x) {
/*      */       case 0:
/*  656 */         return 0;
/*      */       case 1:
/*  658 */         lg++;
/*      */         break;
/*      */       case 2:
/*  661 */         lg += 2;
/*      */         break;
/*      */       case 3:
/*  664 */         lg += 2;
/*      */         break;
/*      */       case 4:
/*  667 */         lg += 3;
/*      */         break;
/*      */       case 5:
/*  670 */         lg += 3;
/*      */         break;
/*      */       case 6:
/*  673 */         lg += 3;
/*      */         break;
/*      */       case 7:
/*  676 */         lg += 3;
/*      */         break;
/*      */       case 8:
/*  679 */         lg += 4;
/*      */         break;
/*      */       case 9:
/*  682 */         lg += 4;
/*      */         break;
/*      */       case 10:
/*  685 */         lg += 4;
/*      */         break;
/*      */       case 11:
/*  688 */         lg += 4;
/*      */         break;
/*      */       case 12:
/*  691 */         lg += 4;
/*      */         break;
/*      */       case 13:
/*  694 */         lg += 4;
/*      */         break;
/*      */       case 14:
/*  697 */         lg += 4;
/*      */         break;
/*      */       case 15:
/*  700 */         lg += 4;
/*      */         break;
/*      */     } 
/*  703 */     return lg;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void rehash(int newKey) {
/*      */     LuaValue[] newArray;
/*      */     Slot[] newHash;
/*      */     int newHashMask;
/*  712 */     if (this.m_metatable != null && (this.m_metatable.useWeakKeys() || this.m_metatable.useWeakValues())) {
/*      */       
/*  714 */       this.hashEntries = countHashKeys();
/*  715 */       if (this.m_metatable.useWeakValues()) {
/*  716 */         dropWeakArrayValues();
/*      */       }
/*      */     } 
/*  719 */     int[] nums = new int[32];
/*  720 */     int total = countIntKeys(nums);
/*  721 */     if (newKey > 0) {
/*  722 */       total++;
/*  723 */       nums[log2(newKey)] = nums[log2(newKey)] + 1;
/*      */     } 
/*      */ 
/*      */     
/*  727 */     int keys = nums[0];
/*  728 */     int newArraySize = 0;
/*  729 */     for (int log = 1; log < 32; log++) {
/*  730 */       keys += nums[log];
/*  731 */       if (total * 2 < 1 << log) {
/*      */         break;
/*      */       }
/*  734 */       if (keys >= 1 << log - 1) {
/*  735 */         newArraySize = 1 << log;
/*      */       }
/*      */     } 
/*      */     
/*  739 */     LuaValue[] oldArray = this.array;
/*  740 */     Slot[] oldHash = this.hash;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  745 */     int movingToArray = 0;
/*  746 */     if (newKey > 0 && newKey <= newArraySize) {
/*  747 */       movingToArray--;
/*      */     }
/*  749 */     if (newArraySize != oldArray.length) {
/*  750 */       newArray = new LuaValue[newArraySize];
/*  751 */       if (newArraySize > oldArray.length) {
/*  752 */         for (int k = log2(oldArray.length + 1), j = log2(newArraySize) + 1; k < j; k++) {
/*  753 */           movingToArray += nums[k];
/*      */         }
/*  755 */       } else if (oldArray.length > newArraySize) {
/*  756 */         for (int k = log2(newArraySize + 1), j = log2(oldArray.length) + 1; k < j; k++) {
/*  757 */           movingToArray -= nums[k];
/*      */         }
/*      */       } 
/*  760 */       System.arraycopy(oldArray, 0, newArray, 0, Math.min(oldArray.length, newArraySize));
/*      */     } else {
/*  762 */       newArray = this.array;
/*      */     } 
/*      */     
/*  765 */     int newHashSize = this.hashEntries - movingToArray + ((newKey < 0 || newKey > newArraySize) ? 1 : 0);
/*  766 */     int oldCapacity = oldHash.length;
/*      */ 
/*      */ 
/*      */     
/*  770 */     if (newHashSize > 0) {
/*      */       
/*  772 */       int newCapacity = (newHashSize < 2) ? 2 : (1 << log2(newHashSize));
/*  773 */       newHashMask = newCapacity - 1;
/*  774 */       newHash = new Slot[newCapacity];
/*      */     } else {
/*  776 */       int newCapacity = 0;
/*  777 */       newHashMask = 0;
/*  778 */       newHash = NOBUCKETS;
/*      */     } 
/*      */     
/*      */     int i;
/*  782 */     for (i = 0; i < oldCapacity; i++) {
/*  783 */       for (Slot slot = oldHash[i]; slot != null; slot = slot.rest()) {
/*      */         int k;
/*  785 */         if ((k = slot.arraykey(newArraySize)) > 0) {
/*  786 */           StrongSlot entry = slot.first();
/*  787 */           if (entry != null)
/*  788 */             newArray[k - 1] = entry.value(); 
/*  789 */         } else if (!(slot instanceof DeadSlot)) {
/*  790 */           int j = slot.keyindex(newHashMask);
/*  791 */           newHash[j] = slot.relink(newHash[j]);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  797 */     for (i = newArraySize; i < oldArray.length;) {
/*      */       
/*  799 */       if ((v = oldArray[i++]) != null) {
/*  800 */         Slot newEntry; int slot = hashmod(LuaInteger.hashCode(i), newHashMask);
/*      */         
/*  802 */         if (this.m_metatable != null) {
/*  803 */           newEntry = this.m_metatable.entry(valueOf(i), v);
/*  804 */           if (newEntry == null)
/*      */             continue; 
/*      */         } else {
/*  807 */           newEntry = defaultEntry(valueOf(i), v);
/*      */         } 
/*  809 */         newHash[slot] = (newHash[slot] != null) ? newHash[slot].add(newEntry) : newEntry;
/*      */       } 
/*      */     } 
/*      */     
/*  813 */     this.hash = newHash;
/*  814 */     this.array = newArray;
/*  815 */     this.hashEntries -= movingToArray;
/*      */   }
/*      */ 
/*      */   
/*      */   public Slot entry(LuaValue key, LuaValue value) {
/*  820 */     return defaultEntry(key, value);
/*      */   }
/*      */   
/*      */   protected static boolean isLargeKey(LuaValue key) {
/*  824 */     switch (key.type()) {
/*      */       case 4:
/*  826 */         return (key.rawlen() > 32);
/*      */       case 1:
/*      */       case 3:
/*  829 */         return false;
/*      */     } 
/*  831 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   protected static Entry defaultEntry(LuaValue key, LuaValue value) {
/*  836 */     if (key.isinttype())
/*  837 */       return new IntKeyEntry(key.toint(), value); 
/*  838 */     if (value.type() == 3) {
/*  839 */       return new NumberValueEntry(key, value.todouble());
/*      */     }
/*  841 */     return new NormalEntry(key, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sort(LuaValue comparator) {
/*  857 */     if (len().tolong() >= 2147483647L)
/*  858 */       throw new LuaError("array too big: " + len().tolong()); 
/*  859 */     if (this.m_metatable != null && this.m_metatable.useWeakValues()) {
/*  860 */       dropWeakArrayValues();
/*      */     }
/*  862 */     int n = length();
/*  863 */     if (n > 1)
/*  864 */       heapSort(n, comparator.isnil() ? null : comparator); 
/*      */   }
/*      */   
/*      */   private void heapSort(int count, LuaValue cmpfunc) {
/*  868 */     heapify(count, cmpfunc);
/*  869 */     for (int end = count; end > 1; ) {
/*  870 */       LuaValue a = get(end);
/*  871 */       set(end, get(1));
/*  872 */       set(1, a);
/*  873 */       siftDown(1, --end, cmpfunc);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void heapify(int count, LuaValue cmpfunc) {
/*  878 */     for (int start = count / 2; start > 0; start--)
/*  879 */       siftDown(start, count, cmpfunc); 
/*      */   }
/*      */   
/*      */   private void siftDown(int start, int end, LuaValue cmpfunc) {
/*  883 */     for (int root = start; root * 2 <= end; ) {
/*  884 */       int child = root * 2;
/*  885 */       if (child < end && compare(child, child + 1, cmpfunc))
/*  886 */         child++; 
/*  887 */       if (compare(root, child, cmpfunc)) {
/*  888 */         LuaValue a = get(root);
/*  889 */         set(root, get(child));
/*  890 */         set(child, a);
/*  891 */         root = child;
/*      */         continue;
/*      */       } 
/*      */       return;
/*      */     } 
/*      */   }
/*      */   private boolean compare(int i, int j, LuaValue cmpfunc) {
/*  898 */     LuaValue a = get(i), b = get(j);
/*  899 */     if (a == null || b == null)
/*  900 */       return false; 
/*  901 */     if (cmpfunc != null) {
/*  902 */       return cmpfunc.call(a, b).toboolean();
/*      */     }
/*  904 */     return a.lt_b(b);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int keyCount() {
/*  915 */     LuaValue k = LuaValue.NIL;
/*  916 */     for (int i = 0;; i++) {
/*  917 */       Varargs n = next(k);
/*  918 */       if ((k = n.arg1()).isnil()) {
/*  919 */         return i;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue[] keys() {
/*  930 */     Vector<LuaValue> l = new Vector();
/*  931 */     LuaValue k = LuaValue.NIL;
/*      */     
/*  933 */     Varargs n = next(k);
/*  934 */     while (!(k = n.arg1()).isnil())
/*      */     {
/*  936 */       l.addElement(k);
/*      */     }
/*  938 */     LuaValue[] a = new LuaValue[l.size()];
/*  939 */     l.copyInto((Object[])a);
/*  940 */     return a;
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaValue eq(LuaValue val) {
/*  945 */     return eq_b(val) ? TRUE : FALSE;
/*      */   }
/*      */   
/*      */   public boolean eq_b(LuaValue val) {
/*  949 */     if (this == val)
/*  950 */       return true; 
/*  951 */     if (this.m_metatable == null || !val.istable())
/*  952 */       return false; 
/*  953 */     LuaValue valmt = val.getmetatable();
/*  954 */     return (valmt != null && LuaValue.eqmtcall(this, this.m_metatable.toLuaValue(), val, valmt));
/*      */   }
/*      */ 
/*      */   
/*      */   public Varargs unpack() {
/*  959 */     return unpack(1, rawlen());
/*      */   }
/*      */ 
/*      */   
/*      */   public Varargs unpack(int i) {
/*  964 */     return unpack(i, rawlen());
/*      */   }
/*      */ 
/*      */   
/*      */   public Varargs unpack(int i, int j) {
/*  969 */     if (j < i)
/*  970 */       return NONE; 
/*  971 */     int count = j - i;
/*  972 */     if (count < 0)
/*  973 */       throw new LuaError("too many results to unpack: greater 2147483647"); 
/*  974 */     int max = 16777215;
/*  975 */     if (count >= max)
/*  976 */       throw new LuaError("too many results to unpack: " + count + " (max is " + max + ')'); 
/*  977 */     int n = j + 1 - i;
/*  978 */     switch (n) {
/*      */       case 0:
/*  980 */         return NONE;
/*      */       case 1:
/*  982 */         return get(i);
/*      */       case 2:
/*  984 */         return varargsOf(get(i), get(i + 1));
/*      */     } 
/*  986 */     if (n < 0)
/*  987 */       return NONE; 
/*      */     try {
/*  989 */       LuaValue[] v = new LuaValue[n];
/*  990 */       while (--n >= 0)
/*  991 */         v[n] = get(i + n); 
/*  992 */       return varargsOf(v);
/*  993 */     } catch (OutOfMemoryError e) {
/*  994 */       throw new LuaError("too many results to unpack [out of memory]: " + n);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static interface Slot
/*      */   {
/*      */     int keyindex(int param1Int);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     LuaTable.StrongSlot first();
/*      */ 
/*      */ 
/*      */     
/*      */     LuaTable.StrongSlot find(LuaValue param1LuaValue);
/*      */ 
/*      */ 
/*      */     
/*      */     boolean keyeq(LuaValue param1LuaValue);
/*      */ 
/*      */ 
/*      */     
/*      */     Slot rest();
/*      */ 
/*      */ 
/*      */     
/*      */     int arraykey(int param1Int);
/*      */ 
/*      */ 
/*      */     
/*      */     Slot set(LuaTable.StrongSlot param1StrongSlot, LuaValue param1LuaValue);
/*      */ 
/*      */ 
/*      */     
/*      */     Slot add(Slot param1Slot);
/*      */ 
/*      */ 
/*      */     
/*      */     Slot remove(LuaTable.StrongSlot param1StrongSlot);
/*      */ 
/*      */ 
/*      */     
/*      */     Slot relink(Slot param1Slot);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static interface StrongSlot
/*      */     extends Slot
/*      */   {
/*      */     LuaValue key();
/*      */ 
/*      */ 
/*      */     
/*      */     LuaValue value();
/*      */ 
/*      */ 
/*      */     
/*      */     Varargs toVarargs();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class LinkSlot
/*      */     implements StrongSlot
/*      */   {
/*      */     private LuaTable.Entry entry;
/*      */ 
/*      */     
/*      */     private LuaTable.Slot next;
/*      */ 
/*      */ 
/*      */     
/*      */     LinkSlot(LuaTable.Entry entry, LuaTable.Slot next) {
/* 1072 */       this.entry = entry;
/* 1073 */       this.next = next;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaValue key() {
/* 1078 */       return this.entry.key();
/*      */     }
/*      */ 
/*      */     
/*      */     public int keyindex(int hashMask) {
/* 1083 */       return this.entry.keyindex(hashMask);
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaValue value() {
/* 1088 */       return this.entry.value();
/*      */     }
/*      */ 
/*      */     
/*      */     public Varargs toVarargs() {
/* 1093 */       return this.entry.toVarargs();
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.StrongSlot first() {
/* 1098 */       return this.entry;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.StrongSlot find(LuaValue key) {
/* 1103 */       return this.entry.keyeq(key) ? this : null;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean keyeq(LuaValue key) {
/* 1108 */       return this.entry.keyeq(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.Slot rest() {
/* 1113 */       return this.next;
/*      */     }
/*      */ 
/*      */     
/*      */     public int arraykey(int max) {
/* 1118 */       return this.entry.arraykey(max);
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.Slot set(LuaTable.StrongSlot target, LuaValue value) {
/* 1123 */       if (target == this) {
/* 1124 */         this.entry = this.entry.set(value);
/* 1125 */         return this;
/*      */       } 
/* 1127 */       return setnext(this.next.set(target, value));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public LuaTable.Slot add(LuaTable.Slot entry) {
/* 1133 */       return setnext(this.next.add(entry));
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.Slot remove(LuaTable.StrongSlot target) {
/* 1138 */       if (this == target) {
/* 1139 */         return new LuaTable.DeadSlot(key(), this.next);
/*      */       }
/* 1141 */       this.next = this.next.remove(target);
/*      */       
/* 1143 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public LuaTable.Slot relink(LuaTable.Slot rest) {
/* 1149 */       return (rest != null) ? new LinkSlot(this.entry, rest) : this.entry;
/*      */     }
/*      */ 
/*      */     
/*      */     private LuaTable.Slot setnext(LuaTable.Slot next) {
/* 1154 */       if (next != null) {
/* 1155 */         this.next = next;
/* 1156 */         return this;
/*      */       } 
/* 1158 */       return this.entry;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1164 */       return this.entry + "; " + this.next;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static abstract class Entry
/*      */     extends Varargs
/*      */     implements StrongSlot
/*      */   {
/*      */     public abstract LuaValue key();
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract LuaValue value();
/*      */ 
/*      */ 
/*      */     
/*      */     abstract Entry set(LuaValue param1LuaValue);
/*      */ 
/*      */     
/*      */     public abstract boolean keyeq(LuaValue param1LuaValue);
/*      */ 
/*      */     
/*      */     public abstract int keyindex(int param1Int);
/*      */ 
/*      */     
/*      */     public int arraykey(int max) {
/* 1192 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaValue arg(int i) {
/* 1197 */       switch (i) {
/*      */         case 1:
/* 1199 */           return key();
/*      */         case 2:
/* 1201 */           return value();
/*      */       } 
/* 1203 */       return LuaValue.NIL;
/*      */     }
/*      */ 
/*      */     
/*      */     public int narg() {
/* 1208 */       return 2;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Varargs toVarargs() {
/* 1216 */       return LuaValue.varargsOf(key(), value());
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaValue arg1() {
/* 1221 */       return key();
/*      */     }
/*      */ 
/*      */     
/*      */     public Varargs subargs(int start) {
/* 1226 */       switch (start) {
/*      */         case 1:
/* 1228 */           return this;
/*      */         case 2:
/* 1230 */           return value();
/*      */       } 
/* 1232 */       return LuaValue.NONE;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.StrongSlot first() {
/* 1237 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.Slot rest() {
/* 1242 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.StrongSlot find(LuaValue key) {
/* 1247 */       return keyeq(key) ? this : null;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.Slot set(LuaTable.StrongSlot target, LuaValue value) {
/* 1252 */       return set(value);
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.Slot add(LuaTable.Slot entry) {
/* 1257 */       return new LuaTable.LinkSlot(this, entry);
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.Slot remove(LuaTable.StrongSlot target) {
/* 1262 */       return new LuaTable.DeadSlot(key(), null);
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.Slot relink(LuaTable.Slot rest) {
/* 1267 */       return (rest != null) ? new LuaTable.LinkSlot(this, rest) : this;
/*      */     }
/*      */   }
/*      */   
/*      */   static class NormalEntry extends Entry {
/*      */     private final LuaValue key;
/*      */     private LuaValue value;
/*      */     
/*      */     NormalEntry(LuaValue key, LuaValue value) {
/* 1276 */       this.key = key;
/* 1277 */       this.value = value;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaValue key() {
/* 1282 */       return this.key;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaValue value() {
/* 1287 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.Entry set(LuaValue value) {
/* 1292 */       this.value = value;
/* 1293 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Varargs toVarargs() {
/* 1298 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public int keyindex(int hashMask) {
/* 1303 */       return LuaTable.hashSlot(this.key, hashMask);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean keyeq(LuaValue key) {
/* 1308 */       return key.raweq(this.key);
/*      */     }
/*      */   }
/*      */   
/*      */   private static class IntKeyEntry extends Entry {
/*      */     private final int key;
/*      */     private LuaValue value;
/*      */     
/*      */     IntKeyEntry(int key, LuaValue value) {
/* 1317 */       this.key = key;
/* 1318 */       this.value = value;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaValue key() {
/* 1323 */       return LuaValue.valueOf(this.key);
/*      */     }
/*      */ 
/*      */     
/*      */     public int arraykey(int max) {
/* 1328 */       return (this.key >= 1 && this.key <= max) ? this.key : 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaValue value() {
/* 1333 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.Entry set(LuaValue value) {
/* 1338 */       this.value = value;
/* 1339 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public int keyindex(int mask) {
/* 1344 */       return LuaTable.hashmod(LuaInteger.hashCode(this.key), mask);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean keyeq(LuaValue key) {
/* 1349 */       return key.raweq(this.key);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class NumberValueEntry
/*      */     extends Entry
/*      */   {
/*      */     private double value;
/*      */     
/*      */     private final LuaValue key;
/*      */     
/*      */     NumberValueEntry(LuaValue key, double value) {
/* 1362 */       this.key = key;
/* 1363 */       this.value = value;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaValue key() {
/* 1368 */       return this.key;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaValue value() {
/* 1373 */       return LuaValue.valueOf(this.value);
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.Entry set(LuaValue value) {
/* 1378 */       if (value.type() == 3) {
/* 1379 */         LuaValue n = value.tonumber();
/* 1380 */         if (!n.isnil()) {
/* 1381 */           this.value = n.todouble();
/* 1382 */           return this;
/*      */         } 
/*      */       } 
/* 1385 */       return new LuaTable.NormalEntry(this.key, value);
/*      */     }
/*      */ 
/*      */     
/*      */     public int keyindex(int mask) {
/* 1390 */       return LuaTable.hashSlot(this.key, mask);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean keyeq(LuaValue key) {
/* 1395 */       return key.raweq(this.key);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class DeadSlot
/*      */     implements Slot
/*      */   {
/*      */     private final Object key;
/*      */     
/*      */     private LuaTable.Slot next;
/*      */ 
/*      */     
/*      */     private DeadSlot(LuaValue key, LuaTable.Slot next) {
/* 1409 */       this.key = LuaTable.isLargeKey(key) ? new WeakReference<>(key) : key;
/* 1410 */       this.next = next;
/*      */     }
/*      */     
/*      */     private LuaValue key() {
/* 1414 */       return (this.key instanceof WeakReference) ? ((WeakReference<LuaValue>)this.key).get() : (LuaValue)this.key;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int keyindex(int hashMask) {
/* 1420 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.StrongSlot first() {
/* 1425 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.StrongSlot find(LuaValue key) {
/* 1430 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean keyeq(LuaValue key) {
/* 1435 */       LuaValue k = key();
/* 1436 */       return (k != null && key.raweq(k));
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.Slot rest() {
/* 1441 */       return this.next;
/*      */     }
/*      */ 
/*      */     
/*      */     public int arraykey(int max) {
/* 1446 */       return -1;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.Slot set(LuaTable.StrongSlot target, LuaValue value) {
/* 1451 */       LuaTable.Slot next = (this.next != null) ? this.next.set(target, value) : null;
/* 1452 */       if (key() != null) {
/*      */ 
/*      */         
/* 1455 */         this.next = next;
/* 1456 */         return this;
/*      */       } 
/* 1458 */       return next;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public LuaTable.Slot add(LuaTable.Slot newEntry) {
/* 1464 */       return (this.next != null) ? this.next.add(newEntry) : newEntry;
/*      */     }
/*      */ 
/*      */     
/*      */     public LuaTable.Slot remove(LuaTable.StrongSlot target) {
/* 1469 */       if (key() != null) {
/* 1470 */         this.next = this.next.remove(target);
/* 1471 */         return this;
/*      */       } 
/* 1473 */       return this.next;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public LuaTable.Slot relink(LuaTable.Slot rest) {
/* 1479 */       return rest;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1484 */       StringBuffer buf = new StringBuffer();
/* 1485 */       buf.append("<dead");
/* 1486 */       LuaValue k = key();
/* 1487 */       if (k != null) {
/* 1488 */         buf.append(": ");
/* 1489 */         buf.append(k.toString());
/*      */       } 
/* 1491 */       buf.append('>');
/* 1492 */       if (this.next != null) {
/* 1493 */         buf.append("; ");
/* 1494 */         buf.append(this.next.toString());
/*      */       } 
/* 1496 */       return buf.toString();
/*      */     }
/*      */   }
/*      */   
/* 1500 */   private static final Slot[] NOBUCKETS = new Slot[0];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean useWeakKeys() {
/* 1506 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean useWeakValues() {
/* 1511 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaValue toLuaValue() {
/* 1516 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaValue wrap(LuaValue value) {
/* 1521 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaValue arrayget(LuaValue[] array, int index) {
/* 1526 */     return array[index];
/*      */   }
/*      */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-core-3.0.3.jar!\org\luaj\vm2\LuaTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */