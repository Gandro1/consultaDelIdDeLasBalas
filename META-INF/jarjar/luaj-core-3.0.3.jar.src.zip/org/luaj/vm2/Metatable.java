package org.luaj.vm2;

interface Metatable {
  boolean useWeakKeys();
  
  boolean useWeakValues();
  
  LuaValue toLuaValue();
  
  LuaTable.Slot entry(LuaValue paramLuaValue1, LuaValue paramLuaValue2);
  
  LuaValue wrap(LuaValue paramLuaValue);
  
  LuaValue arrayget(LuaValue[] paramArrayOfLuaValue, int paramInt);
}


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-core-3.0.3.jar!\org\luaj\vm2\Metatable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */