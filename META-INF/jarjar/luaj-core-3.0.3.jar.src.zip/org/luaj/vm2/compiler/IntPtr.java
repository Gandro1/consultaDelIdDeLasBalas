/*    */ package org.luaj.vm2.compiler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntPtr
/*    */ {
/*    */   int i;
/*    */   
/*    */   IntPtr() {}
/*    */   
/*    */   IntPtr(int value) {
/* 31 */     this.i = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-core-3.0.3.jar!\org\luaj\vm2\compiler\IntPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */