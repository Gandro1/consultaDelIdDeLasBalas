/*      */ package org.luaj.vm2.compiler;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.util.Hashtable;
/*      */ import org.luaj.vm2.LocVars;
/*      */ import org.luaj.vm2.Lua;
/*      */ import org.luaj.vm2.LuaError;
/*      */ import org.luaj.vm2.LuaInteger;
/*      */ import org.luaj.vm2.LuaString;
/*      */ import org.luaj.vm2.LuaValue;
/*      */ import org.luaj.vm2.Prototype;
/*      */ import org.luaj.vm2.lib.MathLib;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LexState
/*      */   extends Constants
/*      */ {
/*      */   protected static final String RESERVED_LOCAL_VAR_FOR_CONTROL = "(for control)";
/*      */   protected static final String RESERVED_LOCAL_VAR_FOR_STATE = "(for state)";
/*      */   protected static final String RESERVED_LOCAL_VAR_FOR_GENERATOR = "(for generator)";
/*      */   protected static final String RESERVED_LOCAL_VAR_FOR_STEP = "(for step)";
/*      */   protected static final String RESERVED_LOCAL_VAR_FOR_LIMIT = "(for limit)";
/*      */   protected static final String RESERVED_LOCAL_VAR_FOR_INDEX = "(for index)";
/*   48 */   protected static final String[] RESERVED_LOCAL_VAR_KEYWORDS = new String[] { "(for control)", "(for generator)", "(for index)", "(for limit)", "(for state)", "(for step)" }; private static final int EOZ = -1; private static final int MAX_INT = 2147483645; private static final int UCHAR_MAX = 255; private static final int LUAI_MAXCCALLS = 200; private static final int LUA_COMPAT_LSTR = 1; private static final boolean LUA_COMPAT_VARARG = true; static final int NO_JUMP = -1; static final int OPR_ADD = 0; static final int OPR_SUB = 1;
/*      */   static final int OPR_MUL = 2;
/*      */   static final int OPR_DIV = 3;
/*   51 */   private static final Hashtable RESERVED_LOCAL_VAR_KEYWORDS_TABLE = new Hashtable<>(); static final int OPR_MOD = 4; static final int OPR_POW = 5; static final int OPR_CONCAT = 6; static final int OPR_NE = 7; static final int OPR_EQ = 8; static final int OPR_LT = 9; static final int OPR_LE = 10; static final int OPR_GT = 11; static final int OPR_GE = 12; static final int OPR_AND = 13; static final int OPR_OR = 14;
/*      */   static {
/*   53 */     for (String element : RESERVED_LOCAL_VAR_KEYWORDS)
/*   54 */       RESERVED_LOCAL_VAR_KEYWORDS_TABLE.put(element, Boolean.TRUE); 
/*      */   }
/*      */   static final int OPR_NOBINOPR = 15; static final int OPR_MINUS = 0; static final int OPR_NOT = 1; static final int OPR_LEN = 2; static final int OPR_NOUNOPR = 3; static final int VVOID = 0; static final int VNIL = 1; static final int VTRUE = 2;
/*      */   static final int VFALSE = 3;
/*      */   static final int VK = 4;
/*      */   static final int VKNUM = 5;
/*      */   
/*      */   private static final String LUA_QS(String s) {
/*   62 */     return "'" + s + "'";
/*      */   } static final int VNONRELOC = 6; static final int VLOCAL = 7; static final int VUPVAL = 8; static final int VINDEXED = 9; static final int VJMP = 10; static final int VRELOCABLE = 11; static final int VCALL = 12; static final int VVARARG = 13; int current; int linenumber; int lastline; private static final String LUA_QL(Object o) {
/*   64 */     return LUA_QS(String.valueOf(o));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isReservedKeyword(String varName) {
/*   70 */     return RESERVED_LOCAL_VAR_KEYWORDS_TABLE.containsKey(varName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class SemInfo
/*      */   {
/*      */     LuaValue r;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     LuaString ts;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private SemInfo() {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class Token
/*      */   {
/*      */     int token;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  109 */     final LexState.SemInfo seminfo = new LexState.SemInfo();
/*      */     
/*      */     public void set(Token other) {
/*  112 */       this.token = other.token;
/*  113 */       this.seminfo.r = other.seminfo.r;
/*  114 */       this.seminfo.ts = other.seminfo.ts;
/*      */     }
/*      */ 
/*      */     
/*      */     private Token() {}
/*      */   }
/*      */   
/*  121 */   final Token t = new Token();
/*  122 */   final Token lookahead = new Token();
/*      */   FuncState fs;
/*      */   LuaC.CompileState L;
/*      */   InputStream z;
/*      */   char[] buff;
/*      */   int nbuff;
/*  128 */   Dyndata dyd = new Dyndata();
/*      */   
/*      */   LuaString source;
/*      */   
/*      */   LuaString envn;
/*      */   byte decpoint;
/*  134 */   static final String[] luaX_tokens = new String[] { "and", "break", "do", "else", "elseif", "end", "false", "for", "function", "goto", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then", "true", "until", "while", "..", "...", "==", ">=", "<=", "~=", "::", "<eos>", "<number>", "<name>", "<string>", "<eof>" }; static final int TK_AND = 257; static final int TK_BREAK = 258; static final int TK_DO = 259; static final int TK_ELSE = 260; static final int TK_ELSEIF = 261; static final int TK_END = 262; static final int TK_FALSE = 263; static final int TK_FOR = 264; static final int TK_FUNCTION = 265; static final int TK_GOTO = 266; static final int TK_IF = 267; static final int TK_IN = 268; static final int TK_LOCAL = 269; static final int TK_NIL = 270; static final int TK_NOT = 271; static final int TK_OR = 272; static final int TK_REPEAT = 273; static final int TK_RETURN = 274; static final int TK_THEN = 275;
/*      */   static final int TK_TRUE = 276;
/*      */   static final int TK_UNTIL = 277;
/*      */   static final int TK_WHILE = 278;
/*      */   static final int TK_CONCAT = 279;
/*      */   static final int TK_DOTS = 280;
/*      */   static final int TK_EQ = 281;
/*      */   static final int TK_GE = 282;
/*      */   static final int TK_LE = 283;
/*      */   static final int TK_NE = 284;
/*      */   static final int TK_DBCOLON = 285;
/*      */   static final int TK_EOS = 286;
/*      */   static final int TK_NUMBER = 287;
/*      */   static final int TK_NAME = 288;
/*      */   static final int TK_STRING = 289;
/*      */   static final int FIRST_RESERVED = 257;
/*      */   static final int NUM_RESERVED = 22;
/*  151 */   static final Hashtable RESERVED = new Hashtable<>();
/*      */   static {
/*  153 */     for (int i = 0; i < 22; i++) {
/*  154 */       LuaString ts = LuaValue.valueOf(luaX_tokens[i]);
/*  155 */       RESERVED.put(ts, Integer.valueOf(257 + i));
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean isalnum(int c) {
/*  160 */     return ((c >= 48 && c <= 57) || (c >= 97 && c <= 122) || (c >= 65 && c <= 90) || c == 95);
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isalpha(int c) {
/*  165 */     return ((c >= 97 && c <= 122) || (c >= 65 && c <= 90));
/*      */   }
/*      */   
/*      */   private boolean isdigit(int c) {
/*  169 */     return (c >= 48 && c <= 57);
/*      */   }
/*      */   
/*      */   private boolean isxdigit(int c) {
/*  173 */     return ((c >= 48 && c <= 57) || (c >= 97 && c <= 102) || (c >= 65 && c <= 70));
/*      */   }
/*      */   
/*      */   private boolean isspace(int c) {
/*  177 */     return (c >= 0 && c <= 32);
/*      */   }
/*      */   
/*      */   public LexState(LuaC.CompileState state, InputStream stream) {
/*  181 */     this.z = stream;
/*  182 */     this.buff = new char[32];
/*  183 */     this.L = state;
/*      */   }
/*      */   
/*      */   void nextChar() {
/*      */     try {
/*  188 */       this.current = this.z.read();
/*  189 */     } catch (IOException e) {
/*  190 */       e.printStackTrace();
/*  191 */       this.current = -1;
/*      */     } 
/*      */   }
/*      */   
/*      */   boolean currIsNewline() {
/*  196 */     return (this.current == 10 || this.current == 13);
/*      */   }
/*      */   
/*      */   void save_and_next() {
/*  200 */     save(this.current);
/*  201 */     nextChar();
/*      */   }
/*      */   
/*      */   void save(int c) {
/*  205 */     if (this.buff == null || this.nbuff + 1 > this.buff.length)
/*  206 */       this.buff = realloc(this.buff, this.nbuff * 2 + 1); 
/*  207 */     this.buff[this.nbuff++] = (char)c;
/*      */   }
/*      */   
/*      */   String token2str(int token) {
/*  211 */     if (token < 257) {
/*  212 */       return iscntrl(token) ? this.L.pushfstring("char(" + token + ")") : this.L.pushfstring(String.valueOf((char)token));
/*      */     }
/*  214 */     return luaX_tokens[token - 257];
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean iscntrl(int token) {
/*  219 */     return (token < 32);
/*      */   }
/*      */   
/*      */   String txtToken(int token) {
/*  223 */     switch (token) {
/*      */       case 287:
/*      */       case 288:
/*      */       case 289:
/*  227 */         return new String(this.buff, 0, this.nbuff);
/*      */     } 
/*  229 */     return token2str(token);
/*      */   }
/*      */ 
/*      */   
/*      */   void lexerror(String msg, int token) {
/*  234 */     String cid = Lua.chunkid(this.source.tojstring());
/*  235 */     this.L.pushfstring(cid + ":" + this.linenumber + ": " + msg);
/*  236 */     if (token != 0)
/*  237 */       this.L.pushfstring("syntax error: " + msg + " near " + txtToken(token)); 
/*  238 */     throw new LuaError(cid + ":" + this.linenumber + ": " + msg);
/*      */   }
/*      */   
/*      */   void syntaxerror(String msg) {
/*  242 */     lexerror(msg, this.t.token);
/*      */   }
/*      */ 
/*      */   
/*      */   LuaString newstring(String s) {
/*  247 */     return this.L.newTString(s);
/*      */   }
/*      */   
/*      */   LuaString newstring(char[] chars, int offset, int len) {
/*  251 */     return this.L.newTString(new String(chars, offset, len));
/*      */   }
/*      */   
/*      */   void inclinenumber() {
/*  255 */     int old = this.current;
/*  256 */     _assert(currIsNewline());
/*  257 */     nextChar();
/*  258 */     if (currIsNewline() && this.current != old)
/*  259 */       nextChar(); 
/*  260 */     if (++this.linenumber >= 2147483645)
/*  261 */       syntaxerror("chunk has too many lines"); 
/*      */   }
/*      */   
/*      */   void setinput(LuaC.CompileState L, int firstByte, InputStream z, LuaString source) {
/*  265 */     this.decpoint = 46;
/*  266 */     this.L = L;
/*  267 */     this.lookahead.token = 286;
/*  268 */     this.z = z;
/*  269 */     this.fs = null;
/*  270 */     this.linenumber = 1;
/*  271 */     this.lastline = 1;
/*  272 */     this.source = source;
/*  273 */     this.envn = LuaValue.ENV;
/*  274 */     this.nbuff = 0;
/*  275 */     this.current = firstByte;
/*  276 */     skipShebang();
/*      */   }
/*      */   
/*      */   private void skipShebang() {
/*  280 */     if (this.current == 35) {
/*  281 */       while (!currIsNewline() && this.current != -1) {
/*  282 */         nextChar();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean check_next(String set) {
/*  292 */     if (set.indexOf(this.current) < 0)
/*  293 */       return false; 
/*  294 */     save_and_next();
/*  295 */     return true;
/*      */   }
/*      */   
/*      */   void buffreplace(char from, char to) {
/*  299 */     int n = this.nbuff;
/*  300 */     char[] p = this.buff;
/*  301 */     while (--n >= 0) {
/*  302 */       if (p[n] == from)
/*  303 */         p[n] = to; 
/*      */     } 
/*      */   }
/*      */   LuaValue strx2number(String str, SemInfo seminfo) {
/*  307 */     char[] c = str.toCharArray();
/*  308 */     int s = 0;
/*  309 */     while (s < c.length && isspace(c[s])) {
/*  310 */       s++;
/*      */     }
/*  312 */     double sgn = 1.0D;
/*  313 */     if (s < c.length && c[s] == '-') {
/*  314 */       sgn = -1.0D;
/*  315 */       s++;
/*      */     } 
/*      */     
/*  318 */     if (s + 2 >= c.length || c[s++] != '0' || (c[s] != 'x' && c[s] != 'X'))
/*  319 */       return (LuaValue)LuaValue.ZERO; 
/*  320 */     s++;
/*      */ 
/*      */     
/*  323 */     double m = 0.0D;
/*  324 */     int e = 0;
/*  325 */     while (s < c.length && isxdigit(c[s]))
/*  326 */       m = m * 16.0D + hexvalue(c[s++]); 
/*  327 */     if (s < c.length && c[s] == '.') {
/*  328 */       s++;
/*  329 */       while (s < c.length && isxdigit(c[s])) {
/*  330 */         m = m * 16.0D + hexvalue(c[s++]);
/*  331 */         e -= 4;
/*      */       } 
/*      */     } 
/*  334 */     if (s < c.length && (c[s] == 'p' || c[s] == 'P')) {
/*  335 */       s++;
/*  336 */       int exp1 = 0;
/*  337 */       boolean neg1 = false;
/*  338 */       if (s < c.length && c[s] == '-') {
/*  339 */         neg1 = true;
/*  340 */         s++;
/*      */       } 
/*  342 */       while (s < c.length && isdigit(c[s]))
/*  343 */         exp1 = exp1 * 10 + c[s++] - 48; 
/*  344 */       if (neg1)
/*  345 */         exp1 = -exp1; 
/*  346 */       e += exp1;
/*      */     } 
/*  348 */     return (LuaValue)LuaValue.valueOf(sgn * m * MathLib.dpow_d(2.0D, e));
/*      */   }
/*      */   
/*      */   boolean str2d(String str, SemInfo seminfo) {
/*  352 */     if (str.indexOf('n') >= 0 || str.indexOf('N') >= 0) {
/*  353 */       seminfo.r = (LuaValue)LuaValue.ZERO;
/*  354 */     } else if (str.indexOf('x') >= 0 || str.indexOf('X') >= 0) {
/*  355 */       seminfo.r = strx2number(str, seminfo);
/*      */     } else {
/*      */       try {
/*  358 */         seminfo.r = (LuaValue)LuaValue.valueOf(Double.parseDouble(str.trim()));
/*  359 */       } catch (NumberFormatException e) {
/*  360 */         lexerror("malformed number (" + e.getMessage() + ")", 287);
/*      */       } 
/*      */     } 
/*  363 */     return true;
/*      */   }
/*      */   
/*      */   void read_numeral(SemInfo seminfo) {
/*  367 */     String expo = "Ee";
/*  368 */     int first = this.current;
/*  369 */     _assert(isdigit(this.current));
/*  370 */     save_and_next();
/*  371 */     if (first == 48 && check_next("Xx"))
/*  372 */       expo = "Pp"; 
/*      */     while (true) {
/*  374 */       if (check_next(expo))
/*  375 */         check_next("+-"); 
/*  376 */       if (isxdigit(this.current) || this.current == 46) {
/*  377 */         save_and_next(); continue;
/*      */       } 
/*      */       break;
/*      */     } 
/*  381 */     String str = new String(this.buff, 0, this.nbuff);
/*  382 */     str2d(str, seminfo);
/*      */   }
/*      */   
/*      */   int skip_sep() {
/*  386 */     int count = 0;
/*  387 */     int s = this.current;
/*  388 */     _assert((s == 91 || s == 93));
/*  389 */     save_and_next();
/*  390 */     while (this.current == 61) {
/*  391 */       save_and_next();
/*  392 */       count++;
/*      */     } 
/*  394 */     return (this.current == s) ? count : (-count - 1);
/*      */   }
/*      */   
/*      */   void read_long_string(SemInfo seminfo, int sep) {
/*  398 */     int cont = 0;
/*  399 */     save_and_next();
/*  400 */     if (currIsNewline())
/*  401 */       inclinenumber(); 
/*  402 */     for (boolean endloop = false; !endloop; ) {
/*  403 */       switch (this.current) {
/*      */         case -1:
/*  405 */           lexerror((seminfo != null) ? "unfinished long string" : "unfinished long comment", 286);
/*      */           continue;
/*      */         case 91:
/*  408 */           if (skip_sep() == sep) {
/*  409 */             save_and_next();
/*  410 */             cont++;
/*      */             
/*  412 */             if (sep == 0) {
/*  413 */               lexerror("nesting of [[...]] is deprecated", 91);
/*      */             }
/*      */           } 
/*      */           continue;
/*      */         
/*      */         case 93:
/*  419 */           if (skip_sep() == sep) {
/*  420 */             save_and_next();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  426 */             endloop = true;
/*      */           } 
/*      */           continue;
/*      */         
/*      */         case 10:
/*      */         case 13:
/*  432 */           save(10);
/*  433 */           inclinenumber();
/*  434 */           if (seminfo == null) {
/*  435 */             this.nbuff = 0;
/*      */           }
/*      */           continue;
/*      */       } 
/*  439 */       if (seminfo != null) {
/*  440 */         save_and_next(); continue;
/*      */       } 
/*  442 */       nextChar();
/*      */     } 
/*      */ 
/*      */     
/*  446 */     if (seminfo != null)
/*  447 */       seminfo.ts = this.L.newTString(LuaString.valueOf(this.buff, 2 + sep, this.nbuff - 2 * (2 + sep))); 
/*      */   }
/*      */   
/*      */   int hexvalue(int c) {
/*  451 */     return (c <= 57) ? (c - 48) : ((c <= 70) ? (c + 10 - 65) : (c + 10 - 97));
/*      */   }
/*      */   
/*      */   int readhexaesc() {
/*  455 */     nextChar();
/*  456 */     int c1 = this.current;
/*  457 */     nextChar();
/*  458 */     int c2 = this.current;
/*  459 */     if (!isxdigit(c1) || !isxdigit(c2))
/*  460 */       lexerror("hexadecimal digit expected 'x" + (char)c1 + (char)c2, 289); 
/*  461 */     return (hexvalue(c1) << 4) + hexvalue(c2);
/*      */   }
/*      */   
/*      */   void read_string(int del, SemInfo seminfo) {
/*  465 */     save_and_next();
/*  466 */     while (this.current != del) {
/*  467 */       int c, i; switch (this.current) {
/*      */         case -1:
/*  469 */           lexerror("unfinished string", 286);
/*      */           continue;
/*      */         case 10:
/*      */         case 13:
/*  473 */           lexerror("unfinished string", 289);
/*      */           continue;
/*      */         
/*      */         case 92:
/*  477 */           nextChar();
/*  478 */           switch (this.current) {
/*      */             case 97:
/*  480 */               c = 7;
/*      */               break;
/*      */             case 98:
/*  483 */               c = 8;
/*      */               break;
/*      */             case 102:
/*  486 */               c = 12;
/*      */               break;
/*      */             case 110:
/*  489 */               c = 10;
/*      */               break;
/*      */             case 114:
/*  492 */               c = 13;
/*      */               break;
/*      */             case 116:
/*  495 */               c = 9;
/*      */               break;
/*      */             case 118:
/*  498 */               c = 11;
/*      */               break;
/*      */             case 120:
/*  501 */               c = readhexaesc();
/*      */               break;
/*      */             case 10:
/*      */             case 13:
/*  505 */               save(10);
/*  506 */               inclinenumber();
/*      */               continue;
/*      */             case -1:
/*      */               continue;
/*      */             case 122:
/*  511 */               nextChar();
/*  512 */               while (isspace(this.current)) {
/*  513 */                 if (currIsNewline()) {
/*  514 */                   inclinenumber(); continue;
/*      */                 } 
/*  516 */                 nextChar();
/*      */               } 
/*      */               continue;
/*      */             
/*      */             default:
/*  521 */               if (!isdigit(this.current)) {
/*  522 */                 save_and_next(); continue;
/*      */               } 
/*  524 */               i = 0;
/*  525 */               c = 0;
/*      */               do {
/*  527 */                 c = 10 * c + this.current - 48;
/*  528 */                 nextChar();
/*  529 */               } while (++i < 3 && isdigit(this.current));
/*  530 */               if (c > 255)
/*  531 */                 lexerror("escape sequence too large", 289); 
/*  532 */               save(c);
/*      */               continue;
/*      */           } 
/*      */ 
/*      */           
/*  537 */           save(c);
/*  538 */           nextChar();
/*      */           continue;
/*      */       } 
/*      */       
/*  542 */       save_and_next();
/*      */     } 
/*      */     
/*  545 */     save_and_next();
/*  546 */     seminfo.ts = this.L.newTString(LuaString.valueOf(this.buff, 1, this.nbuff - 2));
/*      */   }
/*      */   
/*      */   int llex(SemInfo seminfo) {
/*  550 */     this.nbuff = 0; while (true) {
/*      */       int sep;
/*  552 */       switch (this.current) {
/*      */         case 10:
/*      */         case 13:
/*  555 */           inclinenumber();
/*      */           continue;
/*      */         
/*      */         case 9:
/*      */         case 11:
/*      */         case 12:
/*      */         case 32:
/*  562 */           nextChar();
/*      */           continue;
/*      */         
/*      */         case 45:
/*  566 */           nextChar();
/*  567 */           if (this.current != 45) {
/*  568 */             return 45;
/*      */           }
/*  570 */           nextChar();
/*  571 */           if (this.current == 91) {
/*  572 */             int i = skip_sep();
/*  573 */             this.nbuff = 0;
/*  574 */             if (i >= 0) {
/*  575 */               read_long_string((SemInfo)null, i);
/*  576 */               this.nbuff = 0;
/*      */               
/*      */               continue;
/*      */             } 
/*      */           } 
/*  581 */           while (!currIsNewline() && this.current != -1) {
/*  582 */             nextChar();
/*      */           }
/*      */           continue;
/*      */         case 91:
/*  586 */           sep = skip_sep();
/*  587 */           if (sep >= 0) {
/*  588 */             read_long_string(seminfo, sep);
/*  589 */             return 289;
/*  590 */           }  if (sep == -1) {
/*  591 */             return 91;
/*      */           }
/*  593 */           lexerror("invalid long string delimiter", 289);
/*      */ 
/*      */           
/*  596 */           nextChar();
/*  597 */           if (this.current != 61) {
/*  598 */             return 61;
/*      */           }
/*  600 */           nextChar();
/*  601 */           return 281;
/*      */         case 61:
/*      */           continue;
/*      */         case 60:
/*  605 */           nextChar();
/*  606 */           if (this.current != 61) {
/*  607 */             return 60;
/*      */           }
/*  609 */           nextChar();
/*  610 */           return 283;
/*      */ 
/*      */         
/*      */         case 62:
/*  614 */           nextChar();
/*  615 */           if (this.current != 61) {
/*  616 */             return 62;
/*      */           }
/*  618 */           nextChar();
/*  619 */           return 282;
/*      */ 
/*      */         
/*      */         case 126:
/*  623 */           nextChar();
/*  624 */           if (this.current != 61) {
/*  625 */             return 126;
/*      */           }
/*  627 */           nextChar();
/*  628 */           return 284;
/*      */ 
/*      */         
/*      */         case 58:
/*  632 */           nextChar();
/*  633 */           if (this.current != 58) {
/*  634 */             return 58;
/*      */           }
/*  636 */           nextChar();
/*  637 */           return 285;
/*      */ 
/*      */         
/*      */         case 34:
/*      */         case 39:
/*  642 */           read_string(this.current, seminfo);
/*  643 */           return 289;
/*      */         
/*      */         case 46:
/*  646 */           save_and_next();
/*  647 */           if (check_next(".")) {
/*  648 */             if (check_next(".")) {
/*  649 */               return 280;
/*      */             }
/*  651 */             return 279;
/*  652 */           }  if (!isdigit(this.current)) {
/*  653 */             return 46;
/*      */           }
/*  655 */           read_numeral(seminfo);
/*  656 */           return 287;
/*      */ 
/*      */         
/*      */         case 48:
/*      */         case 49:
/*      */         case 50:
/*      */         case 51:
/*      */         case 52:
/*      */         case 53:
/*      */         case 54:
/*      */         case 55:
/*      */         case 56:
/*      */         case 57:
/*  669 */           read_numeral(seminfo);
/*  670 */           return 287;
/*      */         
/*      */         case -1:
/*  673 */           return 286;
/*      */       }  break;
/*      */     } 
/*  676 */     if (isalpha(this.current) || this.current == 95)
/*      */     {
/*      */       while (true) {
/*      */         
/*  680 */         save_and_next();
/*  681 */         if (!isalnum(this.current)) {
/*  682 */           LuaString ts = newstring(this.buff, 0, this.nbuff);
/*  683 */           if (RESERVED.containsKey(ts)) {
/*  684 */             return ((Integer)RESERVED.get(ts)).intValue();
/*      */           }
/*  686 */           seminfo.ts = ts;
/*  687 */           return 288;
/*      */         } 
/*      */       }  } 
/*  690 */     int c = this.current;
/*  691 */     nextChar();
/*  692 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void next() {
/*  700 */     this.lastline = this.linenumber;
/*  701 */     if (this.lookahead.token != 286) {
/*  702 */       this.t.set(this.lookahead);
/*  703 */       this.lookahead.token = 286;
/*      */     } else {
/*  705 */       this.t.token = llex(this.t.seminfo);
/*      */     } 
/*      */   }
/*      */   void lookahead() {
/*  709 */     _assert((this.lookahead.token == 286));
/*  710 */     this.lookahead.token = llex(this.lookahead.seminfo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean vkisvar(int k) {
/*  722 */     return (7 <= k && k <= 9);
/*      */   }
/*      */   
/*      */   static final boolean vkisinreg(int k) {
/*  726 */     return (k == 6 || k == 7);
/*      */   }
/*      */   
/*      */   static class expdesc { int k;
/*      */     
/*      */     static class U {
/*      */       short ind_idx;
/*      */       short ind_t;
/*      */       short ind_vt;
/*      */       private LuaValue _nval;
/*      */       int info;
/*      */       
/*      */       public void setNval(LuaValue r) {
/*  739 */         this._nval = r;
/*      */       }
/*      */       public LuaValue nval() {
/*  742 */         return (this._nval == null) ? (LuaValue)LuaInteger.valueOf(this.info) : this._nval;
/*      */       }
/*      */     }
/*      */     
/*  746 */     final U u = new U();
/*  747 */     final IntPtr t = new IntPtr();
/*  748 */     final IntPtr f = new IntPtr();
/*      */     
/*      */     void init(int k, int i) {
/*  751 */       this.f.i = -1;
/*  752 */       this.t.i = -1;
/*  753 */       this.k = k;
/*  754 */       this.u.info = i;
/*      */     }
/*      */     
/*      */     boolean hasjumps() {
/*  758 */       return (this.t.i != this.f.i);
/*      */     }
/*      */     
/*      */     boolean isnumeral() {
/*  762 */       return (this.k == 5 && this.t.i == -1 && this.f.i == -1);
/*      */     }
/*      */     
/*      */     public void setvalue(expdesc other) {
/*  766 */       this.f.i = other.f.i;
/*  767 */       this.k = other.k;
/*  768 */       this.t.i = other.t.i;
/*  769 */       this.u._nval = other.u._nval;
/*  770 */       this.u.ind_idx = other.u.ind_idx;
/*  771 */       this.u.ind_t = other.u.ind_t;
/*  772 */       this.u.ind_vt = other.u.ind_vt;
/*  773 */       this.u.info = other.u.info;
/*      */     } } static class U { short ind_idx; short ind_t; short ind_vt; private LuaValue _nval; int info; public void setNval(LuaValue r) {
/*      */       this._nval = r;
/*      */     }
/*      */     public LuaValue nval() {
/*      */       return (this._nval == null) ? (LuaValue)LuaInteger.valueOf(this.info) : this._nval;
/*      */     } }
/*      */   static class Vardesc { final short idx;
/*      */     Vardesc(int idx) {
/*  782 */       this.idx = (short)idx;
/*      */     } }
/*      */ 
/*      */   
/*      */   static class Labeldesc
/*      */   {
/*      */     LuaString name;
/*      */     int pc;
/*      */     int line;
/*      */     short nactvar;
/*      */     
/*      */     public Labeldesc(LuaString name, int pc, int line, short nactvar) {
/*  794 */       this.name = name;
/*  795 */       this.pc = pc;
/*  796 */       this.line = line;
/*  797 */       this.nactvar = nactvar;
/*      */     }
/*      */   }
/*      */   
/*      */   static class Dyndata
/*      */   {
/*      */     LexState.Vardesc[] actvar;
/*  804 */     int n_actvar = 0;
/*      */     LexState.Labeldesc[] gt;
/*  806 */     int n_gt = 0;
/*      */     LexState.Labeldesc[] label;
/*  808 */     int n_label = 0;
/*      */   }
/*      */   
/*      */   boolean hasmultret(int k) {
/*  812 */     return (k == 12 || k == 13);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void anchor_token() {
/*  821 */     _assert((this.fs != null || this.t.token == 286));
/*  822 */     if (this.t.token == 288 || this.t.token == 289) {
/*  823 */       LuaString ts = this.t.seminfo.ts;
/*      */       
/*  825 */       this.L.cachedLuaString(this.t.seminfo.ts);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void semerror(String msg) {
/*  831 */     this.t.token = 0;
/*  832 */     syntaxerror(msg);
/*      */   }
/*      */   
/*      */   void error_expected(int token) {
/*  836 */     syntaxerror(this.L.pushfstring(LUA_QS(token2str(token)) + " expected"));
/*      */   }
/*      */   
/*      */   boolean testnext(int c) {
/*  840 */     if (this.t.token == c) {
/*  841 */       next();
/*  842 */       return true;
/*      */     } 
/*  844 */     return false;
/*      */   }
/*      */   
/*      */   void check(int c) {
/*  848 */     if (this.t.token != c)
/*  849 */       error_expected(c); 
/*      */   }
/*      */   
/*      */   void checknext(int c) {
/*  853 */     check(c);
/*  854 */     next();
/*      */   }
/*      */   
/*      */   void check_condition(boolean c, String msg) {
/*  858 */     if (!c)
/*  859 */       syntaxerror(msg); 
/*      */   }
/*      */   
/*      */   void check_match(int what, int who, int where) {
/*  863 */     if (!testnext(what)) {
/*  864 */       if (where == this.linenumber) {
/*  865 */         error_expected(what);
/*      */       } else {
/*  867 */         syntaxerror(this.L.pushfstring(LUA_QS(token2str(what)) + " expected (to close " + LUA_QS(token2str(who)) + " at line " + where + ")"));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   LuaString str_checkname() {
/*  875 */     check(288);
/*  876 */     LuaString ts = this.t.seminfo.ts;
/*  877 */     next();
/*  878 */     return ts;
/*      */   }
/*      */   
/*      */   void codestring(expdesc e, LuaString s) {
/*  882 */     e.init(4, this.fs.stringK(s));
/*      */   }
/*      */   
/*      */   void checkname(expdesc e) {
/*  886 */     codestring(e, str_checkname());
/*      */   }
/*      */   
/*      */   int registerlocalvar(LuaString varname) {
/*  890 */     FuncState fs = this.fs;
/*  891 */     Prototype f = fs.f;
/*  892 */     if (f.locvars == null || fs.nlocvars + 1 > f.locvars.length)
/*  893 */       f.locvars = realloc(f.locvars, fs.nlocvars * 2 + 1); 
/*  894 */     f.locvars[fs.nlocvars] = new LocVars(varname, 0, 0);
/*  895 */     fs.nlocvars = (short)(fs.nlocvars + 1); return fs.nlocvars;
/*      */   }
/*      */   
/*      */   void new_localvar(LuaString name) {
/*  899 */     int reg = registerlocalvar(name);
/*  900 */     this.fs.checklimit(this.dyd.n_actvar + 1, 200, "local variables");
/*  901 */     if (this.dyd.actvar == null || this.dyd.n_actvar + 1 > this.dyd.actvar.length)
/*  902 */       this.dyd.actvar = realloc(this.dyd.actvar, Math.max(1, this.dyd.n_actvar * 2)); 
/*  903 */     this.dyd.actvar[this.dyd.n_actvar++] = new Vardesc(reg);
/*      */   }
/*      */   
/*      */   void new_localvarliteral(String v) {
/*  907 */     LuaString ts = newstring(v);
/*  908 */     new_localvar(ts);
/*      */   }
/*      */   
/*      */   void adjustlocalvars(int nvars) {
/*  912 */     FuncState fs = this.fs;
/*  913 */     fs.nactvar = (short)(fs.nactvar + nvars);
/*  914 */     for (; nvars > 0; nvars--) {
/*  915 */       (fs.getlocvar(fs.nactvar - nvars)).startpc = fs.pc;
/*      */     }
/*      */   }
/*      */   
/*      */   void removevars(int tolevel) {
/*  920 */     FuncState fs = this.fs;
/*  921 */     while (fs.nactvar > tolevel)
/*  922 */       (fs.getlocvar(fs.nactvar = (short)(fs.nactvar - 1))).endpc = fs.pc; 
/*      */   }
/*      */   
/*      */   void singlevar(expdesc var) {
/*  926 */     LuaString varname = str_checkname();
/*  927 */     FuncState fs = this.fs;
/*  928 */     if (FuncState.singlevaraux(fs, varname, var, 1) == 0) {
/*  929 */       expdesc key = new expdesc();
/*  930 */       FuncState.singlevaraux(fs, this.envn, var, 1);
/*  931 */       _assert((var.k == 7 || var.k == 8));
/*  932 */       codestring(key, varname);
/*  933 */       fs.indexed(var, key);
/*      */     } 
/*      */   }
/*      */   
/*      */   void adjust_assign(int nvars, int nexps, expdesc e) {
/*  938 */     FuncState fs = this.fs;
/*  939 */     int extra = nvars - nexps;
/*  940 */     if (hasmultret(e.k)) {
/*      */       
/*  942 */       extra++;
/*  943 */       if (extra < 0) {
/*  944 */         extra = 0;
/*      */       }
/*  946 */       fs.setreturns(e, extra);
/*  947 */       if (extra > 1) {
/*  948 */         fs.reserveregs(extra - 1);
/*      */       }
/*      */     } else {
/*  951 */       if (e.k != 0)
/*  952 */         fs.exp2nextreg(e); 
/*  953 */       if (extra > 0) {
/*  954 */         int reg = fs.freereg;
/*  955 */         fs.reserveregs(extra);
/*  956 */         fs.nil(reg, extra);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   void enterlevel() {
/*  962 */     if (++this.L.nCcalls > 200)
/*  963 */       lexerror("chunk has too many syntax levels", 0); 
/*      */   }
/*      */   
/*      */   void leavelevel() {
/*  967 */     this.L.nCcalls--;
/*      */   }
/*      */   
/*      */   void closegoto(int g, Labeldesc label) {
/*  971 */     FuncState fs = this.fs;
/*  972 */     Labeldesc[] gl = this.dyd.gt;
/*  973 */     Labeldesc gt = gl[g];
/*  974 */     _assert(gt.name.eq_b((LuaValue)label.name));
/*  975 */     if (gt.nactvar < label.nactvar) {
/*  976 */       LuaString vname = (fs.getlocvar(gt.nactvar)).varname;
/*  977 */       String msg = this.L.pushfstring("<goto " + gt.name + "> at line " + gt.line + " jumps into the scope of local '" + vname
/*  978 */           .tojstring() + "'");
/*  979 */       semerror(msg);
/*      */     } 
/*  981 */     fs.patchlist(gt.pc, label.pc);
/*      */     
/*  983 */     System.arraycopy(gl, g + 1, gl, g, this.dyd.n_gt - g - 1);
/*  984 */     gl[--this.dyd.n_gt] = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean findlabel(int g) {
/*  992 */     FuncState.BlockCnt bl = this.fs.bl;
/*  993 */     Dyndata dyd = this.dyd;
/*  994 */     Labeldesc gt = dyd.gt[g];
/*      */     
/*  996 */     for (int i = bl.firstlabel; i < dyd.n_label; i++) {
/*  997 */       Labeldesc lb = dyd.label[i];
/*  998 */       if (lb.name.eq_b((LuaValue)gt.name)) {
/*  999 */         if (gt.nactvar > lb.nactvar && (bl.upval || dyd.n_label > bl.firstlabel))
/* 1000 */           this.fs.patchclose(gt.pc, lb.nactvar); 
/* 1001 */         closegoto(g, lb);
/* 1002 */         return true;
/*      */       } 
/*      */     } 
/* 1005 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   int newlabelentry(Labeldesc[] l, int index, LuaString name, int line, int pc) {
/* 1010 */     l[index] = new Labeldesc(name, pc, line, this.fs.nactvar);
/* 1011 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void findgotos(Labeldesc lb) {
/* 1019 */     Labeldesc[] gl = this.dyd.gt;
/* 1020 */     int i = this.fs.bl.firstgoto;
/* 1021 */     while (i < this.dyd.n_gt) {
/* 1022 */       if ((gl[i]).name.eq_b((LuaValue)lb.name)) {
/* 1023 */         closegoto(i, lb); continue;
/*      */       } 
/* 1025 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void breaklabel() {
/* 1033 */     LuaString n = LuaString.valueOf("break");
/* 1034 */     int l = newlabelentry(this.dyd.label = grow(this.dyd.label, this.dyd.n_label + 1), this.dyd.n_label++, n, 0, this.fs.pc);
/* 1035 */     findgotos(this.dyd.label[l]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void undefgoto(Labeldesc gt) {
/* 1043 */     String msg = this.L.pushfstring(
/* 1044 */         isReservedKeyword(gt.name.tojstring()) ? ("<" + gt.name + "> at line " + gt.line + " not inside a loop") : ("no visible label '" + gt.name + "' for <goto> at line " + gt.line));
/*      */     
/* 1046 */     semerror(msg);
/*      */   }
/*      */ 
/*      */   
/*      */   Prototype addprototype() {
/* 1051 */     Prototype f = this.fs.f;
/* 1052 */     if (f.p == null || this.fs.np >= f.p.length) {
/* 1053 */       f.p = realloc(f.p, Math.max(1, this.fs.np * 2));
/*      */     }
/* 1055 */     Prototype clp = new Prototype();
/* 1056 */     return clp;
/*      */   }
/*      */   
/*      */   void codeclosure(expdesc v) {
/* 1060 */     FuncState fs = this.fs.prev;
/* 1061 */     v.init(11, fs.codeABx(37, 0, fs.np - 1));
/* 1062 */     fs.exp2nextreg(v);
/*      */   }
/*      */   
/*      */   void open_func(FuncState fs, FuncState.BlockCnt bl) {
/* 1066 */     fs.prev = this.fs;
/* 1067 */     fs.ls = this;
/* 1068 */     this.fs = fs;
/* 1069 */     fs.pc = 0;
/* 1070 */     fs.lasttarget = -1;
/* 1071 */     fs.jpc = new IntPtr(-1);
/* 1072 */     fs.freereg = 0;
/* 1073 */     fs.nk = 0;
/* 1074 */     fs.np = 0;
/* 1075 */     fs.nups = 0;
/* 1076 */     fs.nlocvars = 0;
/* 1077 */     fs.nactvar = 0;
/* 1078 */     fs.firstlocal = this.dyd.n_actvar;
/* 1079 */     fs.bl = null;
/* 1080 */     fs.f.source = this.source;
/* 1081 */     fs.f.maxstacksize = 2;
/* 1082 */     fs.enterblock(bl, false);
/*      */   }
/*      */   
/*      */   void close_func() {
/* 1086 */     FuncState fs = this.fs;
/* 1087 */     Prototype f = fs.f;
/* 1088 */     fs.ret(0, 0);
/* 1089 */     fs.leaveblock();
/* 1090 */     f.code = realloc(f.code, fs.pc);
/* 1091 */     f.lineinfo = realloc(f.lineinfo, fs.pc);
/* 1092 */     f.k = realloc(f.k, fs.nk);
/* 1093 */     f.p = realloc(f.p, fs.np);
/* 1094 */     f.locvars = realloc(f.locvars, fs.nlocvars);
/* 1095 */     f.upvalues = realloc(f.upvalues, fs.nups);
/* 1096 */     _assert((fs.bl == null));
/* 1097 */     this.fs = fs.prev;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fieldsel(expdesc v) {
/* 1108 */     FuncState fs = this.fs;
/* 1109 */     expdesc key = new expdesc();
/* 1110 */     fs.exp2anyregup(v);
/* 1111 */     next();
/* 1112 */     checkname(key);
/* 1113 */     fs.indexed(v, key);
/*      */   }
/*      */ 
/*      */   
/*      */   void yindex(expdesc v) {
/* 1118 */     next();
/* 1119 */     expr(v);
/* 1120 */     this.fs.exp2val(v);
/* 1121 */     checknext(93);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class ConsControl
/*      */   {
/* 1131 */     LexState.expdesc v = new LexState.expdesc();
/*      */     
/*      */     LexState.expdesc t;
/*      */     int nh;
/*      */     int na;
/*      */     int tostore;
/*      */   }
/*      */   
/*      */   void recfield(ConsControl cc) {
/* 1140 */     FuncState fs = this.fs;
/* 1141 */     int reg = this.fs.freereg;
/* 1142 */     expdesc key = new expdesc();
/* 1143 */     expdesc val = new expdesc();
/*      */     
/* 1145 */     if (this.t.token == 288) {
/* 1146 */       fs.checklimit(cc.nh, 2147483645, "items in a constructor");
/* 1147 */       checkname(key);
/*      */     } else {
/*      */       
/* 1150 */       yindex(key);
/* 1151 */     }  cc.nh++;
/* 1152 */     checknext(61);
/* 1153 */     int rkkey = fs.exp2RK(key);
/* 1154 */     expr(val);
/* 1155 */     fs.codeABC(10, cc.t.u.info, rkkey, fs.exp2RK(val));
/* 1156 */     fs.freereg = (short)reg;
/*      */   }
/*      */   
/*      */   void listfield(ConsControl cc) {
/* 1160 */     expr(cc.v);
/* 1161 */     this.fs.checklimit(cc.na, 2147483645, "items in a constructor");
/* 1162 */     cc.na++;
/* 1163 */     cc.tostore++;
/*      */   }
/*      */ 
/*      */   
/*      */   void constructor(expdesc t) {
/* 1168 */     FuncState fs = this.fs;
/* 1169 */     int line = this.linenumber;
/* 1170 */     int pc = fs.codeABC(11, 0, 0, 0);
/* 1171 */     ConsControl cc = new ConsControl();
/* 1172 */     cc.na = cc.nh = cc.tostore = 0;
/* 1173 */     cc.t = t;
/* 1174 */     t.init(11, pc);
/* 1175 */     cc.v.init(0, 0);
/* 1176 */     fs.exp2nextreg(t);
/* 1177 */     checknext(123);
/*      */     do {
/* 1179 */       _assert((cc.v.k == 0 || cc.tostore > 0));
/* 1180 */       if (this.t.token == 125)
/*      */         break; 
/* 1182 */       fs.closelistfield(cc);
/* 1183 */       switch (this.t.token) {
/*      */         case 288:
/* 1185 */           lookahead();
/* 1186 */           if (this.lookahead.token != 61) {
/* 1187 */             listfield(cc); break;
/*      */           } 
/* 1189 */           recfield(cc);
/*      */           break;
/*      */         
/*      */         case 91:
/* 1193 */           recfield(cc);
/*      */           break;
/*      */         
/*      */         default:
/* 1197 */           listfield(cc);
/*      */           break;
/*      */       } 
/*      */     
/* 1201 */     } while (testnext(44) || testnext(59));
/* 1202 */     check_match(125, 123, line);
/* 1203 */     fs.lastlistfield(cc);
/* 1204 */     InstructionPtr i = new InstructionPtr(fs.f.code, pc);
/* 1205 */     SETARG_B(i, luaO_int2fb(cc.na));
/* 1206 */     SETARG_C(i, luaO_int2fb(cc.nh));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int luaO_int2fb(int x) {
/* 1215 */     int e = 0;
/* 1216 */     while (x >= 16) {
/* 1217 */       x = x + 1 >> 1;
/* 1218 */       e++;
/*      */     } 
/* 1220 */     if (x < 8) {
/* 1221 */       return x;
/*      */     }
/* 1223 */     return e + 1 << 3 | x - 8;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void parlist() {
/* 1230 */     FuncState fs = this.fs;
/* 1231 */     Prototype f = fs.f;
/* 1232 */     int nparams = 0;
/* 1233 */     f.is_vararg = 0;
/* 1234 */     if (this.t.token != 41) {
/*      */       do {
/* 1236 */         switch (this.t.token) {
/*      */           case 288:
/* 1238 */             new_localvar(str_checkname());
/* 1239 */             nparams++;
/*      */             break;
/*      */           
/*      */           case 280:
/* 1243 */             next();
/* 1244 */             f.is_vararg = 1;
/*      */             break;
/*      */           
/*      */           default:
/* 1248 */             syntaxerror("<name> or " + LUA_QL("...") + " expected"); break;
/*      */         } 
/* 1250 */       } while (f.is_vararg == 0 && testnext(44));
/*      */     }
/* 1252 */     adjustlocalvars(nparams);
/* 1253 */     f.numparams = fs.nactvar;
/* 1254 */     fs.reserveregs(fs.nactvar);
/*      */   }
/*      */ 
/*      */   
/*      */   void body(expdesc e, boolean needself, int line) {
/* 1259 */     FuncState new_fs = new FuncState();
/* 1260 */     FuncState.BlockCnt bl = new FuncState.BlockCnt();
/* 1261 */     new_fs.f = addprototype();
/* 1262 */     new_fs.f.linedefined = line;
/* 1263 */     open_func(new_fs, bl);
/* 1264 */     checknext(40);
/* 1265 */     if (needself) {
/* 1266 */       new_localvarliteral("self");
/* 1267 */       adjustlocalvars(1);
/*      */     } 
/* 1269 */     parlist();
/* 1270 */     checknext(41);
/* 1271 */     statlist();
/* 1272 */     new_fs.f.lastlinedefined = this.linenumber;
/* 1273 */     check_match(262, 265, line);
/* 1274 */     codeclosure(e);
/* 1275 */     close_func();
/*      */   }
/*      */ 
/*      */   
/*      */   int explist(expdesc v) {
/* 1280 */     int n = 1;
/* 1281 */     expr(v);
/* 1282 */     while (testnext(44)) {
/* 1283 */       this.fs.exp2nextreg(v);
/* 1284 */       expr(v);
/* 1285 */       n++;
/*      */     } 
/* 1287 */     return n;
/*      */   }
/*      */   void funcargs(expdesc f, int line) {
/*      */     int nparams;
/* 1291 */     FuncState fs = this.fs;
/* 1292 */     expdesc args = new expdesc();
/*      */     
/* 1294 */     switch (this.t.token) {
/*      */       case 40:
/* 1296 */         next();
/* 1297 */         if (this.t.token == 41) {
/* 1298 */           args.k = 0;
/*      */         } else {
/* 1300 */           explist(args);
/* 1301 */           fs.setmultret(args);
/*      */         } 
/* 1303 */         check_match(41, 40, line);
/*      */         break;
/*      */       
/*      */       case 123:
/* 1307 */         constructor(args);
/*      */         break;
/*      */       
/*      */       case 289:
/* 1311 */         codestring(args, this.t.seminfo.ts);
/* 1312 */         next();
/*      */         break;
/*      */       
/*      */       default:
/* 1316 */         syntaxerror("function arguments expected");
/*      */         return;
/*      */     } 
/*      */     
/* 1320 */     _assert((f.k == 6));
/* 1321 */     int base = f.u.info;
/* 1322 */     if (hasmultret(args.k)) {
/* 1323 */       nparams = -1;
/*      */     } else {
/* 1325 */       if (args.k != 0)
/* 1326 */         fs.exp2nextreg(args); 
/* 1327 */       nparams = fs.freereg - base + 1;
/*      */     } 
/* 1329 */     f.init(12, fs.codeABC(29, base, nparams + 1, 2));
/* 1330 */     fs.fixline(line);
/* 1331 */     fs.freereg = (short)(base + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void primaryexp(expdesc v) {
/*      */     int line;
/* 1343 */     switch (this.t.token) {
/*      */       case 40:
/* 1345 */         line = this.linenumber;
/* 1346 */         next();
/* 1347 */         expr(v);
/* 1348 */         check_match(41, 40, line);
/* 1349 */         this.fs.dischargevars(v);
/*      */         return;
/*      */       
/*      */       case 288:
/* 1353 */         singlevar(v);
/*      */         return;
/*      */     } 
/*      */     
/* 1357 */     syntaxerror("unexpected symbol " + this.t.token + " (" + (char)this.t.token + ")");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void suffixedexp(expdesc v) {
/* 1365 */     int line = this.linenumber;
/* 1366 */     primaryexp(v); while (true) {
/*      */       expdesc key;
/* 1368 */       switch (this.t.token) {
/*      */         case 46:
/* 1370 */           fieldsel(v);
/*      */           continue;
/*      */         
/*      */         case 91:
/* 1374 */           key = new expdesc();
/* 1375 */           this.fs.exp2anyregup(v);
/* 1376 */           yindex(key);
/* 1377 */           this.fs.indexed(v, key);
/*      */           continue;
/*      */         
/*      */         case 58:
/* 1381 */           key = new expdesc();
/* 1382 */           next();
/* 1383 */           checkname(key);
/* 1384 */           this.fs.self(v, key);
/* 1385 */           funcargs(v, line);
/*      */           continue;
/*      */         
/*      */         case 40:
/*      */         case 123:
/*      */         case 289:
/* 1391 */           this.fs.exp2nextreg(v);
/* 1392 */           funcargs(v, line);
/*      */           continue;
/*      */       } 
/*      */       break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void simpleexp(expdesc v) {
/*      */     FuncState fs;
/* 1406 */     switch (this.t.token) {
/*      */       case 287:
/* 1408 */         v.init(5, 0);
/* 1409 */         v.u.setNval(this.t.seminfo.r);
/*      */         break;
/*      */       
/*      */       case 289:
/* 1413 */         codestring(v, this.t.seminfo.ts);
/*      */         break;
/*      */       
/*      */       case 270:
/* 1417 */         v.init(1, 0);
/*      */         break;
/*      */       
/*      */       case 276:
/* 1421 */         v.init(2, 0);
/*      */         break;
/*      */       
/*      */       case 263:
/* 1425 */         v.init(3, 0);
/*      */         break;
/*      */       
/*      */       case 280:
/* 1429 */         fs = this.fs;
/* 1430 */         check_condition((fs.f.is_vararg != 0), "cannot use " + LUA_QL("...") + " outside a vararg function");
/* 1431 */         v.init(13, fs.codeABC(38, 0, 1, 0));
/*      */         break;
/*      */       
/*      */       case 123:
/* 1435 */         constructor(v);
/*      */         return;
/*      */       
/*      */       case 265:
/* 1439 */         next();
/* 1440 */         body(v, false, this.linenumber);
/*      */         return;
/*      */       
/*      */       default:
/* 1444 */         suffixedexp(v);
/*      */         return;
/*      */     } 
/*      */     
/* 1448 */     next();
/*      */   }
/*      */   
/*      */   int getunopr(int op) {
/* 1452 */     switch (op) {
/*      */       case 271:
/* 1454 */         return 1;
/*      */       case 45:
/* 1456 */         return 0;
/*      */       case 35:
/* 1458 */         return 2;
/*      */     } 
/* 1460 */     return 3;
/*      */   }
/*      */ 
/*      */   
/*      */   int getbinopr(int op) {
/* 1465 */     switch (op) {
/*      */       case 43:
/* 1467 */         return 0;
/*      */       case 45:
/* 1469 */         return 1;
/*      */       case 42:
/* 1471 */         return 2;
/*      */       case 47:
/* 1473 */         return 3;
/*      */       case 37:
/* 1475 */         return 4;
/*      */       case 94:
/* 1477 */         return 5;
/*      */       case 279:
/* 1479 */         return 6;
/*      */       case 284:
/* 1481 */         return 7;
/*      */       case 281:
/* 1483 */         return 8;
/*      */       case 60:
/* 1485 */         return 9;
/*      */       case 283:
/* 1487 */         return 10;
/*      */       case 62:
/* 1489 */         return 11;
/*      */       case 282:
/* 1491 */         return 12;
/*      */       case 257:
/* 1493 */         return 13;
/*      */       case 272:
/* 1495 */         return 14;
/*      */     } 
/* 1497 */     return 15;
/*      */   }
/*      */ 
/*      */   
/*      */   static class Priority
/*      */   {
/*      */     final byte left;
/*      */     final byte right;
/*      */     
/*      */     public Priority(int i, int j) {
/* 1507 */       this.left = (byte)i;
/* 1508 */       this.right = (byte)j;
/*      */     }
/*      */   }
/*      */   
/* 1512 */   static Priority[] priority = new Priority[] { new Priority(6, 6), new Priority(6, 6), new Priority(7, 7), new Priority(7, 7), new Priority(7, 7), new Priority(10, 9), new Priority(5, 4), new Priority(3, 3), new Priority(3, 3), new Priority(3, 3), new Priority(3, 3), new Priority(3, 3), new Priority(3, 3), new Priority(2, 2), new Priority(1, 1) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int UNARY_PRIORITY = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int subexpr(expdesc v, int limit) {
/* 1530 */     enterlevel();
/* 1531 */     int uop = getunopr(this.t.token);
/* 1532 */     if (uop != 3) {
/* 1533 */       int line = this.linenumber;
/* 1534 */       next();
/* 1535 */       subexpr(v, 8);
/* 1536 */       this.fs.prefix(uop, v, line);
/*      */     } else {
/* 1538 */       simpleexp(v);
/*      */     } 
/* 1540 */     int op = getbinopr(this.t.token);
/* 1541 */     while (op != 15 && (priority[op]).left > limit) {
/* 1542 */       expdesc v2 = new expdesc();
/* 1543 */       int line = this.linenumber;
/* 1544 */       next();
/* 1545 */       this.fs.infix(op, v);
/*      */       
/* 1547 */       int nextop = subexpr(v2, (priority[op]).right);
/* 1548 */       this.fs.posfix(op, v, v2, line);
/* 1549 */       op = nextop;
/*      */     } 
/* 1551 */     leavelevel();
/* 1552 */     return op;
/*      */   }
/*      */   
/*      */   void expr(expdesc v) {
/* 1556 */     subexpr(v, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean block_follow(boolean withuntil) {
/* 1568 */     switch (this.t.token) {
/*      */       case 260:
/*      */       case 261:
/*      */       case 262:
/*      */       case 286:
/* 1573 */         return true;
/*      */       case 277:
/* 1575 */         return withuntil;
/*      */     } 
/* 1577 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void block() {
/* 1583 */     FuncState fs = this.fs;
/* 1584 */     FuncState.BlockCnt bl = new FuncState.BlockCnt();
/* 1585 */     fs.enterblock(bl, false);
/* 1586 */     statlist();
/* 1587 */     fs.leaveblock();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class LHS_assign
/*      */   {
/*      */     LHS_assign prev;
/*      */ 
/*      */     
/* 1597 */     LexState.expdesc v = new LexState.expdesc();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void check_conflict(LHS_assign lh, expdesc v) {
/* 1607 */     FuncState fs = this.fs;
/* 1608 */     short extra = fs.freereg;
/* 1609 */     boolean conflict = false;
/* 1610 */     for (; lh != null; lh = lh.prev) {
/* 1611 */       if (lh.v.k == 9) {
/*      */         
/* 1613 */         if (lh.v.u.ind_vt == v.k && lh.v.u.ind_t == v.u.info) {
/* 1614 */           conflict = true;
/* 1615 */           lh.v.u.ind_vt = 7;
/* 1616 */           lh.v.u.ind_t = extra;
/*      */         } 
/*      */         
/* 1619 */         if (v.k == 7 && lh.v.u.ind_idx == v.u.info) {
/* 1620 */           conflict = true;
/* 1621 */           lh.v.u.ind_idx = extra;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1625 */     if (conflict) {
/*      */       
/* 1627 */       int op = (v.k == 7) ? 0 : 5;
/* 1628 */       fs.codeABC(op, extra, v.u.info, 0);
/* 1629 */       fs.reserveregs(1);
/*      */     } 
/*      */   }
/*      */   
/*      */   void assignment(LHS_assign lh, int nvars) {
/* 1634 */     expdesc e = new expdesc();
/* 1635 */     check_condition((7 <= lh.v.k && lh.v.k <= 9), "syntax error");
/* 1636 */     if (testnext(44)) {
/* 1637 */       LHS_assign nv = new LHS_assign();
/* 1638 */       nv.prev = lh;
/* 1639 */       suffixedexp(nv.v);
/* 1640 */       if (nv.v.k != 9)
/* 1641 */         check_conflict(lh, nv.v); 
/* 1642 */       assignment(nv, nvars + 1);
/*      */     } else {
/*      */       
/* 1645 */       checknext(61);
/* 1646 */       int nexps = explist(e);
/* 1647 */       if (nexps != nvars) {
/* 1648 */         adjust_assign(nvars, nexps, e);
/* 1649 */         if (nexps > nvars)
/* 1650 */           this.fs.freereg = (short)(this.fs.freereg - nexps - nvars); 
/*      */       } else {
/* 1652 */         this.fs.setoneret(e);
/* 1653 */         this.fs.storevar(lh.v, e);
/*      */         return;
/*      */       } 
/*      */     } 
/* 1657 */     e.init(6, this.fs.freereg - 1);
/* 1658 */     this.fs.storevar(lh.v, e);
/*      */   }
/*      */ 
/*      */   
/*      */   int cond() {
/* 1663 */     expdesc v = new expdesc();
/*      */     
/* 1665 */     expr(v);
/*      */     
/* 1667 */     if (v.k == 1)
/* 1668 */       v.k = 3; 
/* 1669 */     this.fs.goiftrue(v);
/* 1670 */     return v.f.i;
/*      */   }
/*      */   void gotostat(int pc) {
/*      */     LuaString label;
/* 1674 */     int line = this.linenumber;
/*      */ 
/*      */     
/* 1677 */     if (testnext(266)) {
/* 1678 */       label = str_checkname();
/*      */     } else {
/* 1680 */       next();
/* 1681 */       label = LuaString.valueOf("break");
/*      */     } 
/* 1683 */     int g = newlabelentry(this.dyd.gt = grow(this.dyd.gt, this.dyd.n_gt + 1), this.dyd.n_gt++, label, line, pc);
/* 1684 */     findlabel(g);
/*      */   }
/*      */ 
/*      */   
/*      */   void skipnoopstat() {
/* 1689 */     while (this.t.token == 59 || this.t.token == 285) {
/* 1690 */       statement();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void labelstat(LuaString label, int line) {
/* 1696 */     this.fs.checkrepeated(this.dyd.label, this.dyd.n_label, label);
/* 1697 */     checknext(285);
/*      */     
/* 1699 */     int l = newlabelentry(this.dyd.label = grow(this.dyd.label, this.dyd.n_label + 1), this.dyd.n_label++, label, line, this.fs.getlabel());
/* 1700 */     skipnoopstat();
/* 1701 */     if (block_follow(false))
/*      */     {
/* 1703 */       (this.dyd.label[l]).nactvar = this.fs.bl.nactvar;
/*      */     }
/* 1705 */     findgotos(this.dyd.label[l]);
/*      */   }
/*      */ 
/*      */   
/*      */   void whilestat(int line) {
/* 1710 */     FuncState fs = this.fs;
/*      */ 
/*      */     
/* 1713 */     FuncState.BlockCnt bl = new FuncState.BlockCnt();
/* 1714 */     next();
/* 1715 */     int whileinit = fs.getlabel();
/* 1716 */     int condexit = cond();
/* 1717 */     fs.enterblock(bl, true);
/* 1718 */     checknext(259);
/* 1719 */     block();
/* 1720 */     fs.patchlist(fs.jump(), whileinit);
/* 1721 */     check_match(262, 278, line);
/* 1722 */     fs.leaveblock();
/* 1723 */     fs.patchtohere(condexit);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void repeatstat(int line) {
/* 1729 */     FuncState fs = this.fs;
/* 1730 */     int repeat_init = fs.getlabel();
/* 1731 */     FuncState.BlockCnt bl1 = new FuncState.BlockCnt();
/* 1732 */     FuncState.BlockCnt bl2 = new FuncState.BlockCnt();
/* 1733 */     fs.enterblock(bl1, true);
/* 1734 */     fs.enterblock(bl2, false);
/* 1735 */     next();
/* 1736 */     statlist();
/* 1737 */     check_match(277, 273, line);
/* 1738 */     int condexit = cond();
/* 1739 */     if (bl2.upval) {
/* 1740 */       fs.patchclose(condexit, bl2.nactvar);
/*      */     }
/* 1742 */     fs.leaveblock();
/* 1743 */     fs.patchlist(condexit, repeat_init);
/* 1744 */     fs.leaveblock();
/*      */   }
/*      */   
/*      */   int exp1() {
/* 1748 */     expdesc e = new expdesc();
/*      */     
/* 1750 */     expr(e);
/* 1751 */     int k = e.k;
/* 1752 */     this.fs.exp2nextreg(e);
/* 1753 */     return k;
/*      */   }
/*      */   
/*      */   void forbody(int base, int line, int nvars, boolean isnum) {
/*      */     int endfor;
/* 1758 */     FuncState.BlockCnt bl = new FuncState.BlockCnt();
/* 1759 */     FuncState fs = this.fs;
/*      */     
/* 1761 */     adjustlocalvars(3);
/* 1762 */     checknext(259);
/* 1763 */     int prep = isnum ? fs.codeAsBx(33, base, -1) : fs.jump();
/* 1764 */     fs.enterblock(bl, false);
/* 1765 */     adjustlocalvars(nvars);
/* 1766 */     fs.reserveregs(nvars);
/* 1767 */     block();
/* 1768 */     fs.leaveblock();
/* 1769 */     fs.patchtohere(prep);
/* 1770 */     if (isnum) {
/* 1771 */       endfor = fs.codeAsBx(32, base, -1);
/*      */     } else {
/* 1773 */       fs.codeABC(34, base, 0, nvars);
/* 1774 */       fs.fixline(line);
/* 1775 */       endfor = fs.codeAsBx(35, base + 2, -1);
/*      */     } 
/* 1777 */     fs.patchlist(endfor, prep + 1);
/* 1778 */     fs.fixline(line);
/*      */   }
/*      */ 
/*      */   
/*      */   void fornum(LuaString varname, int line) {
/* 1783 */     FuncState fs = this.fs;
/* 1784 */     int base = fs.freereg;
/* 1785 */     new_localvarliteral("(for index)");
/* 1786 */     new_localvarliteral("(for limit)");
/* 1787 */     new_localvarliteral("(for step)");
/* 1788 */     new_localvar(varname);
/* 1789 */     checknext(61);
/* 1790 */     exp1();
/* 1791 */     checknext(44);
/* 1792 */     exp1();
/* 1793 */     if (testnext(44)) {
/* 1794 */       exp1();
/*      */     } else {
/* 1796 */       fs.codeK(fs.freereg, fs.numberK((LuaValue)LuaInteger.valueOf(1)));
/* 1797 */       fs.reserveregs(1);
/*      */     } 
/* 1799 */     forbody(base, line, 1, true);
/*      */   }
/*      */ 
/*      */   
/*      */   void forlist(LuaString indexname) {
/* 1804 */     FuncState fs = this.fs;
/* 1805 */     expdesc e = new expdesc();
/* 1806 */     int nvars = 4;
/*      */     
/* 1808 */     int base = fs.freereg;
/*      */     
/* 1810 */     new_localvarliteral("(for generator)");
/* 1811 */     new_localvarliteral("(for state)");
/* 1812 */     new_localvarliteral("(for control)");
/*      */     
/* 1814 */     new_localvar(indexname);
/* 1815 */     while (testnext(44)) {
/* 1816 */       new_localvar(str_checkname());
/* 1817 */       nvars++;
/*      */     } 
/* 1819 */     checknext(268);
/* 1820 */     int line = this.linenumber;
/* 1821 */     adjust_assign(3, explist(e), e);
/* 1822 */     fs.checkstack(3);
/* 1823 */     forbody(base, line, nvars - 3, false);
/*      */   }
/*      */ 
/*      */   
/*      */   void forstat(int line) {
/* 1828 */     FuncState fs = this.fs;
/*      */     
/* 1830 */     FuncState.BlockCnt bl = new FuncState.BlockCnt();
/* 1831 */     fs.enterblock(bl, true);
/* 1832 */     next();
/* 1833 */     LuaString varname = str_checkname();
/* 1834 */     switch (this.t.token) {
/*      */       case 61:
/* 1836 */         fornum(varname, line);
/*      */         break;
/*      */       case 44:
/*      */       case 268:
/* 1840 */         forlist(varname);
/*      */         break;
/*      */       default:
/* 1843 */         syntaxerror(LUA_QL("=") + " or " + LUA_QL("in") + " expected"); break;
/*      */     } 
/* 1845 */     check_match(262, 264, line);
/* 1846 */     fs.leaveblock();
/*      */   }
/*      */   
/*      */   void test_then_block(IntPtr escapelist) {
/*      */     int jf;
/* 1851 */     expdesc v = new expdesc();
/* 1852 */     FuncState.BlockCnt bl = new FuncState.BlockCnt();
/*      */     
/* 1854 */     next();
/* 1855 */     expr(v);
/* 1856 */     checknext(275);
/* 1857 */     if (this.t.token == 266 || this.t.token == 258) {
/* 1858 */       this.fs.goiffalse(v);
/* 1859 */       this.fs.enterblock(bl, false);
/* 1860 */       gotostat(v.t.i);
/* 1861 */       skipnoopstat();
/* 1862 */       if (block_follow(false)) {
/* 1863 */         this.fs.leaveblock();
/*      */         
/*      */         return;
/*      */       } 
/* 1867 */       jf = this.fs.jump();
/*      */     } else {
/* 1869 */       this.fs.goiftrue(v);
/* 1870 */       this.fs.enterblock(bl, false);
/* 1871 */       jf = v.f.i;
/*      */     } 
/* 1873 */     statlist();
/* 1874 */     this.fs.leaveblock();
/* 1875 */     if (this.t.token == 260 || this.t.token == 261)
/* 1876 */       this.fs.concat(escapelist, this.fs.jump()); 
/* 1877 */     this.fs.patchtohere(jf);
/*      */   }
/*      */   
/*      */   void ifstat(int line) {
/* 1881 */     IntPtr escapelist = new IntPtr(-1);
/* 1882 */     test_then_block(escapelist);
/* 1883 */     while (this.t.token == 261)
/* 1884 */       test_then_block(escapelist); 
/* 1885 */     if (testnext(260))
/* 1886 */       block(); 
/* 1887 */     check_match(262, 267, line);
/* 1888 */     this.fs.patchtohere(escapelist.i);
/*      */   }
/*      */   
/*      */   void localfunc() {
/* 1892 */     expdesc b = new expdesc();
/* 1893 */     FuncState fs = this.fs;
/* 1894 */     new_localvar(str_checkname());
/* 1895 */     adjustlocalvars(1);
/* 1896 */     body(b, false, this.linenumber);
/*      */     
/* 1898 */     (fs.getlocvar(fs.nactvar - 1)).startpc = fs.pc;
/*      */   }
/*      */ 
/*      */   
/*      */   void localstat() {
/* 1903 */     int nvars = 0;
/*      */     
/* 1905 */     expdesc e = new expdesc();
/*      */     while (true) {
/* 1907 */       new_localvar(str_checkname());
/* 1908 */       nvars++;
/* 1909 */       if (!testnext(44)) {
/* 1910 */         int nexps; if (testnext(61)) {
/* 1911 */           nexps = explist(e);
/*      */         } else {
/* 1913 */           e.k = 0;
/* 1914 */           nexps = 0;
/*      */         } 
/* 1916 */         adjust_assign(nvars, nexps, e);
/* 1917 */         adjustlocalvars(nvars);
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   } boolean funcname(expdesc v) {
/* 1922 */     boolean ismethod = false;
/* 1923 */     singlevar(v);
/* 1924 */     while (this.t.token == 46)
/* 1925 */       fieldsel(v); 
/* 1926 */     if (this.t.token == 58) {
/* 1927 */       ismethod = true;
/* 1928 */       fieldsel(v);
/*      */     } 
/* 1930 */     return ismethod;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void funcstat(int line) {
/* 1936 */     expdesc v = new expdesc();
/* 1937 */     expdesc b = new expdesc();
/* 1938 */     next();
/* 1939 */     boolean needself = funcname(v);
/* 1940 */     body(b, needself, line);
/* 1941 */     this.fs.storevar(v, b);
/* 1942 */     this.fs.fixline(line);
/*      */   }
/*      */ 
/*      */   
/*      */   void exprstat() {
/* 1947 */     FuncState fs = this.fs;
/* 1948 */     LHS_assign v = new LHS_assign();
/* 1949 */     suffixedexp(v.v);
/* 1950 */     if (this.t.token == 61 || this.t.token == 44) {
/* 1951 */       v.prev = null;
/* 1952 */       assignment(v, 1);
/*      */     } else {
/* 1954 */       check_condition((v.v.k == 12), "syntax error");
/* 1955 */       SETARG_C(fs.getcodePtr(v.v), 1);
/*      */     } 
/*      */   }
/*      */   
/*      */   void retstat() {
/*      */     int first, nret;
/* 1961 */     FuncState fs = this.fs;
/* 1962 */     expdesc e = new expdesc();
/*      */     
/* 1964 */     if (block_follow(true) || this.t.token == 59) {
/* 1965 */       first = nret = 0;
/*      */     } else {
/* 1967 */       nret = explist(e);
/* 1968 */       if (hasmultret(e.k)) {
/* 1969 */         fs.setmultret(e);
/* 1970 */         if (e.k == 12 && nret == 1) {
/* 1971 */           SET_OPCODE(fs.getcodePtr(e), 30);
/* 1972 */           _assert((Lua.GETARG_A(fs.getcode(e)) == fs.nactvar));
/*      */         } 
/* 1974 */         first = fs.nactvar;
/* 1975 */         nret = -1;
/*      */       }
/* 1977 */       else if (nret == 1) {
/* 1978 */         first = fs.exp2anyreg(e);
/*      */       } else {
/* 1980 */         fs.exp2nextreg(e);
/* 1981 */         first = fs.nactvar;
/* 1982 */         _assert((nret == fs.freereg - first));
/*      */       } 
/*      */     } 
/*      */     
/* 1986 */     fs.ret(first, nret);
/* 1987 */     testnext(59);
/*      */   }
/*      */   
/*      */   void statement() {
/* 1991 */     int line = this.linenumber;
/* 1992 */     enterlevel();
/* 1993 */     switch (this.t.token) {
/*      */       case 59:
/* 1995 */         next();
/*      */         break;
/*      */       
/*      */       case 267:
/* 1999 */         ifstat(line);
/*      */         break;
/*      */       
/*      */       case 278:
/* 2003 */         whilestat(line);
/*      */         break;
/*      */       
/*      */       case 259:
/* 2007 */         next();
/* 2008 */         block();
/* 2009 */         check_match(262, 259, line);
/*      */         break;
/*      */       
/*      */       case 264:
/* 2013 */         forstat(line);
/*      */         break;
/*      */       
/*      */       case 273:
/* 2017 */         repeatstat(line);
/*      */         break;
/*      */       
/*      */       case 265:
/* 2021 */         funcstat(line);
/*      */         break;
/*      */       
/*      */       case 269:
/* 2025 */         next();
/* 2026 */         if (testnext(265)) {
/* 2027 */           localfunc(); break;
/*      */         } 
/* 2029 */         localstat();
/*      */         break;
/*      */       
/*      */       case 285:
/* 2033 */         next();
/* 2034 */         labelstat(str_checkname(), line);
/*      */         break;
/*      */       
/*      */       case 274:
/* 2038 */         next();
/* 2039 */         retstat();
/*      */         break;
/*      */       
/*      */       case 258:
/*      */       case 266:
/* 2044 */         gotostat(this.fs.jump());
/*      */         break;
/*      */       
/*      */       default:
/* 2048 */         exprstat();
/*      */         break;
/*      */     } 
/*      */     
/* 2052 */     _assert((this.fs.f.maxstacksize >= this.fs.freereg && this.fs.freereg >= this.fs.nactvar));
/* 2053 */     this.fs.freereg = this.fs.nactvar;
/* 2054 */     leavelevel();
/*      */   }
/*      */ 
/*      */   
/*      */   void statlist() {
/* 2059 */     while (!block_follow(true)) {
/* 2060 */       if (this.t.token == 274) {
/* 2061 */         statement();
/*      */         return;
/*      */       } 
/* 2064 */       statement();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void mainfunc(FuncState funcstate) {
/* 2073 */     FuncState.BlockCnt bl = new FuncState.BlockCnt();
/* 2074 */     open_func(funcstate, bl);
/* 2075 */     this.fs.f.is_vararg = 1;
/* 2076 */     expdesc v = new expdesc();
/* 2077 */     v.init(7, 0);
/* 2078 */     this.fs.newupvalue(this.envn, v);
/* 2079 */     next();
/* 2080 */     statlist();
/* 2081 */     check(286);
/* 2082 */     close_func();
/*      */   }
/*      */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-core-3.0.3.jar!\org\luaj\vm2\compiler\LexState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */