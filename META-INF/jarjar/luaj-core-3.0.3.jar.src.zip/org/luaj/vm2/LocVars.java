/*    */ package org.luaj.vm2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocVars
/*    */ {
/*    */   public LuaString varname;
/*    */   public int startpc;
/*    */   public int endpc;
/*    */   
/*    */   public LocVars(LuaString varname, int startpc, int endpc) {
/* 46 */     this.varname = varname;
/* 47 */     this.startpc = startpc;
/* 48 */     this.endpc = endpc;
/*    */   }
/*    */   
/*    */   public String tojstring() {
/* 52 */     return this.varname + " " + this.startpc + "-" + this.endpc;
/*    */   }
/*    */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-core-3.0.3.jar!\org\luaj\vm2\LocVars.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */