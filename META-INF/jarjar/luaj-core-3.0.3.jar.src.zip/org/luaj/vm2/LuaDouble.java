/*     */ package org.luaj.vm2;
/*     */ 
/*     */ import org.luaj.vm2.lib.MathLib;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LuaDouble
/*     */   extends LuaNumber
/*     */ {
/*  61 */   public static final LuaDouble NAN = new LuaDouble(Double.NaN);
/*     */ 
/*     */   
/*  64 */   public static final LuaDouble POSINF = new LuaDouble(Double.POSITIVE_INFINITY);
/*     */ 
/*     */   
/*  67 */   public static final LuaDouble NEGINF = new LuaDouble(Double.NEGATIVE_INFINITY);
/*     */ 
/*     */   
/*     */   public static final String JSTR_NAN = "nan";
/*     */ 
/*     */   
/*     */   public static final String JSTR_POSINF = "inf";
/*     */ 
/*     */   
/*     */   public static final String JSTR_NEGINF = "-inf";
/*     */   
/*     */   final double v;
/*     */ 
/*     */   
/*     */   public static LuaNumber valueOf(double d) {
/*  82 */     int id = (int)d;
/*  83 */     return (d == id) ? LuaInteger.valueOf(id) : new LuaDouble(d);
/*     */   }
/*     */ 
/*     */   
/*     */   private LuaDouble(double d) {
/*  88 */     this.v = d;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  93 */     long l = Double.doubleToLongBits(this.v + 1.0D);
/*  94 */     return (int)(l >> 32L) + (int)l;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean islong() {
/*  99 */     return (this.v == (long)this.v);
/*     */   }
/*     */   
/*     */   public byte tobyte() {
/* 103 */     return (byte)(int)(long)this.v;
/*     */   }
/*     */   public char tochar() {
/* 106 */     return (char)(int)(long)this.v;
/*     */   }
/*     */   public double todouble() {
/* 109 */     return this.v;
/*     */   }
/*     */   public float tofloat() {
/* 112 */     return (float)this.v;
/*     */   }
/*     */   public int toint() {
/* 115 */     return (int)(long)this.v;
/*     */   }
/*     */   public long tolong() {
/* 118 */     return (long)this.v;
/*     */   }
/*     */   public short toshort() {
/* 121 */     return (short)(int)(long)this.v;
/*     */   }
/*     */   public double optdouble(double defval) {
/* 124 */     return this.v;
/*     */   }
/*     */   public int optint(int defval) {
/* 127 */     return (int)(long)this.v;
/*     */   }
/*     */   public LuaInteger optinteger(LuaInteger defval) {
/* 130 */     return LuaInteger.valueOf((int)(long)this.v);
/*     */   }
/*     */   public long optlong(long defval) {
/* 133 */     return (long)this.v;
/*     */   }
/*     */   public LuaInteger checkinteger() {
/* 136 */     return LuaInteger.valueOf((int)(long)this.v);
/*     */   }
/*     */   
/*     */   public LuaValue neg() {
/* 140 */     return valueOf(-this.v);
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 144 */     return (o instanceof LuaDouble) ? ((((LuaDouble)o).v == this.v)) : false;
/*     */   }
/*     */   
/*     */   public LuaValue eq(LuaValue val) {
/* 148 */     return val.raweq(this.v) ? TRUE : FALSE;
/*     */   }
/*     */   public boolean eq_b(LuaValue val) {
/* 151 */     return val.raweq(this.v);
/*     */   }
/*     */   
/*     */   public boolean raweq(LuaValue val) {
/* 155 */     return val.raweq(this.v);
/*     */   }
/*     */   public boolean raweq(double val) {
/* 158 */     return (this.v == val);
/*     */   }
/*     */   public boolean raweq(int val) {
/* 161 */     return (this.v == val);
/*     */   }
/*     */   
/*     */   public LuaValue add(LuaValue rhs) {
/* 165 */     return rhs.add(this.v);
/*     */   }
/*     */   public LuaValue add(double lhs) {
/* 168 */     return valueOf(lhs + this.v);
/*     */   }
/*     */   public LuaValue sub(LuaValue rhs) {
/* 171 */     return rhs.subFrom(this.v);
/*     */   }
/*     */   public LuaValue sub(double rhs) {
/* 174 */     return valueOf(this.v - rhs);
/*     */   }
/*     */   public LuaValue sub(int rhs) {
/* 177 */     return valueOf(this.v - rhs);
/*     */   }
/*     */   public LuaValue subFrom(double lhs) {
/* 180 */     return valueOf(lhs - this.v);
/*     */   }
/*     */   public LuaValue mul(LuaValue rhs) {
/* 183 */     return rhs.mul(this.v);
/*     */   }
/*     */   public LuaValue mul(double lhs) {
/* 186 */     return valueOf(lhs * this.v);
/*     */   }
/*     */   public LuaValue mul(int lhs) {
/* 189 */     return valueOf(lhs * this.v);
/*     */   }
/*     */   public LuaValue pow(LuaValue rhs) {
/* 192 */     return rhs.powWith(this.v);
/*     */   }
/*     */   public LuaValue pow(double rhs) {
/* 195 */     return MathLib.dpow(this.v, rhs);
/*     */   }
/*     */   public LuaValue pow(int rhs) {
/* 198 */     return MathLib.dpow(this.v, rhs);
/*     */   }
/*     */   public LuaValue powWith(double lhs) {
/* 201 */     return MathLib.dpow(lhs, this.v);
/*     */   }
/*     */   public LuaValue powWith(int lhs) {
/* 204 */     return MathLib.dpow(lhs, this.v);
/*     */   }
/*     */   public LuaValue div(LuaValue rhs) {
/* 207 */     return rhs.divInto(this.v);
/*     */   }
/*     */   public LuaValue div(double rhs) {
/* 210 */     return ddiv(this.v, rhs);
/*     */   }
/*     */   public LuaValue div(int rhs) {
/* 213 */     return ddiv(this.v, rhs);
/*     */   }
/*     */   public LuaValue divInto(double lhs) {
/* 216 */     return ddiv(lhs, this.v);
/*     */   }
/*     */   public LuaValue mod(LuaValue rhs) {
/* 219 */     return rhs.modFrom(this.v);
/*     */   }
/*     */   public LuaValue mod(double rhs) {
/* 222 */     return dmod(this.v, rhs);
/*     */   }
/*     */   public LuaValue mod(int rhs) {
/* 225 */     return dmod(this.v, rhs);
/*     */   }
/*     */   public LuaValue modFrom(double lhs) {
/* 228 */     return dmod(lhs, this.v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LuaValue ddiv(double lhs, double rhs) {
/* 241 */     return (rhs != 0.0D) ? valueOf(lhs / rhs) : ((lhs > 0.0D) ? POSINF : ((lhs == 0.0D) ? NAN : NEGINF));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double ddiv_d(double lhs, double rhs) {
/* 255 */     return (rhs != 0.0D) ? (lhs / rhs) : ((lhs > 0.0D) ? Double.POSITIVE_INFINITY : ((lhs == 0.0D) ? Double.NaN : Double.NEGATIVE_INFINITY));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LuaValue dmod(double lhs, double rhs) {
/* 269 */     if (rhs == 0.0D || lhs == Double.POSITIVE_INFINITY || lhs == Double.NEGATIVE_INFINITY)
/* 270 */       return NAN; 
/* 271 */     if (rhs == Double.POSITIVE_INFINITY) {
/* 272 */       return (lhs < 0.0D) ? POSINF : valueOf(lhs);
/*     */     }
/* 274 */     if (rhs == Double.NEGATIVE_INFINITY) {
/* 275 */       return (lhs > 0.0D) ? NEGINF : valueOf(lhs);
/*     */     }
/* 277 */     return valueOf(lhs - rhs * Math.floor(lhs / rhs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double dmod_d(double lhs, double rhs) {
/* 291 */     if (rhs == 0.0D || lhs == Double.POSITIVE_INFINITY || lhs == Double.NEGATIVE_INFINITY)
/* 292 */       return Double.NaN; 
/* 293 */     if (rhs == Double.POSITIVE_INFINITY) {
/* 294 */       return (lhs < 0.0D) ? Double.POSITIVE_INFINITY : lhs;
/*     */     }
/* 296 */     if (rhs == Double.NEGATIVE_INFINITY) {
/* 297 */       return (lhs > 0.0D) ? Double.NEGATIVE_INFINITY : lhs;
/*     */     }
/* 299 */     return lhs - rhs * Math.floor(lhs / rhs);
/*     */   }
/*     */ 
/*     */   
/*     */   public LuaValue lt(LuaValue rhs) {
/* 304 */     return (rhs instanceof LuaNumber) ? (rhs.gt_b(this.v) ? TRUE : FALSE) : super.lt(rhs);
/*     */   }
/*     */   public LuaValue lt(double rhs) {
/* 307 */     return (this.v < rhs) ? TRUE : FALSE;
/*     */   }
/*     */   public LuaValue lt(int rhs) {
/* 310 */     return (this.v < rhs) ? TRUE : FALSE;
/*     */   }
/*     */   public boolean lt_b(LuaValue rhs) {
/* 313 */     return (rhs instanceof LuaNumber) ? rhs.gt_b(this.v) : super.lt_b(rhs);
/*     */   }
/*     */   public boolean lt_b(int rhs) {
/* 316 */     return (this.v < rhs);
/*     */   }
/*     */   public boolean lt_b(double rhs) {
/* 319 */     return (this.v < rhs);
/*     */   }
/*     */   
/*     */   public LuaValue lteq(LuaValue rhs) {
/* 323 */     return (rhs instanceof LuaNumber) ? (rhs.gteq_b(this.v) ? TRUE : FALSE) : super.lteq(rhs);
/*     */   }
/*     */   
/*     */   public LuaValue lteq(double rhs) {
/* 327 */     return (this.v <= rhs) ? TRUE : FALSE;
/*     */   }
/*     */   public LuaValue lteq(int rhs) {
/* 330 */     return (this.v <= rhs) ? TRUE : FALSE;
/*     */   }
/*     */   public boolean lteq_b(LuaValue rhs) {
/* 333 */     return (rhs instanceof LuaNumber) ? rhs.gteq_b(this.v) : super.lteq_b(rhs);
/*     */   }
/*     */   public boolean lteq_b(int rhs) {
/* 336 */     return (this.v <= rhs);
/*     */   }
/*     */   public boolean lteq_b(double rhs) {
/* 339 */     return (this.v <= rhs);
/*     */   }
/*     */   public LuaValue gt(LuaValue rhs) {
/* 342 */     return (rhs instanceof LuaNumber) ? (rhs.lt_b(this.v) ? TRUE : FALSE) : super.gt(rhs);
/*     */   }
/*     */   public LuaValue gt(double rhs) {
/* 345 */     return (this.v > rhs) ? TRUE : FALSE;
/*     */   }
/*     */   public LuaValue gt(int rhs) {
/* 348 */     return (this.v > rhs) ? TRUE : FALSE;
/*     */   }
/*     */   public boolean gt_b(LuaValue rhs) {
/* 351 */     return (rhs instanceof LuaNumber) ? rhs.lt_b(this.v) : super.gt_b(rhs);
/*     */   }
/*     */   public boolean gt_b(int rhs) {
/* 354 */     return (this.v > rhs);
/*     */   }
/*     */   public boolean gt_b(double rhs) {
/* 357 */     return (this.v > rhs);
/*     */   }
/*     */   
/*     */   public LuaValue gteq(LuaValue rhs) {
/* 361 */     return (rhs instanceof LuaNumber) ? (rhs.lteq_b(this.v) ? TRUE : FALSE) : super.gteq(rhs);
/*     */   }
/*     */   
/*     */   public LuaValue gteq(double rhs) {
/* 365 */     return (this.v >= rhs) ? TRUE : FALSE;
/*     */   }
/*     */   public LuaValue gteq(int rhs) {
/* 368 */     return (this.v >= rhs) ? TRUE : FALSE;
/*     */   }
/*     */   public boolean gteq_b(LuaValue rhs) {
/* 371 */     return (rhs instanceof LuaNumber) ? rhs.lteq_b(this.v) : super.gteq_b(rhs);
/*     */   }
/*     */   public boolean gteq_b(int rhs) {
/* 374 */     return (this.v >= rhs);
/*     */   }
/*     */   public boolean gteq_b(double rhs) {
/* 377 */     return (this.v >= rhs);
/*     */   }
/*     */   
/*     */   public int strcmp(LuaString rhs) {
/* 381 */     typerror("attempt to compare number with string"); return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String tojstring() {
/* 391 */     long l = (long)this.v;
/* 392 */     if (l == this.v)
/* 393 */       return Long.toString(l); 
/* 394 */     if (Double.isNaN(this.v))
/* 395 */       return "nan"; 
/* 396 */     if (Double.isInfinite(this.v))
/* 397 */       return (this.v < 0.0D) ? "-inf" : "inf"; 
/* 398 */     return Float.toString((float)this.v);
/*     */   }
/*     */ 
/*     */   
/*     */   public LuaString strvalue() {
/* 403 */     return LuaString.valueOf(tojstring());
/*     */   }
/*     */ 
/*     */   
/*     */   public LuaString optstring(LuaString defval) {
/* 408 */     return LuaString.valueOf(tojstring());
/*     */   }
/*     */ 
/*     */   
/*     */   public LuaValue tostring() {
/* 413 */     return LuaString.valueOf(tojstring());
/*     */   }
/*     */ 
/*     */   
/*     */   public String optjstring(String defval) {
/* 418 */     return tojstring();
/*     */   }
/*     */ 
/*     */   
/*     */   public LuaNumber optnumber(LuaNumber defval) {
/* 423 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isnumber() {
/* 428 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isstring() {
/* 433 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public LuaValue tonumber() {
/* 438 */     return this;
/*     */   }
/*     */   
/*     */   public int checkint() {
/* 442 */     return (int)(long)this.v;
/*     */   }
/*     */   public long checklong() {
/* 445 */     return (long)this.v;
/*     */   }
/*     */   public LuaNumber checknumber() {
/* 448 */     return this;
/*     */   }
/*     */   public double checkdouble() {
/* 451 */     return this.v;
/*     */   }
/*     */   
/*     */   public String checkjstring() {
/* 455 */     return tojstring();
/*     */   }
/*     */ 
/*     */   
/*     */   public LuaString checkstring() {
/* 460 */     return LuaString.valueOf(tojstring());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isvalidkey() {
/* 465 */     return !Double.isNaN(this.v);
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-core-3.0.3.jar!\org\luaj\vm2\LuaDouble.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */