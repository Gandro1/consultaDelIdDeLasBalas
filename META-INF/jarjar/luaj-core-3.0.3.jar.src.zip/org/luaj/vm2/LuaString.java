/*      */ package org.luaj.vm2;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PrintStream;
/*      */ import org.luaj.vm2.lib.MathLib;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LuaString
/*      */   extends LuaValue
/*      */ {
/*      */   public static LuaValue s_metatable;
/*      */   public final byte[] m_bytes;
/*      */   public final int m_offset;
/*      */   public final int m_length;
/*      */   private final int m_hashcode;
/*      */   static final int RECENT_STRINGS_CACHE_SIZE = 128;
/*      */   static final int RECENT_STRINGS_MAX_LENGTH = 32;
/*      */   
/*      */   private static final class RecentShortStrings
/*      */   {
/*  113 */     private static final LuaString[] recent_short_strings = new LuaString[128];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaString valueOf(String string) {
/*  125 */     char[] c = string.toCharArray();
/*  126 */     byte[] b = new byte[lengthAsUtf8(c)];
/*  127 */     encodeToUtf8(c, c.length, b, 0);
/*  128 */     return valueUsing(b, 0, b.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaString valueOf(byte[] bytes, int off, int len) {
/*  147 */     if (len > 32)
/*  148 */       return valueFromCopy(bytes, off, len); 
/*  149 */     int hash = hashCode(bytes, off, len);
/*  150 */     int bucket = hash & 0x7F;
/*  151 */     LuaString t = RecentShortStrings.recent_short_strings[bucket];
/*  152 */     if (t != null && t.m_hashcode == hash && t.byteseq(bytes, off, len))
/*  153 */       return t; 
/*  154 */     LuaString s = valueFromCopy(bytes, off, len);
/*  155 */     RecentShortStrings.recent_short_strings[bucket] = s;
/*  156 */     return s;
/*      */   }
/*      */ 
/*      */   
/*      */   private static LuaString valueFromCopy(byte[] bytes, int off, int len) {
/*  161 */     byte[] copy = new byte[len];
/*  162 */     System.arraycopy(bytes, off, copy, 0, len);
/*  163 */     return new LuaString(copy, 0, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaString valueUsing(byte[] bytes, int off, int len) {
/*  180 */     if (bytes.length > 32)
/*  181 */       return new LuaString(bytes, off, len); 
/*  182 */     int hash = hashCode(bytes, off, len);
/*  183 */     int bucket = hash & 0x7F;
/*  184 */     LuaString t = RecentShortStrings.recent_short_strings[bucket];
/*  185 */     if (t != null && t.m_hashcode == hash && t.byteseq(bytes, off, len))
/*  186 */       return t; 
/*  187 */     LuaString s = new LuaString(bytes, off, len);
/*  188 */     RecentShortStrings.recent_short_strings[bucket] = s;
/*  189 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaString valueOf(char[] bytes) {
/*  207 */     return valueOf(bytes, 0, bytes.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaString valueOf(char[] bytes, int off, int len) {
/*  225 */     byte[] b = new byte[len];
/*  226 */     for (int i = 0; i < len; i++)
/*  227 */       b[i] = (byte)bytes[i + off]; 
/*  228 */     return valueUsing(b, 0, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaString valueOf(byte[] bytes) {
/*  243 */     return valueOf(bytes, 0, bytes.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LuaString valueUsing(byte[] bytes) {
/*  260 */     return valueUsing(bytes, 0, bytes.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private LuaString(byte[] bytes, int offset, int length) {
/*  277 */     this.m_bytes = bytes;
/*  278 */     this.m_offset = offset;
/*  279 */     this.m_length = length;
/*  280 */     this.m_hashcode = hashCode(bytes, offset, length);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isstring() {
/*  285 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaValue getmetatable() {
/*  290 */     return s_metatable;
/*      */   }
/*      */ 
/*      */   
/*      */   public int type() {
/*  295 */     return 4;
/*      */   }
/*      */ 
/*      */   
/*      */   public String typename() {
/*  300 */     return "string";
/*      */   }
/*      */ 
/*      */   
/*      */   public String tojstring() {
/*  305 */     return decodeAsUtf8(this.m_bytes, this.m_offset, this.m_length);
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaValue neg() {
/*  310 */     double d = scannumber(); return Double.isNaN(d) ? super.neg() : valueOf(-d);
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaValue add(LuaValue rhs) {
/*  315 */     double d = scannumber();
/*  316 */     return Double.isNaN(d) ? arithmt(ADD, rhs) : rhs.add(d);
/*      */   }
/*      */   
/*      */   public LuaValue add(double rhs) {
/*  320 */     return valueOf(checkarith() + rhs);
/*      */   }
/*      */   public LuaValue add(int rhs) {
/*  323 */     return valueOf(checkarith() + rhs);
/*      */   }
/*      */   
/*      */   public LuaValue sub(LuaValue rhs) {
/*  327 */     double d = scannumber();
/*  328 */     return Double.isNaN(d) ? arithmt(SUB, rhs) : rhs.subFrom(d);
/*      */   }
/*      */   
/*      */   public LuaValue sub(double rhs) {
/*  332 */     return valueOf(checkarith() - rhs);
/*      */   }
/*      */   public LuaValue sub(int rhs) {
/*  335 */     return valueOf(checkarith() - rhs);
/*      */   }
/*      */   public LuaValue subFrom(double lhs) {
/*  338 */     return valueOf(lhs - checkarith());
/*      */   }
/*      */   
/*      */   public LuaValue mul(LuaValue rhs) {
/*  342 */     double d = scannumber();
/*  343 */     return Double.isNaN(d) ? arithmt(MUL, rhs) : rhs.mul(d);
/*      */   }
/*      */   
/*      */   public LuaValue mul(double rhs) {
/*  347 */     return valueOf(checkarith() * rhs);
/*      */   }
/*      */   public LuaValue mul(int rhs) {
/*  350 */     return valueOf(checkarith() * rhs);
/*      */   }
/*      */   
/*      */   public LuaValue pow(LuaValue rhs) {
/*  354 */     double d = scannumber();
/*  355 */     return Double.isNaN(d) ? arithmt(POW, rhs) : rhs.powWith(d);
/*      */   }
/*      */   
/*      */   public LuaValue pow(double rhs) {
/*  359 */     return MathLib.dpow(checkarith(), rhs);
/*      */   }
/*      */   public LuaValue pow(int rhs) {
/*  362 */     return MathLib.dpow(checkarith(), rhs);
/*      */   }
/*      */   public LuaValue powWith(double lhs) {
/*  365 */     return MathLib.dpow(lhs, checkarith());
/*      */   }
/*      */   public LuaValue powWith(int lhs) {
/*  368 */     return MathLib.dpow(lhs, checkarith());
/*      */   }
/*      */   
/*      */   public LuaValue div(LuaValue rhs) {
/*  372 */     double d = scannumber();
/*  373 */     return Double.isNaN(d) ? arithmt(DIV, rhs) : rhs.divInto(d);
/*      */   }
/*      */   
/*      */   public LuaValue div(double rhs) {
/*  377 */     return LuaDouble.ddiv(checkarith(), rhs);
/*      */   }
/*      */   public LuaValue div(int rhs) {
/*  380 */     return LuaDouble.ddiv(checkarith(), rhs);
/*      */   }
/*      */   public LuaValue divInto(double lhs) {
/*  383 */     return LuaDouble.ddiv(lhs, checkarith());
/*      */   }
/*      */   
/*      */   public LuaValue mod(LuaValue rhs) {
/*  387 */     double d = scannumber();
/*  388 */     return Double.isNaN(d) ? arithmt(MOD, rhs) : rhs.modFrom(d);
/*      */   }
/*      */   
/*      */   public LuaValue mod(double rhs) {
/*  392 */     return LuaDouble.dmod(checkarith(), rhs);
/*      */   }
/*      */   public LuaValue mod(int rhs) {
/*  395 */     return LuaDouble.dmod(checkarith(), rhs);
/*      */   }
/*      */   public LuaValue modFrom(double lhs) {
/*  398 */     return LuaDouble.dmod(lhs, checkarith());
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaValue lt(LuaValue rhs) {
/*  403 */     return rhs.isstring() ? ((rhs.strcmp(this) > 0) ? LuaValue.TRUE : FALSE) : super.lt(rhs);
/*      */   }
/*      */   
/*      */   public boolean lt_b(LuaValue rhs) {
/*  407 */     return rhs.isstring() ? ((rhs.strcmp(this) > 0)) : super.lt_b(rhs);
/*      */   }
/*      */   public boolean lt_b(int rhs) {
/*  410 */     typerror("attempt to compare string with number"); return false;
/*      */   }
/*      */   public boolean lt_b(double rhs) {
/*  413 */     typerror("attempt to compare string with number"); return false;
/*      */   }
/*      */   
/*      */   public LuaValue lteq(LuaValue rhs) {
/*  417 */     return rhs.isstring() ? ((rhs.strcmp(this) >= 0) ? LuaValue.TRUE : FALSE) : super.lteq(rhs);
/*      */   }
/*      */   
/*      */   public boolean lteq_b(LuaValue rhs) {
/*  421 */     return rhs.isstring() ? ((rhs.strcmp(this) >= 0)) : super.lteq_b(rhs);
/*      */   }
/*      */   public boolean lteq_b(int rhs) {
/*  424 */     typerror("attempt to compare string with number"); return false;
/*      */   }
/*      */   public boolean lteq_b(double rhs) {
/*  427 */     typerror("attempt to compare string with number"); return false;
/*      */   }
/*      */   
/*      */   public LuaValue gt(LuaValue rhs) {
/*  431 */     return rhs.isstring() ? ((rhs.strcmp(this) < 0) ? LuaValue.TRUE : FALSE) : super.gt(rhs);
/*      */   }
/*      */   
/*      */   public boolean gt_b(LuaValue rhs) {
/*  435 */     return rhs.isstring() ? ((rhs.strcmp(this) < 0)) : super.gt_b(rhs);
/*      */   }
/*      */   public boolean gt_b(int rhs) {
/*  438 */     typerror("attempt to compare string with number"); return false;
/*      */   }
/*      */   public boolean gt_b(double rhs) {
/*  441 */     typerror("attempt to compare string with number"); return false;
/*      */   }
/*      */   
/*      */   public LuaValue gteq(LuaValue rhs) {
/*  445 */     return rhs.isstring() ? ((rhs.strcmp(this) <= 0) ? LuaValue.TRUE : FALSE) : super.gteq(rhs);
/*      */   }
/*      */   
/*      */   public boolean gteq_b(LuaValue rhs) {
/*  449 */     return rhs.isstring() ? ((rhs.strcmp(this) <= 0)) : super.gteq_b(rhs);
/*      */   }
/*      */   public boolean gteq_b(int rhs) {
/*  452 */     typerror("attempt to compare string with number"); return false;
/*      */   }
/*      */   public boolean gteq_b(double rhs) {
/*  455 */     typerror("attempt to compare string with number"); return false;
/*      */   }
/*      */   
/*      */   public LuaValue concat(LuaValue rhs) {
/*  459 */     return rhs.concatTo(this);
/*      */   }
/*      */   public Buffer concat(Buffer rhs) {
/*  462 */     return rhs.concatTo(this);
/*      */   }
/*      */   public LuaValue concatTo(LuaNumber lhs) {
/*  465 */     return concatTo(lhs.strvalue());
/*      */   }
/*      */   
/*      */   public LuaValue concatTo(LuaString lhs) {
/*  469 */     byte[] b = new byte[lhs.m_length + this.m_length];
/*  470 */     System.arraycopy(lhs.m_bytes, lhs.m_offset, b, 0, lhs.m_length);
/*  471 */     System.arraycopy(this.m_bytes, this.m_offset, b, lhs.m_length, this.m_length);
/*  472 */     return valueUsing(b, 0, b.length);
/*      */   }
/*      */ 
/*      */   
/*      */   public int strcmp(LuaValue lhs) {
/*  477 */     return -lhs.strcmp(this);
/*      */   }
/*      */   
/*      */   public int strcmp(LuaString rhs) {
/*  481 */     for (int i = 0, j = 0; i < this.m_length && j < rhs.m_length; i++, j++) {
/*  482 */       if (this.m_bytes[this.m_offset + i] != rhs.m_bytes[rhs.m_offset + j]) {
/*  483 */         return this.m_bytes[this.m_offset + i] - rhs.m_bytes[rhs.m_offset + j];
/*      */       }
/*      */     } 
/*  486 */     return this.m_length - rhs.m_length;
/*      */   }
/*      */ 
/*      */   
/*      */   private double checkarith() {
/*  491 */     double d = scannumber();
/*  492 */     if (Double.isNaN(d))
/*  493 */       aritherror(); 
/*  494 */     return d;
/*      */   }
/*      */ 
/*      */   
/*      */   public int checkint() {
/*  499 */     return (int)(long)checkdouble();
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaInteger checkinteger() {
/*  504 */     return valueOf(checkint());
/*      */   }
/*      */ 
/*      */   
/*      */   public long checklong() {
/*  509 */     return (long)checkdouble();
/*      */   }
/*      */ 
/*      */   
/*      */   public double checkdouble() {
/*  514 */     double d = scannumber();
/*  515 */     if (Double.isNaN(d))
/*  516 */       argerror("number"); 
/*  517 */     return d;
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaNumber checknumber() {
/*  522 */     return valueOf(checkdouble());
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaNumber checknumber(String msg) {
/*  527 */     double d = scannumber();
/*  528 */     if (Double.isNaN(d))
/*  529 */       error(msg); 
/*  530 */     return valueOf(d);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isnumber() {
/*  535 */     double d = scannumber();
/*  536 */     return !Double.isNaN(d);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isint() {
/*  541 */     double d = scannumber();
/*  542 */     if (Double.isNaN(d))
/*  543 */       return false; 
/*  544 */     int i = (int)d;
/*  545 */     return (i == d);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean islong() {
/*  550 */     double d = scannumber();
/*  551 */     if (Double.isNaN(d))
/*  552 */       return false; 
/*  553 */     long l = (long)d;
/*  554 */     return (l == d);
/*      */   }
/*      */   
/*      */   public byte tobyte() {
/*  558 */     return (byte)toint();
/*      */   }
/*      */   public char tochar() {
/*  561 */     return (char)toint();
/*      */   }
/*      */   public double todouble() {
/*  564 */     double d = scannumber(); return Double.isNaN(d) ? 0.0D : d;
/*      */   }
/*      */   public float tofloat() {
/*  567 */     return (float)todouble();
/*      */   }
/*      */   public int toint() {
/*  570 */     return (int)tolong();
/*      */   }
/*      */   public long tolong() {
/*  573 */     return (long)todouble();
/*      */   }
/*      */   public short toshort() {
/*  576 */     return (short)toint();
/*      */   }
/*      */   
/*      */   public double optdouble(double defval) {
/*  580 */     return checkdouble();
/*      */   }
/*      */ 
/*      */   
/*      */   public int optint(int defval) {
/*  585 */     return checkint();
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaInteger optinteger(LuaInteger defval) {
/*  590 */     return checkinteger();
/*      */   }
/*      */ 
/*      */   
/*      */   public long optlong(long defval) {
/*  595 */     return checklong();
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaNumber optnumber(LuaNumber defval) {
/*  600 */     return checknumber();
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaString optstring(LuaString defval) {
/*  605 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaValue tostring() {
/*  610 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public String optjstring(String defval) {
/*  615 */     return tojstring();
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaString strvalue() {
/*  620 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaString substring(int beginIndex, int endIndex) {
/*  634 */     int off = this.m_offset + beginIndex;
/*  635 */     int len = endIndex - beginIndex;
/*  636 */     return (len >= this.m_length / 2) ? valueUsing(this.m_bytes, off, len) : valueOf(this.m_bytes, off, len);
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  641 */     return this.m_hashcode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int hashCode(byte[] bytes, int offset, int length) {
/*  656 */     int h = length;
/*  657 */     int step = (length >> 5) + 1; int l1;
/*  658 */     for (l1 = length; l1 >= step; l1 -= step)
/*  659 */       h ^= (h << 5) + (h >> 2) + (bytes[offset + l1 - 1] & 0xFF); 
/*  660 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object o) {
/*  666 */     if (o instanceof LuaString) {
/*  667 */       return raweq((LuaString)o);
/*      */     }
/*  669 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaValue eq(LuaValue val) {
/*  674 */     return val.raweq(this) ? TRUE : FALSE;
/*      */   }
/*      */   public boolean eq_b(LuaValue val) {
/*  677 */     return val.raweq(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean raweq(LuaValue val) {
/*  682 */     return val.raweq(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean raweq(LuaString s) {
/*  687 */     if (this == s)
/*  688 */       return true; 
/*  689 */     if (s.m_length != this.m_length)
/*  690 */       return false; 
/*  691 */     if (s.m_bytes == this.m_bytes && s.m_offset == this.m_offset)
/*  692 */       return true; 
/*  693 */     if (s.hashCode() != hashCode())
/*  694 */       return false; 
/*  695 */     for (int i = 0; i < this.m_length; i++) {
/*  696 */       if (s.m_bytes[s.m_offset + i] != this.m_bytes[this.m_offset + i])
/*  697 */         return false; 
/*  698 */     }  return true;
/*      */   }
/*      */   
/*      */   public static boolean equals(LuaString a, int i, LuaString b, int j, int n) {
/*  702 */     return equals(a.m_bytes, a.m_offset + i, b.m_bytes, b.m_offset + j, n);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean byteseq(byte[] bytes, int off, int len) {
/*  710 */     return (this.m_length == len && equals(this.m_bytes, this.m_offset, bytes, off, len));
/*      */   }
/*      */   
/*      */   public static boolean equals(byte[] a, int i, byte[] b, int j, int n) {
/*  714 */     if (a.length < i + n || b.length < j + n)
/*  715 */       return false; 
/*  716 */     while (--n >= 0) {
/*  717 */       if (a[i++] != b[j++])
/*  718 */         return false; 
/*  719 */     }  return true;
/*      */   }
/*      */   
/*      */   public void write(DataOutputStream writer, int i, int len) throws IOException {
/*  723 */     writer.write(this.m_bytes, this.m_offset + i, len);
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaValue len() {
/*  728 */     return LuaInteger.valueOf(this.m_length);
/*      */   }
/*      */ 
/*      */   
/*      */   public int length() {
/*  733 */     return this.m_length;
/*      */   }
/*      */ 
/*      */   
/*      */   public int rawlen() {
/*  738 */     return this.m_length;
/*      */   }
/*      */   
/*      */   public int luaByte(int index) {
/*  742 */     return this.m_bytes[this.m_offset + index] & 0xFF;
/*      */   }
/*      */   
/*      */   public int charAt(int index) {
/*  746 */     if (index < 0 || index >= this.m_length)
/*  747 */       throw new IndexOutOfBoundsException(); 
/*  748 */     return luaByte(index);
/*      */   }
/*      */ 
/*      */   
/*      */   public String checkjstring() {
/*  753 */     return tojstring();
/*      */   }
/*      */ 
/*      */   
/*      */   public LuaString checkstring() {
/*  758 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream toInputStream() {
/*  768 */     return new ByteArrayInputStream(this.m_bytes, this.m_offset, this.m_length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyInto(int strOffset, byte[] bytes, int arrayOffset, int len) {
/*  780 */     System.arraycopy(this.m_bytes, this.m_offset + strOffset, bytes, arrayOffset, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int indexOfAny(LuaString accept) {
/*  792 */     int ilimit = this.m_offset + this.m_length;
/*  793 */     int jlimit = accept.m_offset + accept.m_length;
/*  794 */     for (int i = this.m_offset; i < ilimit; i++) {
/*  795 */       for (int j = accept.m_offset; j < jlimit; j++) {
/*  796 */         if (this.m_bytes[i] == accept.m_bytes[j]) {
/*  797 */           return i - this.m_offset;
/*      */         }
/*      */       } 
/*      */     } 
/*  801 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int indexOf(byte b, int start) {
/*  812 */     for (int i = start; i < this.m_length; i++) {
/*  813 */       if (this.m_bytes[this.m_offset + i] == b)
/*  814 */         return i; 
/*      */     } 
/*  816 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int indexOf(LuaString s, int start) {
/*  827 */     int slen = s.length();
/*  828 */     int limit = this.m_length - slen;
/*  829 */     for (int i = start; i <= limit; i++) {
/*  830 */       if (equals(this.m_bytes, this.m_offset + i, s.m_bytes, s.m_offset, slen))
/*  831 */         return i; 
/*      */     } 
/*  833 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int lastIndexOf(LuaString s) {
/*  843 */     int slen = s.length();
/*  844 */     int limit = this.m_length - slen;
/*  845 */     for (int i = limit; i >= 0; i--) {
/*  846 */       if (equals(this.m_bytes, this.m_offset + i, s.m_bytes, s.m_offset, slen))
/*  847 */         return i; 
/*      */     } 
/*  849 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String decodeAsUtf8(byte[] bytes, int offset, int length) {
/*      */     int i, j, n;
/*  866 */     for (i = offset, j = offset + length, n = 0; i < j; n++) {
/*  867 */       switch (0xE0 & bytes[i++]) {
/*      */         case 224:
/*  869 */           i++;
/*      */         case 192:
/*  871 */           i++; break;
/*      */       } 
/*      */     } 
/*  874 */     char[] chars = new char[n];
/*  875 */     for (i = offset, j = offset + length, n = 0; i < j;) {
/*  876 */       chars[n++] = (char)(((b = bytes[i++]) >= 0 || i >= j) ? b : ((b < -32 || i + 1 >= j) ? ((b & 0x3F) << 6 | bytes[i++] & 0x3F) : ((b & 0xF) << 12 | (bytes[i++] & 0x3F) << 6 | bytes[i++] & 0x3F)));
/*      */     }
/*      */ 
/*      */     
/*  880 */     return new String(chars);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lengthAsUtf8(char[] chars) {
/*      */     int b;
/*  895 */     for (int i = b = chars.length; --i >= 0;) {
/*  896 */       if ((c = chars[i]) >= '')
/*  897 */         b += (c >= 'ࠀ') ? 2 : 1; 
/*  898 */     }  return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int encodeToUtf8(char[] chars, int nchars, byte[] bytes, int off) {
/*  919 */     int j = off;
/*  920 */     for (int i = 0; i < nchars; i++) {
/*  921 */       char c; if ((c = chars[i]) < '') {
/*  922 */         bytes[j++] = (byte)c;
/*  923 */       } else if (c < 'ࠀ') {
/*  924 */         bytes[j++] = (byte)(0xC0 | c >> 6 & 0x1F);
/*  925 */         bytes[j++] = (byte)(0x80 | c & 0x3F);
/*      */       } else {
/*  927 */         bytes[j++] = (byte)(0xE0 | c >> 12 & 0xF);
/*  928 */         bytes[j++] = (byte)(0x80 | c >> 6 & 0x3F);
/*  929 */         bytes[j++] = (byte)(0x80 | c & 0x3F);
/*      */       } 
/*      */     } 
/*  932 */     return j - off;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isValidUtf8() {
/*  944 */     for (int i = this.m_offset, j = this.m_offset + this.m_length; i < j; ) {
/*  945 */       int c = this.m_bytes[i++];
/*  946 */       if (c >= 0 || ((c & 0xE0) == 192 && i < j && (this.m_bytes[i++] & 0xC0) == 128))
/*      */         continue; 
/*  948 */       if ((c & 0xF0) == 224 && i + 1 < j && (this.m_bytes[i++] & 0xC0) == 128 && (this.m_bytes[i++] & 0xC0) == 128)
/*      */         continue; 
/*  950 */       return false;
/*      */     } 
/*  952 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue tonumber() {
/*  967 */     double d = scannumber();
/*  968 */     return Double.isNaN(d) ? NIL : valueOf(d);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaValue tonumber(int base) {
/*  981 */     double d = scannumber(base);
/*  982 */     return Double.isNaN(d) ? NIL : valueOf(d);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double scannumber() {
/*  992 */     int i = this.m_offset, j = this.m_offset + this.m_length;
/*  993 */     while (i < j && this.m_bytes[i] == 32)
/*  994 */       i++; 
/*  995 */     while (i < j && this.m_bytes[j - 1] == 32)
/*  996 */       j--; 
/*  997 */     if (i >= j)
/*  998 */       return Double.NaN; 
/*  999 */     if (this.m_bytes[i] == 48 && i + 1 < j && (this.m_bytes[i + 1] == 120 || this.m_bytes[i + 1] == 88))
/* 1000 */       return scanlong(16, i + 2, j); 
/* 1001 */     double l = scanlong(10, i, j);
/* 1002 */     return Double.isNaN(l) ? scandouble(i, j) : l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double scannumber(int base) {
/* 1012 */     if (base < 2 || base > 36)
/* 1013 */       return Double.NaN; 
/* 1014 */     int i = this.m_offset, j = this.m_offset + this.m_length;
/* 1015 */     while (i < j && this.m_bytes[i] == 32)
/* 1016 */       i++; 
/* 1017 */     while (i < j && this.m_bytes[j - 1] == 32)
/* 1018 */       j--; 
/* 1019 */     if (i >= j)
/* 1020 */       return Double.NaN; 
/* 1021 */     return scanlong(base, i, j);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double scanlong(int base, int start, int end) {
/* 1033 */     long x = 0L;
/* 1034 */     boolean neg = (this.m_bytes[start] == 45);
/* 1035 */     for (int i = neg ? (start + 1) : start; i < end; i++) {
/* 1036 */       int digit = this.m_bytes[i] - ((base <= 10 || (this.m_bytes[i] >= 48 && this.m_bytes[i] <= 57)) ? 48 : ((this.m_bytes[i] >= 65 && this.m_bytes[i] <= 90) ? 55 : 87));
/*      */       
/* 1038 */       if (digit < 0 || digit >= base)
/* 1039 */         return Double.NaN; 
/* 1040 */       x = x * base + digit;
/* 1041 */       if (x < 0L)
/* 1042 */         return Double.NaN; 
/*      */     } 
/* 1044 */     return neg ? -x : x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double scandouble(int start, int end) {
/* 1055 */     if (end > start + 64)
/* 1056 */       end = start + 64; 
/* 1057 */     for (int i = start; i < end; i++) {
/* 1058 */       switch (this.m_bytes[i]) {
/*      */         case 43:
/*      */         case 45:
/*      */         case 46:
/*      */         case 48:
/*      */         case 49:
/*      */         case 50:
/*      */         case 51:
/*      */         case 52:
/*      */         case 53:
/*      */         case 54:
/*      */         case 55:
/*      */         case 56:
/*      */         case 57:
/*      */         case 69:
/*      */         case 101:
/*      */           break;
/*      */         default:
/* 1076 */           return Double.NaN;
/*      */       } 
/*      */     } 
/* 1079 */     char[] c = new char[end - start];
/* 1080 */     for (int j = start; j < end; j++)
/* 1081 */       c[j - start] = (char)this.m_bytes[j]; 
/*      */     try {
/* 1083 */       return Double.parseDouble(new String(c));
/* 1084 */     } catch (Exception e) {
/* 1085 */       return Double.NaN;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void printToStream(PrintStream ps) {
/* 1096 */     for (int i = 0, n = this.m_length; i < n; i++) {
/* 1097 */       int c = this.m_bytes[this.m_offset + i];
/* 1098 */       ps.print((char)c);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-core-3.0.3.jar!\org\luaj\vm2\LuaString.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */