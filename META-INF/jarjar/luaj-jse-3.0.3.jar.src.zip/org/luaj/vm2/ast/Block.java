/*    */ package org.luaj.vm2.ast;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Block
/*    */   extends Stat
/*    */ {
/* 29 */   public List<Stat> stats = new ArrayList<>();
/*    */   public NameScope scope;
/*    */   
/*    */   public void add(Stat s) {
/* 33 */     if (s == null)
/*    */       return; 
/* 35 */     this.stats.add(s);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(Visitor visitor) {
/* 40 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\ast\Block.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */