/*    */ package org.luaj.vm2.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FuncBody
/*    */   extends SyntaxElement
/*    */ {
/*    */   public ParList parlist;
/*    */   public Block block;
/*    */   public NameScope scope;
/*    */   
/*    */   public FuncBody(ParList parlist, Block block) {
/* 30 */     this.parlist = (parlist != null) ? parlist : ParList.EMPTY_PARLIST;
/* 31 */     this.block = block;
/*    */   }
/*    */   
/*    */   public void accept(Visitor visitor) {
/* 35 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\ast\FuncBody.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */