package org.luaj.vm2.ast;

public class SyntaxElement {
  public int beginLine;
  
  public short beginColumn;
  
  public int endLine;
  
  public short endColumn;
}


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\ast\SyntaxElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */