/*    */ package org.luaj.vm2.ast;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NameScope
/*    */ {
/* 31 */   private static final Set<String> LUA_KEYWORDS = new HashSet<>();
/*    */   
/*    */   static {
/* 34 */     String[] k = { "and", "break", "do", "else", "elseif", "end", "false", "for", "function", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then", "true", "until", "while" };
/*    */     
/* 36 */     for (String element : k)
/* 37 */       LUA_KEYWORDS.add(element); 
/*    */   }
/*    */   
/* 40 */   public final Map<String, Variable> namedVariables = new HashMap<>();
/*    */   
/*    */   public final NameScope outerScope;
/*    */   
/*    */   public int functionNestingCount;
/*    */ 
/*    */   
/*    */   public NameScope() {
/* 48 */     this.outerScope = null;
/* 49 */     this.functionNestingCount = 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public NameScope(NameScope outerScope) {
/* 54 */     this.outerScope = outerScope;
/* 55 */     this.functionNestingCount = (outerScope != null) ? outerScope.functionNestingCount : 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Variable find(String name) throws IllegalArgumentException {
/* 63 */     validateIsNotKeyword(name);
/* 64 */     for (NameScope n = this; n != null; n = n.outerScope) {
/* 65 */       if (n.namedVariables.containsKey(name))
/* 66 */         return n.namedVariables.get(name); 
/* 67 */     }  Variable value = new Variable(name);
/* 68 */     this.namedVariables.put(name, value);
/* 69 */     return value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Variable define(String name) throws IllegalStateException, IllegalArgumentException {
/* 77 */     validateIsNotKeyword(name);
/* 78 */     Variable value = new Variable(name, this);
/* 79 */     this.namedVariables.put(name, value);
/* 80 */     return value;
/*    */   }
/*    */   
/*    */   private void validateIsNotKeyword(String name) {
/* 84 */     if (LUA_KEYWORDS.contains(name))
/* 85 */       throw new IllegalArgumentException("name is a keyword: '" + name + "'"); 
/*    */   }
/*    */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\ast\NameScope.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */