/*    */ package org.luaj.vm2.ast;
/*    */ 
/*    */ import org.luaj.vm2.LuaValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Variable
/*    */ {
/*    */   public final String name;
/*    */   public final NameScope definingScope;
/*    */   public boolean isupvalue;
/*    */   public boolean hasassignments;
/*    */   public LuaValue initialValue;
/*    */   
/*    */   public Variable(String name) {
/* 52 */     this.name = name;
/* 53 */     this.definingScope = null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Variable(String name, NameScope definingScope) {
/* 58 */     this.name = name;
/* 59 */     this.definingScope = definingScope;
/*    */   }
/*    */   public boolean isLocal() {
/* 62 */     return (this.definingScope != null);
/*    */   } public boolean isConstant() {
/* 64 */     return (!this.hasassignments && this.initialValue != null);
/*    */   }
/*    */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\ast\Variable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */