/*     */ package org.luaj.vm2.ast;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import org.luaj.vm2.LuaString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Str
/*     */ {
/*     */   public static LuaString quoteString(String image) {
/*  34 */     String s = image.substring(1, image.length() - 1);
/*  35 */     byte[] bytes = unquote(s);
/*  36 */     return LuaString.valueUsing(bytes);
/*     */   }
/*     */   
/*     */   public static LuaString charString(String image) {
/*  40 */     String s = image.substring(1, image.length() - 1);
/*  41 */     byte[] bytes = unquote(s);
/*  42 */     return LuaString.valueUsing(bytes);
/*     */   }
/*     */   
/*     */   public static LuaString longString(String image) {
/*  46 */     int i = image.indexOf('[', image.indexOf('[') + 1) + 1;
/*  47 */     String s = image.substring(i, image.length() - i);
/*  48 */     byte[] b = iso88591bytes(s);
/*  49 */     return LuaString.valueUsing(b);
/*     */   }
/*     */   
/*     */   public static byte[] iso88591bytes(String s) {
/*     */     try {
/*  54 */       return s.getBytes("ISO8859-1");
/*  55 */     } catch (UnsupportedEncodingException e) {
/*  56 */       throw new IllegalStateException("ISO8859-1 not supported");
/*     */     } 
/*     */   }
/*     */   
/*     */   public static byte[] unquote(String s) {
/*  61 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  62 */     char[] c = s.toCharArray();
/*  63 */     int n = c.length;
/*  64 */     for (int i = 0; i < n; i++) {
/*  65 */       if (c[i] == '\\' && i < n) {
/*  66 */         int d; int j; switch (c[++i]) {
/*     */           case '0':
/*     */           case '1':
/*     */           case '2':
/*     */           case '3':
/*     */           case '4':
/*     */           case '5':
/*     */           case '6':
/*     */           case '7':
/*     */           case '8':
/*     */           case '9':
/*  77 */             d = c[i++] - 48;
/*  78 */             for (j = 0; i < n && j < 2 && c[i] >= '0' && c[i] <= '9'; i++, j++)
/*  79 */               d = d * 10 + c[i] - 48; 
/*  80 */             baos.write((byte)d);
/*  81 */             i--;
/*     */             break;
/*     */           case 'a':
/*  84 */             baos.write(7);
/*     */             break;
/*     */           case 'b':
/*  87 */             baos.write(8);
/*     */             break;
/*     */           case 'f':
/*  90 */             baos.write(12);
/*     */             break;
/*     */           case 'n':
/*  93 */             baos.write(10);
/*     */             break;
/*     */           case 'r':
/*  96 */             baos.write(13);
/*     */             break;
/*     */           case 't':
/*  99 */             baos.write(9);
/*     */             break;
/*     */           case 'v':
/* 102 */             baos.write(11);
/*     */             break;
/*     */           case '"':
/* 105 */             baos.write(34);
/*     */             break;
/*     */           case '\'':
/* 108 */             baos.write(39);
/*     */             break;
/*     */           case '\\':
/* 111 */             baos.write(92);
/*     */             break;
/*     */           default:
/* 114 */             baos.write((byte)c[i]);
/*     */             break;
/*     */         } 
/*     */       } else {
/* 118 */         baos.write((byte)c[i]);
/*     */       } 
/*     */     } 
/* 121 */     return baos.toByteArray();
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\ast\Str.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */