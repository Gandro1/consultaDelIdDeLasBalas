/*     */ package org.luaj.vm2.ast;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.luaj.vm2.LuaValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NameResolver
/*     */   extends Visitor
/*     */ {
/*  23 */   private NameScope scope = null;
/*     */   
/*     */   private void pushScope() {
/*  26 */     this.scope = new NameScope(this.scope);
/*     */   }
/*     */   
/*     */   private void popScope() {
/*  30 */     this.scope = this.scope.outerScope;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(NameScope scope) {}
/*     */ 
/*     */   
/*     */   public void visit(Block block) {
/*  39 */     pushScope();
/*  40 */     block.scope = this.scope;
/*  41 */     super.visit(block);
/*  42 */     popScope();
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(FuncBody body) {
/*  47 */     pushScope();
/*  48 */     this.scope.functionNestingCount++;
/*  49 */     body.scope = this.scope;
/*  50 */     super.visit(body);
/*  51 */     popScope();
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(Stat.LocalFuncDef stat) {
/*  56 */     defineLocalVar(stat.name);
/*  57 */     super.visit(stat);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(Stat.NumericFor stat) {
/*  62 */     pushScope();
/*  63 */     stat.scope = this.scope;
/*  64 */     defineLocalVar(stat.name);
/*  65 */     super.visit(stat);
/*  66 */     popScope();
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(Stat.GenericFor stat) {
/*  71 */     pushScope();
/*  72 */     stat.scope = this.scope;
/*  73 */     defineLocalVars(stat.names);
/*  74 */     super.visit(stat);
/*  75 */     popScope();
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(Exp.NameExp exp) {
/*  80 */     exp.name.variable = resolveNameReference(exp.name);
/*  81 */     super.visit(exp);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(Stat.FuncDef stat) {
/*  86 */     stat.name.name.variable = resolveNameReference(stat.name.name);
/*  87 */     stat.name.name.variable.hasassignments = true;
/*  88 */     super.visit(stat);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(Stat.Assign stat) {
/*  93 */     super.visit(stat);
/*  94 */     for (Exp.VarExp element : stat.vars) {
/*  95 */       Exp.VarExp v = element;
/*  96 */       v.markHasAssignment();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(Stat.LocalAssign stat) {
/* 102 */     visitExps(stat.values);
/* 103 */     defineLocalVars(stat.names);
/* 104 */     int n = stat.names.size();
/* 105 */     int m = (stat.values != null) ? stat.values.size() : 0;
/* 106 */     boolean isvarlist = (m > 0 && m < n && ((Exp)stat.values.get(m - 1)).isvarargexp()); int i;
/* 107 */     for (i = 0; i < n && i < (isvarlist ? (m - 1) : m); i++) {
/* 108 */       if (stat.values.get(i) instanceof Exp.Constant)
/* 109 */         ((Name)stat.names.get(i)).variable.initialValue = ((Exp.Constant)stat.values.get(i)).value; 
/* 110 */     }  if (!isvarlist)
/* 111 */       for (i = m; i < n; i++) {
/* 112 */         ((Name)stat.names.get(i)).variable.initialValue = LuaValue.NIL;
/*     */       } 
/*     */   }
/*     */   
/*     */   public void visit(ParList pars) {
/* 117 */     if (pars.names != null)
/* 118 */       defineLocalVars(pars.names); 
/* 119 */     if (pars.isvararg)
/* 120 */       this.scope.define("arg"); 
/* 121 */     super.visit(pars);
/*     */   }
/*     */   
/*     */   protected void defineLocalVars(List<Name> names) {
/* 125 */     for (Name name : names)
/* 126 */       defineLocalVar(name); 
/*     */   }
/*     */   
/*     */   protected void defineLocalVar(Name name) {
/* 130 */     name.variable = this.scope.define(name.name);
/*     */   }
/*     */   
/*     */   protected Variable resolveNameReference(Name name) {
/* 134 */     Variable v = this.scope.find(name.name);
/* 135 */     if (v.isLocal() && this.scope.functionNestingCount != v.definingScope.functionNestingCount)
/* 136 */       v.isupvalue = true; 
/* 137 */     return v;
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\ast\NameResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */