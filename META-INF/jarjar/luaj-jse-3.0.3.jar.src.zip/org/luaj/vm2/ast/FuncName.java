/*    */ package org.luaj.vm2.ast;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FuncName
/*    */   extends SyntaxElement
/*    */ {
/*    */   public final Name name;
/*    */   public List<String> dots;
/*    */   public String method;
/*    */   
/*    */   public FuncName(String name) {
/* 40 */     this.name = new Name(name);
/*    */   }
/*    */   
/*    */   public void adddot(String dot) {
/* 44 */     if (this.dots == null)
/* 45 */       this.dots = new ArrayList<>(); 
/* 46 */     this.dots.add(dot);
/*    */   }
/*    */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\ast\FuncName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */