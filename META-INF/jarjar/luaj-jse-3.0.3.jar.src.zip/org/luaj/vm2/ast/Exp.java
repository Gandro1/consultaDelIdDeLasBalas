/*     */ package org.luaj.vm2.ast;
/*     */ 
/*     */ import org.luaj.vm2.LuaValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Exp
/*     */   extends SyntaxElement
/*     */ {
/*     */   public abstract void accept(Visitor paramVisitor);
/*     */   
/*     */   public static Exp constant(LuaValue value) {
/*  31 */     return new Constant(value);
/*     */   }
/*     */   
/*     */   public static Exp numberconstant(String token) {
/*  35 */     return new Constant(LuaValue.valueOf(token).tonumber());
/*     */   }
/*     */   
/*     */   public static Exp varargs() {
/*  39 */     return new VarargsExp();
/*     */   }
/*     */   
/*     */   public static Exp tableconstructor(TableConstructor tc) {
/*  43 */     return tc;
/*     */   }
/*     */   
/*     */   public static Exp unaryexp(int op, Exp rhs) {
/*  47 */     if (rhs instanceof BinopExp) {
/*  48 */       BinopExp b = (BinopExp)rhs;
/*  49 */       if (precedence(op) > precedence(b.op))
/*  50 */         return binaryexp(unaryexp(op, b.lhs), b.op, b.rhs); 
/*     */     } 
/*  52 */     return new UnopExp(op, rhs);
/*     */   }
/*     */   
/*     */   public static Exp binaryexp(Exp lhs, int op, Exp rhs) {
/*  56 */     if (lhs instanceof UnopExp) {
/*  57 */       UnopExp u = (UnopExp)lhs;
/*  58 */       if (precedence(op) > precedence(u.op)) {
/*  59 */         return unaryexp(u.op, binaryexp(u.rhs, op, rhs));
/*     */       }
/*     */     } 
/*     */     
/*  63 */     if (lhs instanceof BinopExp) {
/*  64 */       BinopExp b = (BinopExp)lhs;
/*  65 */       if (precedence(op) > precedence(b.op) || (precedence(op) == precedence(b.op) && isrightassoc(op)))
/*  66 */         return binaryexp(b.lhs, b.op, binaryexp(b.rhs, op, rhs)); 
/*     */     } 
/*  68 */     if (rhs instanceof BinopExp) {
/*  69 */       BinopExp b = (BinopExp)rhs;
/*  70 */       if (precedence(op) > precedence(b.op) || (precedence(op) == precedence(b.op) && !isrightassoc(op)))
/*  71 */         return binaryexp(binaryexp(lhs, op, b.lhs), b.op, b.rhs); 
/*     */     } 
/*  73 */     return new BinopExp(lhs, op, rhs);
/*     */   }
/*     */   
/*     */   static boolean isrightassoc(int op) {
/*  77 */     switch (op) {
/*     */       case 18:
/*     */       case 22:
/*  80 */         return true;
/*     */     } 
/*  82 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   static int precedence(int op) {
/*  87 */     switch (op) {
/*     */       case 59:
/*  89 */         return 0;
/*     */       case 60:
/*  91 */         return 1;
/*     */       case 24:
/*     */       case 25:
/*     */       case 26:
/*     */       case 61:
/*     */       case 62:
/*     */       case 63:
/*  98 */         return 2;
/*     */       case 22:
/* 100 */         return 3;
/*     */       case 13:
/*     */       case 14:
/* 103 */         return 4;
/*     */       case 15:
/*     */       case 16:
/*     */       case 17:
/* 107 */         return 5;
/*     */       case 19:
/*     */       case 20:
/*     */       case 21:
/* 111 */         return 6;
/*     */       case 18:
/* 113 */         return 7;
/*     */     } 
/* 115 */     throw new IllegalStateException("precedence of bad op " + op);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Exp anonymousfunction(FuncBody funcbody) {
/* 120 */     return new AnonFuncDef(funcbody);
/*     */   }
/*     */ 
/*     */   
/*     */   public static NameExp nameprefix(String name) {
/* 125 */     return new NameExp(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public static ParensExp parensprefix(Exp exp) {
/* 130 */     return new ParensExp(exp);
/*     */   }
/*     */ 
/*     */   
/*     */   public static IndexExp indexop(PrimaryExp lhs, Exp exp) {
/* 135 */     return new IndexExp(lhs, exp);
/*     */   }
/*     */ 
/*     */   
/*     */   public static FieldExp fieldop(PrimaryExp lhs, String name) {
/* 140 */     return new FieldExp(lhs, name);
/*     */   }
/*     */ 
/*     */   
/*     */   public static FuncCall functionop(PrimaryExp lhs, FuncArgs args) {
/* 145 */     return new FuncCall(lhs, args);
/*     */   }
/*     */ 
/*     */   
/*     */   public static MethodCall methodop(PrimaryExp lhs, String name, FuncArgs args) {
/* 150 */     return new MethodCall(lhs, name, args);
/*     */   }
/*     */   
/*     */   public boolean isvarexp() {
/* 154 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isfunccall() {
/* 158 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isvarargexp() {
/* 162 */     return false;
/*     */   }
/*     */   
/*     */   public static abstract class PrimaryExp
/*     */     extends Exp {
/*     */     public boolean isvarexp() {
/* 168 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isfunccall() {
/* 173 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract class VarExp
/*     */     extends PrimaryExp {
/*     */     public boolean isvarexp() {
/* 180 */       return true;
/*     */     }
/*     */     
/*     */     public void markHasAssignment() {}
/*     */   }
/*     */   
/*     */   public static class NameExp
/*     */     extends VarExp {
/*     */     public final Name name;
/*     */     
/*     */     public NameExp(String name) {
/* 191 */       this.name = new Name(name);
/*     */     }
/*     */ 
/*     */     
/*     */     public void markHasAssignment() {
/* 196 */       this.name.variable.hasassignments = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 201 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ParensExp extends PrimaryExp {
/*     */     public final Exp exp;
/*     */     
/*     */     public ParensExp(Exp exp) {
/* 209 */       this.exp = exp;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 214 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class FieldExp extends VarExp {
/*     */     public final Exp.PrimaryExp lhs;
/*     */     public final Name name;
/*     */     
/*     */     public FieldExp(Exp.PrimaryExp lhs, String name) {
/* 223 */       this.lhs = lhs;
/* 224 */       this.name = new Name(name);
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 229 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class IndexExp extends VarExp {
/*     */     public final Exp.PrimaryExp lhs;
/*     */     public final Exp exp;
/*     */     
/*     */     public IndexExp(Exp.PrimaryExp lhs, Exp exp) {
/* 238 */       this.lhs = lhs;
/* 239 */       this.exp = exp;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 244 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class FuncCall extends PrimaryExp {
/*     */     public final Exp.PrimaryExp lhs;
/*     */     public final FuncArgs args;
/*     */     
/*     */     public FuncCall(Exp.PrimaryExp lhs, FuncArgs args) {
/* 253 */       this.lhs = lhs;
/* 254 */       this.args = args;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isfunccall() {
/* 259 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 264 */       visitor.visit(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isvarargexp() {
/* 269 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class MethodCall extends FuncCall {
/*     */     public final String name;
/*     */     
/*     */     public MethodCall(Exp.PrimaryExp lhs, String name, FuncArgs args) {
/* 277 */       super(lhs, args);
/* 278 */       this.name = new String(name);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isfunccall() {
/* 283 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 288 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Constant extends Exp {
/*     */     public final LuaValue value;
/*     */     
/*     */     public Constant(LuaValue value) {
/* 296 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 301 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class VarargsExp
/*     */     extends Exp
/*     */   {
/*     */     public void accept(Visitor visitor) {
/* 309 */       visitor.visit(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isvarargexp() {
/* 314 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class UnopExp extends Exp {
/*     */     public final int op;
/*     */     public final Exp rhs;
/*     */     
/*     */     public UnopExp(int op, Exp rhs) {
/* 323 */       this.op = op;
/* 324 */       this.rhs = rhs;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 329 */       visitor.visit(this);
/*     */     } }
/*     */   
/*     */   public static class BinopExp extends Exp {
/*     */     public final Exp lhs;
/*     */     public final Exp rhs;
/*     */     public final int op;
/*     */     
/*     */     public BinopExp(Exp lhs, int op, Exp rhs) {
/* 338 */       this.lhs = lhs;
/* 339 */       this.op = op;
/* 340 */       this.rhs = rhs;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 345 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class AnonFuncDef extends Exp {
/*     */     public final FuncBody body;
/*     */     
/*     */     public AnonFuncDef(FuncBody funcbody) {
/* 353 */       this.body = funcbody;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 358 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\ast\Exp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */