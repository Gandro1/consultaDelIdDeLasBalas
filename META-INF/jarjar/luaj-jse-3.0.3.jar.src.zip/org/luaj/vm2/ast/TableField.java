/*    */ package org.luaj.vm2.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TableField
/*    */   extends SyntaxElement
/*    */ {
/*    */   public final Exp index;
/*    */   public final String name;
/*    */   public final Exp rhs;
/*    */   
/*    */   public TableField(Exp index, String name, Exp rhs) {
/* 31 */     this.index = index;
/* 32 */     this.name = name;
/* 33 */     this.rhs = rhs;
/*    */   }
/*    */   
/*    */   public static TableField keyedField(Exp index, Exp rhs) {
/* 37 */     return new TableField(index, null, rhs);
/*    */   }
/*    */   
/*    */   public static TableField namedField(String name, Exp rhs) {
/* 41 */     return new TableField(null, name, rhs);
/*    */   }
/*    */   
/*    */   public static TableField listField(Exp rhs) {
/* 45 */     return new TableField(null, null, rhs);
/*    */   }
/*    */   
/*    */   public void accept(Visitor visitor) {
/* 49 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\ast\TableField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */