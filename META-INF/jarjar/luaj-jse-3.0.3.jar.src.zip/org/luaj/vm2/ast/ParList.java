/*    */ package org.luaj.vm2.ast;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParList
/*    */   extends SyntaxElement
/*    */ {
/* 28 */   public static final List<Name> EMPTY_NAMELIST = new ArrayList<>();
/* 29 */   public static final ParList EMPTY_PARLIST = new ParList(EMPTY_NAMELIST, false);
/*    */   
/*    */   public final List<Name> names;
/*    */   public final boolean isvararg;
/*    */   
/*    */   public ParList(List<Name> names, boolean isvararg) {
/* 35 */     this.names = names;
/* 36 */     this.isvararg = isvararg;
/*    */   }
/*    */   
/*    */   public void accept(Visitor visitor) {
/* 40 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\ast\ParList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */