/*     */ package org.luaj.vm2.ast;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Stat
/*     */   extends SyntaxElement
/*     */ {
/*     */   public abstract void accept(Visitor paramVisitor);
/*     */   
/*     */   public static Stat block(Block block) {
/*  32 */     return block;
/*     */   }
/*     */   
/*     */   public static Stat whiledo(Exp exp, Block block) {
/*  36 */     return new WhileDo(exp, block);
/*     */   }
/*     */   
/*     */   public static Stat repeatuntil(Block block, Exp exp) {
/*  40 */     return new RepeatUntil(block, exp);
/*     */   }
/*     */   
/*     */   public static Stat breakstat() {
/*  44 */     return new Break();
/*     */   }
/*     */   
/*     */   public static Stat returnstat(List<Exp> exps) {
/*  48 */     return new Return(exps);
/*     */   }
/*     */   
/*     */   public static Stat assignment(List<Exp.VarExp> vars, List<Exp> exps) {
/*  52 */     return new Assign(vars, exps);
/*     */   }
/*     */   
/*     */   public static Stat functioncall(Exp.FuncCall funccall) {
/*  56 */     return new FuncCallStat(funccall);
/*     */   }
/*     */   
/*     */   public static Stat localfunctiondef(String name, FuncBody funcbody) {
/*  60 */     return new LocalFuncDef(name, funcbody);
/*     */   }
/*     */   
/*     */   public static Stat fornumeric(String name, Exp initial, Exp limit, Exp step, Block block) {
/*  64 */     return new NumericFor(name, initial, limit, step, block);
/*     */   }
/*     */   
/*     */   public static Stat functiondef(FuncName funcname, FuncBody funcbody) {
/*  68 */     return new FuncDef(funcname, funcbody);
/*     */   }
/*     */   
/*     */   public static Stat forgeneric(List<Name> names, List<Exp> exps, Block block) {
/*  72 */     return new GenericFor(names, exps, block);
/*     */   }
/*     */   
/*     */   public static Stat localassignment(List<Name> names, List<Exp> values) {
/*  76 */     return new LocalAssign(names, values);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Stat ifthenelse(Exp ifexp, Block ifblock, List<Exp> elseifexps, List<Block> elseifblocks, Block elseblock) {
/*  81 */     return new IfThenElse(ifexp, ifblock, elseifexps, elseifblocks, elseblock);
/*     */   }
/*     */   
/*     */   public static Stat gotostat(String name) {
/*  85 */     return new Goto(name);
/*     */   }
/*     */   
/*     */   public static Stat labelstat(String name) {
/*  89 */     return new Label(name);
/*     */   }
/*     */   
/*     */   public static class Goto extends Stat {
/*     */     public final String name;
/*     */     
/*     */     public Goto(String name) {
/*  96 */       this.name = name;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 101 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Label extends Stat {
/*     */     public final String name;
/*     */     
/*     */     public Label(String name) {
/* 109 */       this.name = name;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 114 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Assign extends Stat {
/*     */     public final List<Exp.VarExp> vars;
/*     */     public final List<Exp> exps;
/*     */     
/*     */     public Assign(List<Exp.VarExp> vars, List<Exp> exps) {
/* 123 */       this.vars = vars;
/* 124 */       this.exps = exps;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 129 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class WhileDo
/*     */     extends Stat {
/*     */     public final Exp exp;
/*     */     public final Block block;
/*     */     
/*     */     public WhileDo(Exp exp, Block block) {
/* 139 */       this.exp = exp;
/* 140 */       this.block = block;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 145 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class RepeatUntil extends Stat {
/*     */     public final Block block;
/*     */     public final Exp exp;
/*     */     
/*     */     public RepeatUntil(Block block, Exp exp) {
/* 154 */       this.block = block;
/* 155 */       this.exp = exp;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 160 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Break
/*     */     extends Stat {
/*     */     public void accept(Visitor visitor) {
/* 167 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Return extends Stat {
/*     */     public final List<Exp> values;
/*     */     
/*     */     public Return(List<Exp> values) {
/* 175 */       this.values = values;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 180 */       visitor.visit(this);
/*     */     }
/*     */     
/*     */     public int nreturns() {
/* 184 */       int n = (this.values != null) ? this.values.size() : 0;
/* 185 */       if (n > 0 && ((Exp)this.values.get(n - 1)).isvarargexp())
/* 186 */         n = -1; 
/* 187 */       return n;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class FuncCallStat extends Stat {
/*     */     public final Exp.FuncCall funccall;
/*     */     
/*     */     public FuncCallStat(Exp.FuncCall funccall) {
/* 195 */       this.funccall = funccall;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 200 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class LocalFuncDef extends Stat {
/*     */     public final Name name;
/*     */     public final FuncBody body;
/*     */     
/*     */     public LocalFuncDef(String name, FuncBody body) {
/* 209 */       this.name = new Name(name);
/* 210 */       this.body = body;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 215 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class FuncDef extends Stat {
/*     */     public final FuncName name;
/*     */     public final FuncBody body;
/*     */     
/*     */     public FuncDef(FuncName name, FuncBody body) {
/* 224 */       this.name = name;
/* 225 */       this.body = body;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 230 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class GenericFor extends Stat {
/*     */     public List<Name> names;
/*     */     public List<Exp> exps;
/*     */     public Block block;
/*     */     public NameScope scope;
/*     */     
/*     */     public GenericFor(List<Name> names, List<Exp> exps, Block block) {
/* 241 */       this.names = names;
/* 242 */       this.exps = exps;
/* 243 */       this.block = block;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 248 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class NumericFor
/*     */     extends Stat {
/*     */     public final Name name;
/*     */     public final Exp initial;
/*     */     public final Exp limit;
/*     */     
/*     */     public NumericFor(String name, Exp initial, Exp limit, Exp step, Block block) {
/* 259 */       this.name = new Name(name);
/* 260 */       this.initial = initial;
/* 261 */       this.limit = limit;
/* 262 */       this.step = step;
/* 263 */       this.block = block;
/*     */     }
/*     */     public final Exp step; public final Block block; public NameScope scope;
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 268 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class LocalAssign extends Stat {
/*     */     public final List<Name> names;
/*     */     public final List<Exp> values;
/*     */     
/*     */     public LocalAssign(List<Name> names, List<Exp> values) {
/* 277 */       this.names = names;
/* 278 */       this.values = values;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 283 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class IfThenElse extends Stat {
/*     */     public final Exp ifexp;
/*     */     public final Block ifblock;
/*     */     public final List<Exp> elseifexps;
/*     */     public final List<Block> elseifblocks;
/*     */     public final Block elseblock;
/*     */     
/*     */     public IfThenElse(Exp ifexp, Block ifblock, List<Exp> elseifexps, List<Block> elseifblocks, Block elseblock) {
/* 295 */       this.ifexp = ifexp;
/* 296 */       this.ifblock = ifblock;
/* 297 */       this.elseifexps = elseifexps;
/* 298 */       this.elseifblocks = elseifblocks;
/* 299 */       this.elseblock = elseblock;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(Visitor visitor) {
/* 304 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\ast\Stat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */