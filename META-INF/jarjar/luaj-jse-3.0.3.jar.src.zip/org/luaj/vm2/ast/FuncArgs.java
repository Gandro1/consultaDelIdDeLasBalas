/*    */ package org.luaj.vm2.ast;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.luaj.vm2.LuaString;
/*    */ import org.luaj.vm2.LuaValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FuncArgs
/*    */   extends SyntaxElement
/*    */ {
/*    */   public final List<Exp> exps;
/*    */   
/*    */   public static FuncArgs explist(List<Exp> explist) {
/* 35 */     return new FuncArgs(explist);
/*    */   }
/*    */ 
/*    */   
/*    */   public static FuncArgs tableconstructor(TableConstructor table) {
/* 40 */     return new FuncArgs(table);
/*    */   }
/*    */ 
/*    */   
/*    */   public static FuncArgs string(LuaString string) {
/* 45 */     return new FuncArgs(string);
/*    */   }
/*    */   
/*    */   public FuncArgs(List<Exp> exps) {
/* 49 */     this.exps = exps;
/*    */   }
/*    */   
/*    */   public FuncArgs(LuaString string) {
/* 53 */     this.exps = new ArrayList<>();
/* 54 */     this.exps.add(Exp.constant((LuaValue)string));
/*    */   }
/*    */   
/*    */   public FuncArgs(TableConstructor table) {
/* 58 */     this.exps = new ArrayList<>();
/* 59 */     this.exps.add(table);
/*    */   }
/*    */   
/*    */   public void accept(Visitor visitor) {
/* 63 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\ast\FuncArgs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */