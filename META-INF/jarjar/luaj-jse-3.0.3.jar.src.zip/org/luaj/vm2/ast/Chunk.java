/*    */ package org.luaj.vm2.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Chunk
/*    */   extends SyntaxElement
/*    */ {
/*    */   public final Block block;
/*    */   
/*    */   public Chunk(Block b) {
/* 28 */     this.block = b;
/*    */   }
/*    */   
/*    */   public void accept(Visitor visitor) {
/* 32 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\ast\Chunk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */