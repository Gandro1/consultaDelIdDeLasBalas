/*     */ package org.luaj.vm2.ast;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Visitor
/*     */ {
/*     */   public void visit(Chunk chunk) {
/*  30 */     chunk.block.accept(this);
/*     */   }
/*     */   
/*     */   public void visit(Block block) {
/*  34 */     visit(block.scope);
/*  35 */     if (block.stats != null)
/*  36 */       for (Stat element : block.stats)
/*  37 */         element.accept(this);  
/*     */   }
/*     */   
/*     */   public void visit(Stat.Assign stat) {
/*  41 */     visitVars(stat.vars);
/*  42 */     visitExps(stat.exps);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(Stat.Break breakstat) {}
/*     */   
/*     */   public void visit(Stat.FuncCallStat stat) {
/*  49 */     stat.funccall.accept(this);
/*     */   }
/*     */   
/*     */   public void visit(Stat.FuncDef stat) {
/*  53 */     stat.body.accept(this);
/*     */   }
/*     */   
/*     */   public void visit(Stat.GenericFor stat) {
/*  57 */     visit(stat.scope);
/*  58 */     visitNames(stat.names);
/*  59 */     visitExps(stat.exps);
/*  60 */     stat.block.accept(this);
/*     */   }
/*     */   
/*     */   public void visit(Stat.IfThenElse stat) {
/*  64 */     stat.ifexp.accept(this);
/*  65 */     stat.ifblock.accept(this);
/*  66 */     if (stat.elseifblocks != null)
/*  67 */       for (int i = 0, n = stat.elseifblocks.size(); i < n; i++) {
/*  68 */         ((Exp)stat.elseifexps.get(i)).accept(this);
/*  69 */         ((Block)stat.elseifblocks.get(i)).accept(this);
/*     */       }  
/*  71 */     if (stat.elseblock != null)
/*  72 */       visit(stat.elseblock); 
/*     */   }
/*     */   
/*     */   public void visit(Stat.LocalAssign stat) {
/*  76 */     visitNames(stat.names);
/*  77 */     visitExps(stat.values);
/*     */   }
/*     */   
/*     */   public void visit(Stat.LocalFuncDef stat) {
/*  81 */     visit(stat.name);
/*  82 */     stat.body.accept(this);
/*     */   }
/*     */   
/*     */   public void visit(Stat.NumericFor stat) {
/*  86 */     visit(stat.scope);
/*  87 */     visit(stat.name);
/*  88 */     stat.initial.accept(this);
/*  89 */     stat.limit.accept(this);
/*  90 */     if (stat.step != null)
/*  91 */       stat.step.accept(this); 
/*  92 */     stat.block.accept(this);
/*     */   }
/*     */   
/*     */   public void visit(Stat.RepeatUntil stat) {
/*  96 */     stat.block.accept(this);
/*  97 */     stat.exp.accept(this);
/*     */   }
/*     */   
/*     */   public void visit(Stat.Return stat) {
/* 101 */     visitExps(stat.values);
/*     */   }
/*     */   
/*     */   public void visit(Stat.WhileDo stat) {
/* 105 */     stat.exp.accept(this);
/* 106 */     stat.block.accept(this);
/*     */   }
/*     */   
/*     */   public void visit(FuncBody body) {
/* 110 */     visit(body.scope);
/* 111 */     body.parlist.accept(this);
/* 112 */     body.block.accept(this);
/*     */   }
/*     */   
/*     */   public void visit(FuncArgs args) {
/* 116 */     visitExps(args.exps);
/*     */   }
/*     */   
/*     */   public void visit(TableField field) {
/* 120 */     if (field.name != null)
/* 121 */       visit(field.name); 
/* 122 */     if (field.index != null)
/* 123 */       field.index.accept(this); 
/* 124 */     field.rhs.accept(this);
/*     */   }
/*     */   
/*     */   public void visit(Exp.AnonFuncDef exp) {
/* 128 */     exp.body.accept(this);
/*     */   }
/*     */   
/*     */   public void visit(Exp.BinopExp exp) {
/* 132 */     exp.lhs.accept(this);
/* 133 */     exp.rhs.accept(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(Exp.Constant exp) {}
/*     */   
/*     */   public void visit(Exp.FieldExp exp) {
/* 140 */     exp.lhs.accept(this);
/* 141 */     visit(exp.name);
/*     */   }
/*     */   
/*     */   public void visit(Exp.FuncCall exp) {
/* 145 */     exp.lhs.accept(this);
/* 146 */     exp.args.accept(this);
/*     */   }
/*     */   
/*     */   public void visit(Exp.IndexExp exp) {
/* 150 */     exp.lhs.accept(this);
/* 151 */     exp.exp.accept(this);
/*     */   }
/*     */   
/*     */   public void visit(Exp.MethodCall exp) {
/* 155 */     exp.lhs.accept(this);
/* 156 */     visit(exp.name);
/* 157 */     exp.args.accept(this);
/*     */   }
/*     */   
/*     */   public void visit(Exp.NameExp exp) {
/* 161 */     visit(exp.name);
/*     */   }
/*     */   
/*     */   public void visit(Exp.ParensExp exp) {
/* 165 */     exp.exp.accept(this);
/*     */   }
/*     */   
/*     */   public void visit(Exp.UnopExp exp) {
/* 169 */     exp.rhs.accept(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(Exp.VarargsExp exp) {}
/*     */   
/*     */   public void visit(ParList pars) {
/* 176 */     visitNames(pars.names);
/*     */   }
/*     */   
/*     */   public void visit(TableConstructor table) {
/* 180 */     if (table.fields != null)
/* 181 */       for (TableField element : table.fields)
/* 182 */         element.accept(this);  
/*     */   }
/*     */   
/*     */   public void visitVars(List<Exp.VarExp> vars) {
/* 186 */     if (vars != null)
/* 187 */       for (Exp.VarExp var : vars)
/* 188 */         var.accept(this);  
/*     */   }
/*     */   
/*     */   public void visitExps(List<Exp> exps) {
/* 192 */     if (exps != null)
/* 193 */       for (Exp exp : exps)
/* 194 */         exp.accept(this);  
/*     */   }
/*     */   
/*     */   public void visitNames(List<Name> names) {
/* 198 */     if (names != null)
/* 199 */       for (Name name : names)
/* 200 */         visit(name);  
/*     */   }
/*     */   
/*     */   public void visit(Name name) {}
/*     */   
/*     */   public void visit(String name) {}
/*     */   
/*     */   public void visit(NameScope scope) {}
/*     */   
/*     */   public void visit(Stat.Goto gotostat) {}
/*     */   
/*     */   public void visit(Stat.Label label) {}
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\ast\Visitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */