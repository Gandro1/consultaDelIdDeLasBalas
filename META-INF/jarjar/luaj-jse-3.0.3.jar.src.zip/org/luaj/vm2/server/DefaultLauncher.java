/*     */ package org.luaj.vm2.server;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import org.luaj.vm2.Globals;
/*     */ import org.luaj.vm2.LuaValue;
/*     */ import org.luaj.vm2.Varargs;
/*     */ import org.luaj.vm2.lib.jse.CoerceJavaToLua;
/*     */ import org.luaj.vm2.lib.jse.JsePlatform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultLauncher
/*     */   implements Launcher
/*     */ {
/*  52 */   protected Globals g = JsePlatform.standardGlobals();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] launch(String script, Object[] arg) {
/*  58 */     return launchChunk(this.g.load(script, "main"), arg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] launch(InputStream script, Object[] arg) {
/*  66 */     return launchChunk(this.g.load(script, "main", "bt", (LuaValue)this.g), arg);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] launch(Reader script, Object[] arg) {
/*  72 */     return launchChunk(this.g.load(script, "main"), arg);
/*     */   }
/*     */   
/*     */   private Object[] launchChunk(LuaValue chunk, Object[] arg) {
/*  76 */     LuaValue[] args = new LuaValue[arg.length];
/*  77 */     for (int i = 0; i < args.length; i++)
/*  78 */       args[i] = CoerceJavaToLua.coerce(arg[i]); 
/*  79 */     Varargs results = chunk.invoke(LuaValue.varargsOf(args));
/*     */     
/*  81 */     int n = results.narg();
/*  82 */     Object[] return_values = new Object[n];
/*  83 */     for (int j = 0; j < n; j++) {
/*  84 */       LuaValue r = results.arg(j + 1);
/*  85 */       switch (r.type()) {
/*     */         case 1:
/*  87 */           return_values[j] = Boolean.valueOf(r.toboolean());
/*     */           break;
/*     */         case 3:
/*  90 */           return_values[j] = Double.valueOf(r.todouble());
/*     */           break;
/*     */         case -2:
/*  93 */           return_values[j] = Integer.valueOf(r.toint());
/*     */           break;
/*     */         case 0:
/*  96 */           return_values[j] = null;
/*     */           break;
/*     */         case 4:
/*  99 */           return_values[j] = r.tojstring();
/*     */           break;
/*     */         case 7:
/* 102 */           return_values[j] = r.touserdata();
/*     */           break;
/*     */         default:
/* 105 */           return_values[j] = r; break;
/*     */       } 
/*     */     } 
/* 108 */     return return_values;
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\server\DefaultLauncher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */