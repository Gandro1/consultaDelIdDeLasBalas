/*     */ package org.luaj.vm2.server;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LuajClassLoader
/*     */   extends ClassLoader
/*     */ {
/*     */   static final String luajPackageRoot = "org.luaj.vm2.";
/*  72 */   static final String launcherInterfaceRoot = Launcher.class.getName();
/*     */ 
/*     */   
/*  75 */   Map<String, Class<?>> classes = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Launcher NewLauncher() throws InstantiationException, IllegalAccessException, ClassNotFoundException {
/*  93 */     return NewLauncher((Class)DefaultLauncher.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Launcher NewLauncher(Class<? extends Launcher> launcher_class) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
/* 114 */     LuajClassLoader loader = new LuajClassLoader();
/* 115 */     Object instance = loader.loadAsUserClass(launcher_class.getName()).newInstance();
/* 116 */     return (Launcher)instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isUserClass(String classname) {
/* 127 */     return (classname.startsWith("org.luaj.vm2.") && !classname.startsWith(launcherInterfaceRoot));
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> loadClass(String classname) throws ClassNotFoundException {
/* 132 */     if (this.classes.containsKey(classname))
/* 133 */       return this.classes.get(classname); 
/* 134 */     if (!isUserClass(classname))
/* 135 */       return findSystemClass(classname); 
/* 136 */     return loadAsUserClass(classname);
/*     */   }
/*     */   
/*     */   private Class<?> loadAsUserClass(String classname) throws ClassNotFoundException {
/* 140 */     String path = classname.replace('.', '/').concat(".class");
/* 141 */     InputStream is = getResourceAsStream(path);
/* 142 */     if (is != null) {
/*     */       try {
/* 144 */         ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 145 */         byte[] b = new byte[1024];
/* 146 */         for (int n = 0; (n = is.read(b)) >= 0;)
/* 147 */           baos.write(b, 0, n); 
/* 148 */         byte[] bytes = baos.toByteArray();
/* 149 */         Class<?> result = defineClass(classname, bytes, 0, bytes.length);
/* 150 */         this.classes.put(classname, result);
/* 151 */         return result;
/* 152 */       } catch (IOException e) {
/* 153 */         throw new ClassNotFoundException("Read failed: " + classname + ": " + e);
/*     */       } 
/*     */     }
/* 156 */     throw new ClassNotFoundException("Not found: " + classname);
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\server\LuajClassLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */