package org.luaj.vm2.server;

import java.io.InputStream;
import java.io.Reader;

public interface Launcher {
  Object[] launch(String paramString, Object[] paramArrayOfObject);
  
  Object[] launch(InputStream paramInputStream, Object[] paramArrayOfObject);
  
  Object[] launch(Reader paramReader, Object[] paramArrayOfObject);
}


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\server\Launcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */