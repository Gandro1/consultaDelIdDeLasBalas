/*      */ package org.luaj.vm2.parser.lua51;
/*      */ 
/*      */ import java.io.IOException;
/*      */ 
/*      */ public class LuaParserTokenManager
/*      */   implements LuaParserConstants {
/*      */   private final int jjStopStringLiteralDfa_0(int pos, long active0, long active1) {
/*    8 */     switch (pos) {
/*      */       
/*      */       case 0:
/*   11 */         if ((active0 & 0x7800L) != 0L || (active1 & 0x80L) != 0L)
/*   12 */           return 14; 
/*   13 */         if ((active0 & 0x103C0L) != 0L || (active1 & 0x2000L) != 0L)
/*   14 */           return 7; 
/*   15 */         if ((active1 & 0x40208L) != 0L)
/*   16 */           return 22; 
/*   17 */         if ((active0 & 0x3FFFFE0000000L) != 0L) {
/*      */           
/*   19 */           this.jjmatchedKind = 50;
/*   20 */           return 17;
/*      */         } 
/*   22 */         return -1;
/*      */       case 1:
/*   24 */         if ((active0 & 0x3F73F60000000L) != 0L) {
/*      */           
/*   26 */           if (this.jjmatchedPos != 1) {
/*      */             
/*   28 */             this.jjmatchedKind = 50;
/*   29 */             this.jjmatchedPos = 1;
/*      */           } 
/*   31 */           return 17;
/*      */         } 
/*   33 */         if ((active0 & 0x8C080000000L) != 0L)
/*   34 */           return 17; 
/*   35 */         if ((active0 & 0x103C0L) != 0L)
/*   36 */           return 6; 
/*   37 */         if ((active0 & 0x7000L) != 0L)
/*   38 */           return 13; 
/*   39 */         return -1;
/*      */       case 2:
/*   41 */         if ((active0 & 0x3F12B40000000L) != 0L) {
/*      */           
/*   43 */           this.jjmatchedKind = 50;
/*   44 */           this.jjmatchedPos = 2;
/*   45 */           return 17;
/*      */         } 
/*   47 */         if ((active0 & 0x61420000000L) != 0L)
/*   48 */           return 17; 
/*   49 */         if ((active0 & 0x3C0L) != 0L)
/*   50 */           return 5; 
/*   51 */         if ((active0 & 0x6000L) != 0L)
/*   52 */           return 12; 
/*   53 */         return -1;
/*      */       case 3:
/*   55 */         if ((active0 & 0x4000L) != 0L)
/*   56 */           return 9; 
/*   57 */         if ((active0 & 0x380L) != 0L)
/*   58 */           return 4; 
/*   59 */         if ((active0 & 0xC00300000000L) != 0L)
/*   60 */           return 17; 
/*   61 */         if ((active0 & 0x3312840000000L) != 0L) {
/*      */           
/*   63 */           if (this.jjmatchedPos != 3) {
/*      */             
/*   65 */             this.jjmatchedKind = 50;
/*   66 */             this.jjmatchedPos = 3;
/*      */           } 
/*   68 */           return 17;
/*      */         } 
/*   70 */         return -1;
/*      */       case 4:
/*   72 */         if ((active0 & 0x300L) != 0L)
/*   73 */           return 3; 
/*   74 */         if ((active0 & 0x3010840000000L) != 0L)
/*   75 */           return 17; 
/*   76 */         if ((active0 & 0x302200000000L) != 0L) {
/*      */           
/*   78 */           this.jjmatchedKind = 50;
/*   79 */           this.jjmatchedPos = 4;
/*   80 */           return 17;
/*      */         } 
/*   82 */         return -1;
/*      */       case 5:
/*   84 */         if ((active0 & 0x300200000000L) != 0L)
/*   85 */           return 17; 
/*   86 */         if ((active0 & 0x2000000000L) != 0L) {
/*      */           
/*   88 */           this.jjmatchedKind = 50;
/*   89 */           this.jjmatchedPos = 5;
/*   90 */           return 17;
/*      */         } 
/*   92 */         if ((active0 & 0x200L) != 0L)
/*   93 */           return 0; 
/*   94 */         return -1;
/*      */       case 6:
/*   96 */         if ((active0 & 0x2000000000L) != 0L) {
/*      */           
/*   98 */           this.jjmatchedKind = 50;
/*   99 */           this.jjmatchedPos = 6;
/*  100 */           return 17;
/*      */         } 
/*  102 */         return -1;
/*      */     } 
/*  104 */     return -1;
/*      */   }
/*      */   
/*      */   private final int jjStartNfa_0(int pos, long active0, long active1) {
/*  108 */     return jjMoveNfa_0(jjStopStringLiteralDfa_0(pos, active0, active1), pos + 1);
/*      */   }
/*      */   
/*      */   private int jjStopAtPos(int pos, int kind) {
/*  112 */     this.jjmatchedKind = kind;
/*  113 */     this.jjmatchedPos = pos;
/*  114 */     return pos + 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa0_0() {
/*  117 */     switch (this.curChar) {
/*      */       
/*      */       case 35:
/*  120 */         return jjStopAtPos(0, 89);
/*      */       case 37:
/*  122 */         return jjStopAtPos(0, 81);
/*      */       case 40:
/*  124 */         return jjStopAtPos(0, 69);
/*      */       case 41:
/*  126 */         return jjStopAtPos(0, 70);
/*      */       case 42:
/*  128 */         return jjStopAtPos(0, 78);
/*      */       case 43:
/*  130 */         return jjStopAtPos(0, 76);
/*      */       case 44:
/*  132 */         return jjStopAtPos(0, 66);
/*      */       case 45:
/*  134 */         this.jjmatchedKind = 77;
/*  135 */         return jjMoveStringLiteralDfa1_0(66496L, 0L);
/*      */       case 46:
/*  137 */         this.jjmatchedKind = 67;
/*  138 */         return jjMoveStringLiteralDfa1_0(0L, 262656L);
/*      */       case 47:
/*  140 */         return jjStopAtPos(0, 79);
/*      */       case 58:
/*  142 */         return jjStopAtPos(0, 68);
/*      */       case 59:
/*  144 */         return jjStopAtPos(0, 64);
/*      */       case 60:
/*  146 */         this.jjmatchedKind = 83;
/*  147 */         return jjMoveStringLiteralDfa1_0(0L, 1048576L);
/*      */       case 61:
/*  149 */         this.jjmatchedKind = 65;
/*  150 */         return jjMoveStringLiteralDfa1_0(0L, 8388608L);
/*      */       case 62:
/*  152 */         this.jjmatchedKind = 85;
/*  153 */         return jjMoveStringLiteralDfa1_0(0L, 4194304L);
/*      */       case 91:
/*  155 */         this.jjmatchedKind = 71;
/*  156 */         return jjMoveStringLiteralDfa1_0(30720L, 0L);
/*      */       case 93:
/*  158 */         return jjStopAtPos(0, 72);
/*      */       case 94:
/*  160 */         return jjStopAtPos(0, 80);
/*      */       case 97:
/*  162 */         return jjMoveStringLiteralDfa1_0(536870912L, 0L);
/*      */       case 98:
/*  164 */         return jjMoveStringLiteralDfa1_0(1073741824L, 0L);
/*      */       case 100:
/*  166 */         return jjMoveStringLiteralDfa1_0(2147483648L, 0L);
/*      */       case 101:
/*  168 */         return jjMoveStringLiteralDfa1_0(30064771072L, 0L);
/*      */       case 102:
/*  170 */         return jjMoveStringLiteralDfa1_0(240518168576L, 0L);
/*      */       case 105:
/*  172 */         return jjMoveStringLiteralDfa1_0(824633720832L, 0L);
/*      */       case 108:
/*  174 */         return jjMoveStringLiteralDfa1_0(1099511627776L, 0L);
/*      */       case 110:
/*  176 */         return jjMoveStringLiteralDfa1_0(6597069766656L, 0L);
/*      */       case 111:
/*  178 */         return jjMoveStringLiteralDfa1_0(8796093022208L, 0L);
/*      */       case 114:
/*  180 */         return jjMoveStringLiteralDfa1_0(52776558133248L, 0L);
/*      */       case 116:
/*  182 */         return jjMoveStringLiteralDfa1_0(211106232532992L, 0L);
/*      */       case 117:
/*  184 */         return jjMoveStringLiteralDfa1_0(281474976710656L, 0L);
/*      */       case 119:
/*  186 */         return jjMoveStringLiteralDfa1_0(562949953421312L, 0L);
/*      */       case 123:
/*  188 */         return jjStopAtPos(0, 74);
/*      */       case 125:
/*  190 */         return jjStopAtPos(0, 75);
/*      */       case 126:
/*  192 */         return jjMoveStringLiteralDfa1_0(0L, 16777216L);
/*      */     } 
/*  194 */     return jjMoveNfa_0(8, 0);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_0(long active0, long active1) {
/*      */     try {
/*  198 */       this.curChar = this.input_stream.readChar();
/*  199 */     } catch (IOException e) {
/*  200 */       jjStopStringLiteralDfa_0(0, active0, active1);
/*  201 */       return 1;
/*      */     } 
/*  203 */     switch (this.curChar) {
/*      */       
/*      */       case 45:
/*  206 */         if ((active0 & 0x10000L) != 0L) {
/*      */           
/*  208 */           this.jjmatchedKind = 16;
/*  209 */           this.jjmatchedPos = 1;
/*      */         } 
/*  211 */         return jjMoveStringLiteralDfa2_0(active0, 960L, active1, 0L);
/*      */       case 46:
/*  213 */         if ((active1 & 0x40000L) != 0L) {
/*      */           
/*  215 */           this.jjmatchedKind = 82;
/*  216 */           this.jjmatchedPos = 1;
/*      */         } 
/*  218 */         return jjMoveStringLiteralDfa2_0(active0, 0L, active1, 512L);
/*      */       case 61:
/*  220 */         if ((active1 & 0x100000L) != 0L)
/*  221 */           return jjStopAtPos(1, 84); 
/*  222 */         if ((active1 & 0x400000L) != 0L)
/*  223 */           return jjStopAtPos(1, 86); 
/*  224 */         if ((active1 & 0x800000L) != 0L)
/*  225 */           return jjStopAtPos(1, 87); 
/*  226 */         if ((active1 & 0x1000000L) != 0L)
/*  227 */           return jjStopAtPos(1, 88); 
/*  228 */         return jjMoveStringLiteralDfa2_0(active0, 28672L, active1, 0L);
/*      */       case 91:
/*  230 */         if ((active0 & 0x800L) != 0L)
/*  231 */           return jjStopAtPos(1, 11); 
/*      */         break;
/*      */       case 97:
/*  234 */         return jjMoveStringLiteralDfa2_0(active0, 34359738368L, active1, 0L);
/*      */       case 101:
/*  236 */         return jjMoveStringLiteralDfa2_0(active0, 52776558133248L, active1, 0L);
/*      */       case 102:
/*  238 */         if ((active0 & 0x4000000000L) != 0L)
/*  239 */           return jjStartNfaWithStates_0(1, 38, 17); 
/*      */         break;
/*      */       case 104:
/*  242 */         return jjMoveStringLiteralDfa2_0(active0, 633318697598976L, active1, 0L);
/*      */       case 105:
/*  244 */         return jjMoveStringLiteralDfa2_0(active0, 2199023255552L, active1, 0L);
/*      */       case 108:
/*  246 */         return jjMoveStringLiteralDfa2_0(active0, 12884901888L, active1, 0L);
/*      */       case 110:
/*  248 */         if ((active0 & 0x8000000000L) != 0L)
/*  249 */           return jjStartNfaWithStates_0(1, 39, 17); 
/*  250 */         return jjMoveStringLiteralDfa2_0(active0, 281492693450752L, active1, 0L);
/*      */       case 111:
/*  252 */         if ((active0 & 0x80000000L) != 0L)
/*  253 */           return jjStartNfaWithStates_0(1, 31, 17); 
/*  254 */         return jjMoveStringLiteralDfa2_0(active0, 5566277615616L, active1, 0L);
/*      */       case 114:
/*  256 */         if ((active0 & 0x80000000000L) != 0L)
/*  257 */           return jjStartNfaWithStates_0(1, 43, 17); 
/*  258 */         return jjMoveStringLiteralDfa2_0(active0, 140738562097152L, active1, 0L);
/*      */       case 117:
/*  260 */         return jjMoveStringLiteralDfa2_0(active0, 137438953472L, active1, 0L);
/*      */     } 
/*      */ 
/*      */     
/*  264 */     return jjStartNfa_0(0, active0, active1);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa2_0(long old0, long active0, long old1, long active1) {
/*  267 */     if (((active0 &= old0) | (active1 &= old1)) == 0L)
/*  268 */       return jjStartNfa_0(0, old0, old1);  try {
/*  269 */       this.curChar = this.input_stream.readChar();
/*  270 */     } catch (IOException e) {
/*  271 */       jjStopStringLiteralDfa_0(1, active0, active1);
/*  272 */       return 2;
/*      */     } 
/*  274 */     switch (this.curChar) {
/*      */       
/*      */       case 46:
/*  277 */         if ((active1 & 0x200L) != 0L)
/*  278 */           return jjStopAtPos(2, 73); 
/*      */         break;
/*      */       case 61:
/*  281 */         return jjMoveStringLiteralDfa3_0(active0, 24576L, active1, 0L);
/*      */       case 91:
/*  283 */         if ((active0 & 0x1000L) != 0L)
/*  284 */           return jjStopAtPos(2, 12); 
/*  285 */         return jjMoveStringLiteralDfa3_0(active0, 960L, active1, 0L);
/*      */       case 99:
/*  287 */         return jjMoveStringLiteralDfa3_0(active0, 1099511627776L, active1, 0L);
/*      */       case 100:
/*  289 */         if ((active0 & 0x20000000L) != 0L)
/*  290 */           return jjStartNfaWithStates_0(2, 29, 17); 
/*  291 */         if ((active0 & 0x400000000L) != 0L)
/*  292 */           return jjStartNfaWithStates_0(2, 34, 17); 
/*      */         break;
/*      */       case 101:
/*  295 */         return jjMoveStringLiteralDfa3_0(active0, 70369817919488L, active1, 0L);
/*      */       case 105:
/*  297 */         return jjMoveStringLiteralDfa3_0(active0, 562949953421312L, active1, 0L);
/*      */       case 108:
/*  299 */         if ((active0 & 0x20000000000L) != 0L)
/*  300 */           return jjStartNfaWithStates_0(2, 41, 17); 
/*  301 */         return jjMoveStringLiteralDfa3_0(active0, 34359738368L, active1, 0L);
/*      */       case 110:
/*  303 */         return jjMoveStringLiteralDfa3_0(active0, 137438953472L, active1, 0L);
/*      */       case 112:
/*  305 */         return jjMoveStringLiteralDfa3_0(active0, 35184372088832L, active1, 0L);
/*      */       case 114:
/*  307 */         if ((active0 & 0x1000000000L) != 0L)
/*  308 */           return jjStartNfaWithStates_0(2, 36, 17); 
/*      */         break;
/*      */       case 115:
/*  311 */         return jjMoveStringLiteralDfa3_0(active0, 12884901888L, active1, 0L);
/*      */       case 116:
/*  313 */         if ((active0 & 0x40000000000L) != 0L)
/*  314 */           return jjStartNfaWithStates_0(2, 42, 17); 
/*  315 */         return jjMoveStringLiteralDfa3_0(active0, 299067162755072L, active1, 0L);
/*      */       case 117:
/*  317 */         return jjMoveStringLiteralDfa3_0(active0, 140737488355328L, active1, 0L);
/*      */     } 
/*      */ 
/*      */     
/*  321 */     return jjStartNfa_0(1, active0, active1);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa3_0(long old0, long active0, long old1, long active1) {
/*  324 */     if (((active0 &= old0) | (active1 &= old1)) == 0L)
/*  325 */       return jjStartNfa_0(1, old0, old1);  try {
/*  326 */       this.curChar = this.input_stream.readChar();
/*  327 */     } catch (IOException e) {
/*  328 */       jjStopStringLiteralDfa_0(2, active0, 0L);
/*  329 */       return 3;
/*      */     } 
/*  331 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/*  334 */         return jjMoveStringLiteralDfa4_0(active0, 17280L);
/*      */       case 91:
/*  336 */         if ((active0 & 0x40L) != 0L)
/*  337 */           return jjStopAtPos(3, 6); 
/*  338 */         if ((active0 & 0x2000L) != 0L)
/*  339 */           return jjStopAtPos(3, 13); 
/*      */         break;
/*      */       case 97:
/*  342 */         return jjMoveStringLiteralDfa4_0(active0, 1100585369600L);
/*      */       case 99:
/*  344 */         return jjMoveStringLiteralDfa4_0(active0, 137438953472L);
/*      */       case 101:
/*  346 */         if ((active0 & 0x100000000L) != 0L) {
/*      */           
/*  348 */           this.jjmatchedKind = 32;
/*  349 */           this.jjmatchedPos = 3;
/*      */         }
/*  351 */         else if ((active0 & 0x800000000000L) != 0L) {
/*  352 */           return jjStartNfaWithStates_0(3, 47, 17);
/*  353 */         }  return jjMoveStringLiteralDfa4_0(active0, 35192962023424L);
/*      */       case 105:
/*  355 */         return jjMoveStringLiteralDfa4_0(active0, 281474976710656L);
/*      */       case 108:
/*  357 */         return jjMoveStringLiteralDfa4_0(active0, 562949953421312L);
/*      */       case 110:
/*  359 */         if ((active0 & 0x400000000000L) != 0L)
/*  360 */           return jjStartNfaWithStates_0(3, 46, 17); 
/*      */         break;
/*      */       case 115:
/*  363 */         return jjMoveStringLiteralDfa4_0(active0, 34359738368L);
/*      */       case 117:
/*  365 */         return jjMoveStringLiteralDfa4_0(active0, 17592186044416L);
/*      */     } 
/*      */ 
/*      */     
/*  369 */     return jjStartNfa_0(2, active0, 0L);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa4_0(long old0, long active0) {
/*  372 */     if ((active0 &= old0) == 0L)
/*  373 */       return jjStartNfa_0(2, old0, 0L);  try {
/*  374 */       this.curChar = this.input_stream.readChar();
/*  375 */     } catch (IOException e) {
/*  376 */       jjStopStringLiteralDfa_0(3, active0, 0L);
/*  377 */       return 4;
/*      */     } 
/*  379 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/*  382 */         return jjMoveStringLiteralDfa5_0(active0, 768L);
/*      */       case 91:
/*  384 */         if ((active0 & 0x80L) != 0L)
/*  385 */           return jjStopAtPos(4, 7); 
/*  386 */         if ((active0 & 0x4000L) != 0L)
/*  387 */           return jjStopAtPos(4, 14); 
/*      */         break;
/*      */       case 97:
/*  390 */         return jjMoveStringLiteralDfa5_0(active0, 35184372088832L);
/*      */       case 101:
/*  392 */         if ((active0 & 0x800000000L) != 0L)
/*  393 */           return jjStartNfaWithStates_0(4, 35, 17); 
/*  394 */         if ((active0 & 0x2000000000000L) != 0L)
/*  395 */           return jjStartNfaWithStates_0(4, 49, 17); 
/*      */         break;
/*      */       case 105:
/*  398 */         return jjMoveStringLiteralDfa5_0(active0, 8589934592L);
/*      */       case 107:
/*  400 */         if ((active0 & 0x40000000L) != 0L)
/*  401 */           return jjStartNfaWithStates_0(4, 30, 17); 
/*      */         break;
/*      */       case 108:
/*  404 */         if ((active0 & 0x10000000000L) != 0L)
/*  405 */           return jjStartNfaWithStates_0(4, 40, 17); 
/*  406 */         if ((active0 & 0x1000000000000L) != 0L)
/*  407 */           return jjStartNfaWithStates_0(4, 48, 17); 
/*      */         break;
/*      */       case 114:
/*  410 */         return jjMoveStringLiteralDfa5_0(active0, 17592186044416L);
/*      */       case 116:
/*  412 */         return jjMoveStringLiteralDfa5_0(active0, 137438953472L);
/*      */     } 
/*      */ 
/*      */     
/*  416 */     return jjStartNfa_0(3, active0, 0L);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa5_0(long old0, long active0) {
/*  419 */     if ((active0 &= old0) == 0L)
/*  420 */       return jjStartNfa_0(3, old0, 0L);  try {
/*  421 */       this.curChar = this.input_stream.readChar();
/*  422 */     } catch (IOException e) {
/*  423 */       jjStopStringLiteralDfa_0(4, active0, 0L);
/*  424 */       return 5;
/*      */     } 
/*  426 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/*  429 */         return jjMoveStringLiteralDfa6_0(active0, 512L);
/*      */       case 91:
/*  431 */         if ((active0 & 0x100L) != 0L)
/*  432 */           return jjStopAtPos(5, 8); 
/*      */         break;
/*      */       case 102:
/*  435 */         if ((active0 & 0x200000000L) != 0L)
/*  436 */           return jjStartNfaWithStates_0(5, 33, 17); 
/*      */         break;
/*      */       case 105:
/*  439 */         return jjMoveStringLiteralDfa6_0(active0, 137438953472L);
/*      */       case 110:
/*  441 */         if ((active0 & 0x100000000000L) != 0L)
/*  442 */           return jjStartNfaWithStates_0(5, 44, 17); 
/*      */         break;
/*      */       case 116:
/*  445 */         if ((active0 & 0x200000000000L) != 0L) {
/*  446 */           return jjStartNfaWithStates_0(5, 45, 17);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  451 */     return jjStartNfa_0(4, active0, 0L);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa6_0(long old0, long active0) {
/*  454 */     if ((active0 &= old0) == 0L)
/*  455 */       return jjStartNfa_0(4, old0, 0L);  try {
/*  456 */       this.curChar = this.input_stream.readChar();
/*  457 */     } catch (IOException e) {
/*  458 */       jjStopStringLiteralDfa_0(5, active0, 0L);
/*  459 */       return 6;
/*      */     } 
/*  461 */     switch (this.curChar) {
/*      */       
/*      */       case 91:
/*  464 */         if ((active0 & 0x200L) != 0L)
/*  465 */           return jjStopAtPos(6, 9); 
/*      */         break;
/*      */       case 111:
/*  468 */         return jjMoveStringLiteralDfa7_0(active0, 137438953472L);
/*      */     } 
/*      */ 
/*      */     
/*  472 */     return jjStartNfa_0(5, active0, 0L);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa7_0(long old0, long active0) {
/*  475 */     if ((active0 &= old0) == 0L)
/*  476 */       return jjStartNfa_0(5, old0, 0L);  try {
/*  477 */       this.curChar = this.input_stream.readChar();
/*  478 */     } catch (IOException e) {
/*  479 */       jjStopStringLiteralDfa_0(6, active0, 0L);
/*  480 */       return 7;
/*      */     } 
/*  482 */     switch (this.curChar) {
/*      */       
/*      */       case 110:
/*  485 */         if ((active0 & 0x2000000000L) != 0L) {
/*  486 */           return jjStartNfaWithStates_0(7, 37, 17);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  491 */     return jjStartNfa_0(6, active0, 0L);
/*      */   }
/*      */   
/*      */   private int jjStartNfaWithStates_0(int pos, int kind, int state) {
/*  495 */     this.jjmatchedKind = kind;
/*  496 */     this.jjmatchedPos = pos; 
/*  497 */     try { this.curChar = this.input_stream.readChar(); }
/*  498 */     catch (IOException e) { return pos + 1; }
/*  499 */      return jjMoveNfa_0(state, pos + 1);
/*      */   }
/*  501 */   static final long[] jjbitVec0 = new long[] { 0L, 0L, -1L, -1L };
/*      */ 
/*      */ 
/*      */   
/*      */   private int jjMoveNfa_0(int startState, int curPos) {
/*  506 */     int startsAt = 0;
/*  507 */     this.jjnewStateCnt = 63;
/*  508 */     int i = 1;
/*  509 */     this.jjstateSet[0] = startState;
/*  510 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/*  513 */       if (++this.jjround == Integer.MAX_VALUE)
/*  514 */         ReInitRounds(); 
/*  515 */       if (this.curChar < 64) {
/*      */         
/*  517 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/*  520 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 8:
/*  523 */               if ((0x3FF000000000000L & l) != 0L) {
/*      */                 
/*  525 */                 if (kind > 51)
/*  526 */                   kind = 51; 
/*  527 */                 jjCheckNAddStates(0, 3);
/*      */               }
/*  529 */               else if (this.curChar == 39) {
/*  530 */                 jjCheckNAddStates(4, 6);
/*  531 */               } else if (this.curChar == 34) {
/*  532 */                 jjCheckNAddStates(7, 9);
/*  533 */               } else if (this.curChar == 46) {
/*  534 */                 jjCheckNAdd(22);
/*  535 */               } else if (this.curChar == 45) {
/*  536 */                 this.jjstateSet[this.jjnewStateCnt++] = 7;
/*  537 */               }  if (this.curChar == 48)
/*  538 */                 this.jjstateSet[this.jjnewStateCnt++] = 19; 
/*      */               break;
/*      */             case 0:
/*      */             case 1:
/*  542 */               if (this.curChar == 61)
/*  543 */                 jjCheckNAddTwoStates(1, 2); 
/*      */               break;
/*      */             case 3:
/*  546 */               if (this.curChar == 61)
/*  547 */                 this.jjstateSet[this.jjnewStateCnt++] = 0; 
/*      */               break;
/*      */             case 4:
/*  550 */               if (this.curChar == 61)
/*  551 */                 this.jjstateSet[this.jjnewStateCnt++] = 3; 
/*      */               break;
/*      */             case 5:
/*  554 */               if (this.curChar == 61)
/*  555 */                 this.jjstateSet[this.jjnewStateCnt++] = 4; 
/*      */               break;
/*      */             case 7:
/*  558 */               if (this.curChar == 45)
/*  559 */                 this.jjstateSet[this.jjnewStateCnt++] = 6; 
/*      */               break;
/*      */             case 9:
/*      */             case 10:
/*  563 */               if (this.curChar == 61)
/*  564 */                 jjCheckNAddTwoStates(10, 11); 
/*      */               break;
/*      */             case 12:
/*  567 */               if (this.curChar == 61)
/*  568 */                 this.jjstateSet[this.jjnewStateCnt++] = 9; 
/*      */               break;
/*      */             case 13:
/*  571 */               if (this.curChar == 61)
/*  572 */                 this.jjstateSet[this.jjnewStateCnt++] = 12; 
/*      */               break;
/*      */             case 14:
/*  575 */               if (this.curChar == 61)
/*  576 */                 this.jjstateSet[this.jjnewStateCnt++] = 13; 
/*      */               break;
/*      */             case 17:
/*  579 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  581 */               if (kind > 50)
/*  582 */                 kind = 50; 
/*  583 */               this.jjstateSet[this.jjnewStateCnt++] = 17;
/*      */               break;
/*      */             case 18:
/*  586 */               if (this.curChar == 48)
/*  587 */                 this.jjstateSet[this.jjnewStateCnt++] = 19; 
/*      */               break;
/*      */             case 20:
/*  590 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  592 */               if (kind > 51)
/*  593 */                 kind = 51; 
/*  594 */               this.jjstateSet[this.jjnewStateCnt++] = 20;
/*      */               break;
/*      */             case 21:
/*  597 */               if (this.curChar == 46)
/*  598 */                 jjCheckNAdd(22); 
/*      */               break;
/*      */             case 22:
/*  601 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  603 */               if (kind > 51)
/*  604 */                 kind = 51; 
/*  605 */               jjCheckNAddTwoStates(22, 23);
/*      */               break;
/*      */             case 24:
/*  608 */               if ((0x280000000000L & l) != 0L)
/*  609 */                 jjCheckNAdd(25); 
/*      */               break;
/*      */             case 25:
/*  612 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  614 */               if (kind > 51)
/*  615 */                 kind = 51; 
/*  616 */               jjCheckNAdd(25);
/*      */               break;
/*      */             case 26:
/*  619 */               if (this.curChar == 34)
/*  620 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 27:
/*  623 */               if ((0xFFFFFFFBFFFFFFFFL & l) != 0L)
/*  624 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 28:
/*  627 */               if (this.curChar == 34 && kind > 57)
/*  628 */                 kind = 57; 
/*      */               break;
/*      */             case 30:
/*  631 */               jjCheckNAddStates(7, 9);
/*      */               break;
/*      */             case 32:
/*  634 */               if ((0x3FF000000000000L & l) != 0L)
/*  635 */                 this.jjstateSet[this.jjnewStateCnt++] = 33; 
/*      */               break;
/*      */             case 33:
/*  638 */               if ((0x3FF000000000000L & l) != 0L)
/*  639 */                 this.jjstateSet[this.jjnewStateCnt++] = 34; 
/*      */               break;
/*      */             case 34:
/*  642 */               if ((0x3FF000000000000L & l) != 0L)
/*  643 */                 this.jjstateSet[this.jjnewStateCnt++] = 35; 
/*      */               break;
/*      */             case 35:
/*      */             case 38:
/*  647 */               if ((0x3FF000000000000L & l) != 0L)
/*  648 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 36:
/*  651 */               if ((0x3FF000000000000L & l) != 0L)
/*  652 */                 jjCheckNAddStates(10, 13); 
/*      */               break;
/*      */             case 37:
/*  655 */               if ((0x3FF000000000000L & l) != 0L)
/*  656 */                 jjCheckNAddStates(14, 17); 
/*      */               break;
/*      */             case 39:
/*  659 */               if (this.curChar == 39)
/*  660 */                 jjCheckNAddStates(4, 6); 
/*      */               break;
/*      */             case 40:
/*  663 */               if ((0xFFFFFF7FFFFFFFFFL & l) != 0L)
/*  664 */                 jjCheckNAddStates(4, 6); 
/*      */               break;
/*      */             case 41:
/*  667 */               if (this.curChar == 39 && kind > 58)
/*  668 */                 kind = 58; 
/*      */               break;
/*      */             case 43:
/*  671 */               jjCheckNAddStates(4, 6);
/*      */               break;
/*      */             case 45:
/*  674 */               if ((0x3FF000000000000L & l) != 0L)
/*  675 */                 this.jjstateSet[this.jjnewStateCnt++] = 46; 
/*      */               break;
/*      */             case 46:
/*  678 */               if ((0x3FF000000000000L & l) != 0L)
/*  679 */                 this.jjstateSet[this.jjnewStateCnt++] = 47; 
/*      */               break;
/*      */             case 47:
/*  682 */               if ((0x3FF000000000000L & l) != 0L)
/*  683 */                 this.jjstateSet[this.jjnewStateCnt++] = 48; 
/*      */               break;
/*      */             case 48:
/*      */             case 51:
/*  687 */               if ((0x3FF000000000000L & l) != 0L)
/*  688 */                 jjCheckNAddStates(4, 6); 
/*      */               break;
/*      */             case 49:
/*  691 */               if ((0x3FF000000000000L & l) != 0L)
/*  692 */                 jjCheckNAddStates(18, 21); 
/*      */               break;
/*      */             case 50:
/*  695 */               if ((0x3FF000000000000L & l) != 0L)
/*  696 */                 jjCheckNAddStates(22, 25); 
/*      */               break;
/*      */             case 52:
/*  699 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  701 */               if (kind > 51)
/*  702 */                 kind = 51; 
/*  703 */               jjCheckNAddStates(0, 3);
/*      */               break;
/*      */             case 53:
/*  706 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  708 */               if (kind > 51)
/*  709 */                 kind = 51; 
/*  710 */               jjCheckNAddTwoStates(53, 54);
/*      */               break;
/*      */             case 55:
/*  713 */               if ((0x280000000000L & l) != 0L)
/*  714 */                 jjCheckNAdd(56); 
/*      */               break;
/*      */             case 56:
/*  717 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  719 */               if (kind > 51)
/*  720 */                 kind = 51; 
/*  721 */               jjCheckNAdd(56);
/*      */               break;
/*      */             case 57:
/*  724 */               if ((0x3FF000000000000L & l) != 0L)
/*  725 */                 jjCheckNAddTwoStates(57, 58); 
/*      */               break;
/*      */             case 58:
/*  728 */               if (this.curChar != 46)
/*      */                 break; 
/*  730 */               if (kind > 51)
/*  731 */                 kind = 51; 
/*  732 */               jjCheckNAddTwoStates(59, 60);
/*      */               break;
/*      */             case 59:
/*  735 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  737 */               if (kind > 51)
/*  738 */                 kind = 51; 
/*  739 */               jjCheckNAddTwoStates(59, 60);
/*      */               break;
/*      */             case 61:
/*  742 */               if ((0x280000000000L & l) != 0L)
/*  743 */                 jjCheckNAdd(62); 
/*      */               break;
/*      */             case 62:
/*  746 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  748 */               if (kind > 51)
/*  749 */                 kind = 51; 
/*  750 */               jjCheckNAdd(62);
/*      */               break;
/*      */           } 
/*      */         
/*  754 */         } while (i != startsAt);
/*      */       }
/*  756 */       else if (this.curChar < 128) {
/*      */         
/*  758 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/*  761 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 8:
/*  764 */               if ((0x7FFFFFE87FFFFFEL & l) != 0L) {
/*      */                 
/*  766 */                 if (kind > 50)
/*  767 */                   kind = 50; 
/*  768 */                 jjCheckNAdd(17); break;
/*      */               } 
/*  770 */               if (this.curChar == 91)
/*  771 */                 this.jjstateSet[this.jjnewStateCnt++] = 14; 
/*      */               break;
/*      */             case 2:
/*  774 */               if (this.curChar == 91 && kind > 10)
/*  775 */                 kind = 10; 
/*      */               break;
/*      */             case 6:
/*  778 */               if (this.curChar == 91)
/*  779 */                 this.jjstateSet[this.jjnewStateCnt++] = 5; 
/*      */               break;
/*      */             case 11:
/*  782 */               if (this.curChar == 91 && kind > 15)
/*  783 */                 kind = 15; 
/*      */               break;
/*      */             case 15:
/*  786 */               if (this.curChar == 91)
/*  787 */                 this.jjstateSet[this.jjnewStateCnt++] = 14; 
/*      */               break;
/*      */             case 16:
/*      */             case 17:
/*  791 */               if ((0x7FFFFFE87FFFFFEL & l) == 0L)
/*      */                 break; 
/*  793 */               if (kind > 50)
/*  794 */                 kind = 50; 
/*  795 */               jjCheckNAdd(17);
/*      */               break;
/*      */             case 19:
/*  798 */               if ((0x100000001000000L & l) != 0L)
/*  799 */                 jjCheckNAdd(20); 
/*      */               break;
/*      */             case 20:
/*  802 */               if ((0x7E0000007EL & l) == 0L)
/*      */                 break; 
/*  804 */               if (kind > 51)
/*  805 */                 kind = 51; 
/*  806 */               jjCheckNAdd(20);
/*      */               break;
/*      */             case 23:
/*  809 */               if ((0x2000000020L & l) != 0L)
/*  810 */                 jjAddStates(26, 27); 
/*      */               break;
/*      */             case 27:
/*  813 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L)
/*  814 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 29:
/*  817 */               if (this.curChar == 92)
/*  818 */                 jjAddStates(28, 30); 
/*      */               break;
/*      */             case 30:
/*  821 */               jjCheckNAddStates(7, 9);
/*      */               break;
/*      */             case 31:
/*  824 */               if (this.curChar == 117)
/*  825 */                 this.jjstateSet[this.jjnewStateCnt++] = 32; 
/*      */               break;
/*      */             case 32:
/*  828 */               if ((0x7E0000007EL & l) != 0L)
/*  829 */                 this.jjstateSet[this.jjnewStateCnt++] = 33; 
/*      */               break;
/*      */             case 33:
/*  832 */               if ((0x7E0000007EL & l) != 0L)
/*  833 */                 this.jjstateSet[this.jjnewStateCnt++] = 34; 
/*      */               break;
/*      */             case 34:
/*  836 */               if ((0x7E0000007EL & l) != 0L)
/*  837 */                 this.jjstateSet[this.jjnewStateCnt++] = 35; 
/*      */               break;
/*      */             case 35:
/*  840 */               if ((0x7E0000007EL & l) != 0L)
/*  841 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 40:
/*  844 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L)
/*  845 */                 jjCheckNAddStates(4, 6); 
/*      */               break;
/*      */             case 42:
/*  848 */               if (this.curChar == 92)
/*  849 */                 jjAddStates(31, 33); 
/*      */               break;
/*      */             case 43:
/*  852 */               jjCheckNAddStates(4, 6);
/*      */               break;
/*      */             case 44:
/*  855 */               if (this.curChar == 117)
/*  856 */                 this.jjstateSet[this.jjnewStateCnt++] = 45; 
/*      */               break;
/*      */             case 45:
/*  859 */               if ((0x7E0000007EL & l) != 0L)
/*  860 */                 this.jjstateSet[this.jjnewStateCnt++] = 46; 
/*      */               break;
/*      */             case 46:
/*  863 */               if ((0x7E0000007EL & l) != 0L)
/*  864 */                 this.jjstateSet[this.jjnewStateCnt++] = 47; 
/*      */               break;
/*      */             case 47:
/*  867 */               if ((0x7E0000007EL & l) != 0L)
/*  868 */                 this.jjstateSet[this.jjnewStateCnt++] = 48; 
/*      */               break;
/*      */             case 48:
/*  871 */               if ((0x7E0000007EL & l) != 0L)
/*  872 */                 jjCheckNAddStates(4, 6); 
/*      */               break;
/*      */             case 54:
/*  875 */               if ((0x2000000020L & l) != 0L)
/*  876 */                 jjAddStates(34, 35); 
/*      */               break;
/*      */             case 60:
/*  879 */               if ((0x2000000020L & l) != 0L) {
/*  880 */                 jjAddStates(36, 37);
/*      */               }
/*      */               break;
/*      */           } 
/*  884 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/*  888 */         int i2 = (this.curChar & 0xFF) >> 6;
/*  889 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/*  892 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 27:
/*      */             case 30:
/*  896 */               if ((jjbitVec0[i2] & l2) != 0L)
/*  897 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 40:
/*      */             case 43:
/*  901 */               if ((jjbitVec0[i2] & l2) != 0L) {
/*  902 */                 jjCheckNAddStates(4, 6);
/*      */               }
/*      */               break;
/*      */           } 
/*  906 */         } while (i != startsAt);
/*      */       } 
/*  908 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/*  910 */         this.jjmatchedKind = kind;
/*  911 */         this.jjmatchedPos = curPos;
/*  912 */         kind = Integer.MAX_VALUE;
/*      */       } 
/*  914 */       curPos++;
/*  915 */       i = this.jjnewStateCnt;
/*  916 */       this.jjnewStateCnt = startsAt;
/*  917 */       startsAt = 63 - this.jjnewStateCnt;
/*  918 */       if (i == startsAt)
/*  919 */         return curPos;  
/*  920 */       try { this.curChar = this.input_stream.readChar(); }
/*  921 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*      */   }
/*      */   private int jjMoveStringLiteralDfa0_1() {
/*  926 */     return jjMoveNfa_1(4, 0);
/*      */   }
/*      */   
/*      */   private int jjMoveNfa_1(int startState, int curPos) {
/*  930 */     int startsAt = 0;
/*  931 */     this.jjnewStateCnt = 4;
/*  932 */     int i = 1;
/*  933 */     this.jjstateSet[0] = startState;
/*  934 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/*  937 */       if (++this.jjround == Integer.MAX_VALUE)
/*  938 */         ReInitRounds(); 
/*  939 */       if (this.curChar < 64) {
/*      */         
/*  941 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/*  944 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 4:
/*  947 */               if ((0xFFFFFFFFFFFFDBFFL & l) != 0L) {
/*      */                 
/*  949 */                 if (kind > 17)
/*  950 */                   kind = 17; 
/*  951 */                 jjCheckNAddStates(38, 40);
/*      */               }
/*  953 */               else if ((0x2400L & l) != 0L) {
/*      */                 
/*  955 */                 if (kind > 17)
/*  956 */                   kind = 17; 
/*      */               } 
/*  958 */               if (this.curChar == 13)
/*  959 */                 this.jjstateSet[this.jjnewStateCnt++] = 2; 
/*      */               break;
/*      */             case 0:
/*  962 */               if ((0xFFFFFFFFFFFFDBFFL & l) == 0L)
/*      */                 break; 
/*  964 */               kind = 17;
/*  965 */               jjCheckNAddStates(38, 40);
/*      */               break;
/*      */             case 1:
/*  968 */               if ((0x2400L & l) != 0L && kind > 17)
/*  969 */                 kind = 17; 
/*      */               break;
/*      */             case 2:
/*  972 */               if (this.curChar == 10 && kind > 17)
/*  973 */                 kind = 17; 
/*      */               break;
/*      */             case 3:
/*  976 */               if (this.curChar == 13) {
/*  977 */                 this.jjstateSet[this.jjnewStateCnt++] = 2;
/*      */               }
/*      */               break;
/*      */           } 
/*  981 */         } while (i != startsAt);
/*      */       }
/*  983 */       else if (this.curChar < 128) {
/*      */         
/*  985 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/*  988 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 4:
/*  992 */               kind = 17;
/*  993 */               jjCheckNAddStates(38, 40);
/*      */               break;
/*      */           } 
/*      */         
/*  997 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/* 1001 */         int i2 = (this.curChar & 0xFF) >> 6;
/* 1002 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1005 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 4:
/* 1009 */               if ((jjbitVec0[i2] & l2) == 0L)
/*      */                 break; 
/* 1011 */               if (kind > 17)
/* 1012 */                 kind = 17; 
/* 1013 */               jjCheckNAddStates(38, 40);
/*      */               break;
/*      */           } 
/*      */         
/* 1017 */         } while (i != startsAt);
/*      */       } 
/* 1019 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/* 1021 */         this.jjmatchedKind = kind;
/* 1022 */         this.jjmatchedPos = curPos;
/* 1023 */         kind = Integer.MAX_VALUE;
/*      */       } 
/* 1025 */       curPos++;
/* 1026 */       i = this.jjnewStateCnt;
/* 1027 */       this.jjnewStateCnt = startsAt;
/* 1028 */       startsAt = 4 - this.jjnewStateCnt;
/* 1029 */       if (i == startsAt)
/* 1030 */         return curPos;  
/* 1031 */       try { this.curChar = this.input_stream.readChar(); }
/* 1032 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*      */   } private int jjMoveStringLiteralDfa0_2() {
/* 1036 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1039 */         return jjMoveStringLiteralDfa1_2(262144L);
/*      */     } 
/* 1041 */     return 1;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa1_2(long active0) { try {
/* 1045 */       this.curChar = this.input_stream.readChar();
/* 1046 */     } catch (IOException e) {
/* 1047 */       return 1;
/*      */     } 
/* 1049 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1052 */         if ((active0 & 0x40000L) != 0L) {
/* 1053 */           return jjStopAtPos(1, 18);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1058 */         return 2;
/*      */     } 
/*      */     return 2; } private int jjMoveStringLiteralDfa0_3() {
/* 1061 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1064 */         return jjMoveStringLiteralDfa1_3(524288L);
/*      */     } 
/* 1066 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_3(long active0) {
/*      */     try {
/* 1070 */       this.curChar = this.input_stream.readChar();
/* 1071 */     } catch (IOException e) {
/* 1072 */       return 1;
/*      */     } 
/* 1074 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1077 */         return jjMoveStringLiteralDfa2_3(active0, 524288L);
/*      */     } 
/* 1079 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_3(long old0, long active0) {
/* 1083 */     if ((active0 &= old0) == 0L)
/* 1084 */       return 2;  try {
/* 1085 */       this.curChar = this.input_stream.readChar();
/* 1086 */     } catch (IOException e) {
/* 1087 */       return 2;
/*      */     } 
/* 1089 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1092 */         if ((active0 & 0x80000L) != 0L) {
/* 1093 */           return jjStopAtPos(2, 19);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1098 */         return 3;
/*      */     } 
/*      */     return 3; } private int jjMoveStringLiteralDfa0_4() {
/* 1101 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1104 */         return jjMoveStringLiteralDfa1_4(1048576L);
/*      */     } 
/* 1106 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_4(long active0) {
/*      */     try {
/* 1110 */       this.curChar = this.input_stream.readChar();
/* 1111 */     } catch (IOException e) {
/* 1112 */       return 1;
/*      */     } 
/* 1114 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1117 */         return jjMoveStringLiteralDfa2_4(active0, 1048576L);
/*      */     } 
/* 1119 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_4(long old0, long active0) {
/* 1123 */     if ((active0 &= old0) == 0L)
/* 1124 */       return 2;  try {
/* 1125 */       this.curChar = this.input_stream.readChar();
/* 1126 */     } catch (IOException e) {
/* 1127 */       return 2;
/*      */     } 
/* 1129 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1132 */         return jjMoveStringLiteralDfa3_4(active0, 1048576L);
/*      */     } 
/* 1134 */     return 3;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_4(long old0, long active0) {
/* 1138 */     if ((active0 &= old0) == 0L)
/* 1139 */       return 3;  try {
/* 1140 */       this.curChar = this.input_stream.readChar();
/* 1141 */     } catch (IOException e) {
/* 1142 */       return 3;
/*      */     } 
/* 1144 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1147 */         if ((active0 & 0x100000L) != 0L) {
/* 1148 */           return jjStopAtPos(3, 20);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1153 */         return 4;
/*      */     } 
/*      */     return 4; } private int jjMoveStringLiteralDfa0_5() {
/* 1156 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1159 */         return jjMoveStringLiteralDfa1_5(2097152L);
/*      */     } 
/* 1161 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_5(long active0) {
/*      */     try {
/* 1165 */       this.curChar = this.input_stream.readChar();
/* 1166 */     } catch (IOException e) {
/* 1167 */       return 1;
/*      */     } 
/* 1169 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1172 */         return jjMoveStringLiteralDfa2_5(active0, 2097152L);
/*      */     } 
/* 1174 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_5(long old0, long active0) {
/* 1178 */     if ((active0 &= old0) == 0L)
/* 1179 */       return 2;  try {
/* 1180 */       this.curChar = this.input_stream.readChar();
/* 1181 */     } catch (IOException e) {
/* 1182 */       return 2;
/*      */     } 
/* 1184 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1187 */         return jjMoveStringLiteralDfa3_5(active0, 2097152L);
/*      */     } 
/* 1189 */     return 3;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_5(long old0, long active0) {
/* 1193 */     if ((active0 &= old0) == 0L)
/* 1194 */       return 3;  try {
/* 1195 */       this.curChar = this.input_stream.readChar();
/* 1196 */     } catch (IOException e) {
/* 1197 */       return 3;
/*      */     } 
/* 1199 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1202 */         return jjMoveStringLiteralDfa4_5(active0, 2097152L);
/*      */     } 
/* 1204 */     return 4;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa4_5(long old0, long active0) {
/* 1208 */     if ((active0 &= old0) == 0L)
/* 1209 */       return 4;  try {
/* 1210 */       this.curChar = this.input_stream.readChar();
/* 1211 */     } catch (IOException e) {
/* 1212 */       return 4;
/*      */     } 
/* 1214 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1217 */         if ((active0 & 0x200000L) != 0L) {
/* 1218 */           return jjStopAtPos(4, 21);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1223 */         return 5;
/*      */     } 
/*      */     return 5;
/*      */   } private int jjMoveStringLiteralDfa0_6() {
/* 1227 */     return jjMoveNfa_6(6, 0);
/*      */   }
/*      */   
/*      */   private int jjMoveNfa_6(int startState, int curPos) {
/* 1231 */     int startsAt = 0;
/* 1232 */     this.jjnewStateCnt = 7;
/* 1233 */     int i = 1;
/* 1234 */     this.jjstateSet[0] = startState;
/* 1235 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/* 1238 */       if (++this.jjround == Integer.MAX_VALUE)
/* 1239 */         ReInitRounds(); 
/* 1240 */       if (this.curChar < 64) {
/*      */         
/* 1242 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/* 1245 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 1:
/* 1249 */               if (this.curChar == 61)
/* 1250 */                 jjCheckNAddTwoStates(1, 2); 
/*      */               break;
/*      */             case 3:
/* 1253 */               if (this.curChar == 61)
/* 1254 */                 this.jjstateSet[this.jjnewStateCnt++] = 0; 
/*      */               break;
/*      */             case 4:
/* 1257 */               if (this.curChar == 61)
/* 1258 */                 this.jjstateSet[this.jjnewStateCnt++] = 3; 
/*      */               break;
/*      */             case 5:
/* 1261 */               if (this.curChar == 61) {
/* 1262 */                 this.jjstateSet[this.jjnewStateCnt++] = 4;
/*      */               }
/*      */               break;
/*      */           } 
/* 1266 */         } while (i != startsAt);
/*      */       }
/* 1268 */       else if (this.curChar < 128) {
/*      */         
/* 1270 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1273 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 2:
/* 1276 */               if (this.curChar == 93 && kind > 22)
/* 1277 */                 kind = 22; 
/*      */               break;
/*      */             case 6:
/* 1280 */               if (this.curChar == 93) {
/* 1281 */                 this.jjstateSet[this.jjnewStateCnt++] = 5;
/*      */               }
/*      */               break;
/*      */           } 
/* 1285 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/* 1289 */         int i2 = (this.curChar & 0xFF) >> 6;
/* 1290 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1293 */           switch (this.jjstateSet[--i]) {
/*      */           
/*      */           } 
/*      */         
/* 1297 */         } while (i != startsAt);
/*      */       } 
/* 1299 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/* 1301 */         this.jjmatchedKind = kind;
/* 1302 */         this.jjmatchedPos = curPos;
/* 1303 */         kind = Integer.MAX_VALUE;
/*      */       } 
/* 1305 */       curPos++;
/* 1306 */       i = this.jjnewStateCnt;
/* 1307 */       this.jjnewStateCnt = startsAt;
/* 1308 */       startsAt = 7 - this.jjnewStateCnt;
/* 1309 */       if (i == startsAt)
/* 1310 */         return curPos;  
/* 1311 */       try { this.curChar = this.input_stream.readChar(); }
/* 1312 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*      */   } private int jjMoveStringLiteralDfa0_7() {
/* 1316 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1319 */         return jjMoveStringLiteralDfa1_7(8388608L);
/*      */     } 
/* 1321 */     return 1;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa1_7(long active0) { try {
/* 1325 */       this.curChar = this.input_stream.readChar();
/* 1326 */     } catch (IOException e) {
/* 1327 */       return 1;
/*      */     } 
/* 1329 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1332 */         if ((active0 & 0x800000L) != 0L) {
/* 1333 */           return jjStopAtPos(1, 23);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1338 */         return 2;
/*      */     } 
/*      */     return 2; } private int jjMoveStringLiteralDfa0_8() {
/* 1341 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1344 */         return jjMoveStringLiteralDfa1_8(16777216L);
/*      */     } 
/* 1346 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_8(long active0) {
/*      */     try {
/* 1350 */       this.curChar = this.input_stream.readChar();
/* 1351 */     } catch (IOException e) {
/* 1352 */       return 1;
/*      */     } 
/* 1354 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1357 */         return jjMoveStringLiteralDfa2_8(active0, 16777216L);
/*      */     } 
/* 1359 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_8(long old0, long active0) {
/* 1363 */     if ((active0 &= old0) == 0L)
/* 1364 */       return 2;  try {
/* 1365 */       this.curChar = this.input_stream.readChar();
/* 1366 */     } catch (IOException e) {
/* 1367 */       return 2;
/*      */     } 
/* 1369 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1372 */         if ((active0 & 0x1000000L) != 0L) {
/* 1373 */           return jjStopAtPos(2, 24);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1378 */         return 3;
/*      */     } 
/*      */     return 3; } private int jjMoveStringLiteralDfa0_9() {
/* 1381 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1384 */         return jjMoveStringLiteralDfa1_9(33554432L);
/*      */     } 
/* 1386 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_9(long active0) {
/*      */     try {
/* 1390 */       this.curChar = this.input_stream.readChar();
/* 1391 */     } catch (IOException e) {
/* 1392 */       return 1;
/*      */     } 
/* 1394 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1397 */         return jjMoveStringLiteralDfa2_9(active0, 33554432L);
/*      */     } 
/* 1399 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_9(long old0, long active0) {
/* 1403 */     if ((active0 &= old0) == 0L)
/* 1404 */       return 2;  try {
/* 1405 */       this.curChar = this.input_stream.readChar();
/* 1406 */     } catch (IOException e) {
/* 1407 */       return 2;
/*      */     } 
/* 1409 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1412 */         return jjMoveStringLiteralDfa3_9(active0, 33554432L);
/*      */     } 
/* 1414 */     return 3;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_9(long old0, long active0) {
/* 1418 */     if ((active0 &= old0) == 0L)
/* 1419 */       return 3;  try {
/* 1420 */       this.curChar = this.input_stream.readChar();
/* 1421 */     } catch (IOException e) {
/* 1422 */       return 3;
/*      */     } 
/* 1424 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1427 */         if ((active0 & 0x2000000L) != 0L) {
/* 1428 */           return jjStopAtPos(3, 25);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1433 */         return 4;
/*      */     } 
/*      */     return 4; } private int jjMoveStringLiteralDfa0_10() {
/* 1436 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1439 */         return jjMoveStringLiteralDfa1_10(67108864L);
/*      */     } 
/* 1441 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_10(long active0) {
/*      */     try {
/* 1445 */       this.curChar = this.input_stream.readChar();
/* 1446 */     } catch (IOException e) {
/* 1447 */       return 1;
/*      */     } 
/* 1449 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1452 */         return jjMoveStringLiteralDfa2_10(active0, 67108864L);
/*      */     } 
/* 1454 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_10(long old0, long active0) {
/* 1458 */     if ((active0 &= old0) == 0L)
/* 1459 */       return 2;  try {
/* 1460 */       this.curChar = this.input_stream.readChar();
/* 1461 */     } catch (IOException e) {
/* 1462 */       return 2;
/*      */     } 
/* 1464 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1467 */         return jjMoveStringLiteralDfa3_10(active0, 67108864L);
/*      */     } 
/* 1469 */     return 3;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_10(long old0, long active0) {
/* 1473 */     if ((active0 &= old0) == 0L)
/* 1474 */       return 3;  try {
/* 1475 */       this.curChar = this.input_stream.readChar();
/* 1476 */     } catch (IOException e) {
/* 1477 */       return 3;
/*      */     } 
/* 1479 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1482 */         return jjMoveStringLiteralDfa4_10(active0, 67108864L);
/*      */     } 
/* 1484 */     return 4;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa4_10(long old0, long active0) {
/* 1488 */     if ((active0 &= old0) == 0L)
/* 1489 */       return 4;  try {
/* 1490 */       this.curChar = this.input_stream.readChar();
/* 1491 */     } catch (IOException e) {
/* 1492 */       return 4;
/*      */     } 
/* 1494 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1497 */         if ((active0 & 0x4000000L) != 0L) {
/* 1498 */           return jjStopAtPos(4, 26);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1503 */         return 5;
/*      */     } 
/*      */     return 5;
/*      */   } private int jjMoveStringLiteralDfa0_11() {
/* 1507 */     return jjMoveNfa_11(6, 0);
/*      */   }
/*      */   
/*      */   private int jjMoveNfa_11(int startState, int curPos) {
/* 1511 */     int startsAt = 0;
/* 1512 */     this.jjnewStateCnt = 7;
/* 1513 */     int i = 1;
/* 1514 */     this.jjstateSet[0] = startState;
/* 1515 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/* 1518 */       if (++this.jjround == Integer.MAX_VALUE)
/* 1519 */         ReInitRounds(); 
/* 1520 */       if (this.curChar < 64) {
/*      */         
/* 1522 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/* 1525 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 1:
/* 1529 */               if (this.curChar == 61)
/* 1530 */                 jjCheckNAddTwoStates(1, 2); 
/*      */               break;
/*      */             case 3:
/* 1533 */               if (this.curChar == 61)
/* 1534 */                 this.jjstateSet[this.jjnewStateCnt++] = 0; 
/*      */               break;
/*      */             case 4:
/* 1537 */               if (this.curChar == 61)
/* 1538 */                 this.jjstateSet[this.jjnewStateCnt++] = 3; 
/*      */               break;
/*      */             case 5:
/* 1541 */               if (this.curChar == 61) {
/* 1542 */                 this.jjstateSet[this.jjnewStateCnt++] = 4;
/*      */               }
/*      */               break;
/*      */           } 
/* 1546 */         } while (i != startsAt);
/*      */       }
/* 1548 */       else if (this.curChar < 128) {
/*      */         
/* 1550 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1553 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 2:
/* 1556 */               if (this.curChar == 93 && kind > 27)
/* 1557 */                 kind = 27; 
/*      */               break;
/*      */             case 6:
/* 1560 */               if (this.curChar == 93) {
/* 1561 */                 this.jjstateSet[this.jjnewStateCnt++] = 5;
/*      */               }
/*      */               break;
/*      */           } 
/* 1565 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/* 1569 */         int i2 = (this.curChar & 0xFF) >> 6;
/* 1570 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1573 */           switch (this.jjstateSet[--i]) {
/*      */           
/*      */           } 
/*      */         
/* 1577 */         } while (i != startsAt);
/*      */       } 
/* 1579 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/* 1581 */         this.jjmatchedKind = kind;
/* 1582 */         this.jjmatchedPos = curPos;
/* 1583 */         kind = Integer.MAX_VALUE;
/*      */       } 
/* 1585 */       curPos++;
/* 1586 */       i = this.jjnewStateCnt;
/* 1587 */       this.jjnewStateCnt = startsAt;
/* 1588 */       startsAt = 7 - this.jjnewStateCnt;
/* 1589 */       if (i == startsAt)
/* 1590 */         return curPos;  
/* 1591 */       try { this.curChar = this.input_stream.readChar(); }
/* 1592 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*      */   }
/*      */   
/* 1597 */   public static final String[] jjstrLiteralImages = new String[] { "", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "and", "break", "do", "else", "elseif", "end", "false", "for", "function", "if", "in", "local", "nil", "not", "or", "return", "repeat", "then", "true", "until", "while", null, null, null, null, null, null, null, null, null, null, null, null, null, null, ";", "=", ",", ".", ":", "(", ")", "[", "]", "...", "{", "}", "+", "-", "*", "/", "^", "%", "..", "<", "<=", ">", ">=", "==", "~=", "#" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Token jjFillToken() {
/*      */     String curTokenImage;
/*      */     int beginLine, endLine, beginColumn, endColumn;
/* 1617 */     if (this.jjmatchedPos < 0) {
/*      */       
/* 1619 */       if (this.image == null) {
/* 1620 */         curTokenImage = "";
/*      */       } else {
/* 1622 */         curTokenImage = this.image.toString();
/* 1623 */       }  beginLine = endLine = this.input_stream.getEndLine();
/* 1624 */       beginColumn = endColumn = this.input_stream.getEndColumn();
/*      */     }
/*      */     else {
/*      */       
/* 1628 */       String im = jjstrLiteralImages[this.jjmatchedKind];
/* 1629 */       curTokenImage = (im == null) ? this.input_stream.getImage() : im;
/* 1630 */       beginLine = this.input_stream.getBeginLine();
/* 1631 */       beginColumn = this.input_stream.getBeginColumn();
/* 1632 */       endLine = this.input_stream.getEndLine();
/* 1633 */       endColumn = this.input_stream.getEndColumn();
/*      */     } 
/* 1635 */     Token t = Token.newToken(this.jjmatchedKind);
/* 1636 */     t.kind = this.jjmatchedKind;
/* 1637 */     t.image = curTokenImage;
/*      */     
/* 1639 */     t.beginLine = beginLine;
/* 1640 */     t.endLine = endLine;
/* 1641 */     t.beginColumn = beginColumn;
/* 1642 */     t.endColumn = endColumn;
/*      */     
/* 1644 */     return t;
/*      */   }
/* 1646 */   static final int[] jjnextStates = new int[] { 53, 54, 57, 58, 40, 41, 42, 27, 28, 29, 27, 28, 29, 37, 27, 38, 28, 29, 40, 41, 42, 50, 40, 51, 41, 42, 24, 25, 30, 31, 36, 43, 44, 49, 55, 56, 61, 62, 0, 1, 3 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1652 */   int curLexState = 0;
/* 1653 */   int defaultLexState = 0;
/*      */   
/*      */   int jjnewStateCnt;
/*      */   
/*      */   int jjround;
/*      */   int jjmatchedPos;
/*      */   int jjmatchedKind;
/*      */   
/*      */   public Token getNextToken() {
/* 1662 */     Token specialToken = null;
/*      */     
/* 1664 */     int curPos = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     label125: while (true) {
/*      */       try {
/* 1671 */         this.curChar = this.input_stream.beginToken();
/*      */       }
/* 1673 */       catch (Exception e) {
/*      */         
/* 1675 */         this.jjmatchedKind = 0;
/* 1676 */         this.jjmatchedPos = -1;
/* 1677 */         Token matchedToken = jjFillToken();
/* 1678 */         matchedToken.specialToken = specialToken;
/* 1679 */         return matchedToken;
/*      */       } 
/* 1681 */       this.image = this.jjimage;
/* 1682 */       this.image.setLength(0);
/* 1683 */       this.jjimageLen = 0;
/*      */ 
/*      */       
/*      */       while (true) {
/* 1687 */         switch (this.curLexState) {
/*      */           
/*      */           case 0:
/*      */             try {
/* 1691 */               this.input_stream.backup(0);
/* 1692 */               while (this.curChar <= 32 && (0x100003600L & 1L << this.curChar) != 0L) {
/* 1693 */                 this.curChar = this.input_stream.beginToken();
/*      */               }
/* 1695 */             } catch (IOException e1) {
/*      */               continue label125;
/*      */             } 
/* 1698 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1699 */             this.jjmatchedPos = 0;
/* 1700 */             curPos = jjMoveStringLiteralDfa0_0();
/*      */             break;
/*      */           case 1:
/* 1703 */             this.jjmatchedKind = 17;
/* 1704 */             this.jjmatchedPos = -1;
/* 1705 */             curPos = 0;
/* 1706 */             curPos = jjMoveStringLiteralDfa0_1();
/*      */             break;
/*      */           case 2:
/* 1709 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1710 */             this.jjmatchedPos = 0;
/* 1711 */             curPos = jjMoveStringLiteralDfa0_2();
/* 1712 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1714 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 3:
/* 1718 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1719 */             this.jjmatchedPos = 0;
/* 1720 */             curPos = jjMoveStringLiteralDfa0_3();
/* 1721 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1723 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 4:
/* 1727 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1728 */             this.jjmatchedPos = 0;
/* 1729 */             curPos = jjMoveStringLiteralDfa0_4();
/* 1730 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1732 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 5:
/* 1736 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1737 */             this.jjmatchedPos = 0;
/* 1738 */             curPos = jjMoveStringLiteralDfa0_5();
/* 1739 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1741 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 6:
/* 1745 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1746 */             this.jjmatchedPos = 0;
/* 1747 */             curPos = jjMoveStringLiteralDfa0_6();
/* 1748 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1750 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 7:
/* 1754 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1755 */             this.jjmatchedPos = 0;
/* 1756 */             curPos = jjMoveStringLiteralDfa0_7();
/* 1757 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1759 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 8:
/* 1763 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1764 */             this.jjmatchedPos = 0;
/* 1765 */             curPos = jjMoveStringLiteralDfa0_8();
/* 1766 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1768 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 9:
/* 1772 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1773 */             this.jjmatchedPos = 0;
/* 1774 */             curPos = jjMoveStringLiteralDfa0_9();
/* 1775 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1777 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 10:
/* 1781 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1782 */             this.jjmatchedPos = 0;
/* 1783 */             curPos = jjMoveStringLiteralDfa0_10();
/* 1784 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1786 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 11:
/* 1790 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1791 */             this.jjmatchedPos = 0;
/* 1792 */             curPos = jjMoveStringLiteralDfa0_11();
/* 1793 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1795 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */         } 
/* 1799 */         if (this.jjmatchedKind != Integer.MAX_VALUE)
/*      */         
/* 1801 */         { if (this.jjmatchedPos + 1 < curPos)
/* 1802 */             this.input_stream.backup(curPos - this.jjmatchedPos - 1); 
/* 1803 */           if ((jjtoToken[this.jjmatchedKind >> 6] & 1L << (this.jjmatchedKind & 0x3F)) != 0L) {
/*      */             
/* 1805 */             Token matchedToken = jjFillToken();
/* 1806 */             matchedToken.specialToken = specialToken;
/* 1807 */             if (jjnewLexState[this.jjmatchedKind] != -1)
/* 1808 */               this.curLexState = jjnewLexState[this.jjmatchedKind]; 
/* 1809 */             return matchedToken;
/*      */           } 
/* 1811 */           if ((jjtoSkip[this.jjmatchedKind >> 6] & 1L << (this.jjmatchedKind & 0x3F)) != 0L) {
/*      */             
/* 1813 */             if ((jjtoSpecial[this.jjmatchedKind >> 6] & 1L << (this.jjmatchedKind & 0x3F)) != 0L) {
/*      */               
/* 1815 */               Token matchedToken = jjFillToken();
/* 1816 */               if (specialToken == null) {
/* 1817 */                 specialToken = matchedToken;
/*      */               } else {
/*      */                 
/* 1820 */                 matchedToken.specialToken = specialToken;
/* 1821 */                 specialToken = specialToken.next = matchedToken;
/*      */               } 
/* 1823 */               SkipLexicalActions(matchedToken);
/*      */             } else {
/*      */               
/* 1826 */               SkipLexicalActions(null);
/* 1827 */             }  if (jjnewLexState[this.jjmatchedKind] != -1) {
/* 1828 */               this.curLexState = jjnewLexState[this.jjmatchedKind]; continue label125;
/*      */             }  continue label125;
/*      */           } 
/* 1831 */           this.jjimageLen += this.jjmatchedPos + 1;
/* 1832 */           if (jjnewLexState[this.jjmatchedKind] != -1)
/* 1833 */             this.curLexState = jjnewLexState[this.jjmatchedKind]; 
/* 1834 */           curPos = 0;
/* 1835 */           this.jjmatchedKind = Integer.MAX_VALUE;
/*      */           
/* 1837 */           try { this.curChar = this.input_stream.readChar();
/*      */             
/*      */             continue; }
/* 1840 */           catch (IOException iOException) { break; }  }  break;
/*      */       }  break;
/* 1842 */     }  int error_line = this.input_stream.getEndLine();
/* 1843 */     int error_column = this.input_stream.getEndColumn();
/* 1844 */     String error_after = null;
/* 1845 */     boolean EOFSeen = false;
/*      */     try {
/* 1847 */       this.input_stream.readChar();
/* 1848 */       this.input_stream.backup(1);
/*      */     }
/* 1850 */     catch (IOException e1) {
/* 1851 */       EOFSeen = true;
/* 1852 */       error_after = (curPos <= 1) ? "" : this.input_stream.getImage();
/* 1853 */       if (this.curChar == 10 || this.curChar == 13) {
/* 1854 */         error_line++;
/* 1855 */         error_column = 0;
/*      */       } else {
/*      */         
/* 1858 */         error_column++;
/*      */       } 
/* 1860 */     }  if (!EOFSeen) {
/* 1861 */       this.input_stream.backup(1);
/* 1862 */       error_after = (curPos <= 1) ? "" : this.input_stream.getImage();
/*      */     } 
/* 1864 */     throw new TokenMgrException(EOFSeen, this.curLexState, error_line, error_column, error_after, this.curChar, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void SkipLexicalActions(Token matchedToken) {
/* 1871 */     switch (this.jjmatchedKind) {
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void MoreLexicalActions() {
/* 1879 */     this.jjimageLen += this.lengthOfMatch = this.jjmatchedPos + 1;
/* 1880 */     switch (this.jjmatchedKind) {
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void TokenLexicalActions(Token matchedToken) {
/* 1888 */     switch (this.jjmatchedKind) {
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void jjCheckNAdd(int state) {
/* 1896 */     if (this.jjrounds[state] != this.jjround) {
/*      */       
/* 1898 */       this.jjstateSet[this.jjnewStateCnt++] = state;
/* 1899 */       this.jjrounds[state] = this.jjround;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void jjAddStates(int start, int end) {
/*      */     do {
/* 1905 */       this.jjstateSet[this.jjnewStateCnt++] = jjnextStates[start];
/* 1906 */     } while (start++ != end);
/*      */   }
/*      */   
/*      */   private void jjCheckNAddTwoStates(int state1, int state2) {
/* 1910 */     jjCheckNAdd(state1);
/* 1911 */     jjCheckNAdd(state2);
/*      */   }
/*      */ 
/*      */   
/*      */   private void jjCheckNAddStates(int start, int end) {
/*      */     do {
/* 1917 */       jjCheckNAdd(jjnextStates[start]);
/* 1918 */     } while (start++ != end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ReInit(SimpleCharStream stream) {
/* 1938 */     this.jjmatchedPos = this.jjnewStateCnt = 0;
/*      */ 
/*      */     
/* 1941 */     this.curLexState = this.defaultLexState;
/* 1942 */     this.input_stream = stream;
/* 1943 */     ReInitRounds();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void ReInitRounds() {
/* 1949 */     this.jjround = -2147483647;
/* 1950 */     for (int i = 63; i-- > 0;) {
/* 1951 */       this.jjrounds[i] = Integer.MIN_VALUE;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void ReInit(SimpleCharStream stream, int lexState) {
/* 1957 */     ReInit(stream);
/* 1958 */     SwitchTo(lexState);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void SwitchTo(int lexState) {
/* 1964 */     if (lexState >= 12 || lexState < 0) {
/* 1965 */       throw new TokenMgrException("Error: Ignoring invalid lexical state : " + lexState + ". State unchanged.", 2);
/*      */     }
/* 1967 */     this.curLexState = lexState;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1972 */   public static final String[] lexStateNames = new String[] { "DEFAULT", "IN_COMMENT", "IN_LC0", "IN_LC1", "IN_LC2", "IN_LC3", "IN_LCN", "IN_LS0", "IN_LS1", "IN_LS2", "IN_LS3", "IN_LSN" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1988 */   public static final int[] jjnewLexState = new int[] { -1, -1, -1, -1, -1, -1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1994 */   static final long[] jjtoToken = new long[] { 436849163578114049L, 67108863L };
/*      */ 
/*      */   
/* 1997 */   static final long[] jjtoSkip = new long[] { 8257598L, 0L };
/*      */ 
/*      */   
/* 2000 */   static final long[] jjtoSpecial = new long[] { 8257536L, 0L };
/*      */ 
/*      */   
/* 2003 */   static final long[] jjtoMore = new long[] { 268566464L, 0L };
/*      */   protected SimpleCharStream input_stream; private final int[] jjrounds; private final int[] jjstateSet; private final StringBuilder jjimage; private StringBuilder image; private int jjimageLen;
/*      */   private int lengthOfMatch;
/*      */   protected int curChar;
/*      */   
/* 2008 */   public LuaParserTokenManager(SimpleCharStream stream) { this.jjrounds = new int[63];
/* 2009 */     this.jjstateSet = new int[126];
/* 2010 */     this.jjimage = new StringBuilder();
/* 2011 */     this.image = this.jjimage; this.input_stream = stream; } public LuaParserTokenManager(SimpleCharStream stream, int lexState) { this.jjrounds = new int[63]; this.jjstateSet = new int[126]; this.jjimage = new StringBuilder(); this.image = this.jjimage;
/*      */     ReInit(stream);
/*      */     SwitchTo(lexState); }
/*      */ 
/*      */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\parser\lua51\LuaParserTokenManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */