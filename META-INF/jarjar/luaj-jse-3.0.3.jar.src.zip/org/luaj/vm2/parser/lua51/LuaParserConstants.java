/*     */ package org.luaj.vm2.parser.lua51;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface LuaParserConstants
/*     */ {
/*     */   public static final int EOF = 0;
/*     */   public static final int COMMENT = 17;
/*     */   public static final int LONGCOMMENT0 = 18;
/*     */   public static final int LONGCOMMENT1 = 19;
/*     */   public static final int LONGCOMMENT2 = 20;
/*     */   public static final int LONGCOMMENT3 = 21;
/*     */   public static final int LONGCOMMENTN = 22;
/*     */   public static final int LONGSTRING0 = 23;
/*     */   public static final int LONGSTRING1 = 24;
/*     */   public static final int LONGSTRING2 = 25;
/*     */   public static final int LONGSTRING3 = 26;
/*     */   public static final int LONGSTRINGN = 27;
/*     */   public static final int AND = 29;
/*     */   public static final int BREAK = 30;
/*     */   public static final int DO = 31;
/*     */   public static final int ELSE = 32;
/*     */   public static final int ELSEIF = 33;
/*     */   public static final int END = 34;
/*     */   public static final int FALSE = 35;
/*     */   public static final int FOR = 36;
/*     */   public static final int FUNCTION = 37;
/*     */   public static final int IF = 38;
/*     */   public static final int IN = 39;
/*     */   public static final int LOCAL = 40;
/*     */   public static final int NIL = 41;
/*     */   public static final int NOT = 42;
/*     */   public static final int OR = 43;
/*     */   public static final int RETURN = 44;
/*     */   public static final int REPEAT = 45;
/*     */   public static final int THEN = 46;
/*     */   public static final int TRUE = 47;
/*     */   public static final int UNTIL = 48;
/*     */   public static final int WHILE = 49;
/*     */   public static final int NAME = 50;
/*     */   public static final int NUMBER = 51;
/*     */   public static final int FLOAT = 52;
/*     */   public static final int DIGIT = 53;
/*     */   public static final int EXP = 54;
/*     */   public static final int HEX = 55;
/*     */   public static final int HEXDIGIT = 56;
/*     */   public static final int STRING = 57;
/*     */   public static final int CHARSTRING = 58;
/*     */   public static final int QUOTED = 59;
/*     */   public static final int DECIMAL = 60;
/*     */   public static final int UNICODE = 61;
/*     */   public static final int CHAR = 62;
/*     */   public static final int LF = 63;
/*     */   public static final int DEFAULT = 0;
/*     */   public static final int IN_COMMENT = 1;
/*     */   public static final int IN_LC0 = 2;
/*     */   public static final int IN_LC1 = 3;
/*     */   public static final int IN_LC2 = 4;
/*     */   public static final int IN_LC3 = 5;
/*     */   public static final int IN_LCN = 6;
/*     */   public static final int IN_LS0 = 7;
/*     */   public static final int IN_LS1 = 8;
/*     */   public static final int IN_LS2 = 9;
/*     */   public static final int IN_LS3 = 10;
/*     */   public static final int IN_LSN = 11;
/* 132 */   public static final String[] tokenImage = new String[] { "<EOF>", "\" \"", "\"\\t\"", "\"\\n\"", "\"\\r\"", "\"\\f\"", "\"--[[\"", "\"--[=[\"", "\"--[==[\"", "\"--[===[\"", "<token of kind 10>", "\"[[\"", "\"[=[\"", "\"[==[\"", "\"[===[\"", "<token of kind 15>", "\"--\"", "<COMMENT>", "\"]]\"", "\"]=]\"", "\"]==]\"", "\"]===]\"", "<LONGCOMMENTN>", "\"]]\"", "\"]=]\"", "\"]==]\"", "\"]===]\"", "<LONGSTRINGN>", "<token of kind 28>", "\"and\"", "\"break\"", "\"do\"", "\"else\"", "\"elseif\"", "\"end\"", "\"false\"", "\"for\"", "\"function\"", "\"if\"", "\"in\"", "\"local\"", "\"nil\"", "\"not\"", "\"or\"", "\"return\"", "\"repeat\"", "\"then\"", "\"true\"", "\"until\"", "\"while\"", "<NAME>", "<NUMBER>", "<FLOAT>", "<DIGIT>", "<EXP>", "<HEX>", "<HEXDIGIT>", "<STRING>", "<CHARSTRING>", "<QUOTED>", "<DECIMAL>", "<UNICODE>", "<CHAR>", "<LF>", "\";\"", "\"=\"", "\",\"", "\".\"", "\":\"", "\"(\"", "\")\"", "\"[\"", "\"]\"", "\"...\"", "\"{\"", "\"}\"", "\"+\"", "\"-\"", "\"*\"", "\"/\"", "\"^\"", "\"%\"", "\"..\"", "\"<\"", "\"<=\"", "\">\"", "\">=\"", "\"==\"", "\"~=\"", "\"#\"" };
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\parser\lua51\LuaParserConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */