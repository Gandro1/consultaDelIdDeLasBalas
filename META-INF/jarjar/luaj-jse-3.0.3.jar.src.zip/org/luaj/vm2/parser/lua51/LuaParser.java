/*      */ package org.luaj.vm2.parser.lua51;public class LuaParser implements LuaParserConstants { public static final int VAR = 0; public static final int CALL = 1; public LuaParserTokenManager token_source; SimpleCharStream jj_input_stream; public Token token; public Token jj_nt; private int jj_ntk;
/*      */   private Token jj_scanpos;
/*      */   private Token jj_lastpos;
/*      */   private int jj_la;
/*      */   private final LookaheadSuccess jj_ls;
/*      */   
/*      */   public static void main(String[] args) throws ParseException {
/*    8 */     LuaParser parser = new LuaParser(System.in);
/*    9 */     parser.Chunk();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Chunk() throws ParseException {
/*   17 */     Block();
/*   18 */     jj_consume_token(0);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void Block() throws ParseException {
/*      */     while (true) {
/*   24 */       switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */         case 31:
/*      */         case 36:
/*      */         case 37:
/*      */         case 38:
/*      */         case 40:
/*      */         case 45:
/*      */         case 49:
/*      */         case 50:
/*      */         case 69:
/*      */           break;
/*      */         
/*      */         default:
/*      */           break;
/*      */       } 
/*   39 */       Stat();
/*   40 */       switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */         case 64:
/*   42 */           jj_consume_token(64);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     } 
/*   49 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 30:
/*      */       case 44:
/*   52 */         LastStat();
/*   53 */         switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */           case 64:
/*   55 */             jj_consume_token(64);
/*      */             break;
/*      */         } 
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Stat() throws ParseException {
/*   69 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 31:
/*   71 */         jj_consume_token(31);
/*   72 */         Block();
/*   73 */         jj_consume_token(34);
/*      */         return;
/*      */       
/*      */       case 49:
/*   77 */         jj_consume_token(49);
/*   78 */         Exp();
/*   79 */         jj_consume_token(31);
/*   80 */         Block();
/*   81 */         jj_consume_token(34);
/*      */         return;
/*      */       
/*      */       case 45:
/*   85 */         jj_consume_token(45);
/*   86 */         Block();
/*   87 */         jj_consume_token(48);
/*   88 */         Exp();
/*      */         return;
/*      */       
/*      */       case 38:
/*   92 */         jj_consume_token(38);
/*   93 */         Exp();
/*   94 */         jj_consume_token(46);
/*   95 */         Block();
/*      */         
/*      */         while (true) {
/*   98 */           switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */             case 33:
/*      */               break;
/*      */             
/*      */             default:
/*      */               break;
/*      */           } 
/*  105 */           jj_consume_token(33);
/*  106 */           Exp();
/*  107 */           jj_consume_token(46);
/*  108 */           Block();
/*      */         } 
/*  110 */         switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */           case 32:
/*  112 */             jj_consume_token(32);
/*  113 */             Block();
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  119 */         jj_consume_token(34);
/*      */         return;
/*      */     } 
/*      */     
/*  123 */     if (jj_2_1(3)) {
/*  124 */       jj_consume_token(36);
/*  125 */       jj_consume_token(50);
/*  126 */       jj_consume_token(65);
/*  127 */       Exp();
/*  128 */       jj_consume_token(66);
/*  129 */       Exp();
/*  130 */       switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */         case 66:
/*  132 */           jj_consume_token(66);
/*  133 */           Exp();
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  139 */       jj_consume_token(31);
/*  140 */       Block();
/*  141 */       jj_consume_token(34);
/*      */     } else {
/*  143 */       switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */         case 36:
/*  145 */           jj_consume_token(36);
/*  146 */           NameList();
/*  147 */           jj_consume_token(39);
/*  148 */           ExpList();
/*  149 */           jj_consume_token(31);
/*  150 */           Block();
/*  151 */           jj_consume_token(34);
/*      */           return;
/*      */         
/*      */         case 37:
/*  155 */           jj_consume_token(37);
/*  156 */           FuncName();
/*  157 */           FuncBody();
/*      */           return;
/*      */       } 
/*      */       
/*  161 */       if (jj_2_2(2)) {
/*  162 */         jj_consume_token(40);
/*  163 */         jj_consume_token(37);
/*  164 */         jj_consume_token(50);
/*  165 */         FuncBody();
/*      */       } else {
/*  167 */         switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */           case 40:
/*  169 */             jj_consume_token(40);
/*  170 */             NameList();
/*  171 */             switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */               case 65:
/*  173 */                 jj_consume_token(65);
/*  174 */                 ExpList();
/*      */                 break;
/*      */             } 
/*      */ 
/*      */             
/*      */             return;
/*      */ 
/*      */           
/*      */           case 50:
/*      */           case 69:
/*  184 */             ExprStat();
/*      */             return;
/*      */         } 
/*      */         
/*  188 */         jj_consume_token(-1);
/*  189 */         throw new ParseException();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void LastStat() throws ParseException {
/*  198 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 30:
/*  200 */         jj_consume_token(30);
/*      */         return;
/*      */       
/*      */       case 44:
/*  204 */         jj_consume_token(44);
/*  205 */         switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/*      */           case 27:
/*      */           case 35:
/*      */           case 37:
/*      */           case 41:
/*      */           case 42:
/*      */           case 47:
/*      */           case 50:
/*      */           case 51:
/*      */           case 57:
/*      */           case 58:
/*      */           case 69:
/*      */           case 73:
/*      */           case 74:
/*      */           case 77:
/*      */           case 89:
/*  225 */             ExpList();
/*      */             break;
/*      */         } 
/*      */ 
/*      */         
/*      */         return;
/*      */     } 
/*      */ 
/*      */     
/*  234 */     jj_consume_token(-1);
/*  235 */     throw new ParseException();
/*      */   }
/*      */   
/*      */   public final void ExprStat() throws ParseException {
/*  239 */     int need = 1;
/*  240 */     int type = PrimaryExp();
/*  241 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 65:
/*      */       case 66:
/*  244 */         Assign();
/*  245 */         need = 0;
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  251 */     if (type != need) throw new ParseException("expected function call or assignment");
/*      */   
/*      */   }
/*      */   
/*      */   public final void Assign() throws ParseException {
/*      */     while (true) {
/*  257 */       switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */         case 66:
/*      */           break;
/*      */         
/*      */         default:
/*      */           break;
/*      */       } 
/*  264 */       jj_consume_token(66);
/*  265 */       VarExp();
/*      */     } 
/*  267 */     jj_consume_token(65);
/*  268 */     ExpList();
/*      */   }
/*      */   
/*      */   public final void VarExp() throws ParseException {
/*  272 */     int type = PrimaryExp();
/*  273 */     if (type != 0) throw new ParseException("expected variable expression"); 
/*      */   }
/*      */   
/*      */   public final void FuncName() throws ParseException {
/*  277 */     jj_consume_token(50);
/*      */     
/*      */     while (true) {
/*  280 */       switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */         case 67:
/*      */           break;
/*      */         
/*      */         default:
/*      */           break;
/*      */       } 
/*  287 */       jj_consume_token(67);
/*  288 */       jj_consume_token(50);
/*      */     } 
/*  290 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 68:
/*  292 */         jj_consume_token(68);
/*  293 */         jj_consume_token(50);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void PrefixExp() throws ParseException {
/*  302 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 50:
/*  304 */         jj_consume_token(50);
/*      */         return;
/*      */       
/*      */       case 69:
/*  308 */         ParenExp();
/*      */         return;
/*      */     } 
/*      */     
/*  312 */     jj_consume_token(-1);
/*  313 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void ParenExp() throws ParseException {
/*  318 */     jj_consume_token(69);
/*  319 */     Exp();
/*  320 */     jj_consume_token(70);
/*      */   }
/*      */   public final int PrimaryExp() throws ParseException {
/*  323 */     int type = 0;
/*  324 */     PrefixExp();
/*      */ 
/*      */     
/*  327 */     while (jj_2_3(2))
/*      */     {
/*      */ 
/*      */       
/*  331 */       type = PostfixOp();
/*      */     }
/*  333 */     if ("" != null) return type; 
/*  334 */     throw new IllegalStateException("Missing return statement in function");
/*      */   }
/*      */   
/*      */   public final int PostfixOp() throws ParseException {
/*  338 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 67:
/*      */       case 71:
/*  341 */         FieldOp();
/*  342 */         if ("" != null) return 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  363 */         throw new IllegalStateException("Missing return statement in function");case 23: case 24: case 25: case 26: case 27: case 57: case 58: case 68: case 69: case 74: FuncOp(); if ("" != null) return 1;  throw new IllegalStateException("Missing return statement in function");
/*      */     } 
/*      */     jj_consume_token(-1);
/*      */     throw new ParseException(); } public final void FieldOp() throws ParseException {
/*  367 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 67:
/*  369 */         jj_consume_token(67);
/*  370 */         jj_consume_token(50);
/*      */         return;
/*      */       
/*      */       case 71:
/*  374 */         jj_consume_token(71);
/*  375 */         Exp();
/*  376 */         jj_consume_token(72);
/*      */         return;
/*      */     } 
/*      */     
/*  380 */     jj_consume_token(-1);
/*  381 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void FuncOp() throws ParseException {
/*  386 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 68:
/*  388 */         jj_consume_token(68);
/*  389 */         jj_consume_token(50);
/*  390 */         FuncArgs();
/*      */         return;
/*      */       
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/*      */       case 26:
/*      */       case 27:
/*      */       case 57:
/*      */       case 58:
/*      */       case 69:
/*      */       case 74:
/*  402 */         FuncArgs();
/*      */         return;
/*      */     } 
/*      */     
/*  406 */     jj_consume_token(-1);
/*  407 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void FuncArgs() throws ParseException {
/*  412 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 69:
/*  414 */         jj_consume_token(69);
/*  415 */         switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/*      */           case 27:
/*      */           case 35:
/*      */           case 37:
/*      */           case 41:
/*      */           case 42:
/*      */           case 47:
/*      */           case 50:
/*      */           case 51:
/*      */           case 57:
/*      */           case 58:
/*      */           case 69:
/*      */           case 73:
/*      */           case 74:
/*      */           case 77:
/*      */           case 89:
/*  435 */             ExpList();
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  441 */         jj_consume_token(70);
/*      */         return;
/*      */       
/*      */       case 74:
/*  445 */         TableConstructor();
/*      */         return;
/*      */       
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/*      */       case 26:
/*      */       case 27:
/*      */       case 57:
/*      */       case 58:
/*  455 */         Str();
/*      */         return;
/*      */     } 
/*      */     
/*  459 */     jj_consume_token(-1);
/*  460 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void NameList() throws ParseException {
/*  465 */     jj_consume_token(50);
/*      */ 
/*      */     
/*  468 */     while (jj_2_4(2)) {
/*      */ 
/*      */ 
/*      */       
/*  472 */       jj_consume_token(66);
/*  473 */       jj_consume_token(50);
/*      */     } 
/*      */   }
/*      */   
/*      */   public final void ExpList() throws ParseException {
/*  478 */     Exp();
/*      */     
/*      */     while (true) {
/*  481 */       switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */         case 66:
/*      */           break;
/*      */         
/*      */         default:
/*      */           break;
/*      */       } 
/*  488 */       jj_consume_token(66);
/*  489 */       Exp();
/*      */     } 
/*      */   }
/*      */   
/*      */   public final void SimpleExp() throws ParseException {
/*  494 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 41:
/*  496 */         jj_consume_token(41);
/*      */         return;
/*      */       
/*      */       case 47:
/*  500 */         jj_consume_token(47);
/*      */         return;
/*      */       
/*      */       case 35:
/*  504 */         jj_consume_token(35);
/*      */         return;
/*      */       
/*      */       case 51:
/*  508 */         jj_consume_token(51);
/*      */         return;
/*      */       
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/*      */       case 26:
/*      */       case 27:
/*      */       case 57:
/*      */       case 58:
/*  518 */         Str();
/*      */         return;
/*      */       
/*      */       case 73:
/*  522 */         jj_consume_token(73);
/*      */         return;
/*      */       
/*      */       case 74:
/*  526 */         TableConstructor();
/*      */         return;
/*      */       
/*      */       case 37:
/*  530 */         Function();
/*      */         return;
/*      */       
/*      */       case 50:
/*      */       case 69:
/*  535 */         PrimaryExp();
/*      */         return;
/*      */     } 
/*      */     
/*  539 */     jj_consume_token(-1);
/*  540 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void Str() throws ParseException {
/*  545 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 57:
/*  547 */         jj_consume_token(57);
/*      */         return;
/*      */       
/*      */       case 58:
/*  551 */         jj_consume_token(58);
/*      */         return;
/*      */       
/*      */       case 23:
/*  555 */         jj_consume_token(23);
/*      */         return;
/*      */       
/*      */       case 24:
/*  559 */         jj_consume_token(24);
/*      */         return;
/*      */       
/*      */       case 25:
/*  563 */         jj_consume_token(25);
/*      */         return;
/*      */       
/*      */       case 26:
/*  567 */         jj_consume_token(26);
/*      */         return;
/*      */       
/*      */       case 27:
/*  571 */         jj_consume_token(27);
/*      */         return;
/*      */     } 
/*      */     
/*  575 */     jj_consume_token(-1);
/*  576 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void Exp() throws ParseException {
/*  581 */     SubExp();
/*      */   }
/*      */   
/*      */   public final void SubExp() throws ParseException {
/*  585 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/*      */       case 26:
/*      */       case 27:
/*      */       case 35:
/*      */       case 37:
/*      */       case 41:
/*      */       case 47:
/*      */       case 50:
/*      */       case 51:
/*      */       case 57:
/*      */       case 58:
/*      */       case 69:
/*      */       case 73:
/*      */       case 74:
/*  602 */         SimpleExp();
/*      */         break;
/*      */       
/*      */       case 42:
/*      */       case 77:
/*      */       case 89:
/*  608 */         Unop();
/*  609 */         SubExp();
/*      */         break;
/*      */       
/*      */       default:
/*  613 */         jj_consume_token(-1);
/*  614 */         throw new ParseException();
/*      */     } 
/*      */ 
/*      */     
/*  618 */     while (jj_2_5(2)) {
/*      */ 
/*      */ 
/*      */       
/*  622 */       Binop();
/*  623 */       SubExp();
/*      */     } 
/*      */   }
/*      */   
/*      */   public final void Function() throws ParseException {
/*  628 */     jj_consume_token(37);
/*  629 */     FuncBody();
/*      */   }
/*      */   
/*      */   public final void FuncBody() throws ParseException {
/*  633 */     jj_consume_token(69);
/*  634 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 50:
/*      */       case 73:
/*  637 */         ParList();
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  643 */     jj_consume_token(70);
/*  644 */     Block();
/*  645 */     jj_consume_token(34);
/*      */   }
/*      */   
/*      */   public final void ParList() throws ParseException {
/*  649 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 50:
/*  651 */         NameList();
/*  652 */         switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */           case 66:
/*  654 */             jj_consume_token(66);
/*  655 */             jj_consume_token(73);
/*      */             break;
/*      */         } 
/*      */ 
/*      */         
/*      */         return;
/*      */ 
/*      */       
/*      */       case 73:
/*  664 */         jj_consume_token(73);
/*      */         return;
/*      */     } 
/*      */     
/*  668 */     jj_consume_token(-1);
/*  669 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void TableConstructor() throws ParseException {
/*  674 */     jj_consume_token(74);
/*  675 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/*      */       case 26:
/*      */       case 27:
/*      */       case 35:
/*      */       case 37:
/*      */       case 41:
/*      */       case 42:
/*      */       case 47:
/*      */       case 50:
/*      */       case 51:
/*      */       case 57:
/*      */       case 58:
/*      */       case 69:
/*      */       case 71:
/*      */       case 73:
/*      */       case 74:
/*      */       case 77:
/*      */       case 89:
/*  696 */         FieldList();
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  702 */     jj_consume_token(75);
/*      */   }
/*      */   
/*      */   public final void FieldList() throws ParseException {
/*  706 */     Field();
/*      */ 
/*      */     
/*  709 */     while (jj_2_6(2)) {
/*      */ 
/*      */ 
/*      */       
/*  713 */       FieldSep();
/*  714 */       Field();
/*      */     } 
/*  716 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 64:
/*      */       case 66:
/*  719 */         FieldSep();
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Field() throws ParseException {
/*  728 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 71:
/*  730 */         jj_consume_token(71);
/*  731 */         Exp();
/*  732 */         jj_consume_token(72);
/*  733 */         jj_consume_token(65);
/*  734 */         Exp();
/*      */         return;
/*      */     } 
/*      */     
/*  738 */     if (jj_2_7(2)) {
/*  739 */       jj_consume_token(50);
/*  740 */       jj_consume_token(65);
/*  741 */       Exp();
/*      */     } else {
/*  743 */       switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */         case 23:
/*      */         case 24:
/*      */         case 25:
/*      */         case 26:
/*      */         case 27:
/*      */         case 35:
/*      */         case 37:
/*      */         case 41:
/*      */         case 42:
/*      */         case 47:
/*      */         case 50:
/*      */         case 51:
/*      */         case 57:
/*      */         case 58:
/*      */         case 69:
/*      */         case 73:
/*      */         case 74:
/*      */         case 77:
/*      */         case 89:
/*  763 */           Exp();
/*      */           return;
/*      */       } 
/*      */       
/*  767 */       jj_consume_token(-1);
/*  768 */       throw new ParseException();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void FieldSep() throws ParseException {
/*  775 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 66:
/*  777 */         jj_consume_token(66);
/*      */         return;
/*      */       
/*      */       case 64:
/*  781 */         jj_consume_token(64);
/*      */         return;
/*      */     } 
/*      */     
/*  785 */     jj_consume_token(-1);
/*  786 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void Binop() throws ParseException {
/*  791 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 76:
/*  793 */         jj_consume_token(76);
/*      */         return;
/*      */       
/*      */       case 77:
/*  797 */         jj_consume_token(77);
/*      */         return;
/*      */       
/*      */       case 78:
/*  801 */         jj_consume_token(78);
/*      */         return;
/*      */       
/*      */       case 79:
/*  805 */         jj_consume_token(79);
/*      */         return;
/*      */       
/*      */       case 80:
/*  809 */         jj_consume_token(80);
/*      */         return;
/*      */       
/*      */       case 81:
/*  813 */         jj_consume_token(81);
/*      */         return;
/*      */       
/*      */       case 82:
/*  817 */         jj_consume_token(82);
/*      */         return;
/*      */       
/*      */       case 83:
/*  821 */         jj_consume_token(83);
/*      */         return;
/*      */       
/*      */       case 84:
/*  825 */         jj_consume_token(84);
/*      */         return;
/*      */       
/*      */       case 85:
/*  829 */         jj_consume_token(85);
/*      */         return;
/*      */       
/*      */       case 86:
/*  833 */         jj_consume_token(86);
/*      */         return;
/*      */       
/*      */       case 87:
/*  837 */         jj_consume_token(87);
/*      */         return;
/*      */       
/*      */       case 88:
/*  841 */         jj_consume_token(88);
/*      */         return;
/*      */       
/*      */       case 29:
/*  845 */         jj_consume_token(29);
/*      */         return;
/*      */       
/*      */       case 43:
/*  849 */         jj_consume_token(43);
/*      */         return;
/*      */     } 
/*      */     
/*  853 */     jj_consume_token(-1);
/*  854 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void Unop() throws ParseException {
/*  859 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 77:
/*  861 */         jj_consume_token(77);
/*      */         return;
/*      */       
/*      */       case 42:
/*  865 */         jj_consume_token(42);
/*      */         return;
/*      */       
/*      */       case 89:
/*  869 */         jj_consume_token(89);
/*      */         return;
/*      */     } 
/*      */     
/*  873 */     jj_consume_token(-1);
/*  874 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_2_1(int xla) {
/*  880 */     this.jj_la = xla;
/*  881 */     this.jj_scanpos = this.token;
/*  882 */     this.jj_lastpos = this.token; 
/*  883 */     try { return !jj_3_1(); }
/*  884 */     catch (LookaheadSuccess ls) { return true; }
/*      */   
/*      */   }
/*      */   
/*      */   private boolean jj_2_2(int xla) {
/*  889 */     this.jj_la = xla;
/*  890 */     this.jj_scanpos = this.token;
/*  891 */     this.jj_lastpos = this.token; 
/*  892 */     try { return !jj_3_2(); }
/*  893 */     catch (LookaheadSuccess ls) { return true; }
/*      */   
/*      */   }
/*      */   
/*      */   private boolean jj_2_3(int xla) {
/*  898 */     this.jj_la = xla;
/*  899 */     this.jj_scanpos = this.token;
/*  900 */     this.jj_lastpos = this.token; 
/*  901 */     try { return !jj_3_3(); }
/*  902 */     catch (LookaheadSuccess ls) { return true; }
/*      */   
/*      */   }
/*      */   
/*      */   private boolean jj_2_4(int xla) {
/*  907 */     this.jj_la = xla;
/*  908 */     this.jj_scanpos = this.token;
/*  909 */     this.jj_lastpos = this.token; 
/*  910 */     try { return !jj_3_4(); }
/*  911 */     catch (LookaheadSuccess ls) { return true; }
/*      */   
/*      */   }
/*      */   
/*      */   private boolean jj_2_5(int xla) {
/*  916 */     this.jj_la = xla;
/*  917 */     this.jj_scanpos = this.token;
/*  918 */     this.jj_lastpos = this.token; 
/*  919 */     try { return !jj_3_5(); }
/*  920 */     catch (LookaheadSuccess ls) { return true; }
/*      */   
/*      */   }
/*      */   
/*      */   private boolean jj_2_6(int xla) {
/*  925 */     this.jj_la = xla;
/*  926 */     this.jj_scanpos = this.token;
/*  927 */     this.jj_lastpos = this.token; 
/*  928 */     try { return !jj_3_6(); }
/*  929 */     catch (LookaheadSuccess ls) { return true; }
/*      */   
/*      */   }
/*      */   
/*      */   private boolean jj_2_7(int xla) {
/*  934 */     this.jj_la = xla;
/*  935 */     this.jj_scanpos = this.token;
/*  936 */     this.jj_lastpos = this.token; 
/*  937 */     try { return !jj_3_7(); }
/*  938 */     catch (LookaheadSuccess ls) { return true; }
/*      */   
/*      */   }
/*      */   
/*      */   private boolean jj_3R_45() {
/*  943 */     if (jj_3R_25()) return true; 
/*  944 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3_4() {
/*  949 */     if (jj_scan_token(66)) return true; 
/*  950 */     if (jj_scan_token(50)) return true; 
/*  951 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_23() {
/*  957 */     Token xsp = this.jj_scanpos;
/*  958 */     if (jj_scan_token(41)) {
/*  959 */       this.jj_scanpos = xsp;
/*  960 */       if (jj_scan_token(47)) {
/*  961 */         this.jj_scanpos = xsp;
/*  962 */         if (jj_scan_token(35)) {
/*  963 */           this.jj_scanpos = xsp;
/*  964 */           if (jj_scan_token(51)) {
/*  965 */             this.jj_scanpos = xsp;
/*  966 */             if (jj_3R_30()) {
/*  967 */               this.jj_scanpos = xsp;
/*  968 */               if (jj_scan_token(73)) {
/*  969 */                 this.jj_scanpos = xsp;
/*  970 */                 if (jj_3R_31()) {
/*  971 */                   this.jj_scanpos = xsp;
/*  972 */                   if (jj_3R_32()) {
/*  973 */                     this.jj_scanpos = xsp;
/*  974 */                     if (jj_3R_33()) return true; 
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  983 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_30() {
/*  988 */     if (jj_3R_35()) return true; 
/*  989 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_31() {
/*  994 */     if (jj_3R_36()) return true; 
/*  995 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_32() {
/* 1000 */     if (jj_3R_37()) return true; 
/* 1001 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_33() {
/* 1006 */     if (jj_3R_38()) return true; 
/* 1007 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_35() {
/* 1013 */     Token xsp = this.jj_scanpos;
/* 1014 */     if (jj_scan_token(57)) {
/* 1015 */       this.jj_scanpos = xsp;
/* 1016 */       if (jj_scan_token(58)) {
/* 1017 */         this.jj_scanpos = xsp;
/* 1018 */         if (jj_scan_token(23)) {
/* 1019 */           this.jj_scanpos = xsp;
/* 1020 */           if (jj_scan_token(24)) {
/* 1021 */             this.jj_scanpos = xsp;
/* 1022 */             if (jj_scan_token(25)) {
/* 1023 */               this.jj_scanpos = xsp;
/* 1024 */               if (jj_scan_token(26)) {
/* 1025 */                 this.jj_scanpos = xsp;
/* 1026 */                 if (jj_scan_token(27)) return true; 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1033 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3_1() {
/* 1038 */     if (jj_scan_token(36)) return true; 
/* 1039 */     if (jj_scan_token(50)) return true; 
/* 1040 */     if (jj_scan_token(65)) return true; 
/* 1041 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_25() {
/* 1046 */     if (jj_3R_12()) return true; 
/* 1047 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3_2() {
/* 1052 */     if (jj_scan_token(40)) return true; 
/* 1053 */     if (jj_scan_token(37)) return true; 
/* 1054 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_12() {
/* 1060 */     Token xsp = this.jj_scanpos;
/* 1061 */     if (jj_3R_17()) {
/* 1062 */       this.jj_scanpos = xsp;
/* 1063 */       if (jj_3R_18()) return true; 
/*      */     } 
/* 1065 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_17() {
/* 1070 */     if (jj_3R_23()) return true; 
/* 1071 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_37() {
/* 1076 */     if (jj_scan_token(37)) return true; 
/* 1077 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_18() {
/* 1082 */     if (jj_3R_24()) return true; 
/* 1083 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_36() {
/* 1088 */     if (jj_scan_token(74)) return true;
/*      */     
/* 1090 */     Token xsp = this.jj_scanpos;
/* 1091 */     if (jj_3R_46()) this.jj_scanpos = xsp; 
/* 1092 */     if (jj_scan_token(75)) return true; 
/* 1093 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_46() {
/* 1098 */     if (jj_3R_48()) return true; 
/* 1099 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_48() {
/* 1104 */     if (jj_3R_14()) return true; 
/* 1105 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3_5() {
/* 1110 */     if (jj_3R_11()) return true; 
/* 1111 */     if (jj_3R_12()) return true; 
/* 1112 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_14() {
/* 1118 */     Token xsp = this.jj_scanpos;
/* 1119 */     if (jj_3R_19()) {
/* 1120 */       this.jj_scanpos = xsp;
/* 1121 */       if (jj_3_7()) {
/* 1122 */         this.jj_scanpos = xsp;
/* 1123 */         if (jj_3R_20()) return true; 
/*      */       } 
/*      */     } 
/* 1126 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_19() {
/* 1131 */     if (jj_scan_token(71)) return true; 
/* 1132 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_42() {
/* 1138 */     Token xsp = this.jj_scanpos;
/* 1139 */     if (jj_scan_token(50)) {
/* 1140 */       this.jj_scanpos = xsp;
/* 1141 */       if (jj_3R_44()) return true; 
/*      */     } 
/* 1143 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3_7() {
/* 1148 */     if (jj_scan_token(50)) return true; 
/* 1149 */     if (jj_scan_token(65)) return true; 
/* 1150 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_44() {
/* 1155 */     if (jj_3R_47()) return true; 
/* 1156 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3_6() {
/* 1161 */     if (jj_3R_13()) return true; 
/* 1162 */     if (jj_3R_14()) return true; 
/* 1163 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_20() {
/* 1168 */     if (jj_3R_25()) return true; 
/* 1169 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_47() {
/* 1174 */     if (jj_scan_token(69)) return true; 
/* 1175 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_13() {
/* 1181 */     Token xsp = this.jj_scanpos;
/* 1182 */     if (jj_scan_token(66)) {
/* 1183 */       this.jj_scanpos = xsp;
/* 1184 */       if (jj_scan_token(64)) return true; 
/*      */     } 
/* 1186 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_38() {
/* 1191 */     if (jj_3R_42()) return true; 
/* 1192 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_11() {
/* 1198 */     Token xsp = this.jj_scanpos;
/* 1199 */     if (jj_scan_token(76)) {
/* 1200 */       this.jj_scanpos = xsp;
/* 1201 */       if (jj_scan_token(77)) {
/* 1202 */         this.jj_scanpos = xsp;
/* 1203 */         if (jj_scan_token(78)) {
/* 1204 */           this.jj_scanpos = xsp;
/* 1205 */           if (jj_scan_token(79)) {
/* 1206 */             this.jj_scanpos = xsp;
/* 1207 */             if (jj_scan_token(80)) {
/* 1208 */               this.jj_scanpos = xsp;
/* 1209 */               if (jj_scan_token(81)) {
/* 1210 */                 this.jj_scanpos = xsp;
/* 1211 */                 if (jj_scan_token(82)) {
/* 1212 */                   this.jj_scanpos = xsp;
/* 1213 */                   if (jj_scan_token(83)) {
/* 1214 */                     this.jj_scanpos = xsp;
/* 1215 */                     if (jj_scan_token(84)) {
/* 1216 */                       this.jj_scanpos = xsp;
/* 1217 */                       if (jj_scan_token(85)) {
/* 1218 */                         this.jj_scanpos = xsp;
/* 1219 */                         if (jj_scan_token(86)) {
/* 1220 */                           this.jj_scanpos = xsp;
/* 1221 */                           if (jj_scan_token(87)) {
/* 1222 */                             this.jj_scanpos = xsp;
/* 1223 */                             if (jj_scan_token(88)) {
/* 1224 */                               this.jj_scanpos = xsp;
/* 1225 */                               if (jj_scan_token(29)) {
/* 1226 */                                 this.jj_scanpos = xsp;
/* 1227 */                                 if (jj_scan_token(43)) return true; 
/*      */                               } 
/*      */                             } 
/*      */                           } 
/*      */                         } 
/*      */                       } 
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1242 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_10() {
/* 1248 */     Token xsp = this.jj_scanpos;
/* 1249 */     if (jj_3R_15()) {
/* 1250 */       this.jj_scanpos = xsp;
/* 1251 */       if (jj_3R_16()) return true; 
/*      */     } 
/* 1253 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_15() {
/* 1258 */     if (jj_3R_21()) return true; 
/* 1259 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_24() {
/* 1265 */     Token xsp = this.jj_scanpos;
/* 1266 */     if (jj_scan_token(77)) {
/* 1267 */       this.jj_scanpos = xsp;
/* 1268 */       if (jj_scan_token(42)) {
/* 1269 */         this.jj_scanpos = xsp;
/* 1270 */         if (jj_scan_token(89)) return true; 
/*      */       } 
/*      */     } 
/* 1273 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_16() {
/* 1278 */     if (jj_3R_22()) return true; 
/* 1279 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_21() {
/* 1285 */     Token xsp = this.jj_scanpos;
/* 1286 */     if (jj_3R_26()) {
/* 1287 */       this.jj_scanpos = xsp;
/* 1288 */       if (jj_3R_27()) return true; 
/*      */     } 
/* 1290 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_26() {
/* 1295 */     if (jj_scan_token(67)) return true; 
/* 1296 */     if (jj_scan_token(50)) return true; 
/* 1297 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3_3() {
/* 1302 */     if (jj_3R_10()) return true; 
/* 1303 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_27() {
/* 1308 */     if (jj_scan_token(71)) return true; 
/* 1309 */     if (jj_3R_25()) return true; 
/* 1310 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_22() {
/* 1316 */     Token xsp = this.jj_scanpos;
/* 1317 */     if (jj_3R_28()) {
/* 1318 */       this.jj_scanpos = xsp;
/* 1319 */       if (jj_3R_29()) return true; 
/*      */     } 
/* 1321 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_28() {
/* 1326 */     if (jj_scan_token(68)) return true; 
/* 1327 */     if (jj_scan_token(50)) return true; 
/* 1328 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_29() {
/* 1333 */     if (jj_3R_34()) return true; 
/* 1334 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_34() {
/* 1340 */     Token xsp = this.jj_scanpos;
/* 1341 */     if (jj_3R_39()) {
/* 1342 */       this.jj_scanpos = xsp;
/* 1343 */       if (jj_3R_40()) {
/* 1344 */         this.jj_scanpos = xsp;
/* 1345 */         if (jj_3R_41()) return true; 
/*      */       } 
/*      */     } 
/* 1348 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_39() {
/* 1353 */     if (jj_scan_token(69)) return true;
/*      */     
/* 1355 */     Token xsp = this.jj_scanpos;
/* 1356 */     if (jj_3R_43()) this.jj_scanpos = xsp; 
/* 1357 */     if (jj_scan_token(70)) return true; 
/* 1358 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_40() {
/* 1363 */     if (jj_3R_36()) return true; 
/* 1364 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_41() {
/* 1369 */     if (jj_3R_35()) return true; 
/* 1370 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_43() {
/* 1375 */     if (jj_3R_45()) return true; 
/* 1376 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaParser(InputStream stream) {
/* 1395 */     this(stream, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaParser(InputStream stream, Charset encoding)
/*      */   {
/* 1496 */     this.jj_ls = new LookaheadSuccess(); this.jj_input_stream = new SimpleCharStream(stream, encoding, 1, 1); this.token_source = new LuaParserTokenManager(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; } public void ReInit(InputStream stream) { ReInit(stream, null); } public void ReInit(InputStream stream, Charset encoding) { this.jj_input_stream.reInit(stream, encoding, 1, 1); this.token_source.ReInit(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; } public LuaParser(Reader stream) { this.jj_ls = new LookaheadSuccess(); this.jj_input_stream = new SimpleCharStream(stream, 1, 1); this.token_source = new LuaParserTokenManager(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; } public LuaParser(LuaParserTokenManager tm) { this.jj_ls = new LookaheadSuccess(); this.token_source = tm; this.token = new Token(); this.jj_ntk = -1; }
/*      */   public void ReInit(Reader stream) { if (this.jj_input_stream == null) { this.jj_input_stream = new SimpleCharStream(stream, 1, 1); } else { this.jj_input_stream.reInit(stream, 1, 1); }  if (this.token_source == null) this.token_source = new LuaParserTokenManager(this.jj_input_stream);  this.token_source.ReInit(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; }
/* 1498 */   public void ReInit(LuaParserTokenManager tm) { this.token_source = tm; this.token = new Token(); this.jj_ntk = -1; } private boolean jj_scan_token(int kind) { if (this.jj_scanpos == this.jj_lastpos) {
/* 1499 */       this.jj_la--;
/* 1500 */       if (this.jj_scanpos.next == null) {
/* 1501 */         this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next = this.token_source.getNextToken();
/*      */       } else {
/* 1503 */         this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next;
/*      */       } 
/*      */     } else {
/* 1506 */       this.jj_scanpos = this.jj_scanpos.next;
/*      */     } 
/* 1508 */     if (this.jj_scanpos.kind != kind) return true; 
/* 1509 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) throw this.jj_ls; 
/* 1510 */     return false; } private Token jj_consume_token(int kind) throws ParseException { Token oldToken = this.token; if (this.token.next != null) {
/*      */       this.token = this.token.next;
/*      */     } else {
/*      */       this.token.next = this.token_source.getNextToken(); this.token = this.token.next;
/*      */     }  this.jj_ntk = -1; if (this.token.kind == kind)
/*      */       return this.token;  this.token = oldToken;
/*      */     throw generateParseException(); } private static final class LookaheadSuccess extends IllegalStateException {
/*      */     private LookaheadSuccess() {} }
/* 1518 */   public final Token getNextToken() { if (this.token.next != null) {
/* 1519 */       this.token = this.token.next;
/*      */     } else {
/* 1521 */       this.token = this.token.next = this.token_source.getNextToken();
/* 1522 */     }  this.jj_ntk = -1;
/* 1523 */     return this.token; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Token getToken(int index) {
/* 1531 */     Token t = this.token;
/* 1532 */     for (int i = 0; i < index; i++) {
/* 1533 */       if (t.next == null)
/* 1534 */         t.next = this.token_source.getNextToken(); 
/* 1535 */       t = t.next;
/*      */     } 
/* 1537 */     return t;
/*      */   }
/*      */   
/*      */   private int jj_ntk_f() {
/* 1541 */     this.jj_nt = this.token.next;
/* 1542 */     if (this.jj_nt == null) {
/* 1543 */       this.token.next = this.token_source.getNextToken();
/* 1544 */       this.jj_ntk = this.token.next.kind;
/* 1545 */       return this.jj_ntk;
/*      */     } 
/* 1547 */     this.jj_ntk = this.jj_nt.kind;
/* 1548 */     return this.jj_ntk;
/*      */   }
/*      */ 
/*      */   
/*      */   public ParseException generateParseException() {
/* 1553 */     Token errortok = this.token.next;
/* 1554 */     int line = errortok.beginLine;
/* 1555 */     int column = errortok.beginColumn;
/* 1556 */     String mess = (errortok.kind == 0) ? tokenImage[0] : errortok.image;
/* 1557 */     return new ParseException("Parse error at line " + line + ", column " + column + ".  Encountered: " + mess);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean trace_enabled() {
/* 1564 */     return false;
/*      */   }
/*      */   
/*      */   public final void enable_tracing() {}
/*      */   
/*      */   public final void disable_tracing() {} }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\parser\lua51\LuaParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */