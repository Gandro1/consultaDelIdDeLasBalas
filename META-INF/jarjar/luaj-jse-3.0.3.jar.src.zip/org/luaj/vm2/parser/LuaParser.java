/*      */ package org.luaj.vm2.parser;public class LuaParser implements LuaParserConstants { public LuaParserTokenManager token_source; SimpleCharStream jj_input_stream;
/*      */   public Token token;
/*      */   public Token jj_nt;
/*      */   private int jj_ntk;
/*      */   private Token jj_scanpos;
/*      */   private Token jj_lastpos;
/*      */   private int jj_la;
/*      */   private int jj_gen;
/*      */   
/*   10 */   static { LuaValue.valueOf(true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1773 */     jj_la1_init_0();
/* 1774 */     jj_la1_init_1();
/* 1775 */     jj_la1_init_2(); }
/*      */   public static void main(String[] args) throws ParseException { LuaParser parser = new LuaParser(System.in); parser.Chunk(); }
/*      */   private static Exp.VarExp assertvarexp(Exp.PrimaryExp pe) throws ParseException { if (!pe.isvarexp()) throw new ParseException("expected variable");  return (Exp.VarExp)pe; }
/* 1778 */   private static Exp.FuncCall assertfunccall(Exp.PrimaryExp pe) throws ParseException { if (!pe.isfunccall()) throw new ParseException("expected function call");  return (Exp.FuncCall)pe; } public SimpleCharStream getCharStream() { return this.jj_input_stream; } private long LineInfo() { return this.jj_input_stream.getBeginLine() << 32L | this.jj_input_stream.getBeginColumn(); } private void L(SyntaxElement e, long startinfo) { e.beginLine = (int)(startinfo >> 32L); e.beginColumn = (short)(int)startinfo; e.endLine = this.token.endLine; e.endColumn = (short)this.token.endColumn; } private void L(SyntaxElement e, Token starttoken) { e.beginLine = starttoken.beginLine; e.beginColumn = (short)starttoken.beginColumn; e.endLine = this.token.endLine; e.endColumn = (short)this.token.endColumn; } public final Chunk Chunk() throws ParseException { long i = LineInfo(); switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 69: jj_consume_token(69); this.token_source.SwitchTo(1); break;default: this.jj_la1[0] = this.jj_gen; break; }  Block b = Block(); jj_consume_token(0); Chunk c = new Chunk(b); L((SyntaxElement)c, i); if ("" != null) return c;  throw new IllegalStateException("Missing return statement in function"); } public final Block Block() throws ParseException { Stat s; Block b = new Block(); long i = LineInfo(); while (true) { switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 30: case 31: case 36: case 37: case 38: case 39: case 41: case 46: case 50: case 51: case 65: case 70: case 75: break;default: this.jj_la1[1] = this.jj_gen; break; }  Stat stat = Stat(); b.add(stat); }  switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 45: s = ReturnStat(); b.add(s); break;default: this.jj_la1[2] = this.jj_gen; break; }  L((SyntaxElement)b, i); if ("" != null) return b;  throw new IllegalStateException("Missing return statement in function"); } public final Stat Stat() throws ParseException { Block b; Exp e; Stat s; Token n; Exp e3 = null; List<Exp> el = null; long i = LineInfo(); switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 70: jj_consume_token(70); if ("" != null) return null;  throw new IllegalStateException("Missing return statement in function");case 65: s = Label(); L((SyntaxElement)s, i); if ("" != null) return s;  throw new IllegalStateException("Missing return statement in function");case 30: jj_consume_token(30); s = Stat.breakstat(); L((SyntaxElement)s, i); if ("" != null) return s;  throw new IllegalStateException("Missing return statement in function");case 38: jj_consume_token(38); n = jj_consume_token(51); s = Stat.gotostat(n.image); L((SyntaxElement)s, i); if ("" != null) return s;  throw new IllegalStateException("Missing return statement in function");case 31: jj_consume_token(31); b = Block(); jj_consume_token(34); s = Stat.block(b); L((SyntaxElement)s, i); if ("" != null) return s;  throw new IllegalStateException("Missing return statement in function");case 50: jj_consume_token(50); e = Exp(); jj_consume_token(31); b = Block(); jj_consume_token(34); s = Stat.whiledo(e, b); L((SyntaxElement)s, i); if ("" != null) return s;  throw new IllegalStateException("Missing return statement in function");case 46: jj_consume_token(46); b = Block(); jj_consume_token(49); e = Exp(); s = Stat.repeatuntil(b, e); L((SyntaxElement)s, i); if ("" != null) return s;  throw new IllegalStateException("Missing return statement in function");case 39: s = IfThenElse(); L((SyntaxElement)s, i); if ("" != null) return s;  throw new IllegalStateException("Missing return statement in function"); }  this.jj_la1[5] = this.jj_gen; if (jj_2_1(3)) { jj_consume_token(36); n = jj_consume_token(51); jj_consume_token(71); e = Exp(); jj_consume_token(72); Exp e2 = Exp(); switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 72: jj_consume_token(72); e3 = Exp(); break;default: this.jj_la1[3] = this.jj_gen; break; }  jj_consume_token(31); b = Block(); jj_consume_token(34); s = Stat.fornumeric(n.image, e, e2, e3, b); L((SyntaxElement)s, i); if ("" != null) return s;  } else { FuncName fn; FuncBody fb; List<Name> nl; switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 36: jj_consume_token(36); nl = NameList(); jj_consume_token(40); el = ExpList(); jj_consume_token(31); b = Block(); jj_consume_token(34); s = Stat.forgeneric(nl, el, b); L((SyntaxElement)s, i); if ("" != null) return s;  throw new IllegalStateException("Missing return statement in function");case 37: jj_consume_token(37); fn = FuncName(); fb = FuncBody(); s = Stat.functiondef(fn, fb); L((SyntaxElement)s, i); if ("" != null) return s;  throw new IllegalStateException("Missing return statement in function"); }  this.jj_la1[6] = this.jj_gen; if (jj_2_2(2)) { jj_consume_token(41); jj_consume_token(37); n = jj_consume_token(51); fb = FuncBody(); s = Stat.localfunctiondef(n.image, fb); L((SyntaxElement)s, i); if ("" != null) return s;  } else { switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 41: jj_consume_token(41); nl = NameList(); switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 71: jj_consume_token(71); el = ExpList(); break;default: this.jj_la1[4] = this.jj_gen; break; }  s = Stat.localassignment(nl, el); L((SyntaxElement)s, i); if ("" != null) return s;  throw new IllegalStateException("Missing return statement in function");case 51: case 75: s = ExprStat(); L((SyntaxElement)s, i); if ("" != null) return s;  throw new IllegalStateException("Missing return statement in function"); }  this.jj_la1[7] = this.jj_gen; jj_consume_token(-1); throw new ParseException(); }  }  throw new IllegalStateException("Missing return statement in function"); } public final Stat IfThenElse() throws ParseException { Block b3 = null; List<Exp> el = null; List<Block> bl = null; jj_consume_token(39); Exp e = Exp(); jj_consume_token(47); Block b = Block(); while (true) { switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 33: break;default: this.jj_la1[8] = this.jj_gen; break; }  jj_consume_token(33); Exp e2 = Exp(); jj_consume_token(47); Block b2 = Block(); if (el == null) el = new ArrayList<>();  if (bl == null) bl = new ArrayList<>();  el.add(e2); bl.add(b2); }  switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 32: jj_consume_token(32); b3 = Block(); break;default: this.jj_la1[9] = this.jj_gen; break; }  jj_consume_token(34); if ("" != null) return Stat.ifthenelse(e, b, el, bl, b3);  throw new IllegalStateException("Missing return statement in function"); } public final Stat ReturnStat() throws ParseException { List<Exp> el = null; long i = LineInfo(); jj_consume_token(45); switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 23: case 24: case 25: case 26: case 27: case 35: case 37: case 42: case 43: case 48: case 51: case 52: case 61: case 62: case 69: case 75: case 79: case 80: case 83: el = ExpList(); break;default: this.jj_la1[10] = this.jj_gen; break; }  switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 70: jj_consume_token(70); break;default: this.jj_la1[11] = this.jj_gen; break; }  Stat s = Stat.returnstat(el); L((SyntaxElement)s, i); if ("" != null) return s;  throw new IllegalStateException("Missing return statement in function"); } public final Stat Label() throws ParseException { jj_consume_token(65); Token n = jj_consume_token(51); jj_consume_token(65); if ("" != null) return Stat.labelstat(n.image);  throw new IllegalStateException("Missing return statement in function"); } public final Stat ExprStat() throws ParseException { Stat s = null; long i = LineInfo(); Exp.PrimaryExp p = PrimaryExp(); switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 71: case 72: s = Assign(assertvarexp(p)); break;default: this.jj_la1[12] = this.jj_gen; break; }  if (s == null) s = Stat.functioncall(assertfunccall(p));  L((SyntaxElement)s, i); if ("" != null) return s;  throw new IllegalStateException("Missing return statement in function"); } public final Stat Assign(Exp.VarExp v0) throws ParseException { List<Exp.VarExp> vl = new ArrayList<>(); vl.add(v0); long i = LineInfo(); while (true) { switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 72: break;default: this.jj_la1[13] = this.jj_gen; break; }  jj_consume_token(72); Exp.VarExp ve = VarExp(); vl.add(ve); }  jj_consume_token(71); List<Exp> el = ExpList(); Stat s = Stat.assignment(vl, el); L((SyntaxElement)s, i); if ("" != null) return s;  throw new IllegalStateException("Missing return statement in function"); } public final Exp.VarExp VarExp() throws ParseException { Exp.PrimaryExp p = PrimaryExp(); if ("" != null) return assertvarexp(p);  throw new IllegalStateException("Missing return statement in function"); } public final FuncName FuncName() throws ParseException { Token n = jj_consume_token(51); FuncName f = new FuncName(n.image); while (true) { switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 73: break;default: this.jj_la1[14] = this.jj_gen; break; }  jj_consume_token(73); n = jj_consume_token(51); f.adddot(n.image); }  switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 74: jj_consume_token(74); n = jj_consume_token(51); f.method = n.image; break;default: this.jj_la1[15] = this.jj_gen; break; }  L((SyntaxElement)f, n); if ("" != null) return f;  throw new IllegalStateException("Missing return statement in function"); } public final Exp.PrimaryExp PrefixExp() throws ParseException { Token n; Exp e; Exp.NameExp nameExp; Exp.ParensExp parensExp; long i = LineInfo(); switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 51: n = jj_consume_token(51); nameExp = Exp.nameprefix(n.image); L((SyntaxElement)nameExp, i); if ("" != null) return (Exp.PrimaryExp)nameExp;  throw new IllegalStateException("Missing return statement in function");case 75: jj_consume_token(75); e = Exp(); jj_consume_token(76); parensExp = Exp.parensprefix(e); L((SyntaxElement)parensExp, i); if ("" != null) return (Exp.PrimaryExp)parensExp;  throw new IllegalStateException("Missing return statement in function"); }  this.jj_la1[16] = this.jj_gen; jj_consume_token(-1); throw new ParseException(); } public final Exp.PrimaryExp PrimaryExp() throws ParseException { long i = LineInfo(); Exp.PrimaryExp p = PrefixExp(); while (jj_2_3(2)) p = PostfixOp(p);  L((SyntaxElement)p, i); if ("" != null) return p;  throw new IllegalStateException("Missing return statement in function"); } public final Exp.PrimaryExp PostfixOp(Exp.PrimaryExp lhs) throws ParseException { Token n; Exp e; FuncArgs a; Exp.FieldExp fieldExp; Exp.IndexExp indexExp; Exp.MethodCall methodCall; Exp.FuncCall funcCall; long i = LineInfo(); switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 73: jj_consume_token(73); n = jj_consume_token(51); fieldExp = Exp.fieldop(lhs, n.image); L((SyntaxElement)fieldExp, i); if ("" != null) return (Exp.PrimaryExp)fieldExp;  throw new IllegalStateException("Missing return statement in function");case 77: jj_consume_token(77); e = Exp(); jj_consume_token(78); indexExp = Exp.indexop(lhs, e); L((SyntaxElement)indexExp, i); if ("" != null) return (Exp.PrimaryExp)indexExp;  throw new IllegalStateException("Missing return statement in function");case 74: jj_consume_token(74); n = jj_consume_token(51); a = FuncArgs(); methodCall = Exp.methodop(lhs, n.image, a); L((SyntaxElement)methodCall, i); if ("" != null) return (Exp.PrimaryExp)methodCall;  throw new IllegalStateException("Missing return statement in function");case 23: case 24: case 25: case 26: case 27: case 61: case 62: case 75: case 80: a = FuncArgs(); funcCall = Exp.functionop(lhs, a); L((SyntaxElement)funcCall, i); if ("" != null) return (Exp.PrimaryExp)funcCall;  throw new IllegalStateException("Missing return statement in function"); }  this.jj_la1[17] = this.jj_gen; jj_consume_token(-1); throw new ParseException(); } public final FuncArgs FuncArgs() throws ParseException { TableConstructor tc; LuaString s; FuncArgs a; List<Exp> el = null; long i = LineInfo(); switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 75: jj_consume_token(75); switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 23: case 24: case 25: case 26: case 27: case 35: case 37: case 42: case 43: case 48: case 51: case 52: case 61: case 62: case 69: case 75: case 79: case 80: case 83: el = ExpList(); break;default: this.jj_la1[18] = this.jj_gen; break; }  jj_consume_token(76); a = FuncArgs.explist(el); L((SyntaxElement)a, i); if ("" != null) return a;  throw new IllegalStateException("Missing return statement in function");case 80: tc = TableConstructor(); a = FuncArgs.tableconstructor(tc); L((SyntaxElement)a, i); if ("" != null) return a;  throw new IllegalStateException("Missing return statement in function");case 23: case 24: case 25: case 26: case 27: case 61: case 62: s = Str(); a = FuncArgs.string(s); L((SyntaxElement)a, i); if ("" != null) return a;  throw new IllegalStateException("Missing return statement in function"); }  this.jj_la1[19] = this.jj_gen; jj_consume_token(-1); throw new ParseException(); } public final List<Name> NameList() throws ParseException { List<Name> l = new ArrayList<>(); Token name = jj_consume_token(51); l.add(new Name(name.image)); while (jj_2_4(2)) { jj_consume_token(72); name = jj_consume_token(51); l.add(new Name(name.image)); }  if ("" != null) return l;  throw new IllegalStateException("Missing return statement in function"); } public final List<Exp> ExpList() throws ParseException { List<Exp> l = new ArrayList<>(); Exp e = Exp(); l.add(e); while (true) { switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 72: break;default: this.jj_la1[20] = this.jj_gen; break; }  jj_consume_token(72); e = Exp(); l.add(e); }  if ("" != null) return l;  throw new IllegalStateException("Missing return statement in function"); } public final Exp SimpleExp() throws ParseException { Token n; LuaString s; Exp e; Exp.PrimaryExp primaryExp; TableConstructor c; FuncBody b; long i = LineInfo(); switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 42: jj_consume_token(42); e = Exp.constant(LuaValue.NIL); L((SyntaxElement)e, i); if ("" != null) return e;  throw new IllegalStateException("Missing return statement in function");case 48: jj_consume_token(48); e = Exp.constant((LuaValue)LuaValue.TRUE); L((SyntaxElement)e, i); if ("" != null) return e;  throw new IllegalStateException("Missing return statement in function");case 35: jj_consume_token(35); e = Exp.constant((LuaValue)LuaValue.FALSE); L((SyntaxElement)e, i); if ("" != null) return e;  throw new IllegalStateException("Missing return statement in function");case 52: n = jj_consume_token(52); e = Exp.numberconstant(n.image); L((SyntaxElement)e, i); if ("" != null) return e;  throw new IllegalStateException("Missing return statement in function");case 23: case 24: case 25: case 26: case 27: case 61: case 62: s = Str(); e = Exp.constant((LuaValue)s); L((SyntaxElement)e, i); if ("" != null) return e;  throw new IllegalStateException("Missing return statement in function");case 79: jj_consume_token(79); e = Exp.varargs(); L((SyntaxElement)e, i); if ("" != null) return e;  throw new IllegalStateException("Missing return statement in function");case 80: c = TableConstructor(); e = Exp.tableconstructor(c); L((SyntaxElement)e, i); if ("" != null) return e;  throw new IllegalStateException("Missing return statement in function");case 37: b = FunctionCall(); e = Exp.anonymousfunction(b); L((SyntaxElement)e, i); if ("" != null) return e;  throw new IllegalStateException("Missing return statement in function");case 51: case 75: primaryExp = PrimaryExp(); if ("" != null) return (Exp)primaryExp;  throw new IllegalStateException("Missing return statement in function"); }  this.jj_la1[21] = this.jj_gen; jj_consume_token(-1); throw new ParseException(); } public final LuaString Str() throws ParseException { switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 61: jj_consume_token(61); if ("" != null) return Str.quoteString(this.token.image);  throw new IllegalStateException("Missing return statement in function");case 62: jj_consume_token(62); if ("" != null) return Str.charString(this.token.image);  throw new IllegalStateException("Missing return statement in function");case 23: jj_consume_token(23); if ("" != null) return Str.longString(this.token.image);  throw new IllegalStateException("Missing return statement in function");case 24: jj_consume_token(24); if ("" != null) return Str.longString(this.token.image);  throw new IllegalStateException("Missing return statement in function");case 25: jj_consume_token(25); if ("" != null) return Str.longString(this.token.image);  throw new IllegalStateException("Missing return statement in function");case 26: jj_consume_token(26); if ("" != null) return Str.longString(this.token.image);  throw new IllegalStateException("Missing return statement in function");case 27: jj_consume_token(27); if ("" != null) return Str.longString(this.token.image);  throw new IllegalStateException("Missing return statement in function"); }  this.jj_la1[22] = this.jj_gen; jj_consume_token(-1); throw new ParseException(); } public final Exp Exp() throws ParseException { Exp e, s; int op; long i = LineInfo(); switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 23: case 24: case 25: case 26: case 27: case 35: case 37: case 42: case 48: case 51: case 52: case 61: case 62: case 75: case 79: case 80: e = SimpleExp(); break;case 43: case 69: case 83: op = Unop(); s = Exp(); e = Exp.unaryexp(op, s); break;default: this.jj_la1[23] = this.jj_gen; jj_consume_token(-1); throw new ParseException(); }  while (jj_2_5(2)) { op = Binop(); s = Exp(); e = Exp.binaryexp(e, op, s); }  L((SyntaxElement)e, i); if ("" != null) return e;  throw new IllegalStateException("Missing return statement in function"); } public final FuncBody FunctionCall() throws ParseException { long i = LineInfo(); jj_consume_token(37); FuncBody b = FuncBody(); L((SyntaxElement)b, i); if ("" != null) return b;  throw new IllegalStateException("Missing return statement in function"); } public final FuncBody FuncBody() throws ParseException { ParList pl = null; long i = LineInfo(); jj_consume_token(75); switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 51: case 79: pl = ParList(); break;default: this.jj_la1[24] = this.jj_gen; break; }  jj_consume_token(76); Block b = Block(); jj_consume_token(34); FuncBody f = new FuncBody(pl, b); L((SyntaxElement)f, i); if ("" != null) return f;  throw new IllegalStateException("Missing return statement in function"); } public final ParList ParList() throws ParseException { ParList p; List<Name> l = null; boolean v = false; long i = LineInfo(); switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 51: l = NameList(); switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 72: jj_consume_token(72); jj_consume_token(79); v = true; break;default: this.jj_la1[25] = this.jj_gen; break; }  p = new ParList(l, v); L((SyntaxElement)p, i); if ("" != null) return p;  throw new IllegalStateException("Missing return statement in function");case 79: jj_consume_token(79); p = new ParList(null, true); L((SyntaxElement)p, i); if ("" != null) return p;  throw new IllegalStateException("Missing return statement in function"); }  this.jj_la1[26] = this.jj_gen; jj_consume_token(-1); throw new ParseException(); } public final TableConstructor TableConstructor() throws ParseException { TableConstructor c = new TableConstructor(); List<TableField> l = null; long i = LineInfo(); jj_consume_token(80); switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 23: case 24: case 25: case 26: case 27: case 35: case 37: case 42: case 43: case 48: case 51: case 52: case 61: case 62: case 69: case 75: case 77: case 79: case 80: case 83: l = FieldList(); c.fields = l; break;default: this.jj_la1[27] = this.jj_gen; break; }  jj_consume_token(81); L((SyntaxElement)c, i); if ("" != null) return c;  throw new IllegalStateException("Missing return statement in function"); } public final List<TableField> FieldList() throws ParseException { List<TableField> l = new ArrayList<>(); TableField f = Field(); l.add(f); while (jj_2_6(2)) { FieldSep(); f = Field(); l.add(f); }  switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 70: case 72: FieldSep(); break;default: this.jj_la1[28] = this.jj_gen; break; }  if ("" != null) return l;  throw new IllegalStateException("Missing return statement in function"); } public final TableField Field() throws ParseException { Exp exp, rhs; TableField f; long i = LineInfo(); switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 77: jj_consume_token(77); exp = Exp(); jj_consume_token(78); jj_consume_token(71); rhs = Exp(); f = TableField.keyedField(exp, rhs); L((SyntaxElement)f, i); if ("" != null) return f;  throw new IllegalStateException("Missing return statement in function"); }  this.jj_la1[29] = this.jj_gen; if (jj_2_7(2)) { Token name = jj_consume_token(51); jj_consume_token(71); rhs = Exp(); f = TableField.namedField(name.image, rhs); L((SyntaxElement)f, i); if ("" != null) return f;  } else { switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 23: case 24: case 25: case 26: case 27: case 35: case 37: case 42: case 43: case 48: case 51: case 52: case 61: case 62: case 69: case 75: case 79: case 80: case 83: rhs = Exp(); f = TableField.listField(rhs); L((SyntaxElement)f, i); if ("" != null) return f;  throw new IllegalStateException("Missing return statement in function"); }  this.jj_la1[30] = this.jj_gen; jj_consume_token(-1); throw new ParseException(); }  throw new IllegalStateException("Missing return statement in function"); } public final void FieldSep() throws ParseException { switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 72: jj_consume_token(72); return;case 70: jj_consume_token(70); return; }  this.jj_la1[31] = this.jj_gen; jj_consume_token(-1); throw new ParseException(); } public final int Binop() throws ParseException { switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 82: jj_consume_token(82); if ("" != null) return 13;  throw new IllegalStateException("Missing return statement in function");case 83: jj_consume_token(83); if ("" != null) return 14;  throw new IllegalStateException("Missing return statement in function");case 84: jj_consume_token(84); if ("" != null) return 15;  throw new IllegalStateException("Missing return statement in function");case 85: jj_consume_token(85); if ("" != null) return 16;  throw new IllegalStateException("Missing return statement in function");case 86: jj_consume_token(86); if ("" != null) return 18;  throw new IllegalStateException("Missing return statement in function");case 87: jj_consume_token(87); if ("" != null) return 17;  throw new IllegalStateException("Missing return statement in function");case 88: jj_consume_token(88); if ("" != null) return 22;  throw new IllegalStateException("Missing return statement in function");case 89: jj_consume_token(89); if ("" != null) return 25;  throw new IllegalStateException("Missing return statement in function");case 90: jj_consume_token(90); if ("" != null) return 26;  throw new IllegalStateException("Missing return statement in function");case 91: jj_consume_token(91); if ("" != null) return 63;  throw new IllegalStateException("Missing return statement in function");case 92: jj_consume_token(92); if ("" != null) return 62;  throw new IllegalStateException("Missing return statement in function");case 93: jj_consume_token(93); if ("" != null) return 24;  throw new IllegalStateException("Missing return statement in function");case 94: jj_consume_token(94); if ("" != null) return 61;  throw new IllegalStateException("Missing return statement in function");case 29: jj_consume_token(29); if ("" != null) return 60;  throw new IllegalStateException("Missing return statement in function");case 44: jj_consume_token(44); if ("" != null) return 59;  throw new IllegalStateException("Missing return statement in function"); }  this.jj_la1[32] = this.jj_gen; jj_consume_token(-1); throw new ParseException(); } public final int Unop() throws ParseException { switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) { case 83: jj_consume_token(83); if ("" != null) return 19;  throw new IllegalStateException("Missing return statement in function");case 43: jj_consume_token(43); if ("" != null) return 20;  throw new IllegalStateException("Missing return statement in function");case 69: jj_consume_token(69); if ("" != null) return 21;  throw new IllegalStateException("Missing return statement in function"); }  this.jj_la1[33] = this.jj_gen; jj_consume_token(-1); throw new ParseException(); } private boolean jj_2_1(int xla) { this.jj_la = xla; this.jj_scanpos = this.token; this.jj_lastpos = this.token; try { return !jj_3_1(); } catch (LookaheadSuccess ls) { return true; } finally { jj_save(0, xla); }  } private boolean jj_2_2(int xla) { this.jj_la = xla; this.jj_scanpos = this.token; this.jj_lastpos = this.token; try { return !jj_3_2(); } catch (LookaheadSuccess ls) { return true; } finally { jj_save(1, xla); }  } private boolean jj_2_3(int xla) { this.jj_la = xla; this.jj_scanpos = this.token; this.jj_lastpos = this.token; try { return !jj_3_3(); } catch (LookaheadSuccess ls) { return true; } finally { jj_save(2, xla); }  } private boolean jj_2_4(int xla) { this.jj_la = xla; this.jj_scanpos = this.token; this.jj_lastpos = this.token; try { return !jj_3_4(); } catch (LookaheadSuccess ls) { return true; } finally { jj_save(3, xla); }  } private boolean jj_2_5(int xla) { this.jj_la = xla; this.jj_scanpos = this.token; this.jj_lastpos = this.token; try { return !jj_3_5(); } catch (LookaheadSuccess ls) { return true; } finally { jj_save(4, xla); }  } private boolean jj_2_6(int xla) { this.jj_la = xla; this.jj_scanpos = this.token; this.jj_lastpos = this.token; try { return !jj_3_6(); } catch (LookaheadSuccess ls) { return true; } finally { jj_save(5, xla); }  } private boolean jj_2_7(int xla) { this.jj_la = xla; this.jj_scanpos = this.token; this.jj_lastpos = this.token; try { return !jj_3_7(); } catch (LookaheadSuccess ls) { return true; } finally { jj_save(6, xla); }  } private boolean jj_3R_20() { if (jj_scan_token(83)) return true;  return false; } private boolean jj_3R_21() { if (jj_scan_token(84)) return true;  return false; } private boolean jj_3R_22() { if (jj_scan_token(85)) return true;  return false; } private boolean jj_3R_23() { if (jj_scan_token(86)) return true;  return false; } private boolean jj_3R_24() { if (jj_scan_token(87)) return true;  return false; } private boolean jj_3R_25() { if (jj_scan_token(88)) return true;  return false; } private boolean jj_3R_26() { if (jj_scan_token(89)) return true;  return false; } private boolean jj_3R_61() { if (jj_3R_12()) return true;  return false; } private boolean jj_3R_27() { if (jj_scan_token(90)) return true;  return false; } private boolean jj_3R_28() { if (jj_scan_token(91)) return true;  return false; } private boolean jj_3R_29() { if (jj_scan_token(92)) return true;  return false; } private boolean jj_3R_30() { if (jj_scan_token(93)) return true;  return false; } private boolean jj_3R_31() { if (jj_scan_token(94)) return true;  return false; } private boolean jj_3R_32() { if (jj_scan_token(29)) return true;  return false; } private boolean jj_3R_33() { if (jj_scan_token(44)) return true;  return false; } private boolean jj_3R_40() { Token xsp = this.jj_scanpos; if (jj_3R_53()) { this.jj_scanpos = xsp; if (jj_3R_54()) { this.jj_scanpos = xsp; if (jj_3R_55()) return true;  }  }  return false; } private static void jj_la1_init_0() { jj_la1_0 = new int[] { 0, -1073741824, 0, 0, 0, -1073741824, 0, 0, 0, 0, 260046848, 0, 0, 0, 0, 0, 0, 260046848, 260046848, 260046848, 0, 260046848, 260046848, 260046848, 0, 0, 0, 260046848, 0, 0, 260046848, 0, 536870912, 0 }; }
/*      */   private boolean jj_3R_53() { if (jj_scan_token(83)) return true;  return false; }
/*      */   private boolean jj_3R_39() { Token xsp = this.jj_scanpos; if (jj_3R_44()) { this.jj_scanpos = xsp; if (jj_3R_45()) { this.jj_scanpos = xsp; if (jj_3R_46()) { this.jj_scanpos = xsp; if (jj_3R_47()) { this.jj_scanpos = xsp; if (jj_3R_48()) { this.jj_scanpos = xsp; if (jj_3R_49()) { this.jj_scanpos = xsp; if (jj_3R_50()) { this.jj_scanpos = xsp; if (jj_3R_51()) { this.jj_scanpos = xsp; if (jj_3R_52()) return true;  }  }  }  }  }  }  }  }  return false; }
/* 1781 */   private boolean jj_3R_44() { if (jj_scan_token(42)) return true;  return false; } private boolean jj_3R_54() { if (jj_scan_token(43)) return true;  return false; } private boolean jj_3R_45() { if (jj_scan_token(48)) return true;  return false; } private boolean jj_3R_55() { if (jj_scan_token(69)) return true;  return false; } private boolean jj_3R_46() { if (jj_scan_token(35)) return true;  return false; } private boolean jj_3R_47() { if (jj_scan_token(52)) return true;  return false; } private boolean jj_3R_48() { if (jj_3R_58()) return true;  return false; } private boolean jj_3R_49() { if (jj_scan_token(79)) return true;  return false; } private boolean jj_3R_50() { if (jj_3R_57()) return true;  return false; } private boolean jj_3R_51() { if (jj_3R_59()) return true;  return false; } private boolean jj_3R_52() { if (jj_3R_60()) return true;  return false; } private boolean jj_3R_58() { Token xsp = this.jj_scanpos; if (jj_3R_63()) { this.jj_scanpos = xsp; if (jj_3R_64()) { this.jj_scanpos = xsp; if (jj_3R_65()) { this.jj_scanpos = xsp; if (jj_3R_66()) { this.jj_scanpos = xsp; if (jj_3R_67()) { this.jj_scanpos = xsp; if (jj_3R_68()) { this.jj_scanpos = xsp; if (jj_3R_69()) return true;  }  }  }  }  }  }  return false; } private boolean jj_3R_63() { if (jj_scan_token(61)) return true;  return false; } private boolean jj_3R_64() { if (jj_scan_token(62)) return true;  return false; } private boolean jj_3R_65() { if (jj_scan_token(23)) return true;  return false; } private boolean jj_3R_66() { if (jj_scan_token(24)) return true;  return false; } private boolean jj_3R_67() { if (jj_scan_token(25)) return true;  return false; } private boolean jj_3R_68() { if (jj_scan_token(26)) return true;  return false; } private boolean jj_3R_69() { if (jj_scan_token(27)) return true;  return false; } private boolean jj_3_4() { if (jj_scan_token(72)) return true;  if (jj_scan_token(51)) return true;  return false; } private boolean jj_3R_12() { Token xsp = this.jj_scanpos; if (jj_3R_34()) { this.jj_scanpos = xsp; if (jj_3R_35()) return true;  }  return false; } private boolean jj_3R_34() { if (jj_3R_39()) return true;  return false; } private boolean jj_3_5() { if (jj_3R_11()) return true;  if (jj_3R_12()) return true;  return false; } private boolean jj_3R_59() { if (jj_scan_token(37)) return true;  return false; } private boolean jj_3R_35() { if (jj_3R_40()) return true;  return false; } private boolean jj_3R_70() { Token xsp = this.jj_scanpos; if (jj_3R_72()) { this.jj_scanpos = xsp; if (jj_3R_73()) return true;  }  return false; } private boolean jj_3R_72() { if (jj_scan_token(51)) return true;  return false; } private boolean jj_3R_73() { if (jj_scan_token(75)) return true;  return false; } private boolean jj_3R_60() { if (jj_3R_70()) return true;  return false; } private boolean jj_3R_57() { if (jj_scan_token(80)) return true;  Token xsp = this.jj_scanpos; if (jj_3R_62()) this.jj_scanpos = xsp;  if (jj_scan_token(81)) return true;  return false; } private boolean jj_3R_62() { if (jj_3R_71()) return true;  return false; } private boolean jj_3R_10() { Token xsp = this.jj_scanpos; if (jj_3R_15()) { this.jj_scanpos = xsp; if (jj_3R_16()) { this.jj_scanpos = xsp; if (jj_3R_17()) { this.jj_scanpos = xsp; if (jj_3R_18()) return true;  }  }  }  return false; } private boolean jj_3R_15() { if (jj_scan_token(73)) return true;  if (jj_scan_token(51)) return true;  return false; } private boolean jj_3R_16() { if (jj_scan_token(77)) return true;  if (jj_3R_12()) return true;  return false; } private boolean jj_3R_71() { if (jj_3R_14()) return true;  return false; } private boolean jj_3R_17() { if (jj_scan_token(74)) return true;  if (jj_scan_token(51)) return true;  return false; } private boolean jj_3_3() { if (jj_3R_10()) return true;  return false; } private boolean jj_3R_18() { if (jj_3R_38()) return true;  return false; } private boolean jj_3_1() { if (jj_scan_token(36)) return true;  if (jj_scan_token(51)) return true;  if (jj_scan_token(71)) return true;  return false; } private boolean jj_3_2() { if (jj_scan_token(41)) return true;  if (jj_scan_token(37)) return true;  return false; } private boolean jj_3R_14() { Token xsp = this.jj_scanpos; if (jj_3R_36()) { this.jj_scanpos = xsp; if (jj_3_7()) { this.jj_scanpos = xsp; if (jj_3R_37()) return true;  }  }  return false; } private boolean jj_3R_36() { if (jj_scan_token(77)) return true;  return false; } private boolean jj_3_7() { if (jj_scan_token(51)) return true;  if (jj_scan_token(71)) return true;  return false; } private boolean jj_3R_38() { Token xsp = this.jj_scanpos; if (jj_3R_41()) { this.jj_scanpos = xsp; if (jj_3R_42()) { this.jj_scanpos = xsp; if (jj_3R_43()) return true;  }  }  return false; } private boolean jj_3R_41() { if (jj_scan_token(75)) return true;  Token xsp = this.jj_scanpos; if (jj_3R_56()) this.jj_scanpos = xsp;  if (jj_scan_token(76)) return true;  return false; } private boolean jj_3R_37() { if (jj_3R_12()) return true;  return false; } private boolean jj_3R_42() { if (jj_3R_57()) return true;  return false; } private boolean jj_3R_43() { if (jj_3R_58()) return true;  return false; } private boolean jj_3R_13() { Token xsp = this.jj_scanpos; if (jj_scan_token(72)) { this.jj_scanpos = xsp; if (jj_scan_token(70)) return true;  }  return false; } private boolean jj_3R_56() { if (jj_3R_61()) return true;  return false; } private boolean jj_3_6() { if (jj_3R_13()) return true;  if (jj_3R_14()) return true;  return false; } private boolean jj_3R_11() { Token xsp = this.jj_scanpos; if (jj_3R_19()) { this.jj_scanpos = xsp; if (jj_3R_20()) { this.jj_scanpos = xsp; if (jj_3R_21()) { this.jj_scanpos = xsp; if (jj_3R_22()) { this.jj_scanpos = xsp; if (jj_3R_23()) { this.jj_scanpos = xsp; if (jj_3R_24()) { this.jj_scanpos = xsp; if (jj_3R_25()) { this.jj_scanpos = xsp; if (jj_3R_26()) { this.jj_scanpos = xsp; if (jj_3R_27()) { this.jj_scanpos = xsp; if (jj_3R_28()) { this.jj_scanpos = xsp; if (jj_3R_29()) { this.jj_scanpos = xsp; if (jj_3R_30()) { this.jj_scanpos = xsp; if (jj_3R_31()) { this.jj_scanpos = xsp; if (jj_3R_32()) { this.jj_scanpos = xsp; if (jj_3R_33()) return true;  }  }  }  }  }  }  }  }  }  }  }  }  }  }  return false; } private boolean jj_3R_19() { if (jj_scan_token(82)) return true;  return false; } private final int[] jj_la1 = new int[34]; private static int[] jj_la1_0; private static int[] jj_la1_1; private static int[] jj_la1_2; private static void jj_la1_init_1() { jj_la1_1 = new int[] { 0, 803568, 8192, 0, 0, 278720, 48, 524800, 2, 1, 1612254248, 0, 0, 0, 0, 0, 524288, 1610612736, 1612254248, 1610612736, 0, 1612252200, 1610612736, 1612254248, 524288, 0, 524288, 1612254248, 0, 0, 1612254248, 0, 4096, 2048 }; }
/*      */   
/*      */   private static void jj_la1_init_2() {
/* 1784 */     jj_la1_2 = new int[] { 32, 2114, 0, 256, 128, 66, 0, 2048, 0, 0, 624672, 64, 384, 256, 512, 1024, 2048, 77312, 624672, 67584, 256, 100352, 0, 624672, 32768, 256, 32768, 632864, 320, 8192, 624672, 320, 2147221504, 524320 };
/*      */   }
/* 1786 */   private final JJCalls[] jj_2_rtns = new JJCalls[7];
/*      */   private boolean jj_rescan = false;
/* 1788 */   private int jj_gc = 0; private final LookaheadSuccess jj_ls; private List<int[]> jj_expentries;
/*      */   private int[] jj_expentry;
/*      */   private int jj_kind;
/*      */   private int[] jj_lasttokens;
/*      */   private int jj_endpos;
/*      */   
/*      */   public LuaParser(InputStream stream) {
/* 1795 */     this(stream, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ReInit(InputStream stream) {
/* 1818 */     ReInit(stream, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ReInit(InputStream stream, Charset encoding) {
/* 1826 */     this.jj_input_stream.reInit(stream, encoding, 1, 1);
/* 1827 */     this.token_source.ReInit(this.jj_input_stream);
/* 1828 */     this.token = new Token();
/* 1829 */     this.jj_ntk = -1;
/* 1830 */     this.jj_gen = 0; int i;
/* 1831 */     for (i = 0; i < 34; ) { this.jj_la1[i] = -1; i++; }
/* 1832 */      for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ReInit(Reader stream) {
/* 1856 */     if (this.jj_input_stream == null) {
/* 1857 */       this.jj_input_stream = new SimpleCharStream(stream, 1, 1);
/*      */     } else {
/* 1859 */       this.jj_input_stream.reInit(stream, 1, 1);
/*      */     } 
/* 1861 */     if (this.token_source == null) {
/* 1862 */       this.token_source = new LuaParserTokenManager(this.jj_input_stream);
/*      */     }
/*      */     
/* 1865 */     this.token_source.ReInit(this.jj_input_stream);
/* 1866 */     this.token = new Token();
/* 1867 */     this.jj_ntk = -1;
/* 1868 */     this.jj_gen = 0; int i;
/* 1869 */     for (i = 0; i < 34; i++)
/* 1870 */       this.jj_la1[i] = -1; 
/* 1871 */     for (i = 0; i < this.jj_2_rtns.length; i++) {
/* 1872 */       this.jj_2_rtns[i] = new JJCalls();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ReInit(LuaParserTokenManager tm) {
/* 1893 */     this.token_source = tm;
/* 1894 */     this.token = new Token();
/* 1895 */     this.jj_ntk = -1;
/* 1896 */     this.jj_gen = 0; int i;
/* 1897 */     for (i = 0; i < 34; ) { this.jj_la1[i] = -1; i++; }
/* 1898 */      for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }
/*      */   
/*      */   }
/*      */   private Token jj_consume_token(int kind) throws ParseException {
/* 1902 */     Token oldToken = this.token;
/* 1903 */     if (this.token.next != null) {
/* 1904 */       this.token = this.token.next;
/*      */     } else {
/* 1906 */       this.token.next = this.token_source.getNextToken();
/* 1907 */       this.token = this.token.next;
/*      */     } 
/* 1909 */     this.jj_ntk = -1;
/* 1910 */     if (this.token.kind == kind) {
/* 1911 */       this.jj_gen++;
/* 1912 */       if (++this.jj_gc > 100) {
/* 1913 */         this.jj_gc = 0;
/* 1914 */         for (int i = 0; i < this.jj_2_rtns.length; i++) {
/* 1915 */           JJCalls c = this.jj_2_rtns[i];
/* 1916 */           while (c != null) {
/* 1917 */             if (c.gen < this.jj_gen)
/* 1918 */               c.first = null; 
/* 1919 */             c = c.next;
/*      */           } 
/*      */         } 
/*      */       } 
/* 1923 */       return this.token;
/*      */     } 
/* 1925 */     this.token = oldToken;
/* 1926 */     this.jj_kind = kind;
/* 1927 */     throw generateParseException();
/*      */   }
/*      */   private static final class LookaheadSuccess extends IllegalStateException {
/*      */     private LookaheadSuccess() {} }
/* 1931 */   public LuaParser(InputStream stream, Charset encoding) { this.jj_ls = new LookaheadSuccess();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1992 */     this.jj_expentries = (List)new ArrayList<>();
/*      */     
/* 1994 */     this.jj_kind = -1;
/* 1995 */     this.jj_lasttokens = new int[100]; this.jj_input_stream = new SimpleCharStream(stream, encoding, 1, 1); this.token_source = new LuaParserTokenManager(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; this.jj_gen = 0; int i; for (i = 0; i < 34; ) { this.jj_la1[i] = -1; i++; }  for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }  } public LuaParser(Reader stream) { this.jj_ls = new LookaheadSuccess(); this.jj_expentries = (List)new ArrayList<>(); this.jj_kind = -1; this.jj_lasttokens = new int[100]; this.jj_input_stream = new SimpleCharStream(stream, 1, 1); this.token_source = new LuaParserTokenManager(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; this.jj_gen = 0; int i; for (i = 0; i < 34; i++) this.jj_la1[i] = -1;  for (i = 0; i < this.jj_2_rtns.length; i++) this.jj_2_rtns[i] = new JJCalls();  } public LuaParser(LuaParserTokenManager tm) { this.jj_ls = new LookaheadSuccess(); this.jj_expentries = (List)new ArrayList<>(); this.jj_kind = -1; this.jj_lasttokens = new int[100]; this.token_source = tm; this.token = new Token(); this.jj_ntk = -1; this.jj_gen = 0; int i; for (i = 0; i < 34; ) { this.jj_la1[i] = -1; i++; }  for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }  } private boolean jj_scan_token(int kind) { if (this.jj_scanpos == this.jj_lastpos) { this.jj_la--; if (this.jj_scanpos.next == null) { this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next = this.token_source.getNextToken(); } else { this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next; }  } else { this.jj_scanpos = this.jj_scanpos.next; }  if (this.jj_rescan) { int i = 0; Token tok = this.token; while (tok != null && tok != this.jj_scanpos) { i++; tok = tok.next; }  if (tok != null) jj_add_error_token(kind, i);  }  if (this.jj_scanpos.kind != kind) return true;  if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) throw this.jj_ls;  return false; }
/*      */   public final Token getNextToken() { if (this.token.next != null) { this.token = this.token.next; } else { this.token = this.token.next = this.token_source.getNextToken(); }  this.jj_ntk = -1; this.jj_gen++; return this.token; }
/*      */   public final Token getToken(int index) { Token t = this.token; for (int i = 0; i < index; i++) { if (t.next == null) t.next = this.token_source.getNextToken();  t = t.next; }  return t; }
/*      */   private int jj_ntk_f() { this.jj_nt = this.token.next; if (this.jj_nt == null) { this.token.next = this.token_source.getNextToken(); this.jj_ntk = this.token.next.kind; return this.jj_ntk; }  this.jj_ntk = this.jj_nt.kind; return this.jj_ntk; }
/* 1999 */   private void jj_add_error_token(int kind, int pos) { if (pos >= 100) {
/*      */       return;
/*      */     }
/*      */     
/* 2003 */     if (pos == this.jj_endpos + 1) {
/* 2004 */       this.jj_lasttokens[this.jj_endpos++] = kind;
/* 2005 */     } else if (this.jj_endpos != 0) {
/* 2006 */       this.jj_expentry = new int[this.jj_endpos];
/*      */       
/* 2008 */       for (int i = 0; i < this.jj_endpos; i++) {
/* 2009 */         this.jj_expentry[i] = this.jj_lasttokens[i];
/*      */       }
/*      */       
/* 2012 */       for (int[] oldentry : this.jj_expentries) {
/* 2013 */         if (oldentry.length == this.jj_expentry.length) {
/* 2014 */           boolean isMatched = true;
/* 2015 */           for (int j = 0; j < this.jj_expentry.length; j++) {
/* 2016 */             if (oldentry[j] != this.jj_expentry[j]) {
/* 2017 */               isMatched = false;
/*      */               break;
/*      */             } 
/*      */           } 
/* 2021 */           if (isMatched) {
/* 2022 */             this.jj_expentries.add(this.jj_expentry);
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/* 2028 */       if (pos != 0) {
/* 2029 */         this.jj_endpos = pos;
/* 2030 */         this.jj_lasttokens[this.jj_endpos - 1] = kind;
/*      */       } 
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ParseException generateParseException() {
/* 2040 */     this.jj_expentries.clear();
/* 2041 */     boolean[] la1tokens = new boolean[95];
/* 2042 */     if (this.jj_kind >= 0) {
/* 2043 */       la1tokens[this.jj_kind] = true;
/* 2044 */       this.jj_kind = -1;
/*      */     }  int i;
/* 2046 */     for (i = 0; i < 34; i++) {
/* 2047 */       if (this.jj_la1[i] == this.jj_gen) {
/* 2048 */         for (int k = 0; k < 32; k++) {
/* 2049 */           if ((jj_la1_0[i] & 1 << k) != 0) {
/* 2050 */             la1tokens[k] = true;
/*      */           }
/* 2052 */           if ((jj_la1_1[i] & 1 << k) != 0) {
/* 2053 */             la1tokens[32 + k] = true;
/*      */           }
/* 2055 */           if ((jj_la1_2[i] & 1 << k) != 0) {
/* 2056 */             la1tokens[64 + k] = true;
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/* 2061 */     for (i = 0; i < 95; i++) {
/* 2062 */       if (la1tokens[i]) {
/* 2063 */         this.jj_expentry = new int[1];
/* 2064 */         this.jj_expentry[0] = i;
/* 2065 */         this.jj_expentries.add(this.jj_expentry);
/*      */       } 
/*      */     } 
/* 2068 */     this.jj_endpos = 0;
/* 2069 */     jj_rescan_token();
/* 2070 */     jj_add_error_token(0, 0);
/* 2071 */     int[][] exptokseq = new int[this.jj_expentries.size()][];
/* 2072 */     for (int j = 0; j < this.jj_expentries.size(); j++) {
/* 2073 */       exptokseq[j] = this.jj_expentries.get(j);
/*      */     }
/* 2075 */     return new ParseException(this.token, exptokseq, tokenImage);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean trace_enabled() {
/* 2082 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void enable_tracing() {}
/*      */ 
/*      */   
/*      */   public final void disable_tracing() {}
/*      */   
/*      */   private void jj_rescan_token() {
/* 2092 */     this.jj_rescan = true;
/* 2093 */     for (int i = 0; i < 7; i++) {
/*      */       try {
/* 2095 */         JJCalls p = this.jj_2_rtns[i];
/*      */         do {
/* 2097 */           if (p.gen > this.jj_gen) {
/* 2098 */             this.jj_la = p.arg;
/* 2099 */             this.jj_scanpos = p.first;
/* 2100 */             this.jj_lastpos = p.first;
/* 2101 */             switch (i) { case 0:
/* 2102 */                 jj_3_1(); break;
/* 2103 */               case 1: jj_3_2(); break;
/* 2104 */               case 2: jj_3_3(); break;
/* 2105 */               case 3: jj_3_4(); break;
/* 2106 */               case 4: jj_3_5(); break;
/* 2107 */               case 5: jj_3_6(); break;
/* 2108 */               case 6: jj_3_7(); break; }
/*      */           
/*      */           } 
/* 2111 */           p = p.next;
/* 2112 */         } while (p != null);
/* 2113 */       } catch (LookaheadSuccess lookaheadSuccess) {}
/*      */     } 
/* 2115 */     this.jj_rescan = false;
/*      */   }
/*      */   
/*      */   private void jj_save(int index, int xla) {
/* 2119 */     JJCalls p = this.jj_2_rtns[index];
/* 2120 */     while (p.gen > this.jj_gen) {
/* 2121 */       if (p.next == null) {
/* 2122 */         p.next = new JJCalls();
/* 2123 */         p = p.next;
/*      */         break;
/*      */       } 
/* 2126 */       p = p.next;
/*      */     } 
/* 2128 */     p.gen = this.jj_gen + xla - this.jj_la;
/* 2129 */     p.first = this.token;
/* 2130 */     p.arg = xla;
/*      */   }
/*      */   
/*      */   static final class JJCalls {
/*      */     int gen;
/*      */     Token first;
/*      */     int arg;
/*      */     JJCalls next;
/*      */   } }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\parser\LuaParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */