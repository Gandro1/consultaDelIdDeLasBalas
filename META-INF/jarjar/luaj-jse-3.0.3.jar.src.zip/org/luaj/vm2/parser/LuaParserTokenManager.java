/*      */ package org.luaj.vm2.parser;
/*      */ 
/*      */ import java.io.IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LuaParserTokenManager
/*      */   implements LuaParserConstants
/*      */ {
/*      */   private final int jjStopStringLiteralDfa_0(int pos, long active0, long active1) {
/*   12 */     switch (pos) {
/*      */       
/*      */       case 0:
/*   15 */         if ((active0 & 0x7800L) != 0L || (active1 & 0x2000L) != 0L)
/*   16 */           return 14; 
/*   17 */         if ((active0 & 0x103C0L) != 0L || (active1 & 0x80000L) != 0L)
/*   18 */           return 7; 
/*   19 */         if ((active0 & 0x7FFFFE0000000L) != 0L) {
/*      */           
/*   21 */           this.jjmatchedKind = 51;
/*   22 */           return 17;
/*      */         } 
/*   24 */         if ((active1 & 0x1008200L) != 0L)
/*   25 */           return 31; 
/*   26 */         return -1;
/*      */       case 1:
/*   28 */         if ((active0 & 0x118080000000L) != 0L)
/*   29 */           return 17; 
/*   30 */         if ((active0 & 0x103C0L) != 0L)
/*   31 */           return 6; 
/*   32 */         if ((active0 & 0x7000L) != 0L)
/*   33 */           return 13; 
/*   34 */         if ((active0 & 0x7EE7F60000000L) != 0L) {
/*      */           
/*   36 */           if (this.jjmatchedPos != 1) {
/*      */             
/*   38 */             this.jjmatchedKind = 51;
/*   39 */             this.jjmatchedPos = 1;
/*      */           } 
/*   41 */           return 17;
/*      */         } 
/*   43 */         return -1;
/*      */       case 2:
/*   45 */         if ((active0 & 0x7E26B40000000L) != 0L) {
/*      */           
/*   47 */           this.jjmatchedKind = 51;
/*   48 */           this.jjmatchedPos = 2;
/*   49 */           return 17;
/*      */         } 
/*   51 */         if ((active0 & 0xC1420000000L) != 0L)
/*   52 */           return 17; 
/*   53 */         if ((active0 & 0x3C0L) != 0L)
/*   54 */           return 5; 
/*   55 */         if ((active0 & 0x6000L) != 0L)
/*   56 */           return 12; 
/*   57 */         return -1;
/*      */       case 3:
/*   59 */         if ((active0 & 0x4000L) != 0L)
/*   60 */           return 9; 
/*   61 */         if ((active0 & 0x380L) != 0L)
/*   62 */           return 4; 
/*   63 */         if ((active0 & 0x1804300000000L) != 0L)
/*   64 */           return 17; 
/*   65 */         if ((active0 & 0x6622840000000L) != 0L) {
/*      */           
/*   67 */           if (this.jjmatchedPos != 3) {
/*      */             
/*   69 */             this.jjmatchedKind = 51;
/*   70 */             this.jjmatchedPos = 3;
/*      */           } 
/*   72 */           return 17;
/*      */         } 
/*   74 */         return -1;
/*      */       case 4:
/*   76 */         if ((active0 & 0x300L) != 0L)
/*   77 */           return 3; 
/*   78 */         if ((active0 & 0x6020840000000L) != 0L)
/*   79 */           return 17; 
/*   80 */         if ((active0 & 0x602200000000L) != 0L) {
/*      */           
/*   82 */           this.jjmatchedKind = 51;
/*   83 */           this.jjmatchedPos = 4;
/*   84 */           return 17;
/*      */         } 
/*   86 */         return -1;
/*      */       case 5:
/*   88 */         if ((active0 & 0x600200000000L) != 0L)
/*   89 */           return 17; 
/*   90 */         if ((active0 & 0x2000000000L) != 0L) {
/*      */           
/*   92 */           this.jjmatchedKind = 51;
/*   93 */           this.jjmatchedPos = 5;
/*   94 */           return 17;
/*      */         } 
/*   96 */         if ((active0 & 0x200L) != 0L)
/*   97 */           return 0; 
/*   98 */         return -1;
/*      */       case 6:
/*  100 */         if ((active0 & 0x2000000000L) != 0L) {
/*      */           
/*  102 */           this.jjmatchedKind = 51;
/*  103 */           this.jjmatchedPos = 6;
/*  104 */           return 17;
/*      */         } 
/*  106 */         return -1;
/*      */     } 
/*  108 */     return -1;
/*      */   }
/*      */   
/*      */   private final int jjStartNfa_0(int pos, long active0, long active1) {
/*  112 */     return jjMoveNfa_0(jjStopStringLiteralDfa_0(pos, active0, active1), pos + 1);
/*      */   }
/*      */   
/*      */   private int jjStopAtPos(int pos, int kind) {
/*  116 */     this.jjmatchedKind = kind;
/*  117 */     this.jjmatchedPos = pos;
/*  118 */     return pos + 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa0_0() {
/*  121 */     switch (this.curChar) {
/*      */       
/*      */       case 35:
/*  124 */         return jjStopAtPos(0, 69);
/*      */       case 37:
/*  126 */         return jjStopAtPos(0, 87);
/*      */       case 40:
/*  128 */         return jjStopAtPos(0, 75);
/*      */       case 41:
/*  130 */         return jjStopAtPos(0, 76);
/*      */       case 42:
/*  132 */         return jjStopAtPos(0, 84);
/*      */       case 43:
/*  134 */         return jjStopAtPos(0, 82);
/*      */       case 44:
/*  136 */         return jjStopAtPos(0, 72);
/*      */       case 45:
/*  138 */         this.jjmatchedKind = 83;
/*  139 */         return jjMoveStringLiteralDfa1_0(66496L, 0L);
/*      */       case 46:
/*  141 */         this.jjmatchedKind = 73;
/*  142 */         return jjMoveStringLiteralDfa1_0(0L, 16809984L);
/*      */       case 47:
/*  144 */         return jjStopAtPos(0, 85);
/*      */       case 58:
/*  146 */         this.jjmatchedKind = 74;
/*  147 */         return jjMoveStringLiteralDfa1_0(0L, 2L);
/*      */       case 59:
/*  149 */         return jjStopAtPos(0, 70);
/*      */       case 60:
/*  151 */         this.jjmatchedKind = 89;
/*  152 */         return jjMoveStringLiteralDfa1_0(0L, 67108864L);
/*      */       case 61:
/*  154 */         this.jjmatchedKind = 71;
/*  155 */         return jjMoveStringLiteralDfa1_0(0L, 536870912L);
/*      */       case 62:
/*  157 */         this.jjmatchedKind = 91;
/*  158 */         return jjMoveStringLiteralDfa1_0(0L, 268435456L);
/*      */       case 91:
/*  160 */         this.jjmatchedKind = 77;
/*  161 */         return jjMoveStringLiteralDfa1_0(30720L, 0L);
/*      */       case 93:
/*  163 */         return jjStopAtPos(0, 78);
/*      */       case 94:
/*  165 */         return jjStopAtPos(0, 86);
/*      */       case 97:
/*  167 */         return jjMoveStringLiteralDfa1_0(536870912L, 0L);
/*      */       case 98:
/*  169 */         return jjMoveStringLiteralDfa1_0(1073741824L, 0L);
/*      */       case 100:
/*  171 */         return jjMoveStringLiteralDfa1_0(2147483648L, 0L);
/*      */       case 101:
/*  173 */         return jjMoveStringLiteralDfa1_0(30064771072L, 0L);
/*      */       case 102:
/*  175 */         return jjMoveStringLiteralDfa1_0(240518168576L, 0L);
/*      */       case 103:
/*  177 */         return jjMoveStringLiteralDfa1_0(274877906944L, 0L);
/*      */       case 105:
/*  179 */         return jjMoveStringLiteralDfa1_0(1649267441664L, 0L);
/*      */       case 108:
/*  181 */         return jjMoveStringLiteralDfa1_0(2199023255552L, 0L);
/*      */       case 110:
/*  183 */         return jjMoveStringLiteralDfa1_0(13194139533312L, 0L);
/*      */       case 111:
/*  185 */         return jjMoveStringLiteralDfa1_0(17592186044416L, 0L);
/*      */       case 114:
/*  187 */         return jjMoveStringLiteralDfa1_0(105553116266496L, 0L);
/*      */       case 116:
/*  189 */         return jjMoveStringLiteralDfa1_0(422212465065984L, 0L);
/*      */       case 117:
/*  191 */         return jjMoveStringLiteralDfa1_0(562949953421312L, 0L);
/*      */       case 119:
/*  193 */         return jjMoveStringLiteralDfa1_0(1125899906842624L, 0L);
/*      */       case 123:
/*  195 */         return jjStopAtPos(0, 80);
/*      */       case 125:
/*  197 */         return jjStopAtPos(0, 81);
/*      */       case 126:
/*  199 */         return jjMoveStringLiteralDfa1_0(0L, 1073741824L);
/*      */     } 
/*  201 */     return jjMoveNfa_0(8, 0);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_0(long active0, long active1) {
/*      */     try {
/*  205 */       this.curChar = this.input_stream.readChar();
/*  206 */     } catch (IOException e) {
/*  207 */       jjStopStringLiteralDfa_0(0, active0, active1);
/*  208 */       return 1;
/*      */     } 
/*  210 */     switch (this.curChar) {
/*      */       
/*      */       case 45:
/*  213 */         if ((active0 & 0x10000L) != 0L) {
/*      */           
/*  215 */           this.jjmatchedKind = 16;
/*  216 */           this.jjmatchedPos = 1;
/*      */         } 
/*  218 */         return jjMoveStringLiteralDfa2_0(active0, 960L, active1, 0L);
/*      */       case 46:
/*  220 */         if ((active1 & 0x1000000L) != 0L) {
/*      */           
/*  222 */           this.jjmatchedKind = 88;
/*  223 */           this.jjmatchedPos = 1;
/*      */         } 
/*  225 */         return jjMoveStringLiteralDfa2_0(active0, 0L, active1, 32768L);
/*      */       case 58:
/*  227 */         if ((active1 & 0x2L) != 0L)
/*  228 */           return jjStopAtPos(1, 65); 
/*      */         break;
/*      */       case 61:
/*  231 */         if ((active1 & 0x4000000L) != 0L)
/*  232 */           return jjStopAtPos(1, 90); 
/*  233 */         if ((active1 & 0x10000000L) != 0L)
/*  234 */           return jjStopAtPos(1, 92); 
/*  235 */         if ((active1 & 0x20000000L) != 0L)
/*  236 */           return jjStopAtPos(1, 93); 
/*  237 */         if ((active1 & 0x40000000L) != 0L)
/*  238 */           return jjStopAtPos(1, 94); 
/*  239 */         return jjMoveStringLiteralDfa2_0(active0, 28672L, active1, 0L);
/*      */       case 91:
/*  241 */         if ((active0 & 0x800L) != 0L)
/*  242 */           return jjStopAtPos(1, 11); 
/*      */         break;
/*      */       case 97:
/*  245 */         return jjMoveStringLiteralDfa2_0(active0, 34359738368L, active1, 0L);
/*      */       case 101:
/*  247 */         return jjMoveStringLiteralDfa2_0(active0, 105553116266496L, active1, 0L);
/*      */       case 102:
/*  249 */         if ((active0 & 0x8000000000L) != 0L)
/*  250 */           return jjStartNfaWithStates_0(1, 39, 17); 
/*      */         break;
/*      */       case 104:
/*  253 */         return jjMoveStringLiteralDfa2_0(active0, 1266637395197952L, active1, 0L);
/*      */       case 105:
/*  255 */         return jjMoveStringLiteralDfa2_0(active0, 4398046511104L, active1, 0L);
/*      */       case 108:
/*  257 */         return jjMoveStringLiteralDfa2_0(active0, 12884901888L, active1, 0L);
/*      */       case 110:
/*  259 */         if ((active0 & 0x10000000000L) != 0L)
/*  260 */           return jjStartNfaWithStates_0(1, 40, 17); 
/*  261 */         return jjMoveStringLiteralDfa2_0(active0, 562967670161408L, active1, 0L);
/*      */       case 111:
/*  263 */         if ((active0 & 0x80000000L) != 0L)
/*  264 */           return jjStartNfaWithStates_0(1, 31, 17); 
/*  265 */         return jjMoveStringLiteralDfa2_0(active0, 11338713661440L, active1, 0L);
/*      */       case 114:
/*  267 */         if ((active0 & 0x100000000000L) != 0L)
/*  268 */           return jjStartNfaWithStates_0(1, 44, 17); 
/*  269 */         return jjMoveStringLiteralDfa2_0(active0, 281476050452480L, active1, 0L);
/*      */       case 117:
/*  271 */         return jjMoveStringLiteralDfa2_0(active0, 137438953472L, active1, 0L);
/*      */     } 
/*      */ 
/*      */     
/*  275 */     return jjStartNfa_0(0, active0, active1);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa2_0(long old0, long active0, long old1, long active1) {
/*  278 */     if (((active0 &= old0) | (active1 &= old1)) == 0L)
/*  279 */       return jjStartNfa_0(0, old0, old1);  try {
/*  280 */       this.curChar = this.input_stream.readChar();
/*  281 */     } catch (IOException e) {
/*  282 */       jjStopStringLiteralDfa_0(1, active0, active1);
/*  283 */       return 2;
/*      */     } 
/*  285 */     switch (this.curChar) {
/*      */       
/*      */       case 46:
/*  288 */         if ((active1 & 0x8000L) != 0L)
/*  289 */           return jjStopAtPos(2, 79); 
/*      */         break;
/*      */       case 61:
/*  292 */         return jjMoveStringLiteralDfa3_0(active0, 24576L, active1, 0L);
/*      */       case 91:
/*  294 */         if ((active0 & 0x1000L) != 0L)
/*  295 */           return jjStopAtPos(2, 12); 
/*  296 */         return jjMoveStringLiteralDfa3_0(active0, 960L, active1, 0L);
/*      */       case 99:
/*  298 */         return jjMoveStringLiteralDfa3_0(active0, 2199023255552L, active1, 0L);
/*      */       case 100:
/*  300 */         if ((active0 & 0x20000000L) != 0L)
/*  301 */           return jjStartNfaWithStates_0(2, 29, 17); 
/*  302 */         if ((active0 & 0x400000000L) != 0L)
/*  303 */           return jjStartNfaWithStates_0(2, 34, 17); 
/*      */         break;
/*      */       case 101:
/*  306 */         return jjMoveStringLiteralDfa3_0(active0, 140738562097152L, active1, 0L);
/*      */       case 105:
/*  308 */         return jjMoveStringLiteralDfa3_0(active0, 1125899906842624L, active1, 0L);
/*      */       case 108:
/*  310 */         if ((active0 & 0x40000000000L) != 0L)
/*  311 */           return jjStartNfaWithStates_0(2, 42, 17); 
/*  312 */         return jjMoveStringLiteralDfa3_0(active0, 34359738368L, active1, 0L);
/*      */       case 110:
/*  314 */         return jjMoveStringLiteralDfa3_0(active0, 137438953472L, active1, 0L);
/*      */       case 112:
/*  316 */         return jjMoveStringLiteralDfa3_0(active0, 70368744177664L, active1, 0L);
/*      */       case 114:
/*  318 */         if ((active0 & 0x1000000000L) != 0L)
/*  319 */           return jjStartNfaWithStates_0(2, 36, 17); 
/*      */         break;
/*      */       case 115:
/*  322 */         return jjMoveStringLiteralDfa3_0(active0, 12884901888L, active1, 0L);
/*      */       case 116:
/*  324 */         if ((active0 & 0x80000000000L) != 0L)
/*  325 */           return jjStartNfaWithStates_0(2, 43, 17); 
/*  326 */         return jjMoveStringLiteralDfa3_0(active0, 598409203417088L, active1, 0L);
/*      */       case 117:
/*  328 */         return jjMoveStringLiteralDfa3_0(active0, 281474976710656L, active1, 0L);
/*      */     } 
/*      */ 
/*      */     
/*  332 */     return jjStartNfa_0(1, active0, active1);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa3_0(long old0, long active0, long old1, long active1) {
/*  335 */     if (((active0 &= old0) | (active1 &= old1)) == 0L)
/*  336 */       return jjStartNfa_0(1, old0, old1);  try {
/*  337 */       this.curChar = this.input_stream.readChar();
/*  338 */     } catch (IOException e) {
/*  339 */       jjStopStringLiteralDfa_0(2, active0, 0L);
/*  340 */       return 3;
/*      */     } 
/*  342 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/*  345 */         return jjMoveStringLiteralDfa4_0(active0, 17280L);
/*      */       case 91:
/*  347 */         if ((active0 & 0x40L) != 0L)
/*  348 */           return jjStopAtPos(3, 6); 
/*  349 */         if ((active0 & 0x2000L) != 0L)
/*  350 */           return jjStopAtPos(3, 13); 
/*      */         break;
/*      */       case 97:
/*  353 */         return jjMoveStringLiteralDfa4_0(active0, 2200096997376L);
/*      */       case 99:
/*  355 */         return jjMoveStringLiteralDfa4_0(active0, 137438953472L);
/*      */       case 101:
/*  357 */         if ((active0 & 0x100000000L) != 0L) {
/*      */           
/*  359 */           this.jjmatchedKind = 32;
/*  360 */           this.jjmatchedPos = 3;
/*      */         }
/*  362 */         else if ((active0 & 0x1000000000000L) != 0L) {
/*  363 */           return jjStartNfaWithStates_0(3, 48, 17);
/*  364 */         }  return jjMoveStringLiteralDfa4_0(active0, 70377334112256L);
/*      */       case 105:
/*  366 */         return jjMoveStringLiteralDfa4_0(active0, 562949953421312L);
/*      */       case 108:
/*  368 */         return jjMoveStringLiteralDfa4_0(active0, 1125899906842624L);
/*      */       case 110:
/*  370 */         if ((active0 & 0x800000000000L) != 0L)
/*  371 */           return jjStartNfaWithStates_0(3, 47, 17); 
/*      */         break;
/*      */       case 111:
/*  374 */         if ((active0 & 0x4000000000L) != 0L)
/*  375 */           return jjStartNfaWithStates_0(3, 38, 17); 
/*      */         break;
/*      */       case 115:
/*  378 */         return jjMoveStringLiteralDfa4_0(active0, 34359738368L);
/*      */       case 117:
/*  380 */         return jjMoveStringLiteralDfa4_0(active0, 35184372088832L);
/*      */     } 
/*      */ 
/*      */     
/*  384 */     return jjStartNfa_0(2, active0, 0L);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa4_0(long old0, long active0) {
/*  387 */     if ((active0 &= old0) == 0L)
/*  388 */       return jjStartNfa_0(2, old0, 0L);  try {
/*  389 */       this.curChar = this.input_stream.readChar();
/*  390 */     } catch (IOException e) {
/*  391 */       jjStopStringLiteralDfa_0(3, active0, 0L);
/*  392 */       return 4;
/*      */     } 
/*  394 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/*  397 */         return jjMoveStringLiteralDfa5_0(active0, 768L);
/*      */       case 91:
/*  399 */         if ((active0 & 0x80L) != 0L)
/*  400 */           return jjStopAtPos(4, 7); 
/*  401 */         if ((active0 & 0x4000L) != 0L)
/*  402 */           return jjStopAtPos(4, 14); 
/*      */         break;
/*      */       case 97:
/*  405 */         return jjMoveStringLiteralDfa5_0(active0, 70368744177664L);
/*      */       case 101:
/*  407 */         if ((active0 & 0x800000000L) != 0L)
/*  408 */           return jjStartNfaWithStates_0(4, 35, 17); 
/*  409 */         if ((active0 & 0x4000000000000L) != 0L)
/*  410 */           return jjStartNfaWithStates_0(4, 50, 17); 
/*      */         break;
/*      */       case 105:
/*  413 */         return jjMoveStringLiteralDfa5_0(active0, 8589934592L);
/*      */       case 107:
/*  415 */         if ((active0 & 0x40000000L) != 0L)
/*  416 */           return jjStartNfaWithStates_0(4, 30, 17); 
/*      */         break;
/*      */       case 108:
/*  419 */         if ((active0 & 0x20000000000L) != 0L)
/*  420 */           return jjStartNfaWithStates_0(4, 41, 17); 
/*  421 */         if ((active0 & 0x2000000000000L) != 0L)
/*  422 */           return jjStartNfaWithStates_0(4, 49, 17); 
/*      */         break;
/*      */       case 114:
/*  425 */         return jjMoveStringLiteralDfa5_0(active0, 35184372088832L);
/*      */       case 116:
/*  427 */         return jjMoveStringLiteralDfa5_0(active0, 137438953472L);
/*      */     } 
/*      */ 
/*      */     
/*  431 */     return jjStartNfa_0(3, active0, 0L);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa5_0(long old0, long active0) {
/*  434 */     if ((active0 &= old0) == 0L)
/*  435 */       return jjStartNfa_0(3, old0, 0L);  try {
/*  436 */       this.curChar = this.input_stream.readChar();
/*  437 */     } catch (IOException e) {
/*  438 */       jjStopStringLiteralDfa_0(4, active0, 0L);
/*  439 */       return 5;
/*      */     } 
/*  441 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/*  444 */         return jjMoveStringLiteralDfa6_0(active0, 512L);
/*      */       case 91:
/*  446 */         if ((active0 & 0x100L) != 0L)
/*  447 */           return jjStopAtPos(5, 8); 
/*      */         break;
/*      */       case 102:
/*  450 */         if ((active0 & 0x200000000L) != 0L)
/*  451 */           return jjStartNfaWithStates_0(5, 33, 17); 
/*      */         break;
/*      */       case 105:
/*  454 */         return jjMoveStringLiteralDfa6_0(active0, 137438953472L);
/*      */       case 110:
/*  456 */         if ((active0 & 0x200000000000L) != 0L)
/*  457 */           return jjStartNfaWithStates_0(5, 45, 17); 
/*      */         break;
/*      */       case 116:
/*  460 */         if ((active0 & 0x400000000000L) != 0L) {
/*  461 */           return jjStartNfaWithStates_0(5, 46, 17);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  466 */     return jjStartNfa_0(4, active0, 0L);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa6_0(long old0, long active0) {
/*  469 */     if ((active0 &= old0) == 0L)
/*  470 */       return jjStartNfa_0(4, old0, 0L);  try {
/*  471 */       this.curChar = this.input_stream.readChar();
/*  472 */     } catch (IOException e) {
/*  473 */       jjStopStringLiteralDfa_0(5, active0, 0L);
/*  474 */       return 6;
/*      */     } 
/*  476 */     switch (this.curChar) {
/*      */       
/*      */       case 91:
/*  479 */         if ((active0 & 0x200L) != 0L)
/*  480 */           return jjStopAtPos(6, 9); 
/*      */         break;
/*      */       case 111:
/*  483 */         return jjMoveStringLiteralDfa7_0(active0, 137438953472L);
/*      */     } 
/*      */ 
/*      */     
/*  487 */     return jjStartNfa_0(5, active0, 0L);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa7_0(long old0, long active0) {
/*  490 */     if ((active0 &= old0) == 0L)
/*  491 */       return jjStartNfa_0(5, old0, 0L);  try {
/*  492 */       this.curChar = this.input_stream.readChar();
/*  493 */     } catch (IOException e) {
/*  494 */       jjStopStringLiteralDfa_0(6, active0, 0L);
/*  495 */       return 7;
/*      */     } 
/*  497 */     switch (this.curChar) {
/*      */       
/*      */       case 110:
/*  500 */         if ((active0 & 0x2000000000L) != 0L) {
/*  501 */           return jjStartNfaWithStates_0(7, 37, 17);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  506 */     return jjStartNfa_0(6, active0, 0L);
/*      */   }
/*      */   
/*      */   private int jjStartNfaWithStates_0(int pos, int kind, int state) {
/*  510 */     this.jjmatchedKind = kind;
/*  511 */     this.jjmatchedPos = pos; 
/*  512 */     try { this.curChar = this.input_stream.readChar(); }
/*  513 */     catch (IOException e) { return pos + 1; }
/*  514 */      return jjMoveNfa_0(state, pos + 1);
/*      */   }
/*  516 */   static final long[] jjbitVec0 = new long[] { -2L, -1L, -1L, -1L };
/*      */ 
/*      */   
/*  519 */   static final long[] jjbitVec2 = new long[] { 0L, 0L, -1L, -1L };
/*      */ 
/*      */ 
/*      */   
/*      */   private int jjMoveNfa_0(int startState, int curPos) {
/*  524 */     int startsAt = 0;
/*  525 */     this.jjnewStateCnt = 66;
/*  526 */     int i = 1;
/*  527 */     this.jjstateSet[0] = startState;
/*  528 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/*  531 */       if (++this.jjround == Integer.MAX_VALUE)
/*  532 */         ReInitRounds(); 
/*  533 */       if (this.curChar < 64) {
/*      */         
/*  535 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/*  538 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 8:
/*  541 */               if ((0x3FF000000000000L & l) != 0L) {
/*      */                 
/*  543 */                 if (kind > 52)
/*  544 */                   kind = 52; 
/*  545 */                 jjCheckNAddStates(0, 3);
/*      */               }
/*  547 */               else if (this.curChar == 39) {
/*  548 */                 jjCheckNAddStates(4, 6);
/*  549 */               } else if (this.curChar == 34) {
/*  550 */                 jjCheckNAddStates(7, 9);
/*  551 */               } else if (this.curChar == 46) {
/*  552 */                 jjCheckNAdd(31);
/*  553 */               } else if (this.curChar == 45) {
/*  554 */                 this.jjstateSet[this.jjnewStateCnt++] = 7;
/*  555 */               }  if (this.curChar == 48)
/*  556 */                 this.jjstateSet[this.jjnewStateCnt++] = 19; 
/*      */               break;
/*      */             case 0:
/*      */             case 1:
/*  560 */               if (this.curChar == 61)
/*  561 */                 jjCheckNAddTwoStates(1, 2); 
/*      */               break;
/*      */             case 3:
/*  564 */               if (this.curChar == 61)
/*  565 */                 this.jjstateSet[this.jjnewStateCnt++] = 0; 
/*      */               break;
/*      */             case 4:
/*  568 */               if (this.curChar == 61)
/*  569 */                 this.jjstateSet[this.jjnewStateCnt++] = 3; 
/*      */               break;
/*      */             case 5:
/*  572 */               if (this.curChar == 61)
/*  573 */                 this.jjstateSet[this.jjnewStateCnt++] = 4; 
/*      */               break;
/*      */             case 7:
/*  576 */               if (this.curChar == 45)
/*  577 */                 this.jjstateSet[this.jjnewStateCnt++] = 6; 
/*      */               break;
/*      */             case 9:
/*      */             case 10:
/*  581 */               if (this.curChar == 61)
/*  582 */                 jjCheckNAddTwoStates(10, 11); 
/*      */               break;
/*      */             case 12:
/*  585 */               if (this.curChar == 61)
/*  586 */                 this.jjstateSet[this.jjnewStateCnt++] = 9; 
/*      */               break;
/*      */             case 13:
/*  589 */               if (this.curChar == 61)
/*  590 */                 this.jjstateSet[this.jjnewStateCnt++] = 12; 
/*      */               break;
/*      */             case 14:
/*  593 */               if (this.curChar == 61)
/*  594 */                 this.jjstateSet[this.jjnewStateCnt++] = 13; 
/*      */               break;
/*      */             case 17:
/*  597 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  599 */               if (kind > 51)
/*  600 */                 kind = 51; 
/*  601 */               this.jjstateSet[this.jjnewStateCnt++] = 17;
/*      */               break;
/*      */             case 18:
/*  604 */               if (this.curChar == 48)
/*  605 */                 this.jjstateSet[this.jjnewStateCnt++] = 19; 
/*      */               break;
/*      */             case 20:
/*  608 */               if (this.curChar == 46)
/*  609 */                 jjCheckNAdd(21); 
/*      */               break;
/*      */             case 21:
/*  612 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  614 */               if (kind > 52)
/*  615 */                 kind = 52; 
/*  616 */               jjCheckNAddTwoStates(21, 22);
/*      */               break;
/*      */             case 23:
/*  619 */               if ((0x280000000000L & l) != 0L)
/*  620 */                 jjCheckNAdd(24); 
/*      */               break;
/*      */             case 24:
/*  623 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  625 */               if (kind > 52)
/*  626 */                 kind = 52; 
/*  627 */               jjCheckNAdd(24);
/*      */               break;
/*      */             case 25:
/*  630 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  632 */               if (kind > 52)
/*  633 */                 kind = 52; 
/*  634 */               jjCheckNAddStates(10, 13);
/*      */               break;
/*      */             case 26:
/*  637 */               if ((0x3FF000000000000L & l) != 0L)
/*  638 */                 jjCheckNAddTwoStates(26, 27); 
/*      */               break;
/*      */             case 27:
/*  641 */               if (this.curChar != 46)
/*      */                 break; 
/*  643 */               if (kind > 52)
/*  644 */                 kind = 52; 
/*  645 */               jjCheckNAddTwoStates(28, 22);
/*      */               break;
/*      */             case 28:
/*  648 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  650 */               if (kind > 52)
/*  651 */                 kind = 52; 
/*  652 */               jjCheckNAddTwoStates(28, 22);
/*      */               break;
/*      */             case 29:
/*  655 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  657 */               if (kind > 52)
/*  658 */                 kind = 52; 
/*  659 */               jjCheckNAddTwoStates(29, 22);
/*      */               break;
/*      */             case 30:
/*  662 */               if (this.curChar == 46)
/*  663 */                 jjCheckNAdd(31); 
/*      */               break;
/*      */             case 31:
/*  666 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  668 */               if (kind > 52)
/*  669 */                 kind = 52; 
/*  670 */               jjCheckNAddTwoStates(31, 32);
/*      */               break;
/*      */             case 33:
/*  673 */               if ((0x280000000000L & l) != 0L)
/*  674 */                 jjCheckNAdd(34); 
/*      */               break;
/*      */             case 34:
/*  677 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  679 */               if (kind > 52)
/*  680 */                 kind = 52; 
/*  681 */               jjCheckNAdd(34);
/*      */               break;
/*      */             case 35:
/*  684 */               if (this.curChar == 34)
/*  685 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 36:
/*  688 */               if ((0xFFFFFFFBFFFFFFFFL & l) != 0L)
/*  689 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 37:
/*  692 */               if (this.curChar == 34 && kind > 61)
/*  693 */                 kind = 61; 
/*      */               break;
/*      */             case 39:
/*  696 */               jjCheckNAddStates(7, 9);
/*      */               break;
/*      */             case 41:
/*  699 */               if ((0x3FF000000000000L & l) != 0L)
/*  700 */                 this.jjstateSet[this.jjnewStateCnt++] = 42; 
/*      */               break;
/*      */             case 42:
/*  703 */               if ((0x3FF000000000000L & l) != 0L)
/*  704 */                 this.jjstateSet[this.jjnewStateCnt++] = 43; 
/*      */               break;
/*      */             case 43:
/*  707 */               if ((0x3FF000000000000L & l) != 0L)
/*  708 */                 this.jjstateSet[this.jjnewStateCnt++] = 44; 
/*      */               break;
/*      */             case 44:
/*      */             case 47:
/*  712 */               if ((0x3FF000000000000L & l) != 0L)
/*  713 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 45:
/*  716 */               if ((0x3FF000000000000L & l) != 0L)
/*  717 */                 jjCheckNAddStates(14, 17); 
/*      */               break;
/*      */             case 46:
/*  720 */               if ((0x3FF000000000000L & l) != 0L)
/*  721 */                 jjCheckNAddStates(18, 21); 
/*      */               break;
/*      */             case 48:
/*  724 */               if (this.curChar == 39)
/*  725 */                 jjCheckNAddStates(4, 6); 
/*      */               break;
/*      */             case 49:
/*  728 */               if ((0xFFFFFF7FFFFFFFFFL & l) != 0L)
/*  729 */                 jjCheckNAddStates(4, 6); 
/*      */               break;
/*      */             case 50:
/*  732 */               if (this.curChar == 39 && kind > 62)
/*  733 */                 kind = 62; 
/*      */               break;
/*      */             case 52:
/*  736 */               jjCheckNAddStates(4, 6);
/*      */               break;
/*      */             case 54:
/*  739 */               if ((0x3FF000000000000L & l) != 0L)
/*  740 */                 this.jjstateSet[this.jjnewStateCnt++] = 55; 
/*      */               break;
/*      */             case 55:
/*  743 */               if ((0x3FF000000000000L & l) != 0L)
/*  744 */                 this.jjstateSet[this.jjnewStateCnt++] = 56; 
/*      */               break;
/*      */             case 56:
/*  747 */               if ((0x3FF000000000000L & l) != 0L)
/*  748 */                 this.jjstateSet[this.jjnewStateCnt++] = 57; 
/*      */               break;
/*      */             case 57:
/*      */             case 60:
/*  752 */               if ((0x3FF000000000000L & l) != 0L)
/*  753 */                 jjCheckNAddStates(4, 6); 
/*      */               break;
/*      */             case 58:
/*  756 */               if ((0x3FF000000000000L & l) != 0L)
/*  757 */                 jjCheckNAddStates(22, 25); 
/*      */               break;
/*      */             case 59:
/*  760 */               if ((0x3FF000000000000L & l) != 0L)
/*  761 */                 jjCheckNAddStates(26, 29); 
/*      */               break;
/*      */             case 61:
/*  764 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  766 */               if (kind > 52)
/*  767 */                 kind = 52; 
/*  768 */               jjCheckNAddStates(0, 3);
/*      */               break;
/*      */             case 62:
/*  771 */               if ((0x3FF000000000000L & l) != 0L)
/*  772 */                 jjCheckNAddTwoStates(62, 63); 
/*      */               break;
/*      */             case 63:
/*  775 */               if (this.curChar != 46)
/*      */                 break; 
/*  777 */               if (kind > 52)
/*  778 */                 kind = 52; 
/*  779 */               jjCheckNAddTwoStates(64, 32);
/*      */               break;
/*      */             case 64:
/*  782 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  784 */               if (kind > 52)
/*  785 */                 kind = 52; 
/*  786 */               jjCheckNAddTwoStates(64, 32);
/*      */               break;
/*      */             case 65:
/*  789 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  791 */               if (kind > 52)
/*  792 */                 kind = 52; 
/*  793 */               jjCheckNAddTwoStates(65, 32);
/*      */               break;
/*      */           } 
/*      */         
/*  797 */         } while (i != startsAt);
/*      */       }
/*  799 */       else if (this.curChar < 128) {
/*      */         
/*  801 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/*  804 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 8:
/*  807 */               if ((0x7FFFFFE87FFFFFEL & l) != 0L) {
/*      */                 
/*  809 */                 if (kind > 51)
/*  810 */                   kind = 51; 
/*  811 */                 jjCheckNAdd(17); break;
/*      */               } 
/*  813 */               if (this.curChar == 91)
/*  814 */                 this.jjstateSet[this.jjnewStateCnt++] = 14; 
/*      */               break;
/*      */             case 2:
/*  817 */               if (this.curChar == 91 && kind > 10)
/*  818 */                 kind = 10; 
/*      */               break;
/*      */             case 6:
/*  821 */               if (this.curChar == 91)
/*  822 */                 this.jjstateSet[this.jjnewStateCnt++] = 5; 
/*      */               break;
/*      */             case 11:
/*  825 */               if (this.curChar == 91 && kind > 15)
/*  826 */                 kind = 15; 
/*      */               break;
/*      */             case 15:
/*  829 */               if (this.curChar == 91)
/*  830 */                 this.jjstateSet[this.jjnewStateCnt++] = 14; 
/*      */               break;
/*      */             case 16:
/*      */             case 17:
/*  834 */               if ((0x7FFFFFE87FFFFFEL & l) == 0L)
/*      */                 break; 
/*  836 */               if (kind > 51)
/*  837 */                 kind = 51; 
/*  838 */               jjCheckNAdd(17);
/*      */               break;
/*      */             case 19:
/*  841 */               if ((0x100000001000000L & l) != 0L)
/*  842 */                 jjAddStates(30, 31); 
/*      */               break;
/*      */             case 21:
/*  845 */               if ((0x7E0000007EL & l) == 0L)
/*      */                 break; 
/*  847 */               if (kind > 52)
/*  848 */                 kind = 52; 
/*  849 */               jjCheckNAddTwoStates(21, 22);
/*      */               break;
/*      */             case 22:
/*  852 */               if ((0x1002000010020L & l) != 0L)
/*  853 */                 jjAddStates(32, 33); 
/*      */               break;
/*      */             case 25:
/*  856 */               if ((0x7E0000007EL & l) == 0L)
/*      */                 break; 
/*  858 */               if (kind > 52)
/*  859 */                 kind = 52; 
/*  860 */               jjCheckNAddStates(10, 13);
/*      */               break;
/*      */             case 26:
/*  863 */               if ((0x7E0000007EL & l) != 0L)
/*  864 */                 jjCheckNAddTwoStates(26, 27); 
/*      */               break;
/*      */             case 28:
/*  867 */               if ((0x7E0000007EL & l) == 0L)
/*      */                 break; 
/*  869 */               if (kind > 52)
/*  870 */                 kind = 52; 
/*  871 */               jjCheckNAddTwoStates(28, 22);
/*      */               break;
/*      */             case 29:
/*  874 */               if ((0x7E0000007EL & l) == 0L)
/*      */                 break; 
/*  876 */               if (kind > 52)
/*  877 */                 kind = 52; 
/*  878 */               jjCheckNAddTwoStates(29, 22);
/*      */               break;
/*      */             case 32:
/*  881 */               if ((0x2000000020L & l) != 0L)
/*  882 */                 jjAddStates(34, 35); 
/*      */               break;
/*      */             case 36:
/*  885 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L)
/*  886 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 38:
/*  889 */               if (this.curChar == 92)
/*  890 */                 jjAddStates(36, 38); 
/*      */               break;
/*      */             case 39:
/*  893 */               jjCheckNAddStates(7, 9);
/*      */               break;
/*      */             case 40:
/*  896 */               if (this.curChar == 117)
/*  897 */                 this.jjstateSet[this.jjnewStateCnt++] = 41; 
/*      */               break;
/*      */             case 41:
/*  900 */               if ((0x7E0000007EL & l) != 0L)
/*  901 */                 this.jjstateSet[this.jjnewStateCnt++] = 42; 
/*      */               break;
/*      */             case 42:
/*  904 */               if ((0x7E0000007EL & l) != 0L)
/*  905 */                 this.jjstateSet[this.jjnewStateCnt++] = 43; 
/*      */               break;
/*      */             case 43:
/*  908 */               if ((0x7E0000007EL & l) != 0L)
/*  909 */                 this.jjstateSet[this.jjnewStateCnt++] = 44; 
/*      */               break;
/*      */             case 44:
/*  912 */               if ((0x7E0000007EL & l) != 0L)
/*  913 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 49:
/*  916 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L)
/*  917 */                 jjCheckNAddStates(4, 6); 
/*      */               break;
/*      */             case 51:
/*  920 */               if (this.curChar == 92)
/*  921 */                 jjAddStates(39, 41); 
/*      */               break;
/*      */             case 52:
/*  924 */               jjCheckNAddStates(4, 6);
/*      */               break;
/*      */             case 53:
/*  927 */               if (this.curChar == 117)
/*  928 */                 this.jjstateSet[this.jjnewStateCnt++] = 54; 
/*      */               break;
/*      */             case 54:
/*  931 */               if ((0x7E0000007EL & l) != 0L)
/*  932 */                 this.jjstateSet[this.jjnewStateCnt++] = 55; 
/*      */               break;
/*      */             case 55:
/*  935 */               if ((0x7E0000007EL & l) != 0L)
/*  936 */                 this.jjstateSet[this.jjnewStateCnt++] = 56; 
/*      */               break;
/*      */             case 56:
/*  939 */               if ((0x7E0000007EL & l) != 0L)
/*  940 */                 this.jjstateSet[this.jjnewStateCnt++] = 57; 
/*      */               break;
/*      */             case 57:
/*  943 */               if ((0x7E0000007EL & l) != 0L) {
/*  944 */                 jjCheckNAddStates(4, 6);
/*      */               }
/*      */               break;
/*      */           } 
/*  948 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/*  952 */         int hiByte = this.curChar >> 8;
/*  953 */         int i1 = hiByte >> 6;
/*  954 */         long l1 = 1L << (hiByte & 0x3F);
/*  955 */         int i2 = (this.curChar & 0xFF) >> 6;
/*  956 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/*  959 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 36:
/*      */             case 39:
/*  963 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2))
/*  964 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 49:
/*      */             case 52:
/*  968 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2))
/*  969 */                 jjCheckNAddStates(4, 6);  break;
/*      */             default:
/*  971 */               if (i1 == 0 || l1 == 0L || i2 == 0 || l2 == 0L); break;
/*      */           } 
/*  973 */         } while (i != startsAt);
/*      */       } 
/*  975 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/*  977 */         this.jjmatchedKind = kind;
/*  978 */         this.jjmatchedPos = curPos;
/*  979 */         kind = Integer.MAX_VALUE;
/*      */       } 
/*  981 */       curPos++;
/*  982 */       i = this.jjnewStateCnt;
/*  983 */       this.jjnewStateCnt = startsAt;
/*  984 */       startsAt = 66 - this.jjnewStateCnt;
/*  985 */       if (i == startsAt)
/*  986 */         return curPos;  
/*  987 */       try { this.curChar = this.input_stream.readChar(); }
/*  988 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*      */   }
/*      */   private int jjMoveStringLiteralDfa0_1() {
/*  993 */     return jjMoveNfa_1(4, 0);
/*      */   }
/*      */   
/*      */   private int jjMoveNfa_1(int startState, int curPos) {
/*  997 */     int startsAt = 0;
/*  998 */     this.jjnewStateCnt = 4;
/*  999 */     int i = 1;
/* 1000 */     this.jjstateSet[0] = startState;
/* 1001 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/* 1004 */       if (++this.jjround == Integer.MAX_VALUE)
/* 1005 */         ReInitRounds(); 
/* 1006 */       if (this.curChar < 64) {
/*      */         
/* 1008 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/* 1011 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 4:
/* 1014 */               if ((0xFFFFFFFFFFFFDBFFL & l) != 0L) {
/*      */                 
/* 1016 */                 if (kind > 17)
/* 1017 */                   kind = 17; 
/* 1018 */                 jjCheckNAddStates(42, 44);
/*      */               }
/* 1020 */               else if ((0x2400L & l) != 0L) {
/*      */                 
/* 1022 */                 if (kind > 17)
/* 1023 */                   kind = 17; 
/*      */               } 
/* 1025 */               if (this.curChar == 13)
/* 1026 */                 this.jjstateSet[this.jjnewStateCnt++] = 2; 
/*      */               break;
/*      */             case 0:
/* 1029 */               if ((0xFFFFFFFFFFFFDBFFL & l) == 0L)
/*      */                 break; 
/* 1031 */               kind = 17;
/* 1032 */               jjCheckNAddStates(42, 44);
/*      */               break;
/*      */             case 1:
/* 1035 */               if ((0x2400L & l) != 0L && kind > 17)
/* 1036 */                 kind = 17; 
/*      */               break;
/*      */             case 2:
/* 1039 */               if (this.curChar == 10 && kind > 17)
/* 1040 */                 kind = 17; 
/*      */               break;
/*      */             case 3:
/* 1043 */               if (this.curChar == 13) {
/* 1044 */                 this.jjstateSet[this.jjnewStateCnt++] = 2;
/*      */               }
/*      */               break;
/*      */           } 
/* 1048 */         } while (i != startsAt);
/*      */       }
/* 1050 */       else if (this.curChar < 128) {
/*      */         
/* 1052 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1055 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 4:
/* 1059 */               kind = 17;
/* 1060 */               jjCheckNAddStates(42, 44);
/*      */               break;
/*      */           } 
/*      */         
/* 1064 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/* 1068 */         int hiByte = this.curChar >> 8;
/* 1069 */         int i1 = hiByte >> 6;
/* 1070 */         long l1 = 1L << (hiByte & 0x3F);
/* 1071 */         int i2 = (this.curChar & 0xFF) >> 6;
/* 1072 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1075 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 4:
/* 1079 */               if (!jjCanMove_0(hiByte, i1, i2, l1, l2))
/*      */                 break; 
/* 1081 */               if (kind > 17)
/* 1082 */                 kind = 17; 
/* 1083 */               jjCheckNAddStates(42, 44); break;
/*      */             default:
/* 1085 */               if (i1 == 0 || l1 == 0L || i2 == 0 || l2 == 0L); break;
/*      */           } 
/* 1087 */         } while (i != startsAt);
/*      */       } 
/* 1089 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/* 1091 */         this.jjmatchedKind = kind;
/* 1092 */         this.jjmatchedPos = curPos;
/* 1093 */         kind = Integer.MAX_VALUE;
/*      */       } 
/* 1095 */       curPos++;
/* 1096 */       i = this.jjnewStateCnt;
/* 1097 */       this.jjnewStateCnt = startsAt;
/* 1098 */       startsAt = 4 - this.jjnewStateCnt;
/* 1099 */       if (i == startsAt)
/* 1100 */         return curPos;  
/* 1101 */       try { this.curChar = this.input_stream.readChar(); }
/* 1102 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*      */   } private int jjMoveStringLiteralDfa0_2() {
/* 1106 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1109 */         return jjMoveStringLiteralDfa1_2(262144L);
/*      */     } 
/* 1111 */     return 1;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa1_2(long active0) { try {
/* 1115 */       this.curChar = this.input_stream.readChar();
/* 1116 */     } catch (IOException e) {
/* 1117 */       return 1;
/*      */     } 
/* 1119 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1122 */         if ((active0 & 0x40000L) != 0L) {
/* 1123 */           return jjStopAtPos(1, 18);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1128 */         return 2;
/*      */     } 
/*      */     return 2; } private int jjMoveStringLiteralDfa0_3() {
/* 1131 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1134 */         return jjMoveStringLiteralDfa1_3(524288L);
/*      */     } 
/* 1136 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_3(long active0) {
/*      */     try {
/* 1140 */       this.curChar = this.input_stream.readChar();
/* 1141 */     } catch (IOException e) {
/* 1142 */       return 1;
/*      */     } 
/* 1144 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1147 */         return jjMoveStringLiteralDfa2_3(active0, 524288L);
/*      */     } 
/* 1149 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_3(long old0, long active0) {
/* 1153 */     if ((active0 &= old0) == 0L)
/* 1154 */       return 2;  try {
/* 1155 */       this.curChar = this.input_stream.readChar();
/* 1156 */     } catch (IOException e) {
/* 1157 */       return 2;
/*      */     } 
/* 1159 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1162 */         if ((active0 & 0x80000L) != 0L) {
/* 1163 */           return jjStopAtPos(2, 19);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1168 */         return 3;
/*      */     } 
/*      */     return 3; } private int jjMoveStringLiteralDfa0_4() {
/* 1171 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1174 */         return jjMoveStringLiteralDfa1_4(1048576L);
/*      */     } 
/* 1176 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_4(long active0) {
/*      */     try {
/* 1180 */       this.curChar = this.input_stream.readChar();
/* 1181 */     } catch (IOException e) {
/* 1182 */       return 1;
/*      */     } 
/* 1184 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1187 */         return jjMoveStringLiteralDfa2_4(active0, 1048576L);
/*      */     } 
/* 1189 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_4(long old0, long active0) {
/* 1193 */     if ((active0 &= old0) == 0L)
/* 1194 */       return 2;  try {
/* 1195 */       this.curChar = this.input_stream.readChar();
/* 1196 */     } catch (IOException e) {
/* 1197 */       return 2;
/*      */     } 
/* 1199 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1202 */         return jjMoveStringLiteralDfa3_4(active0, 1048576L);
/*      */     } 
/* 1204 */     return 3;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_4(long old0, long active0) {
/* 1208 */     if ((active0 &= old0) == 0L)
/* 1209 */       return 3;  try {
/* 1210 */       this.curChar = this.input_stream.readChar();
/* 1211 */     } catch (IOException e) {
/* 1212 */       return 3;
/*      */     } 
/* 1214 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1217 */         if ((active0 & 0x100000L) != 0L) {
/* 1218 */           return jjStopAtPos(3, 20);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1223 */         return 4;
/*      */     } 
/*      */     return 4; } private int jjMoveStringLiteralDfa0_5() {
/* 1226 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1229 */         return jjMoveStringLiteralDfa1_5(2097152L);
/*      */     } 
/* 1231 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_5(long active0) {
/*      */     try {
/* 1235 */       this.curChar = this.input_stream.readChar();
/* 1236 */     } catch (IOException e) {
/* 1237 */       return 1;
/*      */     } 
/* 1239 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1242 */         return jjMoveStringLiteralDfa2_5(active0, 2097152L);
/*      */     } 
/* 1244 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_5(long old0, long active0) {
/* 1248 */     if ((active0 &= old0) == 0L)
/* 1249 */       return 2;  try {
/* 1250 */       this.curChar = this.input_stream.readChar();
/* 1251 */     } catch (IOException e) {
/* 1252 */       return 2;
/*      */     } 
/* 1254 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1257 */         return jjMoveStringLiteralDfa3_5(active0, 2097152L);
/*      */     } 
/* 1259 */     return 3;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_5(long old0, long active0) {
/* 1263 */     if ((active0 &= old0) == 0L)
/* 1264 */       return 3;  try {
/* 1265 */       this.curChar = this.input_stream.readChar();
/* 1266 */     } catch (IOException e) {
/* 1267 */       return 3;
/*      */     } 
/* 1269 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1272 */         return jjMoveStringLiteralDfa4_5(active0, 2097152L);
/*      */     } 
/* 1274 */     return 4;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa4_5(long old0, long active0) {
/* 1278 */     if ((active0 &= old0) == 0L)
/* 1279 */       return 4;  try {
/* 1280 */       this.curChar = this.input_stream.readChar();
/* 1281 */     } catch (IOException e) {
/* 1282 */       return 4;
/*      */     } 
/* 1284 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1287 */         if ((active0 & 0x200000L) != 0L) {
/* 1288 */           return jjStopAtPos(4, 21);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1293 */         return 5;
/*      */     } 
/*      */     return 5;
/*      */   } private int jjMoveStringLiteralDfa0_6() {
/* 1297 */     return jjMoveNfa_6(6, 0);
/*      */   }
/*      */   
/*      */   private int jjMoveNfa_6(int startState, int curPos) {
/* 1301 */     int startsAt = 0;
/* 1302 */     this.jjnewStateCnt = 7;
/* 1303 */     int i = 1;
/* 1304 */     this.jjstateSet[0] = startState;
/* 1305 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/* 1308 */       if (++this.jjround == Integer.MAX_VALUE)
/* 1309 */         ReInitRounds(); 
/* 1310 */       if (this.curChar < 64) {
/*      */         
/* 1312 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/* 1315 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 1:
/* 1319 */               if (this.curChar == 61)
/* 1320 */                 jjCheckNAddTwoStates(1, 2); 
/*      */               break;
/*      */             case 3:
/* 1323 */               if (this.curChar == 61)
/* 1324 */                 this.jjstateSet[this.jjnewStateCnt++] = 0; 
/*      */               break;
/*      */             case 4:
/* 1327 */               if (this.curChar == 61)
/* 1328 */                 this.jjstateSet[this.jjnewStateCnt++] = 3; 
/*      */               break;
/*      */             case 5:
/* 1331 */               if (this.curChar == 61) {
/* 1332 */                 this.jjstateSet[this.jjnewStateCnt++] = 4;
/*      */               }
/*      */               break;
/*      */           } 
/* 1336 */         } while (i != startsAt);
/*      */       }
/* 1338 */       else if (this.curChar < 128) {
/*      */         
/* 1340 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1343 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 2:
/* 1346 */               if (this.curChar == 93 && kind > 22)
/* 1347 */                 kind = 22; 
/*      */               break;
/*      */             case 6:
/* 1350 */               if (this.curChar == 93) {
/* 1351 */                 this.jjstateSet[this.jjnewStateCnt++] = 5;
/*      */               }
/*      */               break;
/*      */           } 
/* 1355 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/* 1359 */         int hiByte = this.curChar >> 8;
/* 1360 */         int i1 = hiByte >> 6;
/* 1361 */         long l1 = 1L << (hiByte & 0x3F);
/* 1362 */         int i2 = (this.curChar & 0xFF) >> 6;
/* 1363 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1366 */           switch (this.jjstateSet[--i]) {
/*      */           
/* 1368 */           }  if (i1 == 0 || l1 == 0L || i2 == 0 || l2 == 0L);
/*      */         }
/* 1370 */         while (i != startsAt);
/*      */       } 
/* 1372 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/* 1374 */         this.jjmatchedKind = kind;
/* 1375 */         this.jjmatchedPos = curPos;
/* 1376 */         kind = Integer.MAX_VALUE;
/*      */       } 
/* 1378 */       curPos++;
/* 1379 */       i = this.jjnewStateCnt;
/* 1380 */       this.jjnewStateCnt = startsAt;
/* 1381 */       startsAt = 7 - this.jjnewStateCnt;
/* 1382 */       if (i == startsAt)
/* 1383 */         return curPos;  
/* 1384 */       try { this.curChar = this.input_stream.readChar(); }
/* 1385 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*      */   } private int jjMoveStringLiteralDfa0_7() {
/* 1389 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1392 */         return jjMoveStringLiteralDfa1_7(8388608L);
/*      */     } 
/* 1394 */     return 1;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa1_7(long active0) { try {
/* 1398 */       this.curChar = this.input_stream.readChar();
/* 1399 */     } catch (IOException e) {
/* 1400 */       return 1;
/*      */     } 
/* 1402 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1405 */         if ((active0 & 0x800000L) != 0L) {
/* 1406 */           return jjStopAtPos(1, 23);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1411 */         return 2;
/*      */     } 
/*      */     return 2; } private int jjMoveStringLiteralDfa0_8() {
/* 1414 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1417 */         return jjMoveStringLiteralDfa1_8(16777216L);
/*      */     } 
/* 1419 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_8(long active0) {
/*      */     try {
/* 1423 */       this.curChar = this.input_stream.readChar();
/* 1424 */     } catch (IOException e) {
/* 1425 */       return 1;
/*      */     } 
/* 1427 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1430 */         return jjMoveStringLiteralDfa2_8(active0, 16777216L);
/*      */     } 
/* 1432 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_8(long old0, long active0) {
/* 1436 */     if ((active0 &= old0) == 0L)
/* 1437 */       return 2;  try {
/* 1438 */       this.curChar = this.input_stream.readChar();
/* 1439 */     } catch (IOException e) {
/* 1440 */       return 2;
/*      */     } 
/* 1442 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1445 */         if ((active0 & 0x1000000L) != 0L) {
/* 1446 */           return jjStopAtPos(2, 24);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1451 */         return 3;
/*      */     } 
/*      */     return 3; } private int jjMoveStringLiteralDfa0_9() {
/* 1454 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1457 */         return jjMoveStringLiteralDfa1_9(33554432L);
/*      */     } 
/* 1459 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_9(long active0) {
/*      */     try {
/* 1463 */       this.curChar = this.input_stream.readChar();
/* 1464 */     } catch (IOException e) {
/* 1465 */       return 1;
/*      */     } 
/* 1467 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1470 */         return jjMoveStringLiteralDfa2_9(active0, 33554432L);
/*      */     } 
/* 1472 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_9(long old0, long active0) {
/* 1476 */     if ((active0 &= old0) == 0L)
/* 1477 */       return 2;  try {
/* 1478 */       this.curChar = this.input_stream.readChar();
/* 1479 */     } catch (IOException e) {
/* 1480 */       return 2;
/*      */     } 
/* 1482 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1485 */         return jjMoveStringLiteralDfa3_9(active0, 33554432L);
/*      */     } 
/* 1487 */     return 3;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_9(long old0, long active0) {
/* 1491 */     if ((active0 &= old0) == 0L)
/* 1492 */       return 3;  try {
/* 1493 */       this.curChar = this.input_stream.readChar();
/* 1494 */     } catch (IOException e) {
/* 1495 */       return 3;
/*      */     } 
/* 1497 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1500 */         if ((active0 & 0x2000000L) != 0L) {
/* 1501 */           return jjStopAtPos(3, 25);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1506 */         return 4;
/*      */     } 
/*      */     return 4; } private int jjMoveStringLiteralDfa0_10() {
/* 1509 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1512 */         return jjMoveStringLiteralDfa1_10(67108864L);
/*      */     } 
/* 1514 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_10(long active0) {
/*      */     try {
/* 1518 */       this.curChar = this.input_stream.readChar();
/* 1519 */     } catch (IOException e) {
/* 1520 */       return 1;
/*      */     } 
/* 1522 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1525 */         return jjMoveStringLiteralDfa2_10(active0, 67108864L);
/*      */     } 
/* 1527 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_10(long old0, long active0) {
/* 1531 */     if ((active0 &= old0) == 0L)
/* 1532 */       return 2;  try {
/* 1533 */       this.curChar = this.input_stream.readChar();
/* 1534 */     } catch (IOException e) {
/* 1535 */       return 2;
/*      */     } 
/* 1537 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1540 */         return jjMoveStringLiteralDfa3_10(active0, 67108864L);
/*      */     } 
/* 1542 */     return 3;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_10(long old0, long active0) {
/* 1546 */     if ((active0 &= old0) == 0L)
/* 1547 */       return 3;  try {
/* 1548 */       this.curChar = this.input_stream.readChar();
/* 1549 */     } catch (IOException e) {
/* 1550 */       return 3;
/*      */     } 
/* 1552 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1555 */         return jjMoveStringLiteralDfa4_10(active0, 67108864L);
/*      */     } 
/* 1557 */     return 4;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa4_10(long old0, long active0) {
/* 1561 */     if ((active0 &= old0) == 0L)
/* 1562 */       return 4;  try {
/* 1563 */       this.curChar = this.input_stream.readChar();
/* 1564 */     } catch (IOException e) {
/* 1565 */       return 4;
/*      */     } 
/* 1567 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1570 */         if ((active0 & 0x4000000L) != 0L) {
/* 1571 */           return jjStopAtPos(4, 26);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1576 */         return 5;
/*      */     } 
/*      */     return 5;
/*      */   } private int jjMoveStringLiteralDfa0_11() {
/* 1580 */     return jjMoveNfa_11(6, 0);
/*      */   }
/*      */   
/*      */   private int jjMoveNfa_11(int startState, int curPos) {
/* 1584 */     int startsAt = 0;
/* 1585 */     this.jjnewStateCnt = 7;
/* 1586 */     int i = 1;
/* 1587 */     this.jjstateSet[0] = startState;
/* 1588 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/* 1591 */       if (++this.jjround == Integer.MAX_VALUE)
/* 1592 */         ReInitRounds(); 
/* 1593 */       if (this.curChar < 64) {
/*      */         
/* 1595 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/* 1598 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 1:
/* 1602 */               if (this.curChar == 61)
/* 1603 */                 jjCheckNAddTwoStates(1, 2); 
/*      */               break;
/*      */             case 3:
/* 1606 */               if (this.curChar == 61)
/* 1607 */                 this.jjstateSet[this.jjnewStateCnt++] = 0; 
/*      */               break;
/*      */             case 4:
/* 1610 */               if (this.curChar == 61)
/* 1611 */                 this.jjstateSet[this.jjnewStateCnt++] = 3; 
/*      */               break;
/*      */             case 5:
/* 1614 */               if (this.curChar == 61) {
/* 1615 */                 this.jjstateSet[this.jjnewStateCnt++] = 4;
/*      */               }
/*      */               break;
/*      */           } 
/* 1619 */         } while (i != startsAt);
/*      */       }
/* 1621 */       else if (this.curChar < 128) {
/*      */         
/* 1623 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1626 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 2:
/* 1629 */               if (this.curChar == 93 && kind > 27)
/* 1630 */                 kind = 27; 
/*      */               break;
/*      */             case 6:
/* 1633 */               if (this.curChar == 93) {
/* 1634 */                 this.jjstateSet[this.jjnewStateCnt++] = 5;
/*      */               }
/*      */               break;
/*      */           } 
/* 1638 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/* 1642 */         int hiByte = this.curChar >> 8;
/* 1643 */         int i1 = hiByte >> 6;
/* 1644 */         long l1 = 1L << (hiByte & 0x3F);
/* 1645 */         int i2 = (this.curChar & 0xFF) >> 6;
/* 1646 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1649 */           switch (this.jjstateSet[--i]) {
/*      */           
/* 1651 */           }  if (i1 == 0 || l1 == 0L || i2 == 0 || l2 == 0L);
/*      */         }
/* 1653 */         while (i != startsAt);
/*      */       } 
/* 1655 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/* 1657 */         this.jjmatchedKind = kind;
/* 1658 */         this.jjmatchedPos = curPos;
/* 1659 */         kind = Integer.MAX_VALUE;
/*      */       } 
/* 1661 */       curPos++;
/* 1662 */       i = this.jjnewStateCnt;
/* 1663 */       this.jjnewStateCnt = startsAt;
/* 1664 */       startsAt = 7 - this.jjnewStateCnt;
/* 1665 */       if (i == startsAt)
/* 1666 */         return curPos;  
/* 1667 */       try { this.curChar = this.input_stream.readChar(); }
/* 1668 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*      */   }
/*      */   
/* 1673 */   public static final String[] jjstrLiteralImages = new String[] { "", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "and", "break", "do", "else", "elseif", "end", "false", "for", "function", "goto", "if", "in", "local", "nil", "not", "or", "return", "repeat", "then", "true", "until", "while", null, null, null, null, null, null, null, null, null, null, null, null, null, null, "::", null, null, null, "#", ";", "=", ",", ".", ":", "(", ")", "[", "]", "...", "{", "}", "+", "-", "*", "/", "^", "%", "..", "<", "<=", ">", ">=", "==", "~=" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Token jjFillToken() {
/*      */     String curTokenImage;
/*      */     int beginLine, endLine, beginColumn, endColumn;
/* 1693 */     if (this.jjmatchedPos < 0) {
/*      */       
/* 1695 */       if (this.image == null) {
/* 1696 */         curTokenImage = "";
/*      */       } else {
/* 1698 */         curTokenImage = this.image.toString();
/* 1699 */       }  beginLine = endLine = this.input_stream.getEndLine();
/* 1700 */       beginColumn = endColumn = this.input_stream.getEndColumn();
/*      */     }
/*      */     else {
/*      */       
/* 1704 */       String im = jjstrLiteralImages[this.jjmatchedKind];
/* 1705 */       curTokenImage = (im == null) ? this.input_stream.getImage() : im;
/* 1706 */       beginLine = this.input_stream.getBeginLine();
/* 1707 */       beginColumn = this.input_stream.getBeginColumn();
/* 1708 */       endLine = this.input_stream.getEndLine();
/* 1709 */       endColumn = this.input_stream.getEndColumn();
/*      */     } 
/* 1711 */     Token t = Token.newToken(this.jjmatchedKind);
/* 1712 */     t.kind = this.jjmatchedKind;
/* 1713 */     t.image = curTokenImage;
/*      */     
/* 1715 */     t.beginLine = beginLine;
/* 1716 */     t.endLine = endLine;
/* 1717 */     t.beginColumn = beginColumn;
/* 1718 */     t.endColumn = endColumn;
/*      */     
/* 1720 */     return t;
/*      */   }
/* 1722 */   static final int[] jjnextStates = new int[] { 62, 63, 65, 32, 49, 50, 51, 36, 37, 38, 26, 27, 29, 22, 36, 37, 38, 46, 36, 47, 37, 38, 49, 50, 51, 59, 49, 60, 50, 51, 20, 25, 23, 24, 33, 34, 39, 40, 45, 52, 53, 58, 0, 1, 3 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean jjCanMove_0(int hiByte, int i1, int i2, long l1, long l2) {
/* 1729 */     switch (hiByte) {
/*      */       
/*      */       case 0:
/* 1732 */         return ((jjbitVec2[i2] & l2) != 0L);
/*      */     } 
/* 1734 */     if ((jjbitVec0[i1] & l1) != 0L)
/* 1735 */       return true; 
/* 1736 */     return false;
/*      */   }
/*      */ 
/*      */   
/* 1740 */   int curLexState = 0;
/* 1741 */   int defaultLexState = 0;
/*      */   
/*      */   int jjnewStateCnt;
/*      */   
/*      */   int jjround;
/*      */   int jjmatchedPos;
/*      */   int jjmatchedKind;
/*      */   
/*      */   public Token getNextToken() {
/* 1750 */     Token specialToken = null;
/*      */     
/* 1752 */     int curPos = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     label125: while (true) {
/*      */       try {
/* 1759 */         this.curChar = this.input_stream.beginToken();
/*      */       }
/* 1761 */       catch (Exception e) {
/*      */         
/* 1763 */         this.jjmatchedKind = 0;
/* 1764 */         this.jjmatchedPos = -1;
/* 1765 */         Token matchedToken = jjFillToken();
/* 1766 */         matchedToken.specialToken = specialToken;
/* 1767 */         return matchedToken;
/*      */       } 
/* 1769 */       this.image = this.jjimage;
/* 1770 */       this.image.setLength(0);
/* 1771 */       this.jjimageLen = 0;
/*      */ 
/*      */       
/*      */       while (true) {
/* 1775 */         switch (this.curLexState) {
/*      */           
/*      */           case 0:
/*      */             try {
/* 1779 */               this.input_stream.backup(0);
/* 1780 */               while (this.curChar <= 32 && (0x100003600L & 1L << this.curChar) != 0L) {
/* 1781 */                 this.curChar = this.input_stream.beginToken();
/*      */               }
/* 1783 */             } catch (IOException e1) {
/*      */               continue label125;
/*      */             } 
/* 1786 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1787 */             this.jjmatchedPos = 0;
/* 1788 */             curPos = jjMoveStringLiteralDfa0_0();
/*      */             break;
/*      */           case 1:
/* 1791 */             this.jjmatchedKind = 17;
/* 1792 */             this.jjmatchedPos = -1;
/* 1793 */             curPos = 0;
/* 1794 */             curPos = jjMoveStringLiteralDfa0_1();
/*      */             break;
/*      */           case 2:
/* 1797 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1798 */             this.jjmatchedPos = 0;
/* 1799 */             curPos = jjMoveStringLiteralDfa0_2();
/* 1800 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1802 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 3:
/* 1806 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1807 */             this.jjmatchedPos = 0;
/* 1808 */             curPos = jjMoveStringLiteralDfa0_3();
/* 1809 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1811 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 4:
/* 1815 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1816 */             this.jjmatchedPos = 0;
/* 1817 */             curPos = jjMoveStringLiteralDfa0_4();
/* 1818 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1820 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 5:
/* 1824 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1825 */             this.jjmatchedPos = 0;
/* 1826 */             curPos = jjMoveStringLiteralDfa0_5();
/* 1827 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1829 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 6:
/* 1833 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1834 */             this.jjmatchedPos = 0;
/* 1835 */             curPos = jjMoveStringLiteralDfa0_6();
/* 1836 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1838 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 7:
/* 1842 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1843 */             this.jjmatchedPos = 0;
/* 1844 */             curPos = jjMoveStringLiteralDfa0_7();
/* 1845 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1847 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 8:
/* 1851 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1852 */             this.jjmatchedPos = 0;
/* 1853 */             curPos = jjMoveStringLiteralDfa0_8();
/* 1854 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1856 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 9:
/* 1860 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1861 */             this.jjmatchedPos = 0;
/* 1862 */             curPos = jjMoveStringLiteralDfa0_9();
/* 1863 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1865 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 10:
/* 1869 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1870 */             this.jjmatchedPos = 0;
/* 1871 */             curPos = jjMoveStringLiteralDfa0_10();
/* 1872 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1874 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 11:
/* 1878 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1879 */             this.jjmatchedPos = 0;
/* 1880 */             curPos = jjMoveStringLiteralDfa0_11();
/* 1881 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1883 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */         } 
/* 1887 */         if (this.jjmatchedKind != Integer.MAX_VALUE)
/*      */         
/* 1889 */         { if (this.jjmatchedPos + 1 < curPos)
/* 1890 */             this.input_stream.backup(curPos - this.jjmatchedPos - 1); 
/* 1891 */           if ((jjtoToken[this.jjmatchedKind >> 6] & 1L << (this.jjmatchedKind & 0x3F)) != 0L) {
/*      */             
/* 1893 */             Token matchedToken = jjFillToken();
/* 1894 */             matchedToken.specialToken = specialToken;
/* 1895 */             if (jjnewLexState[this.jjmatchedKind] != -1)
/* 1896 */               this.curLexState = jjnewLexState[this.jjmatchedKind]; 
/* 1897 */             return matchedToken;
/*      */           } 
/* 1899 */           if ((jjtoSkip[this.jjmatchedKind >> 6] & 1L << (this.jjmatchedKind & 0x3F)) != 0L) {
/*      */             
/* 1901 */             if ((jjtoSpecial[this.jjmatchedKind >> 6] & 1L << (this.jjmatchedKind & 0x3F)) != 0L) {
/*      */               
/* 1903 */               Token matchedToken = jjFillToken();
/* 1904 */               if (specialToken == null) {
/* 1905 */                 specialToken = matchedToken;
/*      */               } else {
/*      */                 
/* 1908 */                 matchedToken.specialToken = specialToken;
/* 1909 */                 specialToken = specialToken.next = matchedToken;
/*      */               } 
/* 1911 */               SkipLexicalActions(matchedToken);
/*      */             } else {
/*      */               
/* 1914 */               SkipLexicalActions(null);
/* 1915 */             }  if (jjnewLexState[this.jjmatchedKind] != -1) {
/* 1916 */               this.curLexState = jjnewLexState[this.jjmatchedKind]; continue label125;
/*      */             }  continue label125;
/*      */           } 
/* 1919 */           this.jjimageLen += this.jjmatchedPos + 1;
/* 1920 */           if (jjnewLexState[this.jjmatchedKind] != -1)
/* 1921 */             this.curLexState = jjnewLexState[this.jjmatchedKind]; 
/* 1922 */           curPos = 0;
/* 1923 */           this.jjmatchedKind = Integer.MAX_VALUE;
/*      */           
/* 1925 */           try { this.curChar = this.input_stream.readChar();
/*      */             
/*      */             continue; }
/* 1928 */           catch (IOException iOException) { break; }  }  break;
/*      */       }  break;
/* 1930 */     }  int error_line = this.input_stream.getEndLine();
/* 1931 */     int error_column = this.input_stream.getEndColumn();
/* 1932 */     String error_after = null;
/* 1933 */     boolean EOFSeen = false;
/*      */     try {
/* 1935 */       this.input_stream.readChar();
/* 1936 */       this.input_stream.backup(1);
/*      */     }
/* 1938 */     catch (IOException e1) {
/* 1939 */       EOFSeen = true;
/* 1940 */       error_after = (curPos <= 1) ? "" : this.input_stream.getImage();
/* 1941 */       if (this.curChar == 10 || this.curChar == 13) {
/* 1942 */         error_line++;
/* 1943 */         error_column = 0;
/*      */       } else {
/*      */         
/* 1946 */         error_column++;
/*      */       } 
/* 1948 */     }  if (!EOFSeen) {
/* 1949 */       this.input_stream.backup(1);
/* 1950 */       error_after = (curPos <= 1) ? "" : this.input_stream.getImage();
/*      */     } 
/* 1952 */     throw new TokenMgrException(EOFSeen, this.curLexState, error_line, error_column, error_after, this.curChar, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void SkipLexicalActions(Token matchedToken) {
/* 1959 */     switch (this.jjmatchedKind) {
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void MoreLexicalActions() {
/* 1967 */     this.jjimageLen += this.lengthOfMatch = this.jjmatchedPos + 1;
/* 1968 */     switch (this.jjmatchedKind) {
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void TokenLexicalActions(Token matchedToken) {
/* 1976 */     switch (this.jjmatchedKind) {
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void jjCheckNAdd(int state) {
/* 1984 */     if (this.jjrounds[state] != this.jjround) {
/*      */       
/* 1986 */       this.jjstateSet[this.jjnewStateCnt++] = state;
/* 1987 */       this.jjrounds[state] = this.jjround;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void jjAddStates(int start, int end) {
/*      */     do {
/* 1993 */       this.jjstateSet[this.jjnewStateCnt++] = jjnextStates[start];
/* 1994 */     } while (start++ != end);
/*      */   }
/*      */   
/*      */   private void jjCheckNAddTwoStates(int state1, int state2) {
/* 1998 */     jjCheckNAdd(state1);
/* 1999 */     jjCheckNAdd(state2);
/*      */   }
/*      */ 
/*      */   
/*      */   private void jjCheckNAddStates(int start, int end) {
/*      */     do {
/* 2005 */       jjCheckNAdd(jjnextStates[start]);
/* 2006 */     } while (start++ != end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ReInit(SimpleCharStream stream) {
/* 2026 */     this.jjmatchedPos = this.jjnewStateCnt = 0;
/*      */ 
/*      */     
/* 2029 */     this.curLexState = this.defaultLexState;
/* 2030 */     this.input_stream = stream;
/* 2031 */     ReInitRounds();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void ReInitRounds() {
/* 2037 */     this.jjround = -2147483647;
/* 2038 */     for (int i = 66; i-- > 0;) {
/* 2039 */       this.jjrounds[i] = Integer.MIN_VALUE;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void ReInit(SimpleCharStream stream, int lexState) {
/* 2045 */     ReInit(stream);
/* 2046 */     SwitchTo(lexState);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void SwitchTo(int lexState) {
/* 2052 */     if (lexState >= 12 || lexState < 0) {
/* 2053 */       throw new TokenMgrException("Error: Ignoring invalid lexical state : " + lexState + ". State unchanged.", 2);
/*      */     }
/* 2055 */     this.curLexState = lexState;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 2060 */   public static final String[] lexStateNames = new String[] { "DEFAULT", "IN_COMMENT", "IN_LC0", "IN_LC1", "IN_LC2", "IN_LC3", "IN_LCN", "IN_LS0", "IN_LS1", "IN_LS2", "IN_LS3", "IN_LSN" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2076 */   public static final int[] jjnewLexState = new int[] { -1, -1, -1, -1, -1, -1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2082 */   static final long[] jjtoToken = new long[] { 6926536226618998785L, 2147483618L };
/*      */ 
/*      */   
/* 2085 */   static final long[] jjtoSkip = new long[] { 8257598L, 0L };
/*      */ 
/*      */   
/* 2088 */   static final long[] jjtoSpecial = new long[] { 8257536L, 0L };
/*      */ 
/*      */   
/* 2091 */   static final long[] jjtoMore = new long[] { 268566464L, 0L };
/*      */   protected SimpleCharStream input_stream; private final int[] jjrounds; private final int[] jjstateSet; private final StringBuilder jjimage; private StringBuilder image; private int jjimageLen;
/*      */   private int lengthOfMatch;
/*      */   protected int curChar;
/*      */   
/* 2096 */   public LuaParserTokenManager(SimpleCharStream stream) { this.jjrounds = new int[66];
/* 2097 */     this.jjstateSet = new int[132];
/* 2098 */     this.jjimage = new StringBuilder();
/* 2099 */     this.image = this.jjimage; this.input_stream = stream; } public LuaParserTokenManager(SimpleCharStream stream, int lexState) { this.jjrounds = new int[66]; this.jjstateSet = new int[132]; this.jjimage = new StringBuilder(); this.image = this.jjimage;
/*      */     ReInit(stream);
/*      */     SwitchTo(lexState); }
/*      */ 
/*      */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\parser\LuaParserTokenManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */