/*      */ package org.luaj.vm2.parser.lua52;
/*      */ 
/*      */ import java.io.IOException;
/*      */ 
/*      */ public class LuaParserTokenManager
/*      */   implements LuaParserConstants {
/*      */   private final int jjStopStringLiteralDfa_0(int pos, long active0, long active1) {
/*    8 */     switch (pos) {
/*      */       
/*      */       case 0:
/*   11 */         if ((active0 & 0x7800L) != 0L || (active1 & 0x2000L) != 0L)
/*   12 */           return 14; 
/*   13 */         if ((active0 & 0x103C0L) != 0L || (active1 & 0x80000L) != 0L)
/*   14 */           return 7; 
/*   15 */         if ((active0 & 0x7FFFFE0000000L) != 0L) {
/*      */           
/*   17 */           this.jjmatchedKind = 51;
/*   18 */           return 17;
/*      */         } 
/*   20 */         if ((active1 & 0x1008200L) != 0L)
/*   21 */           return 31; 
/*   22 */         return -1;
/*      */       case 1:
/*   24 */         if ((active0 & 0x118080000000L) != 0L)
/*   25 */           return 17; 
/*   26 */         if ((active0 & 0x103C0L) != 0L)
/*   27 */           return 6; 
/*   28 */         if ((active0 & 0x7000L) != 0L)
/*   29 */           return 13; 
/*   30 */         if ((active0 & 0x7EE7F60000000L) != 0L) {
/*      */           
/*   32 */           if (this.jjmatchedPos != 1) {
/*      */             
/*   34 */             this.jjmatchedKind = 51;
/*   35 */             this.jjmatchedPos = 1;
/*      */           } 
/*   37 */           return 17;
/*      */         } 
/*   39 */         return -1;
/*      */       case 2:
/*   41 */         if ((active0 & 0x7E26B40000000L) != 0L) {
/*      */           
/*   43 */           this.jjmatchedKind = 51;
/*   44 */           this.jjmatchedPos = 2;
/*   45 */           return 17;
/*      */         } 
/*   47 */         if ((active0 & 0xC1420000000L) != 0L)
/*   48 */           return 17; 
/*   49 */         if ((active0 & 0x3C0L) != 0L)
/*   50 */           return 5; 
/*   51 */         if ((active0 & 0x6000L) != 0L)
/*   52 */           return 12; 
/*   53 */         return -1;
/*      */       case 3:
/*   55 */         if ((active0 & 0x4000L) != 0L)
/*   56 */           return 9; 
/*   57 */         if ((active0 & 0x380L) != 0L)
/*   58 */           return 4; 
/*   59 */         if ((active0 & 0x1804300000000L) != 0L)
/*   60 */           return 17; 
/*   61 */         if ((active0 & 0x6622840000000L) != 0L) {
/*      */           
/*   63 */           if (this.jjmatchedPos != 3) {
/*      */             
/*   65 */             this.jjmatchedKind = 51;
/*   66 */             this.jjmatchedPos = 3;
/*      */           } 
/*   68 */           return 17;
/*      */         } 
/*   70 */         return -1;
/*      */       case 4:
/*   72 */         if ((active0 & 0x300L) != 0L)
/*   73 */           return 3; 
/*   74 */         if ((active0 & 0x6020840000000L) != 0L)
/*   75 */           return 17; 
/*   76 */         if ((active0 & 0x602200000000L) != 0L) {
/*      */           
/*   78 */           this.jjmatchedKind = 51;
/*   79 */           this.jjmatchedPos = 4;
/*   80 */           return 17;
/*      */         } 
/*   82 */         return -1;
/*      */       case 5:
/*   84 */         if ((active0 & 0x600200000000L) != 0L)
/*   85 */           return 17; 
/*   86 */         if ((active0 & 0x2000000000L) != 0L) {
/*      */           
/*   88 */           this.jjmatchedKind = 51;
/*   89 */           this.jjmatchedPos = 5;
/*   90 */           return 17;
/*      */         } 
/*   92 */         if ((active0 & 0x200L) != 0L)
/*   93 */           return 0; 
/*   94 */         return -1;
/*      */       case 6:
/*   96 */         if ((active0 & 0x2000000000L) != 0L) {
/*      */           
/*   98 */           this.jjmatchedKind = 51;
/*   99 */           this.jjmatchedPos = 6;
/*  100 */           return 17;
/*      */         } 
/*  102 */         return -1;
/*      */     } 
/*  104 */     return -1;
/*      */   }
/*      */   
/*      */   private final int jjStartNfa_0(int pos, long active0, long active1) {
/*  108 */     return jjMoveNfa_0(jjStopStringLiteralDfa_0(pos, active0, active1), pos + 1);
/*      */   }
/*      */   
/*      */   private int jjStopAtPos(int pos, int kind) {
/*  112 */     this.jjmatchedKind = kind;
/*  113 */     this.jjmatchedPos = pos;
/*  114 */     return pos + 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa0_0() {
/*  117 */     switch (this.curChar) {
/*      */       
/*      */       case 35:
/*  120 */         return jjStopAtPos(0, 69);
/*      */       case 37:
/*  122 */         return jjStopAtPos(0, 87);
/*      */       case 40:
/*  124 */         return jjStopAtPos(0, 75);
/*      */       case 41:
/*  126 */         return jjStopAtPos(0, 76);
/*      */       case 42:
/*  128 */         return jjStopAtPos(0, 84);
/*      */       case 43:
/*  130 */         return jjStopAtPos(0, 82);
/*      */       case 44:
/*  132 */         return jjStopAtPos(0, 72);
/*      */       case 45:
/*  134 */         this.jjmatchedKind = 83;
/*  135 */         return jjMoveStringLiteralDfa1_0(66496L, 0L);
/*      */       case 46:
/*  137 */         this.jjmatchedKind = 73;
/*  138 */         return jjMoveStringLiteralDfa1_0(0L, 16809984L);
/*      */       case 47:
/*  140 */         return jjStopAtPos(0, 85);
/*      */       case 58:
/*  142 */         this.jjmatchedKind = 74;
/*  143 */         return jjMoveStringLiteralDfa1_0(0L, 2L);
/*      */       case 59:
/*  145 */         return jjStopAtPos(0, 70);
/*      */       case 60:
/*  147 */         this.jjmatchedKind = 89;
/*  148 */         return jjMoveStringLiteralDfa1_0(0L, 67108864L);
/*      */       case 61:
/*  150 */         this.jjmatchedKind = 71;
/*  151 */         return jjMoveStringLiteralDfa1_0(0L, 536870912L);
/*      */       case 62:
/*  153 */         this.jjmatchedKind = 91;
/*  154 */         return jjMoveStringLiteralDfa1_0(0L, 268435456L);
/*      */       case 91:
/*  156 */         this.jjmatchedKind = 77;
/*  157 */         return jjMoveStringLiteralDfa1_0(30720L, 0L);
/*      */       case 93:
/*  159 */         return jjStopAtPos(0, 78);
/*      */       case 94:
/*  161 */         return jjStopAtPos(0, 86);
/*      */       case 97:
/*  163 */         return jjMoveStringLiteralDfa1_0(536870912L, 0L);
/*      */       case 98:
/*  165 */         return jjMoveStringLiteralDfa1_0(1073741824L, 0L);
/*      */       case 100:
/*  167 */         return jjMoveStringLiteralDfa1_0(2147483648L, 0L);
/*      */       case 101:
/*  169 */         return jjMoveStringLiteralDfa1_0(30064771072L, 0L);
/*      */       case 102:
/*  171 */         return jjMoveStringLiteralDfa1_0(240518168576L, 0L);
/*      */       case 103:
/*  173 */         return jjMoveStringLiteralDfa1_0(274877906944L, 0L);
/*      */       case 105:
/*  175 */         return jjMoveStringLiteralDfa1_0(1649267441664L, 0L);
/*      */       case 108:
/*  177 */         return jjMoveStringLiteralDfa1_0(2199023255552L, 0L);
/*      */       case 110:
/*  179 */         return jjMoveStringLiteralDfa1_0(13194139533312L, 0L);
/*      */       case 111:
/*  181 */         return jjMoveStringLiteralDfa1_0(17592186044416L, 0L);
/*      */       case 114:
/*  183 */         return jjMoveStringLiteralDfa1_0(105553116266496L, 0L);
/*      */       case 116:
/*  185 */         return jjMoveStringLiteralDfa1_0(422212465065984L, 0L);
/*      */       case 117:
/*  187 */         return jjMoveStringLiteralDfa1_0(562949953421312L, 0L);
/*      */       case 119:
/*  189 */         return jjMoveStringLiteralDfa1_0(1125899906842624L, 0L);
/*      */       case 123:
/*  191 */         return jjStopAtPos(0, 80);
/*      */       case 125:
/*  193 */         return jjStopAtPos(0, 81);
/*      */       case 126:
/*  195 */         return jjMoveStringLiteralDfa1_0(0L, 1073741824L);
/*      */     } 
/*  197 */     return jjMoveNfa_0(8, 0);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_0(long active0, long active1) {
/*      */     try {
/*  201 */       this.curChar = this.input_stream.readChar();
/*  202 */     } catch (IOException e) {
/*  203 */       jjStopStringLiteralDfa_0(0, active0, active1);
/*  204 */       return 1;
/*      */     } 
/*  206 */     switch (this.curChar) {
/*      */       
/*      */       case 45:
/*  209 */         if ((active0 & 0x10000L) != 0L) {
/*      */           
/*  211 */           this.jjmatchedKind = 16;
/*  212 */           this.jjmatchedPos = 1;
/*      */         } 
/*  214 */         return jjMoveStringLiteralDfa2_0(active0, 960L, active1, 0L);
/*      */       case 46:
/*  216 */         if ((active1 & 0x1000000L) != 0L) {
/*      */           
/*  218 */           this.jjmatchedKind = 88;
/*  219 */           this.jjmatchedPos = 1;
/*      */         } 
/*  221 */         return jjMoveStringLiteralDfa2_0(active0, 0L, active1, 32768L);
/*      */       case 58:
/*  223 */         if ((active1 & 0x2L) != 0L)
/*  224 */           return jjStopAtPos(1, 65); 
/*      */         break;
/*      */       case 61:
/*  227 */         if ((active1 & 0x4000000L) != 0L)
/*  228 */           return jjStopAtPos(1, 90); 
/*  229 */         if ((active1 & 0x10000000L) != 0L)
/*  230 */           return jjStopAtPos(1, 92); 
/*  231 */         if ((active1 & 0x20000000L) != 0L)
/*  232 */           return jjStopAtPos(1, 93); 
/*  233 */         if ((active1 & 0x40000000L) != 0L)
/*  234 */           return jjStopAtPos(1, 94); 
/*  235 */         return jjMoveStringLiteralDfa2_0(active0, 28672L, active1, 0L);
/*      */       case 91:
/*  237 */         if ((active0 & 0x800L) != 0L)
/*  238 */           return jjStopAtPos(1, 11); 
/*      */         break;
/*      */       case 97:
/*  241 */         return jjMoveStringLiteralDfa2_0(active0, 34359738368L, active1, 0L);
/*      */       case 101:
/*  243 */         return jjMoveStringLiteralDfa2_0(active0, 105553116266496L, active1, 0L);
/*      */       case 102:
/*  245 */         if ((active0 & 0x8000000000L) != 0L)
/*  246 */           return jjStartNfaWithStates_0(1, 39, 17); 
/*      */         break;
/*      */       case 104:
/*  249 */         return jjMoveStringLiteralDfa2_0(active0, 1266637395197952L, active1, 0L);
/*      */       case 105:
/*  251 */         return jjMoveStringLiteralDfa2_0(active0, 4398046511104L, active1, 0L);
/*      */       case 108:
/*  253 */         return jjMoveStringLiteralDfa2_0(active0, 12884901888L, active1, 0L);
/*      */       case 110:
/*  255 */         if ((active0 & 0x10000000000L) != 0L)
/*  256 */           return jjStartNfaWithStates_0(1, 40, 17); 
/*  257 */         return jjMoveStringLiteralDfa2_0(active0, 562967670161408L, active1, 0L);
/*      */       case 111:
/*  259 */         if ((active0 & 0x80000000L) != 0L)
/*  260 */           return jjStartNfaWithStates_0(1, 31, 17); 
/*  261 */         return jjMoveStringLiteralDfa2_0(active0, 11338713661440L, active1, 0L);
/*      */       case 114:
/*  263 */         if ((active0 & 0x100000000000L) != 0L)
/*  264 */           return jjStartNfaWithStates_0(1, 44, 17); 
/*  265 */         return jjMoveStringLiteralDfa2_0(active0, 281476050452480L, active1, 0L);
/*      */       case 117:
/*  267 */         return jjMoveStringLiteralDfa2_0(active0, 137438953472L, active1, 0L);
/*      */     } 
/*      */ 
/*      */     
/*  271 */     return jjStartNfa_0(0, active0, active1);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa2_0(long old0, long active0, long old1, long active1) {
/*  274 */     if (((active0 &= old0) | (active1 &= old1)) == 0L)
/*  275 */       return jjStartNfa_0(0, old0, old1);  try {
/*  276 */       this.curChar = this.input_stream.readChar();
/*  277 */     } catch (IOException e) {
/*  278 */       jjStopStringLiteralDfa_0(1, active0, active1);
/*  279 */       return 2;
/*      */     } 
/*  281 */     switch (this.curChar) {
/*      */       
/*      */       case 46:
/*  284 */         if ((active1 & 0x8000L) != 0L)
/*  285 */           return jjStopAtPos(2, 79); 
/*      */         break;
/*      */       case 61:
/*  288 */         return jjMoveStringLiteralDfa3_0(active0, 24576L, active1, 0L);
/*      */       case 91:
/*  290 */         if ((active0 & 0x1000L) != 0L)
/*  291 */           return jjStopAtPos(2, 12); 
/*  292 */         return jjMoveStringLiteralDfa3_0(active0, 960L, active1, 0L);
/*      */       case 99:
/*  294 */         return jjMoveStringLiteralDfa3_0(active0, 2199023255552L, active1, 0L);
/*      */       case 100:
/*  296 */         if ((active0 & 0x20000000L) != 0L)
/*  297 */           return jjStartNfaWithStates_0(2, 29, 17); 
/*  298 */         if ((active0 & 0x400000000L) != 0L)
/*  299 */           return jjStartNfaWithStates_0(2, 34, 17); 
/*      */         break;
/*      */       case 101:
/*  302 */         return jjMoveStringLiteralDfa3_0(active0, 140738562097152L, active1, 0L);
/*      */       case 105:
/*  304 */         return jjMoveStringLiteralDfa3_0(active0, 1125899906842624L, active1, 0L);
/*      */       case 108:
/*  306 */         if ((active0 & 0x40000000000L) != 0L)
/*  307 */           return jjStartNfaWithStates_0(2, 42, 17); 
/*  308 */         return jjMoveStringLiteralDfa3_0(active0, 34359738368L, active1, 0L);
/*      */       case 110:
/*  310 */         return jjMoveStringLiteralDfa3_0(active0, 137438953472L, active1, 0L);
/*      */       case 112:
/*  312 */         return jjMoveStringLiteralDfa3_0(active0, 70368744177664L, active1, 0L);
/*      */       case 114:
/*  314 */         if ((active0 & 0x1000000000L) != 0L)
/*  315 */           return jjStartNfaWithStates_0(2, 36, 17); 
/*      */         break;
/*      */       case 115:
/*  318 */         return jjMoveStringLiteralDfa3_0(active0, 12884901888L, active1, 0L);
/*      */       case 116:
/*  320 */         if ((active0 & 0x80000000000L) != 0L)
/*  321 */           return jjStartNfaWithStates_0(2, 43, 17); 
/*  322 */         return jjMoveStringLiteralDfa3_0(active0, 598409203417088L, active1, 0L);
/*      */       case 117:
/*  324 */         return jjMoveStringLiteralDfa3_0(active0, 281474976710656L, active1, 0L);
/*      */     } 
/*      */ 
/*      */     
/*  328 */     return jjStartNfa_0(1, active0, active1);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa3_0(long old0, long active0, long old1, long active1) {
/*  331 */     if (((active0 &= old0) | (active1 &= old1)) == 0L)
/*  332 */       return jjStartNfa_0(1, old0, old1);  try {
/*  333 */       this.curChar = this.input_stream.readChar();
/*  334 */     } catch (IOException e) {
/*  335 */       jjStopStringLiteralDfa_0(2, active0, 0L);
/*  336 */       return 3;
/*      */     } 
/*  338 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/*  341 */         return jjMoveStringLiteralDfa4_0(active0, 17280L);
/*      */       case 91:
/*  343 */         if ((active0 & 0x40L) != 0L)
/*  344 */           return jjStopAtPos(3, 6); 
/*  345 */         if ((active0 & 0x2000L) != 0L)
/*  346 */           return jjStopAtPos(3, 13); 
/*      */         break;
/*      */       case 97:
/*  349 */         return jjMoveStringLiteralDfa4_0(active0, 2200096997376L);
/*      */       case 99:
/*  351 */         return jjMoveStringLiteralDfa4_0(active0, 137438953472L);
/*      */       case 101:
/*  353 */         if ((active0 & 0x100000000L) != 0L) {
/*      */           
/*  355 */           this.jjmatchedKind = 32;
/*  356 */           this.jjmatchedPos = 3;
/*      */         }
/*  358 */         else if ((active0 & 0x1000000000000L) != 0L) {
/*  359 */           return jjStartNfaWithStates_0(3, 48, 17);
/*  360 */         }  return jjMoveStringLiteralDfa4_0(active0, 70377334112256L);
/*      */       case 105:
/*  362 */         return jjMoveStringLiteralDfa4_0(active0, 562949953421312L);
/*      */       case 108:
/*  364 */         return jjMoveStringLiteralDfa4_0(active0, 1125899906842624L);
/*      */       case 110:
/*  366 */         if ((active0 & 0x800000000000L) != 0L)
/*  367 */           return jjStartNfaWithStates_0(3, 47, 17); 
/*      */         break;
/*      */       case 111:
/*  370 */         if ((active0 & 0x4000000000L) != 0L)
/*  371 */           return jjStartNfaWithStates_0(3, 38, 17); 
/*      */         break;
/*      */       case 115:
/*  374 */         return jjMoveStringLiteralDfa4_0(active0, 34359738368L);
/*      */       case 117:
/*  376 */         return jjMoveStringLiteralDfa4_0(active0, 35184372088832L);
/*      */     } 
/*      */ 
/*      */     
/*  380 */     return jjStartNfa_0(2, active0, 0L);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa4_0(long old0, long active0) {
/*  383 */     if ((active0 &= old0) == 0L)
/*  384 */       return jjStartNfa_0(2, old0, 0L);  try {
/*  385 */       this.curChar = this.input_stream.readChar();
/*  386 */     } catch (IOException e) {
/*  387 */       jjStopStringLiteralDfa_0(3, active0, 0L);
/*  388 */       return 4;
/*      */     } 
/*  390 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/*  393 */         return jjMoveStringLiteralDfa5_0(active0, 768L);
/*      */       case 91:
/*  395 */         if ((active0 & 0x80L) != 0L)
/*  396 */           return jjStopAtPos(4, 7); 
/*  397 */         if ((active0 & 0x4000L) != 0L)
/*  398 */           return jjStopAtPos(4, 14); 
/*      */         break;
/*      */       case 97:
/*  401 */         return jjMoveStringLiteralDfa5_0(active0, 70368744177664L);
/*      */       case 101:
/*  403 */         if ((active0 & 0x800000000L) != 0L)
/*  404 */           return jjStartNfaWithStates_0(4, 35, 17); 
/*  405 */         if ((active0 & 0x4000000000000L) != 0L)
/*  406 */           return jjStartNfaWithStates_0(4, 50, 17); 
/*      */         break;
/*      */       case 105:
/*  409 */         return jjMoveStringLiteralDfa5_0(active0, 8589934592L);
/*      */       case 107:
/*  411 */         if ((active0 & 0x40000000L) != 0L)
/*  412 */           return jjStartNfaWithStates_0(4, 30, 17); 
/*      */         break;
/*      */       case 108:
/*  415 */         if ((active0 & 0x20000000000L) != 0L)
/*  416 */           return jjStartNfaWithStates_0(4, 41, 17); 
/*  417 */         if ((active0 & 0x2000000000000L) != 0L)
/*  418 */           return jjStartNfaWithStates_0(4, 49, 17); 
/*      */         break;
/*      */       case 114:
/*  421 */         return jjMoveStringLiteralDfa5_0(active0, 35184372088832L);
/*      */       case 116:
/*  423 */         return jjMoveStringLiteralDfa5_0(active0, 137438953472L);
/*      */     } 
/*      */ 
/*      */     
/*  427 */     return jjStartNfa_0(3, active0, 0L);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa5_0(long old0, long active0) {
/*  430 */     if ((active0 &= old0) == 0L)
/*  431 */       return jjStartNfa_0(3, old0, 0L);  try {
/*  432 */       this.curChar = this.input_stream.readChar();
/*  433 */     } catch (IOException e) {
/*  434 */       jjStopStringLiteralDfa_0(4, active0, 0L);
/*  435 */       return 5;
/*      */     } 
/*  437 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/*  440 */         return jjMoveStringLiteralDfa6_0(active0, 512L);
/*      */       case 91:
/*  442 */         if ((active0 & 0x100L) != 0L)
/*  443 */           return jjStopAtPos(5, 8); 
/*      */         break;
/*      */       case 102:
/*  446 */         if ((active0 & 0x200000000L) != 0L)
/*  447 */           return jjStartNfaWithStates_0(5, 33, 17); 
/*      */         break;
/*      */       case 105:
/*  450 */         return jjMoveStringLiteralDfa6_0(active0, 137438953472L);
/*      */       case 110:
/*  452 */         if ((active0 & 0x200000000000L) != 0L)
/*  453 */           return jjStartNfaWithStates_0(5, 45, 17); 
/*      */         break;
/*      */       case 116:
/*  456 */         if ((active0 & 0x400000000000L) != 0L) {
/*  457 */           return jjStartNfaWithStates_0(5, 46, 17);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  462 */     return jjStartNfa_0(4, active0, 0L);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa6_0(long old0, long active0) {
/*  465 */     if ((active0 &= old0) == 0L)
/*  466 */       return jjStartNfa_0(4, old0, 0L);  try {
/*  467 */       this.curChar = this.input_stream.readChar();
/*  468 */     } catch (IOException e) {
/*  469 */       jjStopStringLiteralDfa_0(5, active0, 0L);
/*  470 */       return 6;
/*      */     } 
/*  472 */     switch (this.curChar) {
/*      */       
/*      */       case 91:
/*  475 */         if ((active0 & 0x200L) != 0L)
/*  476 */           return jjStopAtPos(6, 9); 
/*      */         break;
/*      */       case 111:
/*  479 */         return jjMoveStringLiteralDfa7_0(active0, 137438953472L);
/*      */     } 
/*      */ 
/*      */     
/*  483 */     return jjStartNfa_0(5, active0, 0L);
/*      */   }
/*      */   private int jjMoveStringLiteralDfa7_0(long old0, long active0) {
/*  486 */     if ((active0 &= old0) == 0L)
/*  487 */       return jjStartNfa_0(5, old0, 0L);  try {
/*  488 */       this.curChar = this.input_stream.readChar();
/*  489 */     } catch (IOException e) {
/*  490 */       jjStopStringLiteralDfa_0(6, active0, 0L);
/*  491 */       return 7;
/*      */     } 
/*  493 */     switch (this.curChar) {
/*      */       
/*      */       case 110:
/*  496 */         if ((active0 & 0x2000000000L) != 0L) {
/*  497 */           return jjStartNfaWithStates_0(7, 37, 17);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  502 */     return jjStartNfa_0(6, active0, 0L);
/*      */   }
/*      */   
/*      */   private int jjStartNfaWithStates_0(int pos, int kind, int state) {
/*  506 */     this.jjmatchedKind = kind;
/*  507 */     this.jjmatchedPos = pos; 
/*  508 */     try { this.curChar = this.input_stream.readChar(); }
/*  509 */     catch (IOException e) { return pos + 1; }
/*  510 */      return jjMoveNfa_0(state, pos + 1);
/*      */   }
/*  512 */   static final long[] jjbitVec0 = new long[] { 0L, 0L, -1L, -1L };
/*      */ 
/*      */ 
/*      */   
/*      */   private int jjMoveNfa_0(int startState, int curPos) {
/*  517 */     int startsAt = 0;
/*  518 */     this.jjnewStateCnt = 66;
/*  519 */     int i = 1;
/*  520 */     this.jjstateSet[0] = startState;
/*  521 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/*  524 */       if (++this.jjround == Integer.MAX_VALUE)
/*  525 */         ReInitRounds(); 
/*  526 */       if (this.curChar < 64) {
/*      */         
/*  528 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/*  531 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 8:
/*  534 */               if ((0x3FF000000000000L & l) != 0L) {
/*      */                 
/*  536 */                 if (kind > 52)
/*  537 */                   kind = 52; 
/*  538 */                 jjCheckNAddStates(0, 3);
/*      */               }
/*  540 */               else if (this.curChar == 39) {
/*  541 */                 jjCheckNAddStates(4, 6);
/*  542 */               } else if (this.curChar == 34) {
/*  543 */                 jjCheckNAddStates(7, 9);
/*  544 */               } else if (this.curChar == 46) {
/*  545 */                 jjCheckNAdd(31);
/*  546 */               } else if (this.curChar == 45) {
/*  547 */                 this.jjstateSet[this.jjnewStateCnt++] = 7;
/*  548 */               }  if (this.curChar == 48)
/*  549 */                 this.jjstateSet[this.jjnewStateCnt++] = 19; 
/*      */               break;
/*      */             case 0:
/*      */             case 1:
/*  553 */               if (this.curChar == 61)
/*  554 */                 jjCheckNAddTwoStates(1, 2); 
/*      */               break;
/*      */             case 3:
/*  557 */               if (this.curChar == 61)
/*  558 */                 this.jjstateSet[this.jjnewStateCnt++] = 0; 
/*      */               break;
/*      */             case 4:
/*  561 */               if (this.curChar == 61)
/*  562 */                 this.jjstateSet[this.jjnewStateCnt++] = 3; 
/*      */               break;
/*      */             case 5:
/*  565 */               if (this.curChar == 61)
/*  566 */                 this.jjstateSet[this.jjnewStateCnt++] = 4; 
/*      */               break;
/*      */             case 7:
/*  569 */               if (this.curChar == 45)
/*  570 */                 this.jjstateSet[this.jjnewStateCnt++] = 6; 
/*      */               break;
/*      */             case 9:
/*      */             case 10:
/*  574 */               if (this.curChar == 61)
/*  575 */                 jjCheckNAddTwoStates(10, 11); 
/*      */               break;
/*      */             case 12:
/*  578 */               if (this.curChar == 61)
/*  579 */                 this.jjstateSet[this.jjnewStateCnt++] = 9; 
/*      */               break;
/*      */             case 13:
/*  582 */               if (this.curChar == 61)
/*  583 */                 this.jjstateSet[this.jjnewStateCnt++] = 12; 
/*      */               break;
/*      */             case 14:
/*  586 */               if (this.curChar == 61)
/*  587 */                 this.jjstateSet[this.jjnewStateCnt++] = 13; 
/*      */               break;
/*      */             case 17:
/*  590 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  592 */               if (kind > 51)
/*  593 */                 kind = 51; 
/*  594 */               this.jjstateSet[this.jjnewStateCnt++] = 17;
/*      */               break;
/*      */             case 18:
/*  597 */               if (this.curChar == 48)
/*  598 */                 this.jjstateSet[this.jjnewStateCnt++] = 19; 
/*      */               break;
/*      */             case 20:
/*  601 */               if (this.curChar == 46)
/*  602 */                 jjCheckNAdd(21); 
/*      */               break;
/*      */             case 21:
/*  605 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  607 */               if (kind > 52)
/*  608 */                 kind = 52; 
/*  609 */               jjCheckNAddTwoStates(21, 22);
/*      */               break;
/*      */             case 23:
/*  612 */               if ((0x280000000000L & l) != 0L)
/*  613 */                 jjCheckNAdd(24); 
/*      */               break;
/*      */             case 24:
/*  616 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  618 */               if (kind > 52)
/*  619 */                 kind = 52; 
/*  620 */               jjCheckNAdd(24);
/*      */               break;
/*      */             case 25:
/*  623 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  625 */               if (kind > 52)
/*  626 */                 kind = 52; 
/*  627 */               jjCheckNAddStates(10, 13);
/*      */               break;
/*      */             case 26:
/*  630 */               if ((0x3FF000000000000L & l) != 0L)
/*  631 */                 jjCheckNAddTwoStates(26, 27); 
/*      */               break;
/*      */             case 27:
/*  634 */               if (this.curChar != 46)
/*      */                 break; 
/*  636 */               if (kind > 52)
/*  637 */                 kind = 52; 
/*  638 */               jjCheckNAddTwoStates(28, 22);
/*      */               break;
/*      */             case 28:
/*  641 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  643 */               if (kind > 52)
/*  644 */                 kind = 52; 
/*  645 */               jjCheckNAddTwoStates(28, 22);
/*      */               break;
/*      */             case 29:
/*  648 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  650 */               if (kind > 52)
/*  651 */                 kind = 52; 
/*  652 */               jjCheckNAddTwoStates(29, 22);
/*      */               break;
/*      */             case 30:
/*  655 */               if (this.curChar == 46)
/*  656 */                 jjCheckNAdd(31); 
/*      */               break;
/*      */             case 31:
/*  659 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  661 */               if (kind > 52)
/*  662 */                 kind = 52; 
/*  663 */               jjCheckNAddTwoStates(31, 32);
/*      */               break;
/*      */             case 33:
/*  666 */               if ((0x280000000000L & l) != 0L)
/*  667 */                 jjCheckNAdd(34); 
/*      */               break;
/*      */             case 34:
/*  670 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  672 */               if (kind > 52)
/*  673 */                 kind = 52; 
/*  674 */               jjCheckNAdd(34);
/*      */               break;
/*      */             case 35:
/*  677 */               if (this.curChar == 34)
/*  678 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 36:
/*  681 */               if ((0xFFFFFFFBFFFFFFFFL & l) != 0L)
/*  682 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 37:
/*  685 */               if (this.curChar == 34 && kind > 61)
/*  686 */                 kind = 61; 
/*      */               break;
/*      */             case 39:
/*  689 */               jjCheckNAddStates(7, 9);
/*      */               break;
/*      */             case 41:
/*  692 */               if ((0x3FF000000000000L & l) != 0L)
/*  693 */                 this.jjstateSet[this.jjnewStateCnt++] = 42; 
/*      */               break;
/*      */             case 42:
/*  696 */               if ((0x3FF000000000000L & l) != 0L)
/*  697 */                 this.jjstateSet[this.jjnewStateCnt++] = 43; 
/*      */               break;
/*      */             case 43:
/*  700 */               if ((0x3FF000000000000L & l) != 0L)
/*  701 */                 this.jjstateSet[this.jjnewStateCnt++] = 44; 
/*      */               break;
/*      */             case 44:
/*      */             case 47:
/*  705 */               if ((0x3FF000000000000L & l) != 0L)
/*  706 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 45:
/*  709 */               if ((0x3FF000000000000L & l) != 0L)
/*  710 */                 jjCheckNAddStates(14, 17); 
/*      */               break;
/*      */             case 46:
/*  713 */               if ((0x3FF000000000000L & l) != 0L)
/*  714 */                 jjCheckNAddStates(18, 21); 
/*      */               break;
/*      */             case 48:
/*  717 */               if (this.curChar == 39)
/*  718 */                 jjCheckNAddStates(4, 6); 
/*      */               break;
/*      */             case 49:
/*  721 */               if ((0xFFFFFF7FFFFFFFFFL & l) != 0L)
/*  722 */                 jjCheckNAddStates(4, 6); 
/*      */               break;
/*      */             case 50:
/*  725 */               if (this.curChar == 39 && kind > 62)
/*  726 */                 kind = 62; 
/*      */               break;
/*      */             case 52:
/*  729 */               jjCheckNAddStates(4, 6);
/*      */               break;
/*      */             case 54:
/*  732 */               if ((0x3FF000000000000L & l) != 0L)
/*  733 */                 this.jjstateSet[this.jjnewStateCnt++] = 55; 
/*      */               break;
/*      */             case 55:
/*  736 */               if ((0x3FF000000000000L & l) != 0L)
/*  737 */                 this.jjstateSet[this.jjnewStateCnt++] = 56; 
/*      */               break;
/*      */             case 56:
/*  740 */               if ((0x3FF000000000000L & l) != 0L)
/*  741 */                 this.jjstateSet[this.jjnewStateCnt++] = 57; 
/*      */               break;
/*      */             case 57:
/*      */             case 60:
/*  745 */               if ((0x3FF000000000000L & l) != 0L)
/*  746 */                 jjCheckNAddStates(4, 6); 
/*      */               break;
/*      */             case 58:
/*  749 */               if ((0x3FF000000000000L & l) != 0L)
/*  750 */                 jjCheckNAddStates(22, 25); 
/*      */               break;
/*      */             case 59:
/*  753 */               if ((0x3FF000000000000L & l) != 0L)
/*  754 */                 jjCheckNAddStates(26, 29); 
/*      */               break;
/*      */             case 61:
/*  757 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  759 */               if (kind > 52)
/*  760 */                 kind = 52; 
/*  761 */               jjCheckNAddStates(0, 3);
/*      */               break;
/*      */             case 62:
/*  764 */               if ((0x3FF000000000000L & l) != 0L)
/*  765 */                 jjCheckNAddTwoStates(62, 63); 
/*      */               break;
/*      */             case 63:
/*  768 */               if (this.curChar != 46)
/*      */                 break; 
/*  770 */               if (kind > 52)
/*  771 */                 kind = 52; 
/*  772 */               jjCheckNAddTwoStates(64, 32);
/*      */               break;
/*      */             case 64:
/*  775 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  777 */               if (kind > 52)
/*  778 */                 kind = 52; 
/*  779 */               jjCheckNAddTwoStates(64, 32);
/*      */               break;
/*      */             case 65:
/*  782 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  784 */               if (kind > 52)
/*  785 */                 kind = 52; 
/*  786 */               jjCheckNAddTwoStates(65, 32);
/*      */               break;
/*      */           } 
/*      */         
/*  790 */         } while (i != startsAt);
/*      */       }
/*  792 */       else if (this.curChar < 128) {
/*      */         
/*  794 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/*  797 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 8:
/*  800 */               if ((0x7FFFFFE87FFFFFEL & l) != 0L) {
/*      */                 
/*  802 */                 if (kind > 51)
/*  803 */                   kind = 51; 
/*  804 */                 jjCheckNAdd(17); break;
/*      */               } 
/*  806 */               if (this.curChar == 91)
/*  807 */                 this.jjstateSet[this.jjnewStateCnt++] = 14; 
/*      */               break;
/*      */             case 2:
/*  810 */               if (this.curChar == 91 && kind > 10)
/*  811 */                 kind = 10; 
/*      */               break;
/*      */             case 6:
/*  814 */               if (this.curChar == 91)
/*  815 */                 this.jjstateSet[this.jjnewStateCnt++] = 5; 
/*      */               break;
/*      */             case 11:
/*  818 */               if (this.curChar == 91 && kind > 15)
/*  819 */                 kind = 15; 
/*      */               break;
/*      */             case 15:
/*  822 */               if (this.curChar == 91)
/*  823 */                 this.jjstateSet[this.jjnewStateCnt++] = 14; 
/*      */               break;
/*      */             case 16:
/*      */             case 17:
/*  827 */               if ((0x7FFFFFE87FFFFFEL & l) == 0L)
/*      */                 break; 
/*  829 */               if (kind > 51)
/*  830 */                 kind = 51; 
/*  831 */               jjCheckNAdd(17);
/*      */               break;
/*      */             case 19:
/*  834 */               if ((0x100000001000000L & l) != 0L)
/*  835 */                 jjAddStates(30, 31); 
/*      */               break;
/*      */             case 21:
/*  838 */               if ((0x7E0000007EL & l) == 0L)
/*      */                 break; 
/*  840 */               if (kind > 52)
/*  841 */                 kind = 52; 
/*  842 */               jjCheckNAddTwoStates(21, 22);
/*      */               break;
/*      */             case 22:
/*  845 */               if ((0x1002000010020L & l) != 0L)
/*  846 */                 jjAddStates(32, 33); 
/*      */               break;
/*      */             case 25:
/*  849 */               if ((0x7E0000007EL & l) == 0L)
/*      */                 break; 
/*  851 */               if (kind > 52)
/*  852 */                 kind = 52; 
/*  853 */               jjCheckNAddStates(10, 13);
/*      */               break;
/*      */             case 26:
/*  856 */               if ((0x7E0000007EL & l) != 0L)
/*  857 */                 jjCheckNAddTwoStates(26, 27); 
/*      */               break;
/*      */             case 28:
/*  860 */               if ((0x7E0000007EL & l) == 0L)
/*      */                 break; 
/*  862 */               if (kind > 52)
/*  863 */                 kind = 52; 
/*  864 */               jjCheckNAddTwoStates(28, 22);
/*      */               break;
/*      */             case 29:
/*  867 */               if ((0x7E0000007EL & l) == 0L)
/*      */                 break; 
/*  869 */               if (kind > 52)
/*  870 */                 kind = 52; 
/*  871 */               jjCheckNAddTwoStates(29, 22);
/*      */               break;
/*      */             case 32:
/*  874 */               if ((0x2000000020L & l) != 0L)
/*  875 */                 jjAddStates(34, 35); 
/*      */               break;
/*      */             case 36:
/*  878 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L)
/*  879 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 38:
/*  882 */               if (this.curChar == 92)
/*  883 */                 jjAddStates(36, 38); 
/*      */               break;
/*      */             case 39:
/*  886 */               jjCheckNAddStates(7, 9);
/*      */               break;
/*      */             case 40:
/*  889 */               if (this.curChar == 117)
/*  890 */                 this.jjstateSet[this.jjnewStateCnt++] = 41; 
/*      */               break;
/*      */             case 41:
/*  893 */               if ((0x7E0000007EL & l) != 0L)
/*  894 */                 this.jjstateSet[this.jjnewStateCnt++] = 42; 
/*      */               break;
/*      */             case 42:
/*  897 */               if ((0x7E0000007EL & l) != 0L)
/*  898 */                 this.jjstateSet[this.jjnewStateCnt++] = 43; 
/*      */               break;
/*      */             case 43:
/*  901 */               if ((0x7E0000007EL & l) != 0L)
/*  902 */                 this.jjstateSet[this.jjnewStateCnt++] = 44; 
/*      */               break;
/*      */             case 44:
/*  905 */               if ((0x7E0000007EL & l) != 0L)
/*  906 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 49:
/*  909 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L)
/*  910 */                 jjCheckNAddStates(4, 6); 
/*      */               break;
/*      */             case 51:
/*  913 */               if (this.curChar == 92)
/*  914 */                 jjAddStates(39, 41); 
/*      */               break;
/*      */             case 52:
/*  917 */               jjCheckNAddStates(4, 6);
/*      */               break;
/*      */             case 53:
/*  920 */               if (this.curChar == 117)
/*  921 */                 this.jjstateSet[this.jjnewStateCnt++] = 54; 
/*      */               break;
/*      */             case 54:
/*  924 */               if ((0x7E0000007EL & l) != 0L)
/*  925 */                 this.jjstateSet[this.jjnewStateCnt++] = 55; 
/*      */               break;
/*      */             case 55:
/*  928 */               if ((0x7E0000007EL & l) != 0L)
/*  929 */                 this.jjstateSet[this.jjnewStateCnt++] = 56; 
/*      */               break;
/*      */             case 56:
/*  932 */               if ((0x7E0000007EL & l) != 0L)
/*  933 */                 this.jjstateSet[this.jjnewStateCnt++] = 57; 
/*      */               break;
/*      */             case 57:
/*  936 */               if ((0x7E0000007EL & l) != 0L) {
/*  937 */                 jjCheckNAddStates(4, 6);
/*      */               }
/*      */               break;
/*      */           } 
/*  941 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/*  945 */         int i2 = (this.curChar & 0xFF) >> 6;
/*  946 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/*  949 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 36:
/*      */             case 39:
/*  953 */               if ((jjbitVec0[i2] & l2) != 0L)
/*  954 */                 jjCheckNAddStates(7, 9); 
/*      */               break;
/*      */             case 49:
/*      */             case 52:
/*  958 */               if ((jjbitVec0[i2] & l2) != 0L) {
/*  959 */                 jjCheckNAddStates(4, 6);
/*      */               }
/*      */               break;
/*      */           } 
/*  963 */         } while (i != startsAt);
/*      */       } 
/*  965 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/*  967 */         this.jjmatchedKind = kind;
/*  968 */         this.jjmatchedPos = curPos;
/*  969 */         kind = Integer.MAX_VALUE;
/*      */       } 
/*  971 */       curPos++;
/*  972 */       i = this.jjnewStateCnt;
/*  973 */       this.jjnewStateCnt = startsAt;
/*  974 */       startsAt = 66 - this.jjnewStateCnt;
/*  975 */       if (i == startsAt)
/*  976 */         return curPos;  
/*  977 */       try { this.curChar = this.input_stream.readChar(); }
/*  978 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*      */   }
/*      */   private int jjMoveStringLiteralDfa0_1() {
/*  983 */     return jjMoveNfa_1(4, 0);
/*      */   }
/*      */   
/*      */   private int jjMoveNfa_1(int startState, int curPos) {
/*  987 */     int startsAt = 0;
/*  988 */     this.jjnewStateCnt = 4;
/*  989 */     int i = 1;
/*  990 */     this.jjstateSet[0] = startState;
/*  991 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/*  994 */       if (++this.jjround == Integer.MAX_VALUE)
/*  995 */         ReInitRounds(); 
/*  996 */       if (this.curChar < 64) {
/*      */         
/*  998 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/* 1001 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 4:
/* 1004 */               if ((0xFFFFFFFFFFFFDBFFL & l) != 0L) {
/*      */                 
/* 1006 */                 if (kind > 17)
/* 1007 */                   kind = 17; 
/* 1008 */                 jjCheckNAddStates(42, 44);
/*      */               }
/* 1010 */               else if ((0x2400L & l) != 0L) {
/*      */                 
/* 1012 */                 if (kind > 17)
/* 1013 */                   kind = 17; 
/*      */               } 
/* 1015 */               if (this.curChar == 13)
/* 1016 */                 this.jjstateSet[this.jjnewStateCnt++] = 2; 
/*      */               break;
/*      */             case 0:
/* 1019 */               if ((0xFFFFFFFFFFFFDBFFL & l) == 0L)
/*      */                 break; 
/* 1021 */               kind = 17;
/* 1022 */               jjCheckNAddStates(42, 44);
/*      */               break;
/*      */             case 1:
/* 1025 */               if ((0x2400L & l) != 0L && kind > 17)
/* 1026 */                 kind = 17; 
/*      */               break;
/*      */             case 2:
/* 1029 */               if (this.curChar == 10 && kind > 17)
/* 1030 */                 kind = 17; 
/*      */               break;
/*      */             case 3:
/* 1033 */               if (this.curChar == 13) {
/* 1034 */                 this.jjstateSet[this.jjnewStateCnt++] = 2;
/*      */               }
/*      */               break;
/*      */           } 
/* 1038 */         } while (i != startsAt);
/*      */       }
/* 1040 */       else if (this.curChar < 128) {
/*      */         
/* 1042 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1045 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 4:
/* 1049 */               kind = 17;
/* 1050 */               jjCheckNAddStates(42, 44);
/*      */               break;
/*      */           } 
/*      */         
/* 1054 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/* 1058 */         int i2 = (this.curChar & 0xFF) >> 6;
/* 1059 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1062 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 4:
/* 1066 */               if ((jjbitVec0[i2] & l2) == 0L)
/*      */                 break; 
/* 1068 */               if (kind > 17)
/* 1069 */                 kind = 17; 
/* 1070 */               jjCheckNAddStates(42, 44);
/*      */               break;
/*      */           } 
/*      */         
/* 1074 */         } while (i != startsAt);
/*      */       } 
/* 1076 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/* 1078 */         this.jjmatchedKind = kind;
/* 1079 */         this.jjmatchedPos = curPos;
/* 1080 */         kind = Integer.MAX_VALUE;
/*      */       } 
/* 1082 */       curPos++;
/* 1083 */       i = this.jjnewStateCnt;
/* 1084 */       this.jjnewStateCnt = startsAt;
/* 1085 */       startsAt = 4 - this.jjnewStateCnt;
/* 1086 */       if (i == startsAt)
/* 1087 */         return curPos;  
/* 1088 */       try { this.curChar = this.input_stream.readChar(); }
/* 1089 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*      */   } private int jjMoveStringLiteralDfa0_2() {
/* 1093 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1096 */         return jjMoveStringLiteralDfa1_2(262144L);
/*      */     } 
/* 1098 */     return 1;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa1_2(long active0) { try {
/* 1102 */       this.curChar = this.input_stream.readChar();
/* 1103 */     } catch (IOException e) {
/* 1104 */       return 1;
/*      */     } 
/* 1106 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1109 */         if ((active0 & 0x40000L) != 0L) {
/* 1110 */           return jjStopAtPos(1, 18);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1115 */         return 2;
/*      */     } 
/*      */     return 2; } private int jjMoveStringLiteralDfa0_3() {
/* 1118 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1121 */         return jjMoveStringLiteralDfa1_3(524288L);
/*      */     } 
/* 1123 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_3(long active0) {
/*      */     try {
/* 1127 */       this.curChar = this.input_stream.readChar();
/* 1128 */     } catch (IOException e) {
/* 1129 */       return 1;
/*      */     } 
/* 1131 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1134 */         return jjMoveStringLiteralDfa2_3(active0, 524288L);
/*      */     } 
/* 1136 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_3(long old0, long active0) {
/* 1140 */     if ((active0 &= old0) == 0L)
/* 1141 */       return 2;  try {
/* 1142 */       this.curChar = this.input_stream.readChar();
/* 1143 */     } catch (IOException e) {
/* 1144 */       return 2;
/*      */     } 
/* 1146 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1149 */         if ((active0 & 0x80000L) != 0L) {
/* 1150 */           return jjStopAtPos(2, 19);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1155 */         return 3;
/*      */     } 
/*      */     return 3; } private int jjMoveStringLiteralDfa0_4() {
/* 1158 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1161 */         return jjMoveStringLiteralDfa1_4(1048576L);
/*      */     } 
/* 1163 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_4(long active0) {
/*      */     try {
/* 1167 */       this.curChar = this.input_stream.readChar();
/* 1168 */     } catch (IOException e) {
/* 1169 */       return 1;
/*      */     } 
/* 1171 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1174 */         return jjMoveStringLiteralDfa2_4(active0, 1048576L);
/*      */     } 
/* 1176 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_4(long old0, long active0) {
/* 1180 */     if ((active0 &= old0) == 0L)
/* 1181 */       return 2;  try {
/* 1182 */       this.curChar = this.input_stream.readChar();
/* 1183 */     } catch (IOException e) {
/* 1184 */       return 2;
/*      */     } 
/* 1186 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1189 */         return jjMoveStringLiteralDfa3_4(active0, 1048576L);
/*      */     } 
/* 1191 */     return 3;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_4(long old0, long active0) {
/* 1195 */     if ((active0 &= old0) == 0L)
/* 1196 */       return 3;  try {
/* 1197 */       this.curChar = this.input_stream.readChar();
/* 1198 */     } catch (IOException e) {
/* 1199 */       return 3;
/*      */     } 
/* 1201 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1204 */         if ((active0 & 0x100000L) != 0L) {
/* 1205 */           return jjStopAtPos(3, 20);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1210 */         return 4;
/*      */     } 
/*      */     return 4; } private int jjMoveStringLiteralDfa0_5() {
/* 1213 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1216 */         return jjMoveStringLiteralDfa1_5(2097152L);
/*      */     } 
/* 1218 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_5(long active0) {
/*      */     try {
/* 1222 */       this.curChar = this.input_stream.readChar();
/* 1223 */     } catch (IOException e) {
/* 1224 */       return 1;
/*      */     } 
/* 1226 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1229 */         return jjMoveStringLiteralDfa2_5(active0, 2097152L);
/*      */     } 
/* 1231 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_5(long old0, long active0) {
/* 1235 */     if ((active0 &= old0) == 0L)
/* 1236 */       return 2;  try {
/* 1237 */       this.curChar = this.input_stream.readChar();
/* 1238 */     } catch (IOException e) {
/* 1239 */       return 2;
/*      */     } 
/* 1241 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1244 */         return jjMoveStringLiteralDfa3_5(active0, 2097152L);
/*      */     } 
/* 1246 */     return 3;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_5(long old0, long active0) {
/* 1250 */     if ((active0 &= old0) == 0L)
/* 1251 */       return 3;  try {
/* 1252 */       this.curChar = this.input_stream.readChar();
/* 1253 */     } catch (IOException e) {
/* 1254 */       return 3;
/*      */     } 
/* 1256 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1259 */         return jjMoveStringLiteralDfa4_5(active0, 2097152L);
/*      */     } 
/* 1261 */     return 4;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa4_5(long old0, long active0) {
/* 1265 */     if ((active0 &= old0) == 0L)
/* 1266 */       return 4;  try {
/* 1267 */       this.curChar = this.input_stream.readChar();
/* 1268 */     } catch (IOException e) {
/* 1269 */       return 4;
/*      */     } 
/* 1271 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1274 */         if ((active0 & 0x200000L) != 0L) {
/* 1275 */           return jjStopAtPos(4, 21);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1280 */         return 5;
/*      */     } 
/*      */     return 5;
/*      */   } private int jjMoveStringLiteralDfa0_6() {
/* 1284 */     return jjMoveNfa_6(6, 0);
/*      */   }
/*      */   
/*      */   private int jjMoveNfa_6(int startState, int curPos) {
/* 1288 */     int startsAt = 0;
/* 1289 */     this.jjnewStateCnt = 7;
/* 1290 */     int i = 1;
/* 1291 */     this.jjstateSet[0] = startState;
/* 1292 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/* 1295 */       if (++this.jjround == Integer.MAX_VALUE)
/* 1296 */         ReInitRounds(); 
/* 1297 */       if (this.curChar < 64) {
/*      */         
/* 1299 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/* 1302 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 1:
/* 1306 */               if (this.curChar == 61)
/* 1307 */                 jjCheckNAddTwoStates(1, 2); 
/*      */               break;
/*      */             case 3:
/* 1310 */               if (this.curChar == 61)
/* 1311 */                 this.jjstateSet[this.jjnewStateCnt++] = 0; 
/*      */               break;
/*      */             case 4:
/* 1314 */               if (this.curChar == 61)
/* 1315 */                 this.jjstateSet[this.jjnewStateCnt++] = 3; 
/*      */               break;
/*      */             case 5:
/* 1318 */               if (this.curChar == 61) {
/* 1319 */                 this.jjstateSet[this.jjnewStateCnt++] = 4;
/*      */               }
/*      */               break;
/*      */           } 
/* 1323 */         } while (i != startsAt);
/*      */       }
/* 1325 */       else if (this.curChar < 128) {
/*      */         
/* 1327 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1330 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 2:
/* 1333 */               if (this.curChar == 93 && kind > 22)
/* 1334 */                 kind = 22; 
/*      */               break;
/*      */             case 6:
/* 1337 */               if (this.curChar == 93) {
/* 1338 */                 this.jjstateSet[this.jjnewStateCnt++] = 5;
/*      */               }
/*      */               break;
/*      */           } 
/* 1342 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/* 1346 */         int i2 = (this.curChar & 0xFF) >> 6;
/* 1347 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1350 */           switch (this.jjstateSet[--i]) {
/*      */           
/*      */           } 
/*      */         
/* 1354 */         } while (i != startsAt);
/*      */       } 
/* 1356 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/* 1358 */         this.jjmatchedKind = kind;
/* 1359 */         this.jjmatchedPos = curPos;
/* 1360 */         kind = Integer.MAX_VALUE;
/*      */       } 
/* 1362 */       curPos++;
/* 1363 */       i = this.jjnewStateCnt;
/* 1364 */       this.jjnewStateCnt = startsAt;
/* 1365 */       startsAt = 7 - this.jjnewStateCnt;
/* 1366 */       if (i == startsAt)
/* 1367 */         return curPos;  
/* 1368 */       try { this.curChar = this.input_stream.readChar(); }
/* 1369 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*      */   } private int jjMoveStringLiteralDfa0_7() {
/* 1373 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1376 */         return jjMoveStringLiteralDfa1_7(8388608L);
/*      */     } 
/* 1378 */     return 1;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa1_7(long active0) { try {
/* 1382 */       this.curChar = this.input_stream.readChar();
/* 1383 */     } catch (IOException e) {
/* 1384 */       return 1;
/*      */     } 
/* 1386 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1389 */         if ((active0 & 0x800000L) != 0L) {
/* 1390 */           return jjStopAtPos(1, 23);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1395 */         return 2;
/*      */     } 
/*      */     return 2; } private int jjMoveStringLiteralDfa0_8() {
/* 1398 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1401 */         return jjMoveStringLiteralDfa1_8(16777216L);
/*      */     } 
/* 1403 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_8(long active0) {
/*      */     try {
/* 1407 */       this.curChar = this.input_stream.readChar();
/* 1408 */     } catch (IOException e) {
/* 1409 */       return 1;
/*      */     } 
/* 1411 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1414 */         return jjMoveStringLiteralDfa2_8(active0, 16777216L);
/*      */     } 
/* 1416 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_8(long old0, long active0) {
/* 1420 */     if ((active0 &= old0) == 0L)
/* 1421 */       return 2;  try {
/* 1422 */       this.curChar = this.input_stream.readChar();
/* 1423 */     } catch (IOException e) {
/* 1424 */       return 2;
/*      */     } 
/* 1426 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1429 */         if ((active0 & 0x1000000L) != 0L) {
/* 1430 */           return jjStopAtPos(2, 24);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1435 */         return 3;
/*      */     } 
/*      */     return 3; } private int jjMoveStringLiteralDfa0_9() {
/* 1438 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1441 */         return jjMoveStringLiteralDfa1_9(33554432L);
/*      */     } 
/* 1443 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_9(long active0) {
/*      */     try {
/* 1447 */       this.curChar = this.input_stream.readChar();
/* 1448 */     } catch (IOException e) {
/* 1449 */       return 1;
/*      */     } 
/* 1451 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1454 */         return jjMoveStringLiteralDfa2_9(active0, 33554432L);
/*      */     } 
/* 1456 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_9(long old0, long active0) {
/* 1460 */     if ((active0 &= old0) == 0L)
/* 1461 */       return 2;  try {
/* 1462 */       this.curChar = this.input_stream.readChar();
/* 1463 */     } catch (IOException e) {
/* 1464 */       return 2;
/*      */     } 
/* 1466 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1469 */         return jjMoveStringLiteralDfa3_9(active0, 33554432L);
/*      */     } 
/* 1471 */     return 3;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_9(long old0, long active0) {
/* 1475 */     if ((active0 &= old0) == 0L)
/* 1476 */       return 3;  try {
/* 1477 */       this.curChar = this.input_stream.readChar();
/* 1478 */     } catch (IOException e) {
/* 1479 */       return 3;
/*      */     } 
/* 1481 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1484 */         if ((active0 & 0x2000000L) != 0L) {
/* 1485 */           return jjStopAtPos(3, 25);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1490 */         return 4;
/*      */     } 
/*      */     return 4; } private int jjMoveStringLiteralDfa0_10() {
/* 1493 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1496 */         return jjMoveStringLiteralDfa1_10(67108864L);
/*      */     } 
/* 1498 */     return 1;
/*      */   }
/*      */   private int jjMoveStringLiteralDfa1_10(long active0) {
/*      */     try {
/* 1502 */       this.curChar = this.input_stream.readChar();
/* 1503 */     } catch (IOException e) {
/* 1504 */       return 1;
/*      */     } 
/* 1506 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1509 */         return jjMoveStringLiteralDfa2_10(active0, 67108864L);
/*      */     } 
/* 1511 */     return 2;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_10(long old0, long active0) {
/* 1515 */     if ((active0 &= old0) == 0L)
/* 1516 */       return 2;  try {
/* 1517 */       this.curChar = this.input_stream.readChar();
/* 1518 */     } catch (IOException e) {
/* 1519 */       return 2;
/*      */     } 
/* 1521 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1524 */         return jjMoveStringLiteralDfa3_10(active0, 67108864L);
/*      */     } 
/* 1526 */     return 3;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_10(long old0, long active0) {
/* 1530 */     if ((active0 &= old0) == 0L)
/* 1531 */       return 3;  try {
/* 1532 */       this.curChar = this.input_stream.readChar();
/* 1533 */     } catch (IOException e) {
/* 1534 */       return 3;
/*      */     } 
/* 1536 */     switch (this.curChar) {
/*      */       
/*      */       case 61:
/* 1539 */         return jjMoveStringLiteralDfa4_10(active0, 67108864L);
/*      */     } 
/* 1541 */     return 4;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa4_10(long old0, long active0) {
/* 1545 */     if ((active0 &= old0) == 0L)
/* 1546 */       return 4;  try {
/* 1547 */       this.curChar = this.input_stream.readChar();
/* 1548 */     } catch (IOException e) {
/* 1549 */       return 4;
/*      */     } 
/* 1551 */     switch (this.curChar) {
/*      */       
/*      */       case 93:
/* 1554 */         if ((active0 & 0x4000000L) != 0L) {
/* 1555 */           return jjStopAtPos(4, 26);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1560 */         return 5;
/*      */     } 
/*      */     return 5;
/*      */   } private int jjMoveStringLiteralDfa0_11() {
/* 1564 */     return jjMoveNfa_11(6, 0);
/*      */   }
/*      */   
/*      */   private int jjMoveNfa_11(int startState, int curPos) {
/* 1568 */     int startsAt = 0;
/* 1569 */     this.jjnewStateCnt = 7;
/* 1570 */     int i = 1;
/* 1571 */     this.jjstateSet[0] = startState;
/* 1572 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/* 1575 */       if (++this.jjround == Integer.MAX_VALUE)
/* 1576 */         ReInitRounds(); 
/* 1577 */       if (this.curChar < 64) {
/*      */         
/* 1579 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/* 1582 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 1:
/* 1586 */               if (this.curChar == 61)
/* 1587 */                 jjCheckNAddTwoStates(1, 2); 
/*      */               break;
/*      */             case 3:
/* 1590 */               if (this.curChar == 61)
/* 1591 */                 this.jjstateSet[this.jjnewStateCnt++] = 0; 
/*      */               break;
/*      */             case 4:
/* 1594 */               if (this.curChar == 61)
/* 1595 */                 this.jjstateSet[this.jjnewStateCnt++] = 3; 
/*      */               break;
/*      */             case 5:
/* 1598 */               if (this.curChar == 61) {
/* 1599 */                 this.jjstateSet[this.jjnewStateCnt++] = 4;
/*      */               }
/*      */               break;
/*      */           } 
/* 1603 */         } while (i != startsAt);
/*      */       }
/* 1605 */       else if (this.curChar < 128) {
/*      */         
/* 1607 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1610 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 2:
/* 1613 */               if (this.curChar == 93 && kind > 27)
/* 1614 */                 kind = 27; 
/*      */               break;
/*      */             case 6:
/* 1617 */               if (this.curChar == 93) {
/* 1618 */                 this.jjstateSet[this.jjnewStateCnt++] = 5;
/*      */               }
/*      */               break;
/*      */           } 
/* 1622 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/* 1626 */         int i2 = (this.curChar & 0xFF) >> 6;
/* 1627 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1630 */           switch (this.jjstateSet[--i]) {
/*      */           
/*      */           } 
/*      */         
/* 1634 */         } while (i != startsAt);
/*      */       } 
/* 1636 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/* 1638 */         this.jjmatchedKind = kind;
/* 1639 */         this.jjmatchedPos = curPos;
/* 1640 */         kind = Integer.MAX_VALUE;
/*      */       } 
/* 1642 */       curPos++;
/* 1643 */       i = this.jjnewStateCnt;
/* 1644 */       this.jjnewStateCnt = startsAt;
/* 1645 */       startsAt = 7 - this.jjnewStateCnt;
/* 1646 */       if (i == startsAt)
/* 1647 */         return curPos;  
/* 1648 */       try { this.curChar = this.input_stream.readChar(); }
/* 1649 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*      */   }
/*      */   
/* 1654 */   public static final String[] jjstrLiteralImages = new String[] { "", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "and", "break", "do", "else", "elseif", "end", "false", "for", "function", "goto", "if", "in", "local", "nil", "not", "or", "return", "repeat", "then", "true", "until", "while", null, null, null, null, null, null, null, null, null, null, null, null, null, null, "::", null, null, null, "#", ";", "=", ",", ".", ":", "(", ")", "[", "]", "...", "{", "}", "+", "-", "*", "/", "^", "%", "..", "<", "<=", ">", ">=", "==", "~=" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Token jjFillToken() {
/*      */     String curTokenImage;
/*      */     int beginLine, endLine, beginColumn, endColumn;
/* 1674 */     if (this.jjmatchedPos < 0) {
/*      */       
/* 1676 */       if (this.image == null) {
/* 1677 */         curTokenImage = "";
/*      */       } else {
/* 1679 */         curTokenImage = this.image.toString();
/* 1680 */       }  beginLine = endLine = this.input_stream.getEndLine();
/* 1681 */       beginColumn = endColumn = this.input_stream.getEndColumn();
/*      */     }
/*      */     else {
/*      */       
/* 1685 */       String im = jjstrLiteralImages[this.jjmatchedKind];
/* 1686 */       curTokenImage = (im == null) ? this.input_stream.getImage() : im;
/* 1687 */       beginLine = this.input_stream.getBeginLine();
/* 1688 */       beginColumn = this.input_stream.getBeginColumn();
/* 1689 */       endLine = this.input_stream.getEndLine();
/* 1690 */       endColumn = this.input_stream.getEndColumn();
/*      */     } 
/* 1692 */     Token t = Token.newToken(this.jjmatchedKind);
/* 1693 */     t.kind = this.jjmatchedKind;
/* 1694 */     t.image = curTokenImage;
/*      */     
/* 1696 */     t.beginLine = beginLine;
/* 1697 */     t.endLine = endLine;
/* 1698 */     t.beginColumn = beginColumn;
/* 1699 */     t.endColumn = endColumn;
/*      */     
/* 1701 */     return t;
/*      */   }
/* 1703 */   static final int[] jjnextStates = new int[] { 62, 63, 65, 32, 49, 50, 51, 36, 37, 38, 26, 27, 29, 22, 36, 37, 38, 46, 36, 47, 37, 38, 49, 50, 51, 59, 49, 60, 50, 51, 20, 25, 23, 24, 33, 34, 39, 40, 45, 52, 53, 58, 0, 1, 3 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1709 */   int curLexState = 0;
/* 1710 */   int defaultLexState = 0;
/*      */   
/*      */   int jjnewStateCnt;
/*      */   
/*      */   int jjround;
/*      */   int jjmatchedPos;
/*      */   int jjmatchedKind;
/*      */   
/*      */   public Token getNextToken() {
/* 1719 */     Token specialToken = null;
/*      */     
/* 1721 */     int curPos = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     label125: while (true) {
/*      */       try {
/* 1728 */         this.curChar = this.input_stream.beginToken();
/*      */       }
/* 1730 */       catch (Exception e) {
/*      */         
/* 1732 */         this.jjmatchedKind = 0;
/* 1733 */         this.jjmatchedPos = -1;
/* 1734 */         Token matchedToken = jjFillToken();
/* 1735 */         matchedToken.specialToken = specialToken;
/* 1736 */         return matchedToken;
/*      */       } 
/* 1738 */       this.image = this.jjimage;
/* 1739 */       this.image.setLength(0);
/* 1740 */       this.jjimageLen = 0;
/*      */ 
/*      */       
/*      */       while (true) {
/* 1744 */         switch (this.curLexState) {
/*      */           
/*      */           case 0:
/*      */             try {
/* 1748 */               this.input_stream.backup(0);
/* 1749 */               while (this.curChar <= 32 && (0x100003600L & 1L << this.curChar) != 0L) {
/* 1750 */                 this.curChar = this.input_stream.beginToken();
/*      */               }
/* 1752 */             } catch (IOException e1) {
/*      */               continue label125;
/*      */             } 
/* 1755 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1756 */             this.jjmatchedPos = 0;
/* 1757 */             curPos = jjMoveStringLiteralDfa0_0();
/*      */             break;
/*      */           case 1:
/* 1760 */             this.jjmatchedKind = 17;
/* 1761 */             this.jjmatchedPos = -1;
/* 1762 */             curPos = 0;
/* 1763 */             curPos = jjMoveStringLiteralDfa0_1();
/*      */             break;
/*      */           case 2:
/* 1766 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1767 */             this.jjmatchedPos = 0;
/* 1768 */             curPos = jjMoveStringLiteralDfa0_2();
/* 1769 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1771 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 3:
/* 1775 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1776 */             this.jjmatchedPos = 0;
/* 1777 */             curPos = jjMoveStringLiteralDfa0_3();
/* 1778 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1780 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 4:
/* 1784 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1785 */             this.jjmatchedPos = 0;
/* 1786 */             curPos = jjMoveStringLiteralDfa0_4();
/* 1787 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1789 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 5:
/* 1793 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1794 */             this.jjmatchedPos = 0;
/* 1795 */             curPos = jjMoveStringLiteralDfa0_5();
/* 1796 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1798 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 6:
/* 1802 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1803 */             this.jjmatchedPos = 0;
/* 1804 */             curPos = jjMoveStringLiteralDfa0_6();
/* 1805 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1807 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 7:
/* 1811 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1812 */             this.jjmatchedPos = 0;
/* 1813 */             curPos = jjMoveStringLiteralDfa0_7();
/* 1814 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1816 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 8:
/* 1820 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1821 */             this.jjmatchedPos = 0;
/* 1822 */             curPos = jjMoveStringLiteralDfa0_8();
/* 1823 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1825 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 9:
/* 1829 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1830 */             this.jjmatchedPos = 0;
/* 1831 */             curPos = jjMoveStringLiteralDfa0_9();
/* 1832 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1834 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 10:
/* 1838 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1839 */             this.jjmatchedPos = 0;
/* 1840 */             curPos = jjMoveStringLiteralDfa0_10();
/* 1841 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1843 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */           case 11:
/* 1847 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1848 */             this.jjmatchedPos = 0;
/* 1849 */             curPos = jjMoveStringLiteralDfa0_11();
/* 1850 */             if (this.jjmatchedPos == 0 && this.jjmatchedKind > 28)
/*      */             {
/* 1852 */               this.jjmatchedKind = 28;
/*      */             }
/*      */             break;
/*      */         } 
/* 1856 */         if (this.jjmatchedKind != Integer.MAX_VALUE)
/*      */         
/* 1858 */         { if (this.jjmatchedPos + 1 < curPos)
/* 1859 */             this.input_stream.backup(curPos - this.jjmatchedPos - 1); 
/* 1860 */           if ((jjtoToken[this.jjmatchedKind >> 6] & 1L << (this.jjmatchedKind & 0x3F)) != 0L) {
/*      */             
/* 1862 */             Token matchedToken = jjFillToken();
/* 1863 */             matchedToken.specialToken = specialToken;
/* 1864 */             if (jjnewLexState[this.jjmatchedKind] != -1)
/* 1865 */               this.curLexState = jjnewLexState[this.jjmatchedKind]; 
/* 1866 */             return matchedToken;
/*      */           } 
/* 1868 */           if ((jjtoSkip[this.jjmatchedKind >> 6] & 1L << (this.jjmatchedKind & 0x3F)) != 0L) {
/*      */             
/* 1870 */             if ((jjtoSpecial[this.jjmatchedKind >> 6] & 1L << (this.jjmatchedKind & 0x3F)) != 0L) {
/*      */               
/* 1872 */               Token matchedToken = jjFillToken();
/* 1873 */               if (specialToken == null) {
/* 1874 */                 specialToken = matchedToken;
/*      */               } else {
/*      */                 
/* 1877 */                 matchedToken.specialToken = specialToken;
/* 1878 */                 specialToken = specialToken.next = matchedToken;
/*      */               } 
/* 1880 */               SkipLexicalActions(matchedToken);
/*      */             } else {
/*      */               
/* 1883 */               SkipLexicalActions(null);
/* 1884 */             }  if (jjnewLexState[this.jjmatchedKind] != -1) {
/* 1885 */               this.curLexState = jjnewLexState[this.jjmatchedKind]; continue label125;
/*      */             }  continue label125;
/*      */           } 
/* 1888 */           this.jjimageLen += this.jjmatchedPos + 1;
/* 1889 */           if (jjnewLexState[this.jjmatchedKind] != -1)
/* 1890 */             this.curLexState = jjnewLexState[this.jjmatchedKind]; 
/* 1891 */           curPos = 0;
/* 1892 */           this.jjmatchedKind = Integer.MAX_VALUE;
/*      */           
/* 1894 */           try { this.curChar = this.input_stream.readChar();
/*      */             
/*      */             continue; }
/* 1897 */           catch (IOException iOException) { break; }  }  break;
/*      */       }  break;
/* 1899 */     }  int error_line = this.input_stream.getEndLine();
/* 1900 */     int error_column = this.input_stream.getEndColumn();
/* 1901 */     String error_after = null;
/* 1902 */     boolean EOFSeen = false;
/*      */     try {
/* 1904 */       this.input_stream.readChar();
/* 1905 */       this.input_stream.backup(1);
/*      */     }
/* 1907 */     catch (IOException e1) {
/* 1908 */       EOFSeen = true;
/* 1909 */       error_after = (curPos <= 1) ? "" : this.input_stream.getImage();
/* 1910 */       if (this.curChar == 10 || this.curChar == 13) {
/* 1911 */         error_line++;
/* 1912 */         error_column = 0;
/*      */       } else {
/*      */         
/* 1915 */         error_column++;
/*      */       } 
/* 1917 */     }  if (!EOFSeen) {
/* 1918 */       this.input_stream.backup(1);
/* 1919 */       error_after = (curPos <= 1) ? "" : this.input_stream.getImage();
/*      */     } 
/* 1921 */     throw new TokenMgrException(EOFSeen, this.curLexState, error_line, error_column, error_after, this.curChar, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void SkipLexicalActions(Token matchedToken) {
/* 1928 */     switch (this.jjmatchedKind) {
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void MoreLexicalActions() {
/* 1936 */     this.jjimageLen += this.lengthOfMatch = this.jjmatchedPos + 1;
/* 1937 */     switch (this.jjmatchedKind) {
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void TokenLexicalActions(Token matchedToken) {
/* 1945 */     switch (this.jjmatchedKind) {
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void jjCheckNAdd(int state) {
/* 1953 */     if (this.jjrounds[state] != this.jjround) {
/*      */       
/* 1955 */       this.jjstateSet[this.jjnewStateCnt++] = state;
/* 1956 */       this.jjrounds[state] = this.jjround;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void jjAddStates(int start, int end) {
/*      */     do {
/* 1962 */       this.jjstateSet[this.jjnewStateCnt++] = jjnextStates[start];
/* 1963 */     } while (start++ != end);
/*      */   }
/*      */   
/*      */   private void jjCheckNAddTwoStates(int state1, int state2) {
/* 1967 */     jjCheckNAdd(state1);
/* 1968 */     jjCheckNAdd(state2);
/*      */   }
/*      */ 
/*      */   
/*      */   private void jjCheckNAddStates(int start, int end) {
/*      */     do {
/* 1974 */       jjCheckNAdd(jjnextStates[start]);
/* 1975 */     } while (start++ != end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ReInit(SimpleCharStream stream) {
/* 1995 */     this.jjmatchedPos = this.jjnewStateCnt = 0;
/*      */ 
/*      */     
/* 1998 */     this.curLexState = this.defaultLexState;
/* 1999 */     this.input_stream = stream;
/* 2000 */     ReInitRounds();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void ReInitRounds() {
/* 2006 */     this.jjround = -2147483647;
/* 2007 */     for (int i = 66; i-- > 0;) {
/* 2008 */       this.jjrounds[i] = Integer.MIN_VALUE;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void ReInit(SimpleCharStream stream, int lexState) {
/* 2014 */     ReInit(stream);
/* 2015 */     SwitchTo(lexState);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void SwitchTo(int lexState) {
/* 2021 */     if (lexState >= 12 || lexState < 0) {
/* 2022 */       throw new TokenMgrException("Error: Ignoring invalid lexical state : " + lexState + ". State unchanged.", 2);
/*      */     }
/* 2024 */     this.curLexState = lexState;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 2029 */   public static final String[] lexStateNames = new String[] { "DEFAULT", "IN_COMMENT", "IN_LC0", "IN_LC1", "IN_LC2", "IN_LC3", "IN_LCN", "IN_LS0", "IN_LS1", "IN_LS2", "IN_LS3", "IN_LSN" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2045 */   public static final int[] jjnewLexState = new int[] { -1, -1, -1, -1, -1, -1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2051 */   static final long[] jjtoToken = new long[] { 6926536226618998785L, 2147483618L };
/*      */ 
/*      */   
/* 2054 */   static final long[] jjtoSkip = new long[] { 8257598L, 0L };
/*      */ 
/*      */   
/* 2057 */   static final long[] jjtoSpecial = new long[] { 8257536L, 0L };
/*      */ 
/*      */   
/* 2060 */   static final long[] jjtoMore = new long[] { 268566464L, 0L };
/*      */   protected SimpleCharStream input_stream; private final int[] jjrounds; private final int[] jjstateSet; private final StringBuilder jjimage; private StringBuilder image; private int jjimageLen;
/*      */   private int lengthOfMatch;
/*      */   protected int curChar;
/*      */   
/* 2065 */   public LuaParserTokenManager(SimpleCharStream stream) { this.jjrounds = new int[66];
/* 2066 */     this.jjstateSet = new int[132];
/* 2067 */     this.jjimage = new StringBuilder();
/* 2068 */     this.image = this.jjimage; this.input_stream = stream; } public LuaParserTokenManager(SimpleCharStream stream, int lexState) { this.jjrounds = new int[66]; this.jjstateSet = new int[132]; this.jjimage = new StringBuilder(); this.image = this.jjimage;
/*      */     ReInit(stream);
/*      */     SwitchTo(lexState); }
/*      */ 
/*      */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\parser\lua52\LuaParserTokenManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */