/*      */ package org.luaj.vm2.parser.lua52;public class LuaParser implements LuaParserConstants { public static final int VAR = 0; public static final int CALL = 1; public LuaParserTokenManager token_source; SimpleCharStream jj_input_stream; public Token token; public Token jj_nt; private int jj_ntk;
/*      */   private Token jj_scanpos;
/*      */   private Token jj_lastpos;
/*      */   private int jj_la;
/*      */   private final LookaheadSuccess jj_ls;
/*      */   
/*      */   public static void main(String[] args) throws ParseException {
/*    8 */     LuaParser parser = new LuaParser(System.in);
/*    9 */     parser.Chunk();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Chunk() throws ParseException {
/*   17 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 69:
/*   19 */         jj_consume_token(69);
/*   20 */         this.token_source.SwitchTo(1);
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*   26 */     Block();
/*   27 */     jj_consume_token(0);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void Block() throws ParseException {
/*      */     while (true) {
/*   33 */       switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */         case 30:
/*      */         case 31:
/*      */         case 36:
/*      */         case 37:
/*      */         case 38:
/*      */         case 39:
/*      */         case 41:
/*      */         case 46:
/*      */         case 50:
/*      */         case 51:
/*      */         case 65:
/*      */         case 70:
/*      */         case 75:
/*      */           break;
/*      */         
/*      */         default:
/*      */           break;
/*      */       } 
/*   52 */       Stat();
/*      */     } 
/*   54 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 45:
/*   56 */         ReturnStat();
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Stat() throws ParseException {
/*   65 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 70:
/*   67 */         jj_consume_token(70);
/*      */         return;
/*      */       
/*      */       case 65:
/*   71 */         Label();
/*      */         return;
/*      */       
/*      */       case 30:
/*   75 */         jj_consume_token(30);
/*      */         return;
/*      */       
/*      */       case 38:
/*   79 */         jj_consume_token(38);
/*   80 */         jj_consume_token(51);
/*      */         return;
/*      */       
/*      */       case 31:
/*   84 */         jj_consume_token(31);
/*   85 */         Block();
/*   86 */         jj_consume_token(34);
/*      */         return;
/*      */       
/*      */       case 50:
/*   90 */         jj_consume_token(50);
/*   91 */         Exp();
/*   92 */         jj_consume_token(31);
/*   93 */         Block();
/*   94 */         jj_consume_token(34);
/*      */         return;
/*      */       
/*      */       case 46:
/*   98 */         jj_consume_token(46);
/*   99 */         Block();
/*  100 */         jj_consume_token(49);
/*  101 */         Exp();
/*      */         return;
/*      */       
/*      */       case 39:
/*  105 */         jj_consume_token(39);
/*  106 */         Exp();
/*  107 */         jj_consume_token(47);
/*  108 */         Block();
/*      */         
/*      */         while (true) {
/*  111 */           switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */             case 33:
/*      */               break;
/*      */             
/*      */             default:
/*      */               break;
/*      */           } 
/*  118 */           jj_consume_token(33);
/*  119 */           Exp();
/*  120 */           jj_consume_token(47);
/*  121 */           Block();
/*      */         } 
/*  123 */         switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */           case 32:
/*  125 */             jj_consume_token(32);
/*  126 */             Block();
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  132 */         jj_consume_token(34);
/*      */         return;
/*      */     } 
/*      */     
/*  136 */     if (jj_2_1(3)) {
/*  137 */       jj_consume_token(36);
/*  138 */       jj_consume_token(51);
/*  139 */       jj_consume_token(71);
/*  140 */       Exp();
/*  141 */       jj_consume_token(72);
/*  142 */       Exp();
/*  143 */       switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */         case 72:
/*  145 */           jj_consume_token(72);
/*  146 */           Exp();
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  152 */       jj_consume_token(31);
/*  153 */       Block();
/*  154 */       jj_consume_token(34);
/*      */     } else {
/*  156 */       switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */         case 36:
/*  158 */           jj_consume_token(36);
/*  159 */           NameList();
/*  160 */           jj_consume_token(40);
/*  161 */           ExpList();
/*  162 */           jj_consume_token(31);
/*  163 */           Block();
/*  164 */           jj_consume_token(34);
/*      */           return;
/*      */         
/*      */         case 37:
/*  168 */           jj_consume_token(37);
/*  169 */           FuncName();
/*  170 */           FuncBody();
/*      */           return;
/*      */       } 
/*      */       
/*  174 */       if (jj_2_2(2)) {
/*  175 */         jj_consume_token(41);
/*  176 */         jj_consume_token(37);
/*  177 */         jj_consume_token(51);
/*  178 */         FuncBody();
/*      */       } else {
/*  180 */         switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */           case 41:
/*  182 */             jj_consume_token(41);
/*  183 */             NameList();
/*  184 */             switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */               case 71:
/*  186 */                 jj_consume_token(71);
/*  187 */                 ExpList();
/*      */                 break;
/*      */             } 
/*      */ 
/*      */             
/*      */             return;
/*      */ 
/*      */           
/*      */           case 51:
/*      */           case 75:
/*  197 */             ExprStat();
/*      */             return;
/*      */         } 
/*      */         
/*  201 */         jj_consume_token(-1);
/*  202 */         throw new ParseException();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void ReturnStat() throws ParseException {
/*  211 */     jj_consume_token(45);
/*  212 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/*      */       case 26:
/*      */       case 27:
/*      */       case 35:
/*      */       case 37:
/*      */       case 42:
/*      */       case 43:
/*      */       case 48:
/*      */       case 51:
/*      */       case 52:
/*      */       case 61:
/*      */       case 62:
/*      */       case 69:
/*      */       case 75:
/*      */       case 79:
/*      */       case 80:
/*      */       case 83:
/*  232 */         ExpList();
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  238 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 70:
/*  240 */         jj_consume_token(70);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Label() throws ParseException {
/*  249 */     jj_consume_token(65);
/*  250 */     jj_consume_token(51);
/*  251 */     jj_consume_token(65);
/*      */   }
/*      */   public final void ExprStat() throws ParseException {
/*  254 */     int need = 1;
/*  255 */     int type = PrimaryExp();
/*  256 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 71:
/*      */       case 72:
/*  259 */         Assign();
/*  260 */         need = 0;
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  266 */     if (type != need) throw new ParseException("expected function call or assignment");
/*      */   
/*      */   }
/*      */   
/*      */   public final void Assign() throws ParseException {
/*      */     while (true) {
/*  272 */       switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */         case 72:
/*      */           break;
/*      */         
/*      */         default:
/*      */           break;
/*      */       } 
/*  279 */       jj_consume_token(72);
/*  280 */       VarExp();
/*      */     } 
/*  282 */     jj_consume_token(71);
/*  283 */     ExpList();
/*      */   }
/*      */   
/*      */   public final void VarExp() throws ParseException {
/*  287 */     int type = PrimaryExp();
/*  288 */     if (type != 0) throw new ParseException("expected variable expression"); 
/*      */   }
/*      */   
/*      */   public final void FuncName() throws ParseException {
/*  292 */     jj_consume_token(51);
/*      */     
/*      */     while (true) {
/*  295 */       switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */         case 73:
/*      */           break;
/*      */         
/*      */         default:
/*      */           break;
/*      */       } 
/*  302 */       jj_consume_token(73);
/*  303 */       jj_consume_token(51);
/*      */     } 
/*  305 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 74:
/*  307 */         jj_consume_token(74);
/*  308 */         jj_consume_token(51);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void PrefixExp() throws ParseException {
/*  317 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 51:
/*  319 */         jj_consume_token(51);
/*      */         return;
/*      */       
/*      */       case 75:
/*  323 */         ParenExp();
/*      */         return;
/*      */     } 
/*      */     
/*  327 */     jj_consume_token(-1);
/*  328 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void ParenExp() throws ParseException {
/*  333 */     jj_consume_token(75);
/*  334 */     Exp();
/*  335 */     jj_consume_token(76);
/*      */   }
/*      */   public final int PrimaryExp() throws ParseException {
/*  338 */     int type = 0;
/*  339 */     PrefixExp();
/*      */ 
/*      */     
/*  342 */     while (jj_2_3(2))
/*      */     {
/*      */ 
/*      */       
/*  346 */       type = PostfixOp();
/*      */     }
/*  348 */     if ("" != null) return type; 
/*  349 */     throw new IllegalStateException("Missing return statement in function");
/*      */   }
/*      */   
/*      */   public final int PostfixOp() throws ParseException {
/*  353 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 73:
/*      */       case 77:
/*  356 */         FieldOp();
/*  357 */         if ("" != null) return 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  378 */         throw new IllegalStateException("Missing return statement in function");case 23: case 24: case 25: case 26: case 27: case 61: case 62: case 74: case 75: case 80: FuncOp(); if ("" != null) return 1;  throw new IllegalStateException("Missing return statement in function");
/*      */     } 
/*      */     jj_consume_token(-1);
/*      */     throw new ParseException(); } public final void FieldOp() throws ParseException {
/*  382 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 73:
/*  384 */         jj_consume_token(73);
/*  385 */         jj_consume_token(51);
/*      */         return;
/*      */       
/*      */       case 77:
/*  389 */         jj_consume_token(77);
/*  390 */         Exp();
/*  391 */         jj_consume_token(78);
/*      */         return;
/*      */     } 
/*      */     
/*  395 */     jj_consume_token(-1);
/*  396 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void FuncOp() throws ParseException {
/*  401 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 74:
/*  403 */         jj_consume_token(74);
/*  404 */         jj_consume_token(51);
/*  405 */         FuncArgs();
/*      */         return;
/*      */       
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/*      */       case 26:
/*      */       case 27:
/*      */       case 61:
/*      */       case 62:
/*      */       case 75:
/*      */       case 80:
/*  417 */         FuncArgs();
/*      */         return;
/*      */     } 
/*      */     
/*  421 */     jj_consume_token(-1);
/*  422 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void FuncArgs() throws ParseException {
/*  427 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 75:
/*  429 */         jj_consume_token(75);
/*  430 */         switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/*      */           case 27:
/*      */           case 35:
/*      */           case 37:
/*      */           case 42:
/*      */           case 43:
/*      */           case 48:
/*      */           case 51:
/*      */           case 52:
/*      */           case 61:
/*      */           case 62:
/*      */           case 69:
/*      */           case 75:
/*      */           case 79:
/*      */           case 80:
/*      */           case 83:
/*  450 */             ExpList();
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  456 */         jj_consume_token(76);
/*      */         return;
/*      */       
/*      */       case 80:
/*  460 */         TableConstructor();
/*      */         return;
/*      */       
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/*      */       case 26:
/*      */       case 27:
/*      */       case 61:
/*      */       case 62:
/*  470 */         Str();
/*      */         return;
/*      */     } 
/*      */     
/*  474 */     jj_consume_token(-1);
/*  475 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void NameList() throws ParseException {
/*  480 */     jj_consume_token(51);
/*      */ 
/*      */     
/*  483 */     while (jj_2_4(2)) {
/*      */ 
/*      */ 
/*      */       
/*  487 */       jj_consume_token(72);
/*  488 */       jj_consume_token(51);
/*      */     } 
/*      */   }
/*      */   
/*      */   public final void ExpList() throws ParseException {
/*  493 */     Exp();
/*      */     
/*      */     while (true) {
/*  496 */       switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */         case 72:
/*      */           break;
/*      */         
/*      */         default:
/*      */           break;
/*      */       } 
/*  503 */       jj_consume_token(72);
/*  504 */       Exp();
/*      */     } 
/*      */   }
/*      */   
/*      */   public final void SimpleExp() throws ParseException {
/*  509 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 42:
/*  511 */         jj_consume_token(42);
/*      */         return;
/*      */       
/*      */       case 48:
/*  515 */         jj_consume_token(48);
/*      */         return;
/*      */       
/*      */       case 35:
/*  519 */         jj_consume_token(35);
/*      */         return;
/*      */       
/*      */       case 52:
/*  523 */         jj_consume_token(52);
/*      */         return;
/*      */       
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/*      */       case 26:
/*      */       case 27:
/*      */       case 61:
/*      */       case 62:
/*  533 */         Str();
/*      */         return;
/*      */       
/*      */       case 79:
/*  537 */         jj_consume_token(79);
/*      */         return;
/*      */       
/*      */       case 80:
/*  541 */         TableConstructor();
/*      */         return;
/*      */       
/*      */       case 37:
/*  545 */         FunctionCall();
/*      */         return;
/*      */       
/*      */       case 51:
/*      */       case 75:
/*  550 */         PrimaryExp();
/*      */         return;
/*      */     } 
/*      */     
/*  554 */     jj_consume_token(-1);
/*  555 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void Str() throws ParseException {
/*  560 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 61:
/*  562 */         jj_consume_token(61);
/*      */         return;
/*      */       
/*      */       case 62:
/*  566 */         jj_consume_token(62);
/*      */         return;
/*      */       
/*      */       case 23:
/*  570 */         jj_consume_token(23);
/*      */         return;
/*      */       
/*      */       case 24:
/*  574 */         jj_consume_token(24);
/*      */         return;
/*      */       
/*      */       case 25:
/*  578 */         jj_consume_token(25);
/*      */         return;
/*      */       
/*      */       case 26:
/*  582 */         jj_consume_token(26);
/*      */         return;
/*      */       
/*      */       case 27:
/*  586 */         jj_consume_token(27);
/*      */         return;
/*      */     } 
/*      */     
/*  590 */     jj_consume_token(-1);
/*  591 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void Exp() throws ParseException {
/*  596 */     SubExp();
/*      */   }
/*      */   
/*      */   public final void SubExp() throws ParseException {
/*  600 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/*      */       case 26:
/*      */       case 27:
/*      */       case 35:
/*      */       case 37:
/*      */       case 42:
/*      */       case 48:
/*      */       case 51:
/*      */       case 52:
/*      */       case 61:
/*      */       case 62:
/*      */       case 75:
/*      */       case 79:
/*      */       case 80:
/*  617 */         SimpleExp();
/*      */         break;
/*      */       
/*      */       case 43:
/*      */       case 69:
/*      */       case 83:
/*  623 */         Unop();
/*  624 */         SubExp();
/*      */         break;
/*      */       
/*      */       default:
/*  628 */         jj_consume_token(-1);
/*  629 */         throw new ParseException();
/*      */     } 
/*      */ 
/*      */     
/*  633 */     while (jj_2_5(2)) {
/*      */ 
/*      */ 
/*      */       
/*  637 */       Binop();
/*  638 */       SubExp();
/*      */     } 
/*      */   }
/*      */   
/*      */   public final void FunctionCall() throws ParseException {
/*  643 */     jj_consume_token(37);
/*  644 */     FuncBody();
/*      */   }
/*      */   
/*      */   public final void FuncBody() throws ParseException {
/*  648 */     jj_consume_token(75);
/*  649 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 51:
/*      */       case 79:
/*  652 */         ParList();
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  658 */     jj_consume_token(76);
/*  659 */     Block();
/*  660 */     jj_consume_token(34);
/*      */   }
/*      */   
/*      */   public final void ParList() throws ParseException {
/*  664 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 51:
/*  666 */         NameList();
/*  667 */         switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */           case 72:
/*  669 */             jj_consume_token(72);
/*  670 */             jj_consume_token(79);
/*      */             break;
/*      */         } 
/*      */ 
/*      */         
/*      */         return;
/*      */ 
/*      */       
/*      */       case 79:
/*  679 */         jj_consume_token(79);
/*      */         return;
/*      */     } 
/*      */     
/*  683 */     jj_consume_token(-1);
/*  684 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void TableConstructor() throws ParseException {
/*  689 */     jj_consume_token(80);
/*  690 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/*      */       case 26:
/*      */       case 27:
/*      */       case 35:
/*      */       case 37:
/*      */       case 42:
/*      */       case 43:
/*      */       case 48:
/*      */       case 51:
/*      */       case 52:
/*      */       case 61:
/*      */       case 62:
/*      */       case 69:
/*      */       case 75:
/*      */       case 77:
/*      */       case 79:
/*      */       case 80:
/*      */       case 83:
/*  711 */         FieldList();
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  717 */     jj_consume_token(81);
/*      */   }
/*      */   
/*      */   public final void FieldList() throws ParseException {
/*  721 */     Field();
/*      */ 
/*      */     
/*  724 */     while (jj_2_6(2)) {
/*      */ 
/*      */ 
/*      */       
/*  728 */       FieldSep();
/*  729 */       Field();
/*      */     } 
/*  731 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 70:
/*      */       case 72:
/*  734 */         FieldSep();
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Field() throws ParseException {
/*  743 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 77:
/*  745 */         jj_consume_token(77);
/*  746 */         Exp();
/*  747 */         jj_consume_token(78);
/*  748 */         jj_consume_token(71);
/*  749 */         Exp();
/*      */         return;
/*      */     } 
/*      */     
/*  753 */     if (jj_2_7(2)) {
/*  754 */       jj_consume_token(51);
/*  755 */       jj_consume_token(71);
/*  756 */       Exp();
/*      */     } else {
/*  758 */       switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */         case 23:
/*      */         case 24:
/*      */         case 25:
/*      */         case 26:
/*      */         case 27:
/*      */         case 35:
/*      */         case 37:
/*      */         case 42:
/*      */         case 43:
/*      */         case 48:
/*      */         case 51:
/*      */         case 52:
/*      */         case 61:
/*      */         case 62:
/*      */         case 69:
/*      */         case 75:
/*      */         case 79:
/*      */         case 80:
/*      */         case 83:
/*  778 */           Exp();
/*      */           return;
/*      */       } 
/*      */       
/*  782 */       jj_consume_token(-1);
/*  783 */       throw new ParseException();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void FieldSep() throws ParseException {
/*  790 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 72:
/*  792 */         jj_consume_token(72);
/*      */         return;
/*      */       
/*      */       case 70:
/*  796 */         jj_consume_token(70);
/*      */         return;
/*      */     } 
/*      */     
/*  800 */     jj_consume_token(-1);
/*  801 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void Binop() throws ParseException {
/*  806 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 82:
/*  808 */         jj_consume_token(82);
/*      */         return;
/*      */       
/*      */       case 83:
/*  812 */         jj_consume_token(83);
/*      */         return;
/*      */       
/*      */       case 84:
/*  816 */         jj_consume_token(84);
/*      */         return;
/*      */       
/*      */       case 85:
/*  820 */         jj_consume_token(85);
/*      */         return;
/*      */       
/*      */       case 86:
/*  824 */         jj_consume_token(86);
/*      */         return;
/*      */       
/*      */       case 87:
/*  828 */         jj_consume_token(87);
/*      */         return;
/*      */       
/*      */       case 88:
/*  832 */         jj_consume_token(88);
/*      */         return;
/*      */       
/*      */       case 89:
/*  836 */         jj_consume_token(89);
/*      */         return;
/*      */       
/*      */       case 90:
/*  840 */         jj_consume_token(90);
/*      */         return;
/*      */       
/*      */       case 91:
/*  844 */         jj_consume_token(91);
/*      */         return;
/*      */       
/*      */       case 92:
/*  848 */         jj_consume_token(92);
/*      */         return;
/*      */       
/*      */       case 93:
/*  852 */         jj_consume_token(93);
/*      */         return;
/*      */       
/*      */       case 94:
/*  856 */         jj_consume_token(94);
/*      */         return;
/*      */       
/*      */       case 29:
/*  860 */         jj_consume_token(29);
/*      */         return;
/*      */       
/*      */       case 44:
/*  864 */         jj_consume_token(44);
/*      */         return;
/*      */     } 
/*      */     
/*  868 */     jj_consume_token(-1);
/*  869 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void Unop() throws ParseException {
/*  874 */     switch ((this.jj_ntk == -1) ? jj_ntk_f() : this.jj_ntk) {
/*      */       case 83:
/*  876 */         jj_consume_token(83);
/*      */         return;
/*      */       
/*      */       case 43:
/*  880 */         jj_consume_token(43);
/*      */         return;
/*      */       
/*      */       case 69:
/*  884 */         jj_consume_token(69);
/*      */         return;
/*      */     } 
/*      */     
/*  888 */     jj_consume_token(-1);
/*  889 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_2_1(int xla) {
/*  895 */     this.jj_la = xla;
/*  896 */     this.jj_scanpos = this.token;
/*  897 */     this.jj_lastpos = this.token; 
/*  898 */     try { return !jj_3_1(); }
/*  899 */     catch (LookaheadSuccess ls) { return true; }
/*      */   
/*      */   }
/*      */   
/*      */   private boolean jj_2_2(int xla) {
/*  904 */     this.jj_la = xla;
/*  905 */     this.jj_scanpos = this.token;
/*  906 */     this.jj_lastpos = this.token; 
/*  907 */     try { return !jj_3_2(); }
/*  908 */     catch (LookaheadSuccess ls) { return true; }
/*      */   
/*      */   }
/*      */   
/*      */   private boolean jj_2_3(int xla) {
/*  913 */     this.jj_la = xla;
/*  914 */     this.jj_scanpos = this.token;
/*  915 */     this.jj_lastpos = this.token; 
/*  916 */     try { return !jj_3_3(); }
/*  917 */     catch (LookaheadSuccess ls) { return true; }
/*      */   
/*      */   }
/*      */   
/*      */   private boolean jj_2_4(int xla) {
/*  922 */     this.jj_la = xla;
/*  923 */     this.jj_scanpos = this.token;
/*  924 */     this.jj_lastpos = this.token; 
/*  925 */     try { return !jj_3_4(); }
/*  926 */     catch (LookaheadSuccess ls) { return true; }
/*      */   
/*      */   }
/*      */   
/*      */   private boolean jj_2_5(int xla) {
/*  931 */     this.jj_la = xla;
/*  932 */     this.jj_scanpos = this.token;
/*  933 */     this.jj_lastpos = this.token; 
/*  934 */     try { return !jj_3_5(); }
/*  935 */     catch (LookaheadSuccess ls) { return true; }
/*      */   
/*      */   }
/*      */   
/*      */   private boolean jj_2_6(int xla) {
/*  940 */     this.jj_la = xla;
/*  941 */     this.jj_scanpos = this.token;
/*  942 */     this.jj_lastpos = this.token; 
/*  943 */     try { return !jj_3_6(); }
/*  944 */     catch (LookaheadSuccess ls) { return true; }
/*      */   
/*      */   }
/*      */   
/*      */   private boolean jj_2_7(int xla) {
/*  949 */     this.jj_la = xla;
/*  950 */     this.jj_scanpos = this.token;
/*  951 */     this.jj_lastpos = this.token; 
/*  952 */     try { return !jj_3_7(); }
/*  953 */     catch (LookaheadSuccess ls) { return true; }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_34() {
/*  959 */     Token xsp = this.jj_scanpos;
/*  960 */     if (jj_3R_39()) {
/*  961 */       this.jj_scanpos = xsp;
/*  962 */       if (jj_3R_40()) {
/*  963 */         this.jj_scanpos = xsp;
/*  964 */         if (jj_3R_41()) return true; 
/*      */       } 
/*      */     } 
/*  967 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_39() {
/*  972 */     if (jj_scan_token(75)) return true;
/*      */     
/*  974 */     Token xsp = this.jj_scanpos;
/*  975 */     if (jj_3R_43()) this.jj_scanpos = xsp; 
/*  976 */     if (jj_scan_token(76)) return true; 
/*  977 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_40() {
/*  982 */     if (jj_3R_36()) return true; 
/*  983 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_41() {
/*  988 */     if (jj_3R_35()) return true; 
/*  989 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_43() {
/*  994 */     if (jj_3R_45()) return true; 
/*  995 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_45() {
/* 1000 */     if (jj_3R_25()) return true; 
/* 1001 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3_4() {
/* 1006 */     if (jj_scan_token(72)) return true; 
/* 1007 */     if (jj_scan_token(51)) return true; 
/* 1008 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_23() {
/* 1014 */     Token xsp = this.jj_scanpos;
/* 1015 */     if (jj_scan_token(42)) {
/* 1016 */       this.jj_scanpos = xsp;
/* 1017 */       if (jj_scan_token(48)) {
/* 1018 */         this.jj_scanpos = xsp;
/* 1019 */         if (jj_scan_token(35)) {
/* 1020 */           this.jj_scanpos = xsp;
/* 1021 */           if (jj_scan_token(52)) {
/* 1022 */             this.jj_scanpos = xsp;
/* 1023 */             if (jj_3R_30()) {
/* 1024 */               this.jj_scanpos = xsp;
/* 1025 */               if (jj_scan_token(79)) {
/* 1026 */                 this.jj_scanpos = xsp;
/* 1027 */                 if (jj_3R_31()) {
/* 1028 */                   this.jj_scanpos = xsp;
/* 1029 */                   if (jj_3R_32()) {
/* 1030 */                     this.jj_scanpos = xsp;
/* 1031 */                     if (jj_3R_33()) return true; 
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1040 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_30() {
/* 1045 */     if (jj_3R_35()) return true; 
/* 1046 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_31() {
/* 1051 */     if (jj_3R_36()) return true; 
/* 1052 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_32() {
/* 1057 */     if (jj_3R_37()) return true; 
/* 1058 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_33() {
/* 1063 */     if (jj_3R_38()) return true; 
/* 1064 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_35() {
/* 1070 */     Token xsp = this.jj_scanpos;
/* 1071 */     if (jj_scan_token(61)) {
/* 1072 */       this.jj_scanpos = xsp;
/* 1073 */       if (jj_scan_token(62)) {
/* 1074 */         this.jj_scanpos = xsp;
/* 1075 */         if (jj_scan_token(23)) {
/* 1076 */           this.jj_scanpos = xsp;
/* 1077 */           if (jj_scan_token(24)) {
/* 1078 */             this.jj_scanpos = xsp;
/* 1079 */             if (jj_scan_token(25)) {
/* 1080 */               this.jj_scanpos = xsp;
/* 1081 */               if (jj_scan_token(26)) {
/* 1082 */                 this.jj_scanpos = xsp;
/* 1083 */                 if (jj_scan_token(27)) return true; 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1090 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3_1() {
/* 1095 */     if (jj_scan_token(36)) return true; 
/* 1096 */     if (jj_scan_token(51)) return true; 
/* 1097 */     if (jj_scan_token(71)) return true; 
/* 1098 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3_2() {
/* 1103 */     if (jj_scan_token(41)) return true; 
/* 1104 */     if (jj_scan_token(37)) return true; 
/* 1105 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_25() {
/* 1110 */     if (jj_3R_12()) return true; 
/* 1111 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_12() {
/* 1117 */     Token xsp = this.jj_scanpos;
/* 1118 */     if (jj_3R_17()) {
/* 1119 */       this.jj_scanpos = xsp;
/* 1120 */       if (jj_3R_18()) return true; 
/*      */     } 
/* 1122 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_17() {
/* 1127 */     if (jj_3R_23()) return true; 
/* 1128 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_37() {
/* 1133 */     if (jj_scan_token(37)) return true; 
/* 1134 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_18() {
/* 1139 */     if (jj_3R_24()) return true; 
/* 1140 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_36() {
/* 1145 */     if (jj_scan_token(80)) return true;
/*      */     
/* 1147 */     Token xsp = this.jj_scanpos;
/* 1148 */     if (jj_3R_46()) this.jj_scanpos = xsp; 
/* 1149 */     if (jj_scan_token(81)) return true; 
/* 1150 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_46() {
/* 1155 */     if (jj_3R_48()) return true; 
/* 1156 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_48() {
/* 1161 */     if (jj_3R_14()) return true; 
/* 1162 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3_5() {
/* 1167 */     if (jj_3R_11()) return true; 
/* 1168 */     if (jj_3R_12()) return true; 
/* 1169 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_14() {
/* 1175 */     Token xsp = this.jj_scanpos;
/* 1176 */     if (jj_3R_19()) {
/* 1177 */       this.jj_scanpos = xsp;
/* 1178 */       if (jj_3_7()) {
/* 1179 */         this.jj_scanpos = xsp;
/* 1180 */         if (jj_3R_20()) return true; 
/*      */       } 
/*      */     } 
/* 1183 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_19() {
/* 1188 */     if (jj_scan_token(77)) return true; 
/* 1189 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_42() {
/* 1195 */     Token xsp = this.jj_scanpos;
/* 1196 */     if (jj_scan_token(51)) {
/* 1197 */       this.jj_scanpos = xsp;
/* 1198 */       if (jj_3R_44()) return true; 
/*      */     } 
/* 1200 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3_7() {
/* 1205 */     if (jj_scan_token(51)) return true; 
/* 1206 */     if (jj_scan_token(71)) return true; 
/* 1207 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_44() {
/* 1212 */     if (jj_3R_47()) return true; 
/* 1213 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3_6() {
/* 1218 */     if (jj_3R_13()) return true; 
/* 1219 */     if (jj_3R_14()) return true; 
/* 1220 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_20() {
/* 1225 */     if (jj_3R_25()) return true; 
/* 1226 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_47() {
/* 1231 */     if (jj_scan_token(75)) return true; 
/* 1232 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_13() {
/* 1238 */     Token xsp = this.jj_scanpos;
/* 1239 */     if (jj_scan_token(72)) {
/* 1240 */       this.jj_scanpos = xsp;
/* 1241 */       if (jj_scan_token(70)) return true; 
/*      */     } 
/* 1243 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_38() {
/* 1248 */     if (jj_3R_42()) return true; 
/* 1249 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_11() {
/* 1255 */     Token xsp = this.jj_scanpos;
/* 1256 */     if (jj_scan_token(82)) {
/* 1257 */       this.jj_scanpos = xsp;
/* 1258 */       if (jj_scan_token(83)) {
/* 1259 */         this.jj_scanpos = xsp;
/* 1260 */         if (jj_scan_token(84)) {
/* 1261 */           this.jj_scanpos = xsp;
/* 1262 */           if (jj_scan_token(85)) {
/* 1263 */             this.jj_scanpos = xsp;
/* 1264 */             if (jj_scan_token(86)) {
/* 1265 */               this.jj_scanpos = xsp;
/* 1266 */               if (jj_scan_token(87)) {
/* 1267 */                 this.jj_scanpos = xsp;
/* 1268 */                 if (jj_scan_token(88)) {
/* 1269 */                   this.jj_scanpos = xsp;
/* 1270 */                   if (jj_scan_token(89)) {
/* 1271 */                     this.jj_scanpos = xsp;
/* 1272 */                     if (jj_scan_token(90)) {
/* 1273 */                       this.jj_scanpos = xsp;
/* 1274 */                       if (jj_scan_token(91)) {
/* 1275 */                         this.jj_scanpos = xsp;
/* 1276 */                         if (jj_scan_token(92)) {
/* 1277 */                           this.jj_scanpos = xsp;
/* 1278 */                           if (jj_scan_token(93)) {
/* 1279 */                             this.jj_scanpos = xsp;
/* 1280 */                             if (jj_scan_token(94)) {
/* 1281 */                               this.jj_scanpos = xsp;
/* 1282 */                               if (jj_scan_token(29)) {
/* 1283 */                                 this.jj_scanpos = xsp;
/* 1284 */                                 if (jj_scan_token(44)) return true; 
/*      */                               } 
/*      */                             } 
/*      */                           } 
/*      */                         } 
/*      */                       } 
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1299 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_10() {
/* 1305 */     Token xsp = this.jj_scanpos;
/* 1306 */     if (jj_3R_15()) {
/* 1307 */       this.jj_scanpos = xsp;
/* 1308 */       if (jj_3R_16()) return true; 
/*      */     } 
/* 1310 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_15() {
/* 1315 */     if (jj_3R_21()) return true; 
/* 1316 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_24() {
/* 1322 */     Token xsp = this.jj_scanpos;
/* 1323 */     if (jj_scan_token(83)) {
/* 1324 */       this.jj_scanpos = xsp;
/* 1325 */       if (jj_scan_token(43)) {
/* 1326 */         this.jj_scanpos = xsp;
/* 1327 */         if (jj_scan_token(69)) return true; 
/*      */       } 
/*      */     } 
/* 1330 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_16() {
/* 1335 */     if (jj_3R_22()) return true; 
/* 1336 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_21() {
/* 1342 */     Token xsp = this.jj_scanpos;
/* 1343 */     if (jj_3R_26()) {
/* 1344 */       this.jj_scanpos = xsp;
/* 1345 */       if (jj_3R_27()) return true; 
/*      */     } 
/* 1347 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_26() {
/* 1352 */     if (jj_scan_token(73)) return true; 
/* 1353 */     if (jj_scan_token(51)) return true; 
/* 1354 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3_3() {
/* 1359 */     if (jj_3R_10()) return true; 
/* 1360 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_27() {
/* 1365 */     if (jj_scan_token(77)) return true; 
/* 1366 */     if (jj_3R_25()) return true; 
/* 1367 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_3R_22() {
/* 1373 */     Token xsp = this.jj_scanpos;
/* 1374 */     if (jj_3R_28()) {
/* 1375 */       this.jj_scanpos = xsp;
/* 1376 */       if (jj_3R_29()) return true; 
/*      */     } 
/* 1378 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_28() {
/* 1383 */     if (jj_scan_token(74)) return true; 
/* 1384 */     if (jj_scan_token(51)) return true; 
/* 1385 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_29() {
/* 1390 */     if (jj_3R_34()) return true; 
/* 1391 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaParser(InputStream stream) {
/* 1410 */     this(stream, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LuaParser(InputStream stream, Charset encoding)
/*      */   {
/* 1511 */     this.jj_ls = new LookaheadSuccess(); this.jj_input_stream = new SimpleCharStream(stream, encoding, 1, 1); this.token_source = new LuaParserTokenManager(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; } public void ReInit(InputStream stream) { ReInit(stream, null); } public void ReInit(InputStream stream, Charset encoding) { this.jj_input_stream.reInit(stream, encoding, 1, 1); this.token_source.ReInit(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; } public LuaParser(Reader stream) { this.jj_ls = new LookaheadSuccess(); this.jj_input_stream = new SimpleCharStream(stream, 1, 1); this.token_source = new LuaParserTokenManager(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; } public LuaParser(LuaParserTokenManager tm) { this.jj_ls = new LookaheadSuccess(); this.token_source = tm; this.token = new Token(); this.jj_ntk = -1; }
/*      */   public void ReInit(Reader stream) { if (this.jj_input_stream == null) { this.jj_input_stream = new SimpleCharStream(stream, 1, 1); } else { this.jj_input_stream.reInit(stream, 1, 1); }  if (this.token_source == null) this.token_source = new LuaParserTokenManager(this.jj_input_stream);  this.token_source.ReInit(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; }
/* 1513 */   public void ReInit(LuaParserTokenManager tm) { this.token_source = tm; this.token = new Token(); this.jj_ntk = -1; } private boolean jj_scan_token(int kind) { if (this.jj_scanpos == this.jj_lastpos) {
/* 1514 */       this.jj_la--;
/* 1515 */       if (this.jj_scanpos.next == null) {
/* 1516 */         this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next = this.token_source.getNextToken();
/*      */       } else {
/* 1518 */         this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next;
/*      */       } 
/*      */     } else {
/* 1521 */       this.jj_scanpos = this.jj_scanpos.next;
/*      */     } 
/* 1523 */     if (this.jj_scanpos.kind != kind) return true; 
/* 1524 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) throw this.jj_ls; 
/* 1525 */     return false; } private Token jj_consume_token(int kind) throws ParseException { Token oldToken = this.token; if (this.token.next != null) {
/*      */       this.token = this.token.next;
/*      */     } else {
/*      */       this.token.next = this.token_source.getNextToken(); this.token = this.token.next;
/*      */     }  this.jj_ntk = -1; if (this.token.kind == kind)
/*      */       return this.token;  this.token = oldToken;
/*      */     throw generateParseException(); } private static final class LookaheadSuccess extends IllegalStateException {
/*      */     private LookaheadSuccess() {} }
/* 1533 */   public final Token getNextToken() { if (this.token.next != null) {
/* 1534 */       this.token = this.token.next;
/*      */     } else {
/* 1536 */       this.token = this.token.next = this.token_source.getNextToken();
/* 1537 */     }  this.jj_ntk = -1;
/* 1538 */     return this.token; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Token getToken(int index) {
/* 1546 */     Token t = this.token;
/* 1547 */     for (int i = 0; i < index; i++) {
/* 1548 */       if (t.next == null)
/* 1549 */         t.next = this.token_source.getNextToken(); 
/* 1550 */       t = t.next;
/*      */     } 
/* 1552 */     return t;
/*      */   }
/*      */   
/*      */   private int jj_ntk_f() {
/* 1556 */     this.jj_nt = this.token.next;
/* 1557 */     if (this.jj_nt == null) {
/* 1558 */       this.token.next = this.token_source.getNextToken();
/* 1559 */       this.jj_ntk = this.token.next.kind;
/* 1560 */       return this.jj_ntk;
/*      */     } 
/* 1562 */     this.jj_ntk = this.jj_nt.kind;
/* 1563 */     return this.jj_ntk;
/*      */   }
/*      */ 
/*      */   
/*      */   public ParseException generateParseException() {
/* 1568 */     Token errortok = this.token.next;
/* 1569 */     int line = errortok.beginLine;
/* 1570 */     int column = errortok.beginColumn;
/* 1571 */     String mess = (errortok.kind == 0) ? tokenImage[0] : errortok.image;
/* 1572 */     return new ParseException("Parse error at line " + line + ", column " + column + ".  Encountered: " + mess);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean trace_enabled() {
/* 1579 */     return false;
/*      */   }
/*      */   
/*      */   public final void enable_tracing() {}
/*      */   
/*      */   public final void disable_tracing() {} }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\parser\lua52\LuaParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */