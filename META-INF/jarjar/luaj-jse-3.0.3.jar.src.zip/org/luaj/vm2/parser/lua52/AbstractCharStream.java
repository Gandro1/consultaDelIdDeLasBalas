/*     */ package org.luaj.vm2.parser.lua52;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractCharStream
/*     */   implements CharStream
/*     */ {
/*     */   public static final int DEFAULT_BUF_SIZE = 4096;
/*     */   
/*     */   static final int hexval(char c) throws IOException {
/*  19 */     switch (c) {
/*     */       
/*     */       case '0':
/*  22 */         return 0;
/*     */       case '1':
/*  24 */         return 1;
/*     */       case '2':
/*  26 */         return 2;
/*     */       case '3':
/*  28 */         return 3;
/*     */       case '4':
/*  30 */         return 4;
/*     */       case '5':
/*  32 */         return 5;
/*     */       case '6':
/*  34 */         return 6;
/*     */       case '7':
/*  36 */         return 7;
/*     */       case '8':
/*  38 */         return 8;
/*     */       case '9':
/*  40 */         return 9;
/*     */       case 'A':
/*     */       case 'a':
/*  43 */         return 10;
/*     */       case 'B':
/*     */       case 'b':
/*  46 */         return 11;
/*     */       case 'C':
/*     */       case 'c':
/*  49 */         return 12;
/*     */       case 'D':
/*     */       case 'd':
/*  52 */         return 13;
/*     */       case 'E':
/*     */       case 'e':
/*  55 */         return 14;
/*     */       case 'F':
/*     */       case 'f':
/*  58 */         return 15;
/*     */     } 
/*  60 */     throw new IOException("Invalid hex char '" + c + "' (=" + c + ") provided!");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  65 */   private int m_nTabSize = 1;
/*     */ 
/*     */   
/*     */   protected char[] buffer;
/*     */ 
/*     */   
/*     */   protected int bufsize;
/*     */ 
/*     */   
/*     */   protected int bufpos;
/*     */ 
/*     */   
/*     */   protected int available;
/*     */ 
/*     */   
/*     */   protected int tokenBegin;
/*     */ 
/*     */   
/*     */   protected int inBuf;
/*     */ 
/*     */   
/*     */   protected int maxNextCharInd;
/*     */ 
/*     */   
/*     */   private int[] m_aBufLine;
/*     */ 
/*     */   
/*     */   private int[] m_aBufColumn;
/*     */ 
/*     */   
/*     */   private int m_nLineNo;
/*     */ 
/*     */   
/*     */   private int m_nColumnNo;
/*     */   
/*     */   private boolean m_bPrevCharIsCR;
/*     */   
/*     */   private boolean m_bPrevCharIsLF;
/*     */   
/*     */   private boolean m_bTrackLineColumn = true;
/*     */ 
/*     */   
/*     */   public AbstractCharStream(int nStartLine, int nStartColumn, int nBufferSize) {
/* 108 */     reInit(nStartLine, nStartColumn, nBufferSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void reInit(int nStartLine, int nStartColumn, int nBufferSize) {
/* 116 */     this.m_nLineNo = nStartLine;
/* 117 */     this.m_nColumnNo = nStartColumn - 1;
/* 118 */     this.m_bPrevCharIsCR = false;
/* 119 */     this.m_bPrevCharIsLF = false;
/* 120 */     if (this.buffer == null || nBufferSize != this.buffer.length) {
/*     */       
/* 122 */       this.bufsize = nBufferSize;
/* 123 */       this.available = nBufferSize;
/* 124 */       this.buffer = new char[nBufferSize];
/* 125 */       this.m_aBufLine = new int[nBufferSize];
/* 126 */       this.m_aBufColumn = new int[nBufferSize];
/*     */     } 
/* 128 */     this.maxNextCharInd = 0;
/* 129 */     this.inBuf = 0;
/* 130 */     this.tokenBegin = 0;
/* 131 */     this.bufpos = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract int streamRead(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void streamClose() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getBufSizeAfterExpansion() {
/* 153 */     return this.bufsize * 2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void expandBuff(boolean bWrapAround) {
/* 159 */     int nNewBufSize = getBufSizeAfterExpansion();
/*     */     
/* 161 */     char[] newbuffer = new char[nNewBufSize];
/* 162 */     int[] newbufline = new int[nNewBufSize];
/* 163 */     int[] newbufcolumn = new int[nNewBufSize];
/*     */ 
/*     */     
/* 166 */     int nPreservedChars = this.bufsize - this.tokenBegin;
/*     */     
/* 168 */     if (bWrapAround) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 174 */       System.arraycopy(this.buffer, this.tokenBegin, newbuffer, 0, nPreservedChars);
/*     */ 
/*     */       
/* 177 */       System.arraycopy(this.buffer, 0, newbuffer, nPreservedChars, this.bufpos);
/*     */ 
/*     */       
/* 180 */       this.buffer = newbuffer;
/*     */       
/* 182 */       System.arraycopy(this.m_aBufLine, this.tokenBegin, newbufline, 0, nPreservedChars);
/* 183 */       System.arraycopy(this.m_aBufLine, 0, newbufline, nPreservedChars, this.bufpos);
/* 184 */       this.m_aBufLine = newbufline;
/*     */       
/* 186 */       System.arraycopy(this.m_aBufColumn, this.tokenBegin, newbufcolumn, 0, nPreservedChars);
/* 187 */       System.arraycopy(this.m_aBufColumn, 0, newbufcolumn, nPreservedChars, this.bufpos);
/* 188 */       this.m_aBufColumn = newbufcolumn;
/*     */       
/* 190 */       this.bufpos += nPreservedChars;
/* 191 */       this.maxNextCharInd = this.bufpos;
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 197 */       System.arraycopy(this.buffer, this.tokenBegin, newbuffer, 0, nPreservedChars);
/* 198 */       this.buffer = newbuffer;
/*     */       
/* 200 */       System.arraycopy(this.m_aBufLine, this.tokenBegin, newbufline, 0, nPreservedChars);
/* 201 */       this.m_aBufLine = newbufline;
/*     */       
/* 203 */       System.arraycopy(this.m_aBufColumn, this.tokenBegin, newbufcolumn, 0, nPreservedChars);
/* 204 */       this.m_aBufColumn = newbufcolumn;
/*     */       
/* 206 */       this.bufpos -= this.tokenBegin;
/* 207 */       this.maxNextCharInd = this.bufpos;
/*     */     } 
/*     */ 
/*     */     
/* 211 */     this.bufsize = nNewBufSize;
/* 212 */     this.available = nNewBufSize;
/* 213 */     this.tokenBegin = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void internalAdjustBuffSize() {
/* 218 */     int nHalfBufferSize = this.bufsize / 2;
/* 219 */     if (this.available == this.bufsize) {
/*     */       
/* 221 */       if (this.tokenBegin < 0)
/*     */       {
/*     */ 
/*     */         
/* 225 */         this.bufpos = 0;
/* 226 */         this.maxNextCharInd = 0;
/*     */       
/*     */       }
/* 229 */       else if (this.tokenBegin > nHalfBufferSize)
/*     */       {
/*     */         
/* 232 */         this.bufpos = 0;
/* 233 */         this.maxNextCharInd = 0;
/*     */ 
/*     */         
/* 236 */         this.available = this.tokenBegin;
/*     */       
/*     */       }
/*     */       else
/*     */       {
/*     */         
/* 242 */         expandBuff(false);
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 248 */     else if (this.available > this.tokenBegin) {
/*     */       
/* 250 */       this.available = this.bufsize;
/*     */     
/*     */     }
/* 253 */     else if (this.tokenBegin - this.available < nHalfBufferSize) {
/*     */       
/* 255 */       expandBuff(true);
/*     */     }
/*     */     else {
/*     */       
/* 259 */       this.available = this.tokenBegin;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fillBuff() throws IOException {
/* 266 */     if (this.maxNextCharInd == this.available) {
/* 267 */       internalAdjustBuffSize();
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 272 */       int nCharsRead = streamRead(this.buffer, this.maxNextCharInd, this.available - this.maxNextCharInd);
/* 273 */       if (nCharsRead == -1) {
/*     */ 
/*     */         
/* 276 */         streamClose();
/*     */ 
/*     */         
/* 279 */         throw new IOException("PGCC end of stream");
/*     */       } 
/* 281 */       this.maxNextCharInd += nCharsRead;
/*     */     }
/* 283 */     catch (IOException ex) {
/*     */       
/* 285 */       this.bufpos--;
/*     */       
/* 287 */       backup(0);
/* 288 */       if (this.tokenBegin == -1)
/*     */       {
/*     */         
/* 291 */         this.tokenBegin = this.bufpos;
/*     */       }
/* 293 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void internalSetBufLineColumn(int nLine, int nColumn) {
/* 299 */     this.m_aBufLine[this.bufpos] = nLine;
/* 300 */     this.m_aBufColumn[this.bufpos] = nColumn;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void internalUpdateLineColumn(char c) {
/* 305 */     this.m_nColumnNo++;
/*     */     
/* 307 */     if (this.m_bPrevCharIsLF) {
/*     */ 
/*     */ 
/*     */       
/* 311 */       this.m_bPrevCharIsLF = false;
/* 312 */       this.m_nColumnNo = 1;
/* 313 */       this.m_nLineNo++;
/*     */     
/*     */     }
/* 316 */     else if (this.m_bPrevCharIsCR) {
/*     */       
/* 318 */       this.m_bPrevCharIsCR = false;
/* 319 */       if (c == '\n') {
/*     */ 
/*     */         
/* 322 */         this.m_bPrevCharIsLF = true;
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 327 */         this.m_nColumnNo = 1;
/* 328 */         this.m_nLineNo++;
/*     */       } 
/*     */     } 
/*     */     
/* 332 */     switch (c) {
/*     */       
/*     */       case '\r':
/* 335 */         this.m_bPrevCharIsCR = true;
/*     */         break;
/*     */       case '\n':
/* 338 */         this.m_bPrevCharIsLF = true;
/*     */         break;
/*     */       case '\t':
/* 341 */         this.m_nColumnNo--;
/* 342 */         this.m_nColumnNo += this.m_nTabSize - this.m_nColumnNo % this.m_nTabSize;
/*     */         break;
/*     */     } 
/*     */     
/* 346 */     internalSetBufLineColumn(this.m_nLineNo, this.m_nColumnNo);
/*     */   }
/*     */ 
/*     */   
/*     */   public char readChar() throws IOException {
/* 351 */     if (this.inBuf > 0) {
/*     */ 
/*     */       
/* 354 */       this.inBuf--;
/*     */       
/* 356 */       this.bufpos++;
/* 357 */       if (this.bufpos == this.bufsize)
/*     */       {
/*     */         
/* 360 */         this.bufpos = 0;
/*     */       }
/*     */       
/* 363 */       return this.buffer[this.bufpos];
/*     */     } 
/*     */     
/* 366 */     this.bufpos++;
/* 367 */     if (this.bufpos >= this.maxNextCharInd) {
/* 368 */       fillBuff();
/*     */     }
/* 370 */     char c = this.buffer[this.bufpos];
/*     */     
/* 372 */     if (this.m_bTrackLineColumn)
/* 373 */       internalUpdateLineColumn(c); 
/* 374 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   public char beginToken() throws IOException {
/* 379 */     this.tokenBegin = -1;
/* 380 */     char c = readChar();
/* 381 */     this.tokenBegin = this.bufpos;
/* 382 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBeginColumn() {
/* 387 */     return this.m_aBufColumn[this.tokenBegin];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBeginLine() {
/* 392 */     return this.m_aBufLine[this.tokenBegin];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getEndColumn() {
/* 397 */     return this.m_aBufColumn[this.bufpos];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getEndLine() {
/* 402 */     return this.m_aBufLine[this.bufpos];
/*     */   }
/*     */ 
/*     */   
/*     */   public void backup(int nAmount) {
/* 407 */     if (nAmount > this.bufsize) {
/* 408 */       throw new IllegalStateException("Cannot back " + nAmount + " chars which is larger than the internal buffer size (" + this.bufsize + ")");
/*     */     }
/* 410 */     this.inBuf += nAmount;
/* 411 */     this.bufpos -= nAmount;
/* 412 */     if (this.bufpos < 0)
/*     */     {
/*     */       
/* 415 */       this.bufpos += this.bufsize;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getImage() {
/* 421 */     if (this.bufpos >= this.tokenBegin)
/*     */     {
/*     */       
/* 424 */       return new String(this.buffer, this.tokenBegin, this.bufpos - this.tokenBegin + 1);
/*     */     }
/*     */ 
/*     */     
/* 428 */     return new String(this.buffer, this.tokenBegin, this.bufsize - this.tokenBegin) + new String(this.buffer, 0, this.bufpos + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] getSuffix(int len) {
/* 434 */     char[] ret = new char[len];
/* 435 */     if (this.bufpos + 1 >= len) {
/*     */ 
/*     */       
/* 438 */       System.arraycopy(this.buffer, this.bufpos - len + 1, ret, 0, len);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 443 */       int nPart1 = len - this.bufpos - 1;
/* 444 */       System.arraycopy(this.buffer, this.bufsize - nPart1, ret, 0, nPart1);
/* 445 */       System.arraycopy(this.buffer, 0, ret, nPart1, this.bufpos + 1);
/*     */     } 
/* 447 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public void done() {
/* 452 */     this.buffer = null;
/* 453 */     this.m_aBufLine = null;
/* 454 */     this.m_aBufColumn = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getTabSize() {
/* 459 */     return this.m_nTabSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setTabSize(int nTabSize) {
/* 464 */     this.m_nTabSize = nTabSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void adjustBeginLineColumn(int nNewLine, int newCol) {
/* 473 */     int len, start = this.tokenBegin;
/* 474 */     int newLine = nNewLine;
/*     */ 
/*     */     
/* 477 */     if (this.bufpos >= this.tokenBegin) {
/*     */       
/* 479 */       len = this.bufpos - this.tokenBegin + this.inBuf + 1;
/*     */     }
/*     */     else {
/*     */       
/* 483 */       len = this.bufsize - this.tokenBegin + this.bufpos + 1 + this.inBuf;
/*     */     } 
/*     */     
/* 486 */     int i = 0;
/* 487 */     int j = 0;
/* 488 */     int k = 0;
/* 489 */     int nextColDiff = 0;
/* 490 */     int columnDiff = 0;
/*     */ 
/*     */     
/* 493 */     while (i < len && this.m_aBufLine[j = start % this.bufsize] == this.m_aBufLine[k = ++start % this.bufsize]) {
/*     */       
/* 495 */       this.m_aBufLine[j] = newLine;
/* 496 */       nextColDiff = columnDiff + this.m_aBufColumn[k] - this.m_aBufColumn[j];
/* 497 */       this.m_aBufColumn[j] = newCol + columnDiff;
/* 498 */       columnDiff = nextColDiff;
/* 499 */       i++;
/*     */     } 
/*     */     
/* 502 */     if (i < len) {
/*     */       
/* 504 */       this.m_aBufLine[j] = newLine++;
/* 505 */       this.m_aBufColumn[j] = newCol + columnDiff;
/*     */       
/* 507 */       while (i++ < len) {
/*     */ 
/*     */         
/* 510 */         if (this.m_aBufLine[j = start % this.bufsize] != this.m_aBufLine[++start % this.bufsize]) {
/* 511 */           this.m_aBufLine[j] = newLine++; continue;
/*     */         } 
/* 513 */         this.m_aBufLine[j] = newLine;
/*     */       } 
/*     */     } 
/*     */     
/* 517 */     this.m_nLineNo = this.m_aBufLine[j];
/* 518 */     this.m_nColumnNo = this.m_aBufColumn[j];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int getLine() {
/* 526 */     return this.m_nLineNo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int getColumn() {
/* 534 */     return this.m_nColumnNo;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isTrackLineColumn() {
/* 539 */     return this.m_bTrackLineColumn;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setTrackLineColumn(boolean bTrackLineColumn) {
/* 544 */     this.m_bTrackLineColumn = bTrackLineColumn;
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\parser\lua52\AbstractCharStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */