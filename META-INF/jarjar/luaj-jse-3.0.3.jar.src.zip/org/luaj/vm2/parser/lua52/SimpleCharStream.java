/*     */ package org.luaj.vm2.parser.lua52;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.Charset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleCharStream
/*     */   extends AbstractCharStream
/*     */ {
/*     */   private Reader m_aIS;
/*     */   
/*     */   public SimpleCharStream(Reader dstream, int startline, int startcolumn, int buffersize) {
/*  20 */     super(startline, startcolumn, buffersize);
/*  21 */     this.m_aIS = dstream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleCharStream(Reader dstream, int startline, int startcolumn) {
/*  29 */     this(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleCharStream(Reader dstream) {
/*  35 */     this(dstream, 1, 1, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reInit(Reader dstream, int startline, int startcolumn, int buffersize) {
/*  44 */     this.m_aIS = dstream;
/*  45 */     reInit(startline, startcolumn, buffersize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reInit(Reader dstream, int startline, int startcolumn) {
/*  53 */     reInit(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reInit(Reader dstream) {
/*  59 */     reInit(dstream, 1, 1, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleCharStream(InputStream dstream, Charset encoding, int startline, int startcolumn, int buffersize) {
/*  69 */     this(new InputStreamReader(dstream, encoding), startline, startcolumn, buffersize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleCharStream(InputStream dstream, Charset encoding, int startline, int startcolumn) {
/*  78 */     this(dstream, encoding, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleCharStream(InputStream dstream, Charset encoding) {
/*  85 */     this(dstream, encoding, 1, 1, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reInit(InputStream dstream, Charset encoding) {
/*  92 */     reInit(dstream, encoding, 1, 1, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reInit(InputStream dstream, Charset encoding, int startline, int startcolumn) {
/* 101 */     reInit(dstream, encoding, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reInit(InputStream dstream, Charset encoding, int startline, int startcolumn, int buffersize) {
/* 111 */     reInit(new InputStreamReader(dstream, encoding), startline, startcolumn, buffersize);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int streamRead(char[] aBuf, int nOfs, int nLen) throws IOException {
/* 117 */     return this.m_aIS.read(aBuf, nOfs, nLen);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void streamClose() throws IOException {
/* 123 */     if (this.m_aIS != null)
/* 124 */       this.m_aIS.close(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\parser\lua52\SimpleCharStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */