package org.luaj.vm2.parser;

import java.io.IOException;

public interface CharStream {
  char readChar() throws IOException;
  
  int getBeginColumn();
  
  int getBeginLine();
  
  int getEndColumn();
  
  int getEndLine();
  
  void backup(int paramInt);
  
  char beginToken() throws IOException;
  
  String getImage();
  
  char[] getSuffix(int paramInt);
  
  void done();
  
  int getTabSize();
  
  void setTabSize(int paramInt);
  
  boolean isTrackLineColumn();
  
  void setTrackLineColumn(boolean paramBoolean);
}


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\parser\CharStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */