/*     */ package org.luaj.vm2.luajc;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.bcel.generic.AASTORE;
/*     */ import org.apache.bcel.generic.ALOAD;
/*     */ import org.apache.bcel.generic.ANEWARRAY;
/*     */ import org.apache.bcel.generic.ASTORE;
/*     */ import org.apache.bcel.generic.ArrayType;
/*     */ import org.apache.bcel.generic.BranchInstruction;
/*     */ import org.apache.bcel.generic.ClassGen;
/*     */ import org.apache.bcel.generic.CompoundInstruction;
/*     */ import org.apache.bcel.generic.ConstantPoolGen;
/*     */ import org.apache.bcel.generic.FieldGen;
/*     */ import org.apache.bcel.generic.GOTO;
/*     */ import org.apache.bcel.generic.IFEQ;
/*     */ import org.apache.bcel.generic.IFNE;
/*     */ import org.apache.bcel.generic.Instruction;
/*     */ import org.apache.bcel.generic.InstructionConstants;
/*     */ import org.apache.bcel.generic.InstructionFactory;
/*     */ import org.apache.bcel.generic.InstructionHandle;
/*     */ import org.apache.bcel.generic.InstructionList;
/*     */ import org.apache.bcel.generic.LocalVariableGen;
/*     */ import org.apache.bcel.generic.MethodGen;
/*     */ import org.apache.bcel.generic.ObjectType;
/*     */ import org.apache.bcel.generic.PUSH;
/*     */ import org.apache.bcel.generic.Type;
/*     */ import org.luaj.vm2.Buffer;
/*     */ import org.luaj.vm2.Lua;
/*     */ import org.luaj.vm2.LuaBoolean;
/*     */ import org.luaj.vm2.LuaInteger;
/*     */ import org.luaj.vm2.LuaNumber;
/*     */ import org.luaj.vm2.LuaString;
/*     */ import org.luaj.vm2.LuaTable;
/*     */ import org.luaj.vm2.LuaValue;
/*     */ import org.luaj.vm2.Prototype;
/*     */ import org.luaj.vm2.Varargs;
/*     */ import org.luaj.vm2.lib.OneArgFunction;
/*     */ import org.luaj.vm2.lib.ThreeArgFunction;
/*     */ import org.luaj.vm2.lib.TwoArgFunction;
/*     */ import org.luaj.vm2.lib.VarArgFunction;
/*     */ import org.luaj.vm2.lib.ZeroArgFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaBuilder
/*     */ {
/*  71 */   private static final String STR_VARARGS = Varargs.class.getName();
/*  72 */   private static final String STR_LUAVALUE = LuaValue.class.getName();
/*  73 */   private static final String STR_LUASTRING = LuaString.class.getName();
/*  74 */   private static final String STR_LUAINTEGER = LuaInteger.class.getName();
/*  75 */   private static final String STR_LUANUMBER = LuaNumber.class.getName();
/*  76 */   private static final String STR_LUABOOLEAN = LuaBoolean.class.getName();
/*  77 */   private static final String STR_LUATABLE = LuaTable.class.getName();
/*  78 */   private static final String STR_BUFFER = Buffer.class.getName();
/*  79 */   private static final String STR_STRING = String.class.getName();
/*     */   
/*     */   private static final String STR_JSEPLATFORM = "org.luaj.vm2.lib.jse.JsePlatform";
/*  82 */   private static final ObjectType TYPE_VARARGS = new ObjectType(STR_VARARGS);
/*  83 */   private static final ObjectType TYPE_LUAVALUE = new ObjectType(STR_LUAVALUE);
/*  84 */   private static final ObjectType TYPE_LUASTRING = new ObjectType(STR_LUASTRING);
/*  85 */   private static final ObjectType TYPE_LUAINTEGER = new ObjectType(STR_LUAINTEGER);
/*  86 */   private static final ObjectType TYPE_LUANUMBER = new ObjectType(STR_LUANUMBER);
/*  87 */   private static final ObjectType TYPE_LUABOOLEAN = new ObjectType(STR_LUABOOLEAN);
/*  88 */   private static final ObjectType TYPE_LUATABLE = new ObjectType(STR_LUATABLE);
/*  89 */   private static final ObjectType TYPE_BUFFER = new ObjectType(STR_BUFFER);
/*  90 */   private static final ObjectType TYPE_STRING = new ObjectType(STR_STRING);
/*     */   
/*  92 */   private static final ArrayType TYPE_LOCALUPVALUE = new ArrayType((Type)TYPE_LUAVALUE, 1);
/*  93 */   private static final ArrayType TYPE_CHARARRAY = new ArrayType((Type)Type.CHAR, 1);
/*  94 */   private static final ArrayType TYPE_STRINGARRAY = new ArrayType((Type)TYPE_STRING, 1);
/*     */   
/*  96 */   private static final String STR_FUNCV = VarArgFunction.class.getName();
/*  97 */   private static final String STR_FUNC0 = ZeroArgFunction.class.getName();
/*  98 */   private static final String STR_FUNC1 = OneArgFunction.class.getName();
/*  99 */   private static final String STR_FUNC2 = TwoArgFunction.class.getName();
/* 100 */   private static final String STR_FUNC3 = ThreeArgFunction.class.getName();
/*     */ 
/*     */   
/* 103 */   private static final Type[] ARG_TYPES_NONE = new Type[0];
/* 104 */   private static final Type[] ARG_TYPES_INT = new Type[] { (Type)Type.INT };
/* 105 */   private static final Type[] ARG_TYPES_DOUBLE = new Type[] { (Type)Type.DOUBLE };
/* 106 */   private static final Type[] ARG_TYPES_STRING = new Type[] { (Type)Type.STRING };
/* 107 */   private static final Type[] ARG_TYPES_CHARARRAY = new Type[] { (Type)TYPE_CHARARRAY };
/* 108 */   private static final Type[] ARG_TYPES_INT_LUAVALUE = new Type[] { (Type)Type.INT, (Type)TYPE_LUAVALUE };
/* 109 */   private static final Type[] ARG_TYPES_INT_VARARGS = new Type[] { (Type)Type.INT, (Type)TYPE_VARARGS };
/* 110 */   private static final Type[] ARG_TYPES_LUAVALUE_VARARGS = new Type[] { (Type)TYPE_LUAVALUE, (Type)TYPE_VARARGS };
/* 111 */   private static final Type[] ARG_TYPES_LUAVALUE_LUAVALUE_VARARGS = new Type[] { (Type)TYPE_LUAVALUE, (Type)TYPE_LUAVALUE, (Type)TYPE_VARARGS };
/* 112 */   private static final Type[] ARG_TYPES_LUAVALUEARRAY = new Type[] { (Type)new ArrayType((Type)TYPE_LUAVALUE, 1) };
/* 113 */   private static final Type[] ARG_TYPES_LUAVALUEARRAY_VARARGS = new Type[] { (Type)new ArrayType((Type)TYPE_LUAVALUE, 1), (Type)TYPE_VARARGS };
/*     */   
/* 115 */   private static final Type[] ARG_TYPES_LUAVALUE_LUAVALUE_LUAVALUE = new Type[] { (Type)TYPE_LUAVALUE, (Type)TYPE_LUAVALUE, (Type)TYPE_LUAVALUE };
/* 116 */   private static final Type[] ARG_TYPES_VARARGS = new Type[] { (Type)TYPE_VARARGS };
/* 117 */   private static final Type[] ARG_TYPES_LUAVALUE_LUAVALUE = new Type[] { (Type)TYPE_LUAVALUE, (Type)TYPE_LUAVALUE };
/* 118 */   private static final Type[] ARG_TYPES_INT_INT = new Type[] { (Type)Type.INT, (Type)Type.INT };
/* 119 */   private static final Type[] ARG_TYPES_LUAVALUE = new Type[] { (Type)TYPE_LUAVALUE };
/* 120 */   private static final Type[] ARG_TYPES_BUFFER = new Type[] { (Type)TYPE_BUFFER };
/* 121 */   private static final Type[] ARG_TYPES_STRINGARRAY = new Type[] { (Type)TYPE_STRINGARRAY };
/* 122 */   private static final Type[] ARG_TYPES_LUAVALUE_STRINGARRAY = new Type[] { (Type)TYPE_LUAVALUE, (Type)TYPE_STRINGARRAY };
/*     */ 
/*     */   
/* 125 */   private static final String[] SUPER_NAME_N = new String[] { STR_FUNC0, STR_FUNC1, STR_FUNC2, STR_FUNC3, STR_FUNCV };
/* 126 */   private static final ObjectType[] RETURN_TYPE_N = new ObjectType[] { TYPE_LUAVALUE, TYPE_LUAVALUE, TYPE_LUAVALUE, TYPE_LUAVALUE, TYPE_VARARGS };
/*     */   
/* 128 */   private static final Type[][] ARG_TYPES_N = new Type[][] { ARG_TYPES_NONE, ARG_TYPES_LUAVALUE, ARG_TYPES_LUAVALUE_LUAVALUE, ARG_TYPES_LUAVALUE_LUAVALUE_LUAVALUE, ARG_TYPES_VARARGS };
/*     */   
/* 130 */   private static final String[][] ARG_NAMES_N = new String[][] { {}, { "arg" }, { "arg1", "arg2" }, { "arg1", "arg2", "arg3" }, { "args" } };
/*     */   
/* 132 */   private static final String[] METH_NAME_N = new String[] { "call", "call", "call", "call", "onInvoke" };
/*     */   
/*     */   private static final String PREFIX_CONSTANT = "k";
/*     */   
/*     */   private static final String PREFIX_UPVALUE = "u";
/*     */   
/*     */   private static final String PREFIX_PLAIN_SLOT = "s";
/*     */   
/*     */   private static final String PREFIX_UPVALUE_SLOT = "a";
/*     */   
/*     */   private static final String NAME_VARRESULT = "v";
/*     */   
/*     */   private final ProtoInfo pi;
/*     */   
/*     */   private final Prototype p;
/*     */   
/*     */   private final String classname;
/*     */   
/*     */   private final ClassGen cg;
/*     */   
/*     */   private final ConstantPoolGen cp;
/*     */   private final InstructionFactory factory;
/*     */   private final InstructionList init;
/*     */   private final InstructionList main;
/*     */   private final MethodGen mg;
/*     */   private int superclassType;
/* 158 */   private static int SUPERTYPE_VARARGS = 4;
/*     */   
/*     */   private final int[] targets;
/*     */   
/*     */   private final BranchInstruction[] branches;
/*     */   
/*     */   private final InstructionHandle[] branchDestHandles;
/*     */   
/*     */   private final InstructionHandle[] lastInstrHandles;
/*     */   private InstructionHandle beginningOfLuaInstruction;
/* 168 */   private LocalVariableGen varresult = null;
/* 169 */   private int prev_line = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<Integer, Integer> plainSlotVars;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<Integer, Integer> upvalueSlotVars;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<Integer, LocalVariableGen> localVarGenBySlot;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<LuaValue, String> constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int BRANCH_GOTO = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int BRANCH_IFNE = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int BRANCH_IFEQ = 3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeSlots() {
/* 226 */     int slot = 0;
/* 227 */     createUpvalues(-1, 0, this.p.maxstacksize);
/* 228 */     if (this.superclassType == SUPERTYPE_VARARGS) {
/* 229 */       for (slot = 0; slot < this.p.numparams; slot++) {
/* 230 */         if (this.pi.isInitialValueUsed(slot)) {
/* 231 */           append((Instruction)new ALOAD(1));
/* 232 */           append((CompoundInstruction)new PUSH(this.cp, slot + 1));
/* 233 */           append((Instruction)this.factory.createInvoke(STR_VARARGS, "arg", (Type)TYPE_LUAVALUE, ARG_TYPES_INT, (short)182));
/*     */           
/* 235 */           storeLocal(-1, slot);
/*     */         } 
/*     */       } 
/* 238 */       append((Instruction)new ALOAD(1));
/* 239 */       append((CompoundInstruction)new PUSH(this.cp, 1 + this.p.numparams));
/* 240 */       append((Instruction)this.factory.createInvoke(STR_VARARGS, "subargs", (Type)TYPE_VARARGS, ARG_TYPES_INT, (short)182));
/* 241 */       append((Instruction)new ASTORE(1));
/*     */     } else {
/*     */       
/* 244 */       for (slot = 0; slot < this.p.numparams; slot++) {
/* 245 */         this.plainSlotVars.put(Integer.valueOf(slot), Integer.valueOf(1 + slot));
/* 246 */         if (this.pi.isUpvalueCreate(-1, slot)) {
/* 247 */           append((Instruction)new ALOAD(1 + slot));
/* 248 */           storeLocal(-1, slot);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 255 */     for (; slot < this.p.maxstacksize; slot++) {
/* 256 */       if (this.pi.isInitialValueUsed(slot)) {
/* 257 */         loadNil();
/* 258 */         storeLocal(-1, slot);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] completeClass(boolean genmain) {
/* 266 */     if (!this.init.isEmpty()) {
/*     */       
/* 268 */       MethodGen mg = new MethodGen(8, (Type)Type.VOID, ARG_TYPES_NONE, new String[0], "<clinit>", this.cg.getClassName(), this.init, this.cg.getConstantPool());
/* 269 */       this.init.append((Instruction)InstructionConstants.RETURN);
/* 270 */       mg.setMaxStack();
/* 271 */       this.cg.addMethod(mg.getMethod());
/* 272 */       this.init.dispose();
/*     */     } 
/*     */ 
/*     */     
/* 276 */     this.cg.addEmptyConstructor(1);
/*     */ 
/*     */     
/* 279 */     resolveBranches();
/* 280 */     this.mg.setMaxStack();
/* 281 */     this.cg.addMethod(this.mg.getMethod());
/* 282 */     this.main.dispose();
/*     */ 
/*     */     
/* 285 */     if (this.p.upvalues.length == 1 && this.superclassType == SUPERTYPE_VARARGS) {
/* 286 */       MethodGen mg = new MethodGen(17, (Type)Type.VOID, ARG_TYPES_LUAVALUE, new String[] { "env" }, "initupvalue1", STR_LUAVALUE, this.main, this.cp);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 292 */       boolean isrw = this.pi.isReadWriteUpvalue(this.pi.upvals[0]);
/* 293 */       append((Instruction)InstructionConstants.THIS);
/* 294 */       append((Instruction)new ALOAD(1));
/* 295 */       if (isrw) {
/* 296 */         append((Instruction)this.factory.createInvoke(this.classname, "newupl", (Type)TYPE_LOCALUPVALUE, ARG_TYPES_LUAVALUE, (short)184));
/*     */         
/* 298 */         append((Instruction)this.factory.createFieldAccess(this.classname, upvalueName(0), (Type)TYPE_LOCALUPVALUE, (short)181));
/*     */       } else {
/* 300 */         append((Instruction)this.factory.createFieldAccess(this.classname, upvalueName(0), (Type)TYPE_LUAVALUE, (short)181));
/*     */       } 
/* 302 */       append((Instruction)InstructionConstants.RETURN);
/* 303 */       mg.setMaxStack();
/* 304 */       this.cg.addMethod(mg.getMethod());
/* 305 */       this.main.dispose();
/*     */     } 
/*     */ 
/*     */     
/* 309 */     if (genmain) {
/* 310 */       MethodGen mg = new MethodGen(9, (Type)Type.VOID, ARG_TYPES_STRINGARRAY, new String[] { "arg" }, "main", this.classname, this.main, this.cp);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 316 */       append((Instruction)this.factory.createNew(this.classname));
/* 317 */       append((Instruction)InstructionConstants.DUP);
/* 318 */       append((Instruction)this.factory.createInvoke(this.classname, "<init>", (Type)Type.VOID, ARG_TYPES_NONE, (short)183));
/*     */       
/* 320 */       append((Instruction)new ALOAD(0));
/* 321 */       append((Instruction)this.factory.createInvoke("org.luaj.vm2.lib.jse.JsePlatform", "luaMain", (Type)Type.VOID, ARG_TYPES_LUAVALUE_STRINGARRAY, (short)184));
/*     */       
/* 323 */       append((Instruction)InstructionConstants.RETURN);
/* 324 */       mg.setMaxStack();
/* 325 */       this.cg.addMethod(mg.getMethod());
/* 326 */       this.main.dispose();
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 331 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 332 */       this.cg.getJavaClass().dump(baos);
/* 333 */       return baos.toByteArray();
/* 334 */     } catch (IOException ioe) {
/* 335 */       throw new RuntimeException("JavaClass.dump() threw " + ioe);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void dup() {
/* 340 */     append((Instruction)InstructionConstants.DUP);
/*     */   }
/*     */   
/*     */   public void pop() {
/* 344 */     append((Instruction)InstructionConstants.POP);
/*     */   }
/*     */   
/*     */   public void loadNil() {
/* 348 */     append((Instruction)this.factory.createFieldAccess(STR_LUAVALUE, "NIL", (Type)TYPE_LUAVALUE, (short)178));
/*     */   }
/*     */   
/*     */   public void loadNone() {
/* 352 */     append((Instruction)this.factory.createFieldAccess(STR_LUAVALUE, "NONE", (Type)TYPE_LUAVALUE, (short)178));
/*     */   }
/*     */   
/*     */   public void loadBoolean(boolean b) {
/* 356 */     String field = b ? "TRUE" : "FALSE";
/* 357 */     append((Instruction)this.factory.createFieldAccess(STR_LUAVALUE, field, (Type)TYPE_LUABOOLEAN, (short)178));
/*     */   }
/*     */   
/* 360 */   public JavaBuilder(ProtoInfo pi, String classname, String filename) { this.plainSlotVars = new HashMap<>();
/* 361 */     this.upvalueSlotVars = new HashMap<>();
/* 362 */     this.localVarGenBySlot = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 728 */     this.constants = new HashMap<>(); this.pi = pi; this.p = pi.prototype; this.classname = classname; this.superclassType = this.p.numparams; if (this.p.is_vararg != 0 || this.superclassType >= SUPERTYPE_VARARGS) this.superclassType = SUPERTYPE_VARARGS;  for (int inst : this.p.code) { int o = Lua.GET_OPCODE(inst); if (o == 30 || (o == 31 && (Lua.GETARG_B(inst) < 1 || Lua.GETARG_B(inst) > 2))) { this.superclassType = SUPERTYPE_VARARGS; break; }  }  this.cg = new ClassGen(classname, SUPER_NAME_N[this.superclassType], filename, 33, null); this.cp = this.cg.getConstantPool(); this.factory = new InstructionFactory(this.cg); this.init = new InstructionList(); this.main = new InstructionList(); for (int i = 0; i < this.p.upvalues.length; i++) { boolean isrw = pi.isReadWriteUpvalue(pi.upvals[i]); Type uptype = isrw ? (Type)TYPE_LOCALUPVALUE : (Type)TYPE_LUAVALUE; FieldGen fg = new FieldGen(0, uptype, upvalueName(i), this.cp); this.cg.addField(fg.getField()); }  this.mg = new MethodGen(17, (Type)RETURN_TYPE_N[this.superclassType], ARG_TYPES_N[this.superclassType], ARG_NAMES_N[this.superclassType], METH_NAME_N[this.superclassType], STR_LUAVALUE, this.main, this.cp); initializeSlots(); int nc = this.p.code.length; this.targets = new int[nc]; this.branches = new BranchInstruction[nc]; this.branchDestHandles = new InstructionHandle[nc]; this.lastInstrHandles = new InstructionHandle[nc]; } private int findSlot(int slot, Map<Integer, Integer> map, String prefix, Type type) { Integer islot = Integer.valueOf(slot); if (map.containsKey(islot)) return ((Integer)map.get(islot)).intValue();  String name = prefix + slot; LocalVariableGen local = this.mg.addLocalVariable(name, type, null, null); int index = local.getIndex(); map.put(islot, Integer.valueOf(index)); this.localVarGenBySlot.put(islot, local); return index; } private int findSlotIndex(int slot, boolean isupvalue) { return isupvalue ? findSlot(slot, this.upvalueSlotVars, "a", (Type)TYPE_LOCALUPVALUE) : findSlot(slot, this.plainSlotVars, "s", (Type)TYPE_LUAVALUE); } public void loadLocal(int pc, int slot) { boolean isupval = this.pi.isUpvalueRefer(pc, slot); int index = findSlotIndex(slot, isupval); append((Instruction)new ALOAD(index)); if (isupval) { append((CompoundInstruction)new PUSH(this.cp, 0)); append((Instruction)InstructionConstants.AALOAD); }  } public void storeLocal(int pc, int slot) { boolean isupval = this.pi.isUpvalueAssign(pc, slot); int index = findSlotIndex(slot, isupval); if (isupval) { boolean isupcreate = this.pi.isUpvalueCreate(pc, slot); if (isupcreate) { append((Instruction)this.factory.createInvoke(this.classname, "newupe", (Type)TYPE_LOCALUPVALUE, ARG_TYPES_NONE, (short)184)); append((Instruction)InstructionConstants.DUP); append((Instruction)new ASTORE(index)); } else { append((Instruction)new ALOAD(index)); }  append((Instruction)InstructionConstants.SWAP); append((CompoundInstruction)new PUSH(this.cp, 0)); append((Instruction)InstructionConstants.SWAP); append((Instruction)InstructionConstants.AASTORE); } else { append((Instruction)new ASTORE(index)); }  } public void createUpvalues(int pc, int firstslot, int numslots) { for (int i = 0; i < numslots; i++) { int slot = firstslot + i; boolean isupcreate = this.pi.isUpvalueCreate(pc, slot); if (isupcreate) { int index = findSlotIndex(slot, true); append((Instruction)this.factory.createInvoke(this.classname, "newupn", (Type)TYPE_LOCALUPVALUE, ARG_TYPES_NONE, (short)184)); append((Instruction)new ASTORE(index)); }  }  } public void convertToUpvalue(int pc, int slot) { boolean isupassign = this.pi.isUpvalueAssign(pc, slot); if (isupassign) { int index = findSlotIndex(slot, false); append((Instruction)new ALOAD(index)); append((Instruction)this.factory.createInvoke(this.classname, "newupl", (Type)TYPE_LOCALUPVALUE, ARG_TYPES_LUAVALUE, (short)184)); int upindex = findSlotIndex(slot, true); append((Instruction)new ASTORE(upindex)); }  } private static String upvalueName(int upindex) { return "u" + upindex; } public void loadUpvalue(int upindex) { boolean isrw = this.pi.isReadWriteUpvalue(this.pi.upvals[upindex]); append((Instruction)InstructionConstants.THIS); if (isrw) { append((Instruction)this.factory.createFieldAccess(this.classname, upvalueName(upindex), (Type)TYPE_LOCALUPVALUE, (short)180)); append((CompoundInstruction)new PUSH(this.cp, 0)); append((Instruction)InstructionConstants.AALOAD); } else { append((Instruction)this.factory.createFieldAccess(this.classname, upvalueName(upindex), (Type)TYPE_LUAVALUE, (short)180)); }  } public void storeUpvalue(int pc, int upindex, int slot) { boolean isrw = this.pi.isReadWriteUpvalue(this.pi.upvals[upindex]); append((Instruction)InstructionConstants.THIS); if (isrw) { append((Instruction)this.factory.createFieldAccess(this.classname, upvalueName(upindex), (Type)TYPE_LOCALUPVALUE, (short)180)); append((CompoundInstruction)new PUSH(this.cp, 0)); loadLocal(pc, slot); append((Instruction)InstructionConstants.AASTORE); } else { loadLocal(pc, slot); append((Instruction)this.factory.createFieldAccess(this.classname, upvalueName(upindex), (Type)TYPE_LUAVALUE, (short)181)); }  } public void newTable(int b, int c) { append((CompoundInstruction)new PUSH(this.cp, b)); append((CompoundInstruction)new PUSH(this.cp, c)); append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "tableOf", (Type)TYPE_LUATABLE, ARG_TYPES_INT_INT, (short)184)); } public void loadVarargs() { append((Instruction)new ALOAD(1)); } public void loadVarargs(int argindex) { loadVarargs(); arg(argindex); } public void arg(int argindex) { if (argindex == 1) { append((Instruction)this.factory.createInvoke(STR_VARARGS, "arg1", (Type)TYPE_LUAVALUE, ARG_TYPES_NONE, (short)182)); } else { append((CompoundInstruction)new PUSH(this.cp, argindex)); append((Instruction)this.factory.createInvoke(STR_VARARGS, "arg", (Type)TYPE_LUAVALUE, ARG_TYPES_INT, (short)182)); }  } private int getVarresultIndex() { if (this.varresult == null) this.varresult = this.mg.addLocalVariable("v", (Type)TYPE_VARARGS, null, null);  return this.varresult.getIndex(); } public void loadVarresult() { append((Instruction)new ALOAD(getVarresultIndex())); } public void storeVarresult() { append((Instruction)new ASTORE(getVarresultIndex())); }
/*     */   public void subargs(int firstarg) { append((CompoundInstruction)new PUSH(this.cp, firstarg)); append((Instruction)this.factory.createInvoke(STR_VARARGS, "subargs", (Type)TYPE_VARARGS, ARG_TYPES_INT, (short)182)); }
/*     */   public void getTable() { append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "get", (Type)TYPE_LUAVALUE, ARG_TYPES_LUAVALUE, (short)182)); }
/* 731 */   public void loadConstant(LuaValue value) { String name; switch (value.type()) {
/*     */       case 0:
/* 733 */         loadNil();
/*     */         return;
/*     */       case 1:
/* 736 */         loadBoolean(value.toboolean());
/*     */         return;
/*     */       case 3:
/*     */       case 4:
/* 740 */         name = this.constants.get(value);
/* 741 */         if (name == null) {
/*     */           
/* 743 */           name = (value.type() == 3) ? (value.isinttype() ? createLuaIntegerField(value.checkint()) : createLuaDoubleField(value.checkdouble())) : createLuaStringField(value.checkstring());
/* 744 */           this.constants.put(value, name);
/*     */         } 
/* 746 */         append((Instruction)this.factory.createGetStatic(this.classname, name, (Type)TYPE_LUAVALUE));
/*     */         return;
/*     */     } 
/* 749 */     throw new IllegalArgumentException("bad constant type: " + value.type()); }
/*     */   public void setTable() { append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "set", (Type)Type.VOID, ARG_TYPES_LUAVALUE_LUAVALUE, (short)182)); }
/*     */   public void unaryop(int o) { String op; switch (o) { default: op = "neg"; break;case 20: op = "not"; break;case 21: op = "len"; break; }  append((Instruction)this.factory.createInvoke(STR_LUAVALUE, op, (Type)TYPE_LUAVALUE, Type.NO_ARGS, (short)182)); }
/*     */   public void binaryop(int o) { String op; switch (o) { default: op = "add"; break;case 14: op = "sub"; break;case 15: op = "mul"; break;case 16: op = "div"; break;case 17: op = "mod"; break;case 18: op = "pow"; break; }  append((Instruction)this.factory.createInvoke(STR_LUAVALUE, op, (Type)TYPE_LUAVALUE, ARG_TYPES_LUAVALUE, (short)182)); }
/*     */   public void compareop(int o) { String op; switch (o) { default: op = "eq_b"; break;case 25: op = "lt_b"; break;case 26: op = "lteq_b"; break; }  append((Instruction)this.factory.createInvoke(STR_LUAVALUE, op, (Type)Type.BOOLEAN, ARG_TYPES_LUAVALUE, (short)182)); }
/* 754 */   public void areturn() { append((Instruction)InstructionConstants.ARETURN); } public void toBoolean() { append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "toboolean", (Type)Type.BOOLEAN, Type.NO_ARGS, (short)182)); } public void tostring() { append((Instruction)this.factory.createInvoke(STR_BUFFER, "tostring", (Type)TYPE_LUASTRING, Type.NO_ARGS, (short)182)); } public void isNil() { append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "isnil", (Type)Type.BOOLEAN, Type.NO_ARGS, (short)182)); } public void testForLoop() { append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "testfor_b", (Type)Type.BOOLEAN, ARG_TYPES_LUAVALUE_LUAVALUE, (short)182)); } private String createLuaIntegerField(int value) { String name = "k" + this.constants.size();
/* 755 */     FieldGen fg = new FieldGen(24, (Type)TYPE_LUAVALUE, name, this.cp);
/* 756 */     this.cg.addField(fg.getField());
/* 757 */     this.init.append((CompoundInstruction)new PUSH(this.cp, value));
/* 758 */     this.init.append((Instruction)this.factory
/* 759 */         .createInvoke(STR_LUAVALUE, "valueOf", (Type)TYPE_LUAINTEGER, ARG_TYPES_INT, (short)184));
/* 760 */     this.init.append((Instruction)this.factory.createPutStatic(this.classname, name, (Type)TYPE_LUAVALUE));
/* 761 */     return name; }
/*     */   public void loadArrayArgs(int pc, int firstslot, int nargs) { append((CompoundInstruction)new PUSH(this.cp, nargs)); append((Instruction)new ANEWARRAY(this.cp.addClass(STR_LUAVALUE))); for (int i = 0; i < nargs; i++) { append((Instruction)InstructionConstants.DUP); append((CompoundInstruction)new PUSH(this.cp, i)); loadLocal(pc, firstslot++); append((Instruction)new AASTORE()); }  }
/*     */   public void newVarargs(int pc, int firstslot, int nargs) { switch (nargs) { case 0: loadNone(); return;case 1: loadLocal(pc, firstslot); return;case 2: loadLocal(pc, firstslot); loadLocal(pc, firstslot + 1); append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "varargsOf", (Type)TYPE_VARARGS, ARG_TYPES_LUAVALUE_VARARGS, (short)184)); return;case 3: loadLocal(pc, firstslot); loadLocal(pc, firstslot + 1); loadLocal(pc, firstslot + 2); append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "varargsOf", (Type)TYPE_VARARGS, ARG_TYPES_LUAVALUE_LUAVALUE_VARARGS, (short)184)); return; }  loadArrayArgs(pc, firstslot, nargs); append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "varargsOf", (Type)TYPE_VARARGS, ARG_TYPES_LUAVALUEARRAY, (short)184)); }
/*     */   public void newVarargsVarresult(int pc, int firstslot, int nslots) { loadArrayArgs(pc, firstslot, nslots); loadVarresult(); append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "varargsOf", (Type)TYPE_VARARGS, ARG_TYPES_LUAVALUEARRAY_VARARGS, (short)184)); }
/* 765 */   public void call(int nargs) { switch (nargs) { case 0: append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "call", (Type)TYPE_LUAVALUE, ARG_TYPES_NONE, (short)182)); return;case 1: append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "call", (Type)TYPE_LUAVALUE, ARG_TYPES_LUAVALUE, (short)182)); return;case 2: append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "call", (Type)TYPE_LUAVALUE, ARG_TYPES_LUAVALUE_LUAVALUE, (short)182)); return;case 3: append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "call", (Type)TYPE_LUAVALUE, ARG_TYPES_LUAVALUE_LUAVALUE_LUAVALUE, (short)182)); return; }  throw new IllegalArgumentException("can't call with " + nargs + " args"); } public void newTailcallVarargs() { append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "tailcallOf", (Type)TYPE_VARARGS, ARG_TYPES_LUAVALUE_VARARGS, (short)184)); } public void invoke(int nargs) { switch (nargs) { case -1: append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "invoke", (Type)TYPE_VARARGS, ARG_TYPES_VARARGS, (short)182)); return;case 0: append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "invoke", (Type)TYPE_VARARGS, ARG_TYPES_NONE, (short)182)); return;case 1: append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "invoke", (Type)TYPE_VARARGS, ARG_TYPES_VARARGS, (short)182)); return;case 2: append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "invoke", (Type)TYPE_VARARGS, ARG_TYPES_LUAVALUE_VARARGS, (short)182)); return;case 3: append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "invoke", (Type)TYPE_VARARGS, ARG_TYPES_LUAVALUE_LUAVALUE_VARARGS, (short)182)); return; }  throw new IllegalArgumentException("can't invoke with " + nargs + " args"); } public void closureCreate(String protoname) { append((Instruction)this.factory.createNew(new ObjectType(protoname))); append((Instruction)InstructionConstants.DUP); append((Instruction)this.factory.createInvoke(protoname, "<init>", (Type)Type.VOID, Type.NO_ARGS, (short)183)); } public void closureInitUpvalueFromUpvalue(String protoname, int newup, int upindex) { boolean isrw = this.pi.isReadWriteUpvalue(this.pi.upvals[upindex]); Type uptype = isrw ? (Type)TYPE_LOCALUPVALUE : (Type)TYPE_LUAVALUE; String srcname = upvalueName(upindex); String destname = upvalueName(newup); append((Instruction)InstructionConstants.THIS); append((Instruction)this.factory.createFieldAccess(this.classname, srcname, uptype, (short)180)); append((Instruction)this.factory.createFieldAccess(protoname, destname, uptype, (short)181)); } public void closureInitUpvalueFromLocal(String protoname, int newup, int pc, int srcslot) { boolean isrw = this.pi.isReadWriteUpvalue((this.pi.vars[srcslot][pc]).upvalue); Type uptype = isrw ? (Type)TYPE_LOCALUPVALUE : (Type)TYPE_LUAVALUE; String destname = upvalueName(newup); int index = findSlotIndex(srcslot, isrw); append((Instruction)new ALOAD(index)); append((Instruction)this.factory.createFieldAccess(protoname, destname, uptype, (short)181)); } private String createLuaDoubleField(double value) { String name = "k" + this.constants.size();
/* 766 */     FieldGen fg = new FieldGen(24, (Type)TYPE_LUAVALUE, name, this.cp);
/* 767 */     this.cg.addField(fg.getField());
/* 768 */     this.init.append((CompoundInstruction)new PUSH(this.cp, value));
/* 769 */     this.init.append((Instruction)this.factory
/* 770 */         .createInvoke(STR_LUAVALUE, "valueOf", (Type)TYPE_LUANUMBER, ARG_TYPES_DOUBLE, (short)184));
/* 771 */     this.init.append((Instruction)this.factory.createPutStatic(this.classname, name, (Type)TYPE_LUAVALUE));
/* 772 */     return name; }
/*     */ 
/*     */   
/*     */   private String createLuaStringField(LuaString value) {
/* 776 */     String name = "k" + this.constants.size();
/* 777 */     FieldGen fg = new FieldGen(24, (Type)TYPE_LUAVALUE, name, this.cp);
/* 778 */     this.cg.addField(fg.getField());
/* 779 */     LuaString ls = value.checkstring();
/* 780 */     if (ls.isValidUtf8()) {
/* 781 */       this.init.append((CompoundInstruction)new PUSH(this.cp, value.tojstring()));
/* 782 */       this.init.append((Instruction)this.factory.createInvoke(STR_LUASTRING, "valueOf", (Type)TYPE_LUASTRING, ARG_TYPES_STRING, (short)184));
/*     */     } else {
/*     */       
/* 785 */       char[] c = new char[ls.m_length];
/* 786 */       for (int j = 0; j < ls.m_length; j++)
/* 787 */         c[j] = (char)(0xFF & ls.m_bytes[ls.m_offset + j]); 
/* 788 */       this.init.append((CompoundInstruction)new PUSH(this.cp, new String(c)));
/* 789 */       this.init.append((Instruction)this.factory
/* 790 */           .createInvoke(STR_STRING, "toCharArray", (Type)TYPE_CHARARRAY, Type.NO_ARGS, (short)182));
/* 791 */       this.init.append((Instruction)this.factory.createInvoke(STR_LUASTRING, "valueOf", (Type)TYPE_LUASTRING, ARG_TYPES_CHARARRAY, (short)184));
/*     */     } 
/*     */     
/* 794 */     this.init.append((Instruction)this.factory.createPutStatic(this.classname, name, (Type)TYPE_LUAVALUE));
/* 795 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addBranch(int pc, int branchType, int targetpc) {
/* 804 */     switch (branchType) {
/*     */       
/*     */       default:
/* 807 */         this.branches[pc] = (BranchInstruction)new GOTO(null);
/*     */         break;
/*     */       case 2:
/* 810 */         this.branches[pc] = (BranchInstruction)new IFNE(null);
/*     */         break;
/*     */       case 3:
/* 813 */         this.branches[pc] = (BranchInstruction)new IFEQ(null);
/*     */         break;
/*     */     } 
/* 816 */     this.targets[pc] = targetpc;
/* 817 */     append(this.branches[pc]);
/*     */   }
/*     */   
/*     */   private void append(Instruction i) {
/* 821 */     conditionalSetBeginningOfLua(this.main.append(i));
/*     */   }
/*     */   
/*     */   private void append(CompoundInstruction i) {
/* 825 */     conditionalSetBeginningOfLua(this.main.append(i));
/*     */   }
/*     */   
/*     */   private void append(BranchInstruction i) {
/* 829 */     conditionalSetBeginningOfLua((InstructionHandle)this.main.append(i));
/*     */   }
/*     */   
/*     */   private void conditionalSetBeginningOfLua(InstructionHandle ih) {
/* 833 */     if (this.beginningOfLuaInstruction == null)
/* 834 */       this.beginningOfLuaInstruction = ih; 
/*     */   }
/*     */   
/*     */   public void onEndOfLuaInstruction(int pc, int line) {
/* 838 */     this.branchDestHandles[pc] = this.beginningOfLuaInstruction;
/* 839 */     this.lastInstrHandles[pc] = this.main.getEnd();
/* 840 */     if (line != this.prev_line)
/* 841 */       this.mg.addLineNumber(this.beginningOfLuaInstruction, this.prev_line = line); 
/* 842 */     this.beginningOfLuaInstruction = null;
/*     */   }
/*     */   
/*     */   public void setVarStartEnd(int slot, int start_pc, int end_pc, String name) {
/* 846 */     Integer islot = Integer.valueOf(slot);
/* 847 */     if (this.localVarGenBySlot.containsKey(islot)) {
/* 848 */       name = name.replaceAll("[^a-zA-Z0-9]", "_");
/* 849 */       LocalVariableGen l = this.localVarGenBySlot.get(islot);
/* 850 */       l.setEnd(this.lastInstrHandles[end_pc - 1]);
/* 851 */       if (start_pc > 1)
/* 852 */         l.setStart(this.lastInstrHandles[start_pc - 2]); 
/* 853 */       l.setName(name);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void resolveBranches() {
/* 858 */     int nc = this.p.code.length;
/* 859 */     for (int pc = 0; pc < nc; pc++) {
/* 860 */       if (this.branches[pc] != null) {
/* 861 */         int t = this.targets[pc];
/* 862 */         while (t < this.branchDestHandles.length && this.branchDestHandles[t] == null)
/* 863 */           t++; 
/* 864 */         if (t >= this.branchDestHandles.length)
/* 865 */           throw new IllegalArgumentException("no target at or after " + this.targets[pc] + " op=" + 
/* 866 */               Lua.GET_OPCODE(this.p.code[this.targets[pc]])); 
/* 867 */         this.branches[pc].setTarget(this.branchDestHandles[t]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setlistStack(int pc, int a0, int index0, int nvals) {
/* 873 */     for (int i = 0; i < nvals; i++) {
/* 874 */       dup();
/* 875 */       append((CompoundInstruction)new PUSH(this.cp, index0 + i));
/* 876 */       loadLocal(pc, a0 + i);
/* 877 */       append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "rawset", (Type)Type.VOID, ARG_TYPES_INT_LUAVALUE, (short)182));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setlistVarargs(int index0, int vresultbase) {
/* 883 */     append((CompoundInstruction)new PUSH(this.cp, index0));
/* 884 */     loadVarresult();
/* 885 */     append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "rawsetlist", (Type)Type.VOID, ARG_TYPES_INT_VARARGS, (short)182));
/*     */   }
/*     */ 
/*     */   
/*     */   public void concatvalue() {
/* 890 */     append((Instruction)this.factory
/* 891 */         .createInvoke(STR_LUAVALUE, "concat", (Type)TYPE_LUAVALUE, ARG_TYPES_LUAVALUE, (short)182));
/*     */   }
/*     */   
/*     */   public void concatbuffer() {
/* 895 */     append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "concat", (Type)TYPE_BUFFER, ARG_TYPES_BUFFER, (short)182));
/*     */   }
/*     */   
/*     */   public void tobuffer() {
/* 899 */     append((Instruction)this.factory.createInvoke(STR_LUAVALUE, "buffer", (Type)TYPE_BUFFER, Type.NO_ARGS, (short)182));
/*     */   }
/*     */   
/*     */   public void tovalue() {
/* 903 */     append((Instruction)this.factory.createInvoke(STR_BUFFER, "value", (Type)TYPE_LUAVALUE, Type.NO_ARGS, (short)182));
/*     */   }
/*     */   
/*     */   public void closeUpvalue(int pc, int upindex) {}
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\luajc\JavaBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */