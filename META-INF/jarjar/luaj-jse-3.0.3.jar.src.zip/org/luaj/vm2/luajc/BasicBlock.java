/*     */ package org.luaj.vm2.luajc;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import org.luaj.vm2.Lua;
/*     */ import org.luaj.vm2.Prototype;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicBlock
/*     */ {
/*     */   int pc0;
/*     */   int pc1;
/*     */   BasicBlock[] prev;
/*     */   BasicBlock[] next;
/*     */   boolean islive;
/*     */   
/*     */   public BasicBlock(Prototype p, int pc0) {
/*  18 */     this.pc0 = this.pc1 = pc0;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  23 */     StringBuffer sb = new StringBuffer();
/*  24 */     sb.append((this.pc0 + 1) + "-" + (this.pc1 + 1) + ((this.prev != null) ? ("  prv: " + str(this.prev, 1)) : "") + ((this.next != null) ? ("  nxt: " + 
/*  25 */         str(this.next, 0)) : "") + "\n");
/*  26 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private String str(BasicBlock[] b, int p) {
/*  30 */     if (b == null)
/*  31 */       return ""; 
/*  32 */     StringBuffer sb = new StringBuffer();
/*  33 */     sb.append("(");
/*  34 */     for (int i = 0, n = b.length; i < n; i++) {
/*  35 */       if (i > 0)
/*  36 */         sb.append(","); 
/*  37 */       sb.append(String.valueOf((p == 1) ? ((b[i]).pc1 + 1) : ((b[i]).pc0 + 1)));
/*     */     } 
/*  39 */     sb.append(")");
/*  40 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static BasicBlock[] findBasicBlocks(Prototype p) {
/*  46 */     int n = p.code.length;
/*  47 */     boolean[] isbeg = new boolean[n];
/*  48 */     boolean[] isend = new boolean[n];
/*  49 */     isbeg[0] = true;
/*  50 */     BranchVisitor bv = new MarkAndMergeVisitor(isbeg, isend);
/*  51 */     visitBranches(p, bv);
/*  52 */     visitBranches(p, bv);
/*     */ 
/*     */     
/*  55 */     BasicBlock[] blocks = new BasicBlock[n];
/*  56 */     for (int i = 0; i < n; i++) {
/*  57 */       isbeg[i] = true;
/*  58 */       BasicBlock b = new BasicBlock(p, i);
/*  59 */       blocks[i] = b;
/*  60 */       while (!isend[i] && i + 1 < n && !isbeg[i + 1]) {
/*  61 */         blocks[b.pc1 = ++i] = b;
/*     */       }
/*     */     } 
/*     */     
/*  65 */     int[] nnext = new int[n];
/*  66 */     int[] nprev = new int[n];
/*  67 */     visitBranches(p, new CountPrevNextVistor(isbeg, nnext, nprev));
/*     */ 
/*     */     
/*  70 */     visitBranches(p, new AllocAndXRefVisitor(isbeg, nnext, nprev, blocks));
/*  71 */     return blocks;
/*     */   }
/*     */   
/*     */   private static final class AllocAndXRefVisitor extends BranchVisitor {
/*     */     private final int[] nnext;
/*     */     private final int[] nprev;
/*     */     private final BasicBlock[] blocks;
/*     */     
/*     */     private AllocAndXRefVisitor(boolean[] isbeg, int[] nnext, int[] nprev, BasicBlock[] blocks) {
/*  80 */       super(isbeg);
/*  81 */       this.nnext = nnext;
/*  82 */       this.nprev = nprev;
/*  83 */       this.blocks = blocks;
/*     */     }
/*     */ 
/*     */     
/*     */     public void visitBranch(int pc0, int pc1) {
/*  88 */       if ((this.blocks[pc0]).next == null)
/*  89 */         (this.blocks[pc0]).next = new BasicBlock[this.nnext[pc0]]; 
/*  90 */       if ((this.blocks[pc1]).prev == null)
/*  91 */         (this.blocks[pc1]).prev = new BasicBlock[this.nprev[pc1]]; 
/*  92 */       this.nnext[pc0] = this.nnext[pc0] - 1; (this.blocks[pc0]).next[this.nnext[pc0] - 1] = this.blocks[pc1];
/*  93 */       this.nprev[pc1] = this.nprev[pc1] - 1; (this.blocks[pc1]).prev[this.nprev[pc1] - 1] = this.blocks[pc0];
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class CountPrevNextVistor extends BranchVisitor {
/*     */     private final int[] nnext;
/*     */     private final int[] nprev;
/*     */     
/*     */     private CountPrevNextVistor(boolean[] isbeg, int[] nnext, int[] nprev) {
/* 102 */       super(isbeg);
/* 103 */       this.nnext = nnext;
/* 104 */       this.nprev = nprev;
/*     */     }
/*     */ 
/*     */     
/*     */     public void visitBranch(int pc0, int pc1) {
/* 109 */       this.nnext[pc0] = this.nnext[pc0] + 1;
/* 110 */       this.nprev[pc1] = this.nprev[pc1] + 1;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class MarkAndMergeVisitor extends BranchVisitor {
/*     */     private final boolean[] isend;
/*     */     
/*     */     private MarkAndMergeVisitor(boolean[] isbeg, boolean[] isend) {
/* 118 */       super(isbeg);
/* 119 */       this.isend = isend;
/*     */     }
/*     */ 
/*     */     
/*     */     public void visitBranch(int pc0, int pc1) {
/* 124 */       this.isend[pc0] = true;
/* 125 */       this.isbeg[pc1] = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void visitReturn(int pc) {
/* 130 */       this.isend[pc] = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract class BranchVisitor {
/*     */     final boolean[] isbeg;
/*     */     
/*     */     public BranchVisitor(boolean[] isbeg) {
/* 138 */       this.isbeg = isbeg;
/*     */     }
/*     */ 
/*     */     
/*     */     public void visitBranch(int frompc, int topc) {}
/*     */     
/*     */     public void visitReturn(int atpc) {}
/*     */   }
/*     */   
/*     */   public static void visitBranches(Prototype p, BranchVisitor visitor) {
/* 148 */     int[] code = p.code;
/* 149 */     int n = code.length;
/* 150 */     for (int i = 0; i < n; i++) {
/* 151 */       int sbx, j, ins = code[i];
/* 152 */       switch (Lua.GET_OPCODE(ins)) {
/*     */         case 3:
/* 154 */           if (0 != Lua.GETARG_C(ins)) {
/*     */             
/* 156 */             if (Lua.GET_OPCODE(code[i + 1]) == 23)
/* 157 */               throw new IllegalArgumentException("OP_LOADBOOL followed by jump at " + i); 
/* 158 */             visitor.visitBranch(i, i + 2); break;
/*     */           } 
/*     */         case 24:
/*     */         case 25:
/*     */         case 26:
/*     */         case 27:
/*     */         case 28:
/* 165 */           if (Lua.GET_OPCODE(code[i + 1]) != 23)
/* 166 */             throw new IllegalArgumentException("test not followed by jump at " + i); 
/* 167 */           sbx = Lua.GETARG_sBx(code[i + 1]);
/* 168 */           i++;
/* 169 */           j = i + sbx + 1;
/* 170 */           visitor.visitBranch(i, j);
/* 171 */           visitor.visitBranch(i, i + 1);
/*     */           break;
/*     */         case 32:
/*     */         case 35:
/* 175 */           sbx = Lua.GETARG_sBx(ins);
/* 176 */           j = i + sbx + 1;
/* 177 */           visitor.visitBranch(i, j);
/* 178 */           visitor.visitBranch(i, i + 1);
/*     */           break;
/*     */         case 23:
/*     */         case 33:
/* 182 */           sbx = Lua.GETARG_sBx(ins);
/* 183 */           j = i + sbx + 1;
/* 184 */           visitor.visitBranch(i, j);
/*     */           break;
/*     */         case 30:
/*     */         case 31:
/* 188 */           visitor.visitReturn(i);
/*     */           break;
/*     */         default:
/* 191 */           if (i + 1 < n && visitor.isbeg[i + 1])
/* 192 */             visitor.visitBranch(i, i + 1); 
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public static BasicBlock[] findLiveBlocks(BasicBlock[] blocks) {
/* 198 */     Vector<BasicBlock> next = new Vector();
/* 199 */     next.addElement(blocks[0]);
/* 200 */     while (!next.isEmpty()) {
/* 201 */       BasicBlock b = next.elementAt(0);
/* 202 */       next.removeElementAt(0);
/* 203 */       if (!b.islive) {
/* 204 */         b.islive = true;
/* 205 */         for (int j = 0, n = (b.next != null) ? b.next.length : 0; j < n; j++) {
/* 206 */           if (!(b.next[j]).islive) {
/* 207 */             next.addElement(b.next[j]);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 212 */     Vector<BasicBlock> list = new Vector();
/* 213 */     for (int i = 0; i < blocks.length; i = (blocks[i]).pc1 + 1) {
/* 214 */       if ((blocks[i]).islive) {
/* 215 */         list.addElement(blocks[i]);
/*     */       }
/*     */     } 
/* 218 */     BasicBlock[] array = new BasicBlock[list.size()];
/* 219 */     list.copyInto((Object[])array);
/* 220 */     return array;
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\luajc\BasicBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */