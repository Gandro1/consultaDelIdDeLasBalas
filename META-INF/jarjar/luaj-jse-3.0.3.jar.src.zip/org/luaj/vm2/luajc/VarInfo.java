/*     */ package org.luaj.vm2.luajc;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VarInfo
/*     */ {
/*  12 */   public static VarInfo INVALID = new VarInfo(-1, -1); public final int slot; public final int pc;
/*     */   
/*     */   public static VarInfo PARAM(int slot) {
/*  15 */     return new ParamVarInfo(slot, -1);
/*     */   }
/*     */   public UpvalInfo upvalue; public boolean allocupvalue; public boolean isreferenced;
/*     */   public static VarInfo NIL(int slot) {
/*  19 */     return new NilVarInfo(slot, -1);
/*     */   }
/*     */   
/*     */   public static VarInfo PHI(ProtoInfo pi, int slot, int pc) {
/*  23 */     return new PhiVarInfo(pi, slot, pc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VarInfo(int slot, int pc) {
/*  36 */     this.slot = slot;
/*  37 */     this.pc = pc;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  42 */     return (this.slot < 0) ? "x.x" : (this.slot + "." + this.pc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VarInfo resolvePhiVariableValues() {
/*  54 */     return null;
/*     */   }
/*     */   
/*     */   protected void collectUniqueValues(Set visitedBlocks, Set<VarInfo> vars) {
/*  58 */     vars.add(this);
/*     */   }
/*     */   public boolean isPhiVar() {
/*  61 */     return false;
/*     */   }
/*     */   
/*     */   private static final class ParamVarInfo extends VarInfo { private ParamVarInfo(int slot, int pc) {
/*  65 */       super(slot, pc);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  70 */       return this.slot + ".p";
/*     */     } }
/*     */ 
/*     */   
/*     */   private static final class NilVarInfo extends VarInfo {
/*     */     private NilVarInfo(int slot, int pc) {
/*  76 */       super(slot, pc);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  81 */       return "nil";
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class PhiVarInfo extends VarInfo {
/*     */     private final ProtoInfo pi;
/*     */     VarInfo[] values;
/*     */     
/*     */     private PhiVarInfo(ProtoInfo pi, int slot, int pc) {
/*  90 */       super(slot, pc);
/*  91 */       this.pi = pi;
/*     */     }
/*     */     
/*     */     public boolean isPhiVar() {
/*  95 */       return true;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  99 */       StringBuffer sb = new StringBuffer();
/* 100 */       sb.append(super.toString());
/* 101 */       sb.append("={");
/* 102 */       for (int i = 0, n = (this.values != null) ? this.values.length : 0; i < n; i++) {
/* 103 */         if (i > 0)
/* 104 */           sb.append(","); 
/* 105 */         sb.append(String.valueOf(this.values[i]));
/*     */       } 
/* 107 */       sb.append("}");
/* 108 */       return sb.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public VarInfo resolvePhiVariableValues() {
/* 113 */       Set visitedBlocks = new HashSet();
/* 114 */       Set vars = new HashSet();
/* 115 */       collectUniqueValues(visitedBlocks, vars);
/* 116 */       if (vars.contains(INVALID))
/* 117 */         return INVALID; 
/* 118 */       int n = vars.size();
/* 119 */       Iterator<VarInfo> it = vars.iterator();
/* 120 */       if (n == 1) {
/* 121 */         VarInfo v = it.next();
/* 122 */         v.isreferenced |= this.isreferenced;
/* 123 */         return v;
/*     */       } 
/* 125 */       this.values = new VarInfo[n];
/* 126 */       for (int i = 0; i < n; i++) {
/* 127 */         this.values[i] = it.next();
/* 128 */         (this.values[i]).isreferenced |= this.isreferenced;
/*     */       } 
/* 130 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void collectUniqueValues(Set<BasicBlock> visitedBlocks, Set<VarInfo> vars) {
/* 135 */       BasicBlock b = this.pi.blocks[this.pc];
/* 136 */       if (this.pc == 0)
/* 137 */         vars.add(this.pi.params[this.slot]); 
/* 138 */       for (int i = 0, n = (b.prev != null) ? b.prev.length : 0; i < n; i++) {
/* 139 */         BasicBlock bp = b.prev[i];
/* 140 */         if (!visitedBlocks.contains(bp)) {
/* 141 */           visitedBlocks.add(bp);
/* 142 */           VarInfo v = this.pi.vars[this.slot][bp.pc1];
/* 143 */           if (v != null)
/* 144 */             v.collectUniqueValues(visitedBlocks, vars); 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\luajc\VarInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */