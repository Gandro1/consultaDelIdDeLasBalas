/*    */ package org.luaj.vm2.luajc;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.luaj.vm2.LuaFunction;
/*    */ import org.luaj.vm2.LuaValue;
/*    */ import org.luaj.vm2.Prototype;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaLoader
/*    */   extends ClassLoader
/*    */ {
/* 33 */   private final Map<String, byte[]> unloaded = (Map)new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LuaFunction load(Prototype p, String classname, String filename, LuaValue env) {
/* 39 */     JavaGen jg = new JavaGen(p, classname, filename, false);
/* 40 */     return load(jg, env);
/*    */   }
/*    */   
/*    */   public LuaFunction load(JavaGen jg, LuaValue env) {
/* 44 */     include(jg);
/* 45 */     return load(jg.classname, env);
/*    */   }
/*    */   
/*    */   public LuaFunction load(String classname, LuaValue env) {
/*    */     try {
/* 50 */       Class<?> c = loadClass(classname);
/* 51 */       LuaFunction v = (LuaFunction)c.newInstance();
/* 52 */       v.initupvalue1(env);
/* 53 */       return v;
/* 54 */     } catch (Exception e) {
/* 55 */       e.printStackTrace();
/* 56 */       throw new IllegalStateException("bad class gen: " + e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void include(JavaGen jg) {
/* 61 */     this.unloaded.put(jg.classname, jg.bytecode);
/* 62 */     for (int i = 0, n = (jg.inners != null) ? jg.inners.length : 0; i < n; i++) {
/* 63 */       include(jg.inners[i]);
/*    */     }
/*    */   }
/*    */   
/*    */   public Class findClass(String classname) throws ClassNotFoundException {
/* 68 */     byte[] bytes = this.unloaded.get(classname);
/* 69 */     if (bytes != null)
/* 70 */       return defineClass(classname, bytes, 0, bytes.length); 
/* 71 */     return super.findClass(classname);
/*    */   }
/*    */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\luajc\JavaLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */