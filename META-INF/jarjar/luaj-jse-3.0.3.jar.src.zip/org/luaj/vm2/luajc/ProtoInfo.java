/*     */ package org.luaj.vm2.luajc;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Hashtable;
/*     */ import org.luaj.vm2.Lua;
/*     */ import org.luaj.vm2.LuaString;
/*     */ import org.luaj.vm2.Print;
/*     */ import org.luaj.vm2.Prototype;
/*     */ import org.luaj.vm2.Upvaldesc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProtoInfo
/*     */ {
/*     */   public final String name;
/*     */   public final Prototype prototype;
/*     */   public final ProtoInfo[] subprotos;
/*     */   public final BasicBlock[] blocks;
/*     */   public final BasicBlock[] blocklist;
/*     */   public final VarInfo[] params;
/*     */   public final VarInfo[][] vars;
/*     */   public final UpvalInfo[] upvals;
/*     */   public final UpvalInfo[][] openups;
/*     */   
/*     */   public ProtoInfo(Prototype p, String name) {
/*  31 */     this(p, name, null);
/*     */   }
/*     */   
/*     */   private ProtoInfo(Prototype p, String name, UpvalInfo[] u) {
/*  35 */     this.name = name;
/*  36 */     this.prototype = p;
/*  37 */     (new UpvalInfo[1])[0] = new UpvalInfo(this); this.upvals = (u != null) ? u : new UpvalInfo[1];
/*  38 */     this.subprotos = (p.p != null && p.p.length > 0) ? new ProtoInfo[p.p.length] : null;
/*     */ 
/*     */     
/*  41 */     this.blocks = BasicBlock.findBasicBlocks(p);
/*  42 */     this.blocklist = BasicBlock.findLiveBlocks(this.blocks);
/*     */ 
/*     */     
/*  45 */     this.params = new VarInfo[p.maxstacksize];
/*  46 */     for (int slot = 0; slot < p.maxstacksize; slot++) {
/*  47 */       VarInfo v = VarInfo.PARAM(slot);
/*  48 */       this.params[slot] = v;
/*     */     } 
/*     */ 
/*     */     
/*  52 */     this.vars = findVariables();
/*  53 */     replaceTrivialPhiVariables();
/*     */ 
/*     */     
/*  56 */     this.openups = new UpvalInfo[p.maxstacksize][];
/*  57 */     findUpvalues();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  62 */     StringBuffer sb = new StringBuffer();
/*     */ 
/*     */     
/*  65 */     sb.append("proto '" + this.name + "'\n");
/*     */     
/*     */     int i;
/*  68 */     for (i = 0, n = (this.upvals != null) ? this.upvals.length : 0; i < n; i++) {
/*  69 */       sb.append(" up[" + i + "]: " + this.upvals[i] + "\n");
/*     */     }
/*     */     
/*  72 */     for (BasicBlock b : this.blocklist) {
/*  73 */       int pc0 = b.pc0;
/*  74 */       sb.append("  block " + b.toString());
/*  75 */       appendOpenUps(sb, -1);
/*     */ 
/*     */       
/*  78 */       for (int pc = pc0; pc <= b.pc1; pc++) {
/*     */ 
/*     */         
/*  81 */         appendOpenUps(sb, pc);
/*     */ 
/*     */         
/*  84 */         sb.append("     ");
/*  85 */         for (int j = 0; j < this.prototype.maxstacksize; j++) {
/*  86 */           VarInfo v = this.vars[j][pc];
/*  87 */           String u = (v == null) ? "" : ((v.upvalue != null) ? (!v.upvalue.rw ? "[C] " : ((v.allocupvalue && v.pc == pc) ? "[*] " : "[]  ")) : "    ");
/*     */ 
/*     */           
/*  90 */           String s = (v == null) ? "null   " : String.valueOf(v);
/*  91 */           sb.append(s + u);
/*     */         } 
/*  93 */         sb.append("  ");
/*  94 */         ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  95 */         PrintStream ops = Print.ps;
/*  96 */         Print.ps = new PrintStream(baos);
/*     */         try {
/*  98 */           Print.printOpCode(this.prototype, pc);
/*     */         } finally {
/* 100 */           Print.ps.close();
/* 101 */           Print.ps = ops;
/*     */         } 
/* 103 */         sb.append(baos.toString());
/* 104 */         sb.append("\n");
/*     */       } 
/*     */     } 
/*     */     
/*     */     int n;
/* 109 */     for (i = 0, n = (this.subprotos != null) ? this.subprotos.length : 0; i < n; i++) {
/* 110 */       sb.append(this.subprotos[i].toString());
/*     */     }
/*     */     
/* 113 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private void appendOpenUps(StringBuffer sb, int pc) {
/* 117 */     for (int j = 0; j < this.prototype.maxstacksize; j++) {
/* 118 */       VarInfo v = (pc < 0) ? this.params[j] : this.vars[j][pc];
/* 119 */       if (v != null && v.pc == pc && v.allocupvalue) {
/* 120 */         sb.append("    open: " + v.upvalue + "\n");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private VarInfo[][] findVariables() {
/* 128 */     int n = this.prototype.code.length;
/* 129 */     int m = this.prototype.maxstacksize;
/* 130 */     VarInfo[][] v = new VarInfo[m][];
/* 131 */     for (int i = 0; i < v.length; i++) {
/* 132 */       v[i] = new VarInfo[n];
/*     */     }
/*     */     
/* 135 */     for (BasicBlock element : this.blocklist) {
/* 136 */       BasicBlock b0 = element;
/*     */ 
/*     */       
/* 139 */       int nprev = (b0.prev != null) ? b0.prev.length : 0;
/* 140 */       for (int slot = 0; slot < m; slot++) {
/* 141 */         VarInfo var = null;
/* 142 */         if (nprev == 0) {
/* 143 */           var = this.params[slot];
/* 144 */         } else if (nprev == 1) {
/* 145 */           var = v[slot][(b0.prev[0]).pc1];
/*     */         } else {
/* 147 */           for (int j = 0; j < nprev; j++) {
/* 148 */             BasicBlock bp = b0.prev[j];
/* 149 */             if (v[slot][bp.pc1] == VarInfo.INVALID)
/* 150 */               var = VarInfo.INVALID; 
/*     */           } 
/*     */         } 
/* 153 */         if (var == null)
/* 154 */           var = VarInfo.PHI(this, slot, b0.pc0); 
/* 155 */         v[slot][b0.pc0] = var;
/*     */       } 
/*     */ 
/*     */       
/* 159 */       for (int pc = b0.pc0; pc <= b0.pc1; pc++) {
/*     */         int a, b, c, i4, i3, j, i2; Upvaldesc[] upvalues;
/*     */         int i1, k, nups;
/* 162 */         if (pc > b0.pc0) {
/* 163 */           propogateVars(v, pc - 1, pc);
/*     */         }
/*     */         
/* 166 */         int ins = this.prototype.code[pc];
/* 167 */         int op = Lua.GET_OPCODE(ins);
/*     */ 
/*     */         
/* 170 */         switch (op) {
/*     */           case 1:
/*     */           case 3:
/*     */           case 5:
/*     */           case 11:
/* 175 */             a = Lua.GETARG_A(ins);
/* 176 */             v[a][pc] = new VarInfo(a, pc);
/*     */             break;
/*     */           
/*     */           case 0:
/*     */           case 19:
/*     */           case 20:
/*     */           case 21:
/*     */           case 28:
/* 184 */             a = Lua.GETARG_A(ins);
/* 185 */             b = Lua.GETARG_B(ins);
/* 186 */             (v[b][pc]).isreferenced = true;
/* 187 */             v[a][pc] = new VarInfo(a, pc);
/*     */             break;
/*     */           
/*     */           case 13:
/*     */           case 14:
/*     */           case 15:
/*     */           case 16:
/*     */           case 17:
/*     */           case 18:
/* 196 */             a = Lua.GETARG_A(ins);
/* 197 */             b = Lua.GETARG_B(ins);
/* 198 */             c = Lua.GETARG_C(ins);
/* 199 */             if (!Lua.ISK(b))
/* 200 */               (v[b][pc]).isreferenced = true; 
/* 201 */             if (!Lua.ISK(c))
/* 202 */               (v[c][pc]).isreferenced = true; 
/* 203 */             v[a][pc] = new VarInfo(a, pc);
/*     */             break;
/*     */           
/*     */           case 10:
/* 207 */             a = Lua.GETARG_A(ins);
/* 208 */             b = Lua.GETARG_B(ins);
/* 209 */             c = Lua.GETARG_C(ins);
/* 210 */             (v[a][pc]).isreferenced = true;
/* 211 */             if (!Lua.ISK(b))
/* 212 */               (v[b][pc]).isreferenced = true; 
/* 213 */             if (!Lua.ISK(c)) {
/* 214 */               (v[c][pc]).isreferenced = true;
/*     */             }
/*     */             break;
/*     */           case 8:
/* 218 */             b = Lua.GETARG_B(ins);
/* 219 */             c = Lua.GETARG_C(ins);
/* 220 */             if (!Lua.ISK(b))
/* 221 */               (v[b][pc]).isreferenced = true; 
/* 222 */             if (!Lua.ISK(c)) {
/* 223 */               (v[c][pc]).isreferenced = true;
/*     */             }
/*     */             break;
/*     */           case 22:
/* 227 */             a = Lua.GETARG_A(ins);
/* 228 */             b = Lua.GETARG_B(ins);
/* 229 */             c = Lua.GETARG_C(ins);
/* 230 */             for (; b <= c; b++)
/* 231 */               (v[b][pc]).isreferenced = true; 
/* 232 */             v[a][pc] = new VarInfo(a, pc);
/*     */             break;
/*     */           
/*     */           case 33:
/* 236 */             a = Lua.GETARG_A(ins);
/* 237 */             (v[a + 2][pc]).isreferenced = true;
/* 238 */             v[a][pc] = new VarInfo(a, pc);
/*     */             break;
/*     */           
/*     */           case 7:
/* 242 */             a = Lua.GETARG_A(ins);
/* 243 */             b = Lua.GETARG_B(ins);
/* 244 */             c = Lua.GETARG_C(ins);
/* 245 */             (v[b][pc]).isreferenced = true;
/* 246 */             if (!Lua.ISK(c))
/* 247 */               (v[c][pc]).isreferenced = true; 
/* 248 */             v[a][pc] = new VarInfo(a, pc);
/*     */             break;
/*     */           
/*     */           case 6:
/* 252 */             a = Lua.GETARG_A(ins);
/* 253 */             c = Lua.GETARG_C(ins);
/* 254 */             if (!Lua.ISK(c))
/* 255 */               (v[c][pc]).isreferenced = true; 
/* 256 */             v[a][pc] = new VarInfo(a, pc);
/*     */             break;
/*     */           
/*     */           case 12:
/* 260 */             a = Lua.GETARG_A(ins);
/* 261 */             b = Lua.GETARG_B(ins);
/* 262 */             c = Lua.GETARG_C(ins);
/* 263 */             (v[b][pc]).isreferenced = true;
/* 264 */             if (!Lua.ISK(c))
/* 265 */               (v[c][pc]).isreferenced = true; 
/* 266 */             v[a][pc] = new VarInfo(a, pc);
/* 267 */             v[a + 1][pc] = new VarInfo(a + 1, pc);
/*     */             break;
/*     */ 
/*     */           
/*     */           case 32:
/* 272 */             a = Lua.GETARG_A(ins);
/* 273 */             (v[a][pc]).isreferenced = true;
/* 274 */             (v[a + 2][pc]).isreferenced = true;
/* 275 */             v[a][pc] = new VarInfo(a, pc);
/* 276 */             (v[a][pc]).isreferenced = true;
/* 277 */             (v[a + 1][pc]).isreferenced = true;
/* 278 */             v[a + 3][pc] = new VarInfo(a + 3, pc);
/*     */             break;
/*     */           
/*     */           case 4:
/* 282 */             a = Lua.GETARG_A(ins);
/* 283 */             b = Lua.GETARG_B(ins);
/* 284 */             for (; b-- >= 0; a++) {
/* 285 */               v[a][pc] = new VarInfo(a, pc);
/*     */             }
/*     */             break;
/*     */           case 38:
/* 289 */             a = Lua.GETARG_A(ins);
/* 290 */             b = Lua.GETARG_B(ins);
/* 291 */             for (i4 = 1; i4 < b; i4++, a++)
/* 292 */               v[a][pc] = new VarInfo(a, pc); 
/* 293 */             if (b == 0)
/* 294 */               for (; a < m; a++) {
/* 295 */                 v[a][pc] = VarInfo.INVALID;
/*     */               } 
/*     */             break;
/*     */           case 29:
/* 299 */             a = Lua.GETARG_A(ins);
/* 300 */             b = Lua.GETARG_B(ins);
/* 301 */             c = Lua.GETARG_C(ins);
/* 302 */             (v[a][pc]).isreferenced = true;
/* 303 */             (v[a][pc]).isreferenced = true;
/* 304 */             for (i3 = 1; i3 <= b - 1; i3++)
/* 305 */               (v[a + i3][pc]).isreferenced = true; 
/* 306 */             for (j = 0; j <= c - 2; j++, a++)
/* 307 */               v[a][pc] = new VarInfo(a, pc); 
/* 308 */             for (; a < m; a++) {
/* 309 */               v[a][pc] = VarInfo.INVALID;
/*     */             }
/*     */             break;
/*     */           case 34:
/* 313 */             a = Lua.GETARG_A(ins);
/* 314 */             c = Lua.GETARG_C(ins);
/* 315 */             (v[a++][pc]).isreferenced = true;
/* 316 */             (v[a++][pc]).isreferenced = true;
/* 317 */             (v[a++][pc]).isreferenced = true;
/* 318 */             for (j = 0; j < c; j++, a++)
/* 319 */               v[a][pc] = new VarInfo(a, pc); 
/* 320 */             for (; a < m; a++) {
/* 321 */               v[a][pc] = VarInfo.INVALID;
/*     */             }
/*     */             break;
/*     */           case 35:
/* 325 */             a = Lua.GETARG_A(ins);
/* 326 */             (v[a + 1][pc]).isreferenced = true;
/* 327 */             v[a][pc] = new VarInfo(a, pc);
/*     */             break;
/*     */           
/*     */           case 30:
/* 331 */             a = Lua.GETARG_A(ins);
/* 332 */             b = Lua.GETARG_B(ins);
/* 333 */             (v[a][pc]).isreferenced = true;
/* 334 */             for (i2 = 1; i2 <= b - 1; i2++) {
/* 335 */               (v[a + i2][pc]).isreferenced = true;
/*     */             }
/*     */             break;
/*     */           case 31:
/* 339 */             a = Lua.GETARG_A(ins);
/* 340 */             b = Lua.GETARG_B(ins);
/* 341 */             for (i2 = 0; i2 <= b - 2; i2++) {
/* 342 */               (v[a + i2][pc]).isreferenced = true;
/*     */             }
/*     */             break;
/*     */           case 37:
/* 346 */             a = Lua.GETARG_A(ins);
/* 347 */             b = Lua.GETARG_Bx(ins);
/* 348 */             upvalues = (this.prototype.p[b]).upvalues;
/* 349 */             for (k = 0, nups = upvalues.length; k < nups; k++) {
/* 350 */               if ((upvalues[k]).instack)
/* 351 */                 (v[(upvalues[k]).idx][pc]).isreferenced = true; 
/* 352 */             }  v[a][pc] = new VarInfo(a, pc);
/*     */             break;
/*     */ 
/*     */           
/*     */           case 36:
/* 357 */             a = Lua.GETARG_A(ins);
/* 358 */             b = Lua.GETARG_B(ins);
/* 359 */             (v[a][pc]).isreferenced = true;
/* 360 */             for (i1 = 1; i1 <= b; i1++) {
/* 361 */               (v[a + i1][pc]).isreferenced = true;
/*     */             }
/*     */             break;
/*     */           case 9:
/*     */           case 27:
/* 366 */             a = Lua.GETARG_A(ins);
/* 367 */             (v[a][pc]).isreferenced = true;
/*     */             break;
/*     */           
/*     */           case 24:
/*     */           case 25:
/*     */           case 26:
/* 373 */             b = Lua.GETARG_B(ins);
/* 374 */             c = Lua.GETARG_C(ins);
/* 375 */             if (!Lua.ISK(b))
/* 376 */               (v[b][pc]).isreferenced = true; 
/* 377 */             if (!Lua.ISK(c)) {
/* 378 */               (v[c][pc]).isreferenced = true;
/*     */             }
/*     */             break;
/*     */           case 23:
/* 382 */             a = Lua.GETARG_A(ins);
/* 383 */             if (a > 0)
/* 384 */               for (; --a < m; a++) {
/* 385 */                 v[a][pc] = VarInfo.INVALID;
/*     */               } 
/*     */             break;
/*     */           default:
/* 389 */             throw new IllegalStateException("unhandled opcode: " + ins);
/*     */         } 
/*     */       } 
/*     */     } 
/* 393 */     return v;
/*     */   }
/*     */   
/*     */   private static void propogateVars(VarInfo[][] v, int pcfrom, int pcto) {
/* 397 */     for (int j = 0, m = v.length; j < m; j++)
/* 398 */       v[j][pcto] = v[j][pcfrom]; 
/*     */   }
/*     */   
/*     */   private void replaceTrivialPhiVariables() {
/* 402 */     for (BasicBlock b0 : this.blocklist) {
/* 403 */       for (int slot = 0; slot < this.prototype.maxstacksize; slot++) {
/* 404 */         VarInfo vold = this.vars[slot][b0.pc0];
/* 405 */         VarInfo vnew = vold.resolvePhiVariableValues();
/* 406 */         if (vnew != null)
/* 407 */           substituteVariable(slot, vold, vnew); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void substituteVariable(int slot, VarInfo vold, VarInfo vnew) {
/* 413 */     for (int i = 0, n = this.prototype.code.length; i < n; i++)
/* 414 */       replaceAll(this.vars[slot], (this.vars[slot]).length, vold, vnew); 
/*     */   }
/*     */   
/*     */   private void replaceAll(VarInfo[] v, int n, VarInfo vold, VarInfo vnew) {
/* 418 */     for (int i = 0; i < n; i++) {
/* 419 */       if (v[i] == vold)
/* 420 */         v[i] = vnew; 
/*     */     } 
/*     */   }
/*     */   private void findUpvalues() {
/* 424 */     int[] code = this.prototype.code;
/* 425 */     int n = code.length;
/*     */ 
/*     */     
/* 428 */     String[] names = findInnerprotoNames(); int pc;
/* 429 */     for (pc = 0; pc < n; pc++) {
/* 430 */       if (Lua.GET_OPCODE(code[pc]) == 37) {
/* 431 */         int bx = Lua.GETARG_Bx(code[pc]);
/* 432 */         Prototype newp = this.prototype.p[bx];
/* 433 */         UpvalInfo[] newu = new UpvalInfo[newp.upvalues.length];
/* 434 */         String newname = this.name + "$" + names[bx];
/* 435 */         for (int j = 0; j < newp.upvalues.length; j++) {
/* 436 */           Upvaldesc u = newp.upvalues[j];
/* 437 */           newu[j] = u.instack ? findOpenUp(pc, u.idx) : this.upvals[u.idx];
/*     */         } 
/* 439 */         this.subprotos[bx] = new ProtoInfo(newp, newname, newu);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 444 */     for (pc = 0; pc < n; pc++) {
/* 445 */       if (Lua.GET_OPCODE(code[pc]) == 9)
/* 446 */         (this.upvals[Lua.GETARG_B(code[pc])]).rw = true; 
/*     */     } 
/*     */   }
/*     */   
/*     */   private UpvalInfo findOpenUp(int pc, int slot) {
/* 451 */     if (this.openups[slot] == null)
/* 452 */       this.openups[slot] = new UpvalInfo[this.prototype.code.length]; 
/* 453 */     if (this.openups[slot][pc] != null)
/* 454 */       return this.openups[slot][pc]; 
/* 455 */     UpvalInfo u = new UpvalInfo(this, pc, slot);
/* 456 */     for (int i = 0, n = this.prototype.code.length; i < n; i++) {
/* 457 */       if (this.vars[slot][i] != null && (this.vars[slot][i]).upvalue == u)
/* 458 */         this.openups[slot][i] = u; 
/* 459 */     }  return u;
/*     */   }
/*     */   
/*     */   public boolean isUpvalueAssign(int pc, int slot) {
/* 463 */     VarInfo v = (pc < 0) ? this.params[slot] : this.vars[slot][pc];
/* 464 */     return (v != null && v.upvalue != null && v.upvalue.rw);
/*     */   }
/*     */   
/*     */   public boolean isUpvalueCreate(int pc, int slot) {
/* 468 */     VarInfo v = (pc < 0) ? this.params[slot] : this.vars[slot][pc];
/* 469 */     return (v != null && v.upvalue != null && v.upvalue.rw && v.allocupvalue && pc == v.pc);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUpvalueRefer(int pc, int slot) {
/* 474 */     if (pc > 0 && this.vars[slot][pc] != null && (this.vars[slot][pc]).pc == pc && this.vars[slot][pc - 1] != null)
/* 475 */       pc--; 
/* 476 */     VarInfo v = (pc < 0) ? this.params[slot] : this.vars[slot][pc];
/* 477 */     return (v != null && v.upvalue != null && v.upvalue.rw);
/*     */   }
/*     */   
/*     */   public boolean isInitialValueUsed(int slot) {
/* 481 */     VarInfo v = this.params[slot];
/* 482 */     return v.isreferenced;
/*     */   }
/*     */   
/*     */   public boolean isReadWriteUpvalue(UpvalInfo u) {
/* 486 */     return u.rw;
/*     */   }
/*     */   
/*     */   private String[] findInnerprotoNames() {
/* 490 */     if (this.prototype.p.length <= 0) {
/* 491 */       return null;
/*     */     }
/* 493 */     String[] names = new String[this.prototype.p.length];
/* 494 */     Hashtable<Object, Object> used = new Hashtable<>();
/* 495 */     int[] code = this.prototype.code;
/* 496 */     int n = code.length;
/* 497 */     for (int pc = 0; pc < n; pc++) {
/* 498 */       if (Lua.GET_OPCODE(code[pc]) == 37) {
/* 499 */         int b, a; LuaString s; int bx = Lua.GETARG_Bx(code[pc]);
/* 500 */         String name = null;
/* 501 */         int i = code[pc + 1];
/* 502 */         switch (Lua.GET_OPCODE(i)) {
/*     */           case 8:
/*     */           case 10:
/* 505 */             b = Lua.GETARG_B(i);
/* 506 */             if (Lua.ISK(b)) {
/* 507 */               name = this.prototype.k[b & 0xFF].tojstring();
/*     */             }
/*     */             break;
/*     */           case 9:
/* 511 */             b = Lua.GETARG_B(i);
/* 512 */             s = (this.prototype.upvalues[b]).name;
/* 513 */             if (s != null) {
/* 514 */               name = s.tojstring();
/*     */             }
/*     */             break;
/*     */           default:
/* 518 */             a = Lua.GETARG_A(code[pc]);
/* 519 */             s = this.prototype.getlocalname(a + 1, pc + 1);
/* 520 */             if (s != null)
/* 521 */               name = s.tojstring(); 
/*     */             break;
/*     */         } 
/* 524 */         name = (name != null) ? toJavaClassPart(name) : String.valueOf(bx);
/* 525 */         if (used.containsKey(name)) {
/* 526 */           String basename = name;
/* 527 */           int count = 1;
/*     */           do {
/* 529 */             name = basename + '$' + count++;
/* 530 */           } while (used.containsKey(name));
/*     */         } 
/* 532 */         used.put(name, Boolean.TRUE);
/* 533 */         names[bx] = name;
/*     */       } 
/*     */     } 
/* 536 */     return names;
/*     */   }
/*     */   
/*     */   private static String toJavaClassPart(String s) {
/* 540 */     int n = s.length();
/* 541 */     StringBuffer sb = new StringBuffer(n);
/* 542 */     for (int i = 0; i < n; i++)
/* 543 */       sb.append(Character.isJavaIdentifierPart(s.charAt(i)) ? s.charAt(i) : 95); 
/* 544 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\luajc\ProtoInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */