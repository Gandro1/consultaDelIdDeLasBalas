/*     */ package org.luaj.vm2.luajc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.util.Hashtable;
/*     */ import org.luaj.vm2.Globals;
/*     */ import org.luaj.vm2.LuaFunction;
/*     */ import org.luaj.vm2.LuaValue;
/*     */ import org.luaj.vm2.Prototype;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LuaJC
/*     */   implements Globals.Loader
/*     */ {
/*  69 */   public static final LuaJC instance = new LuaJC();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void install(Globals G) {
/*  76 */     G.loader = instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable compileAll(InputStream script, String chunkname, String filename, Globals globals, boolean genmain) throws IOException {
/*  83 */     String classname = toStandardJavaClassName(chunkname);
/*  84 */     Prototype p = globals.loadPrototype(script, classname, "bt");
/*  85 */     return compileProtoAndSubProtos(p, classname, filename, genmain);
/*     */   }
/*     */ 
/*     */   
/*     */   public Hashtable compileAll(Reader script, String chunkname, String filename, Globals globals, boolean genmain) throws IOException {
/*  90 */     String classname = toStandardJavaClassName(chunkname);
/*  91 */     Prototype p = globals.compilePrototype(script, classname);
/*  92 */     return compileProtoAndSubProtos(p, classname, filename, genmain);
/*     */   }
/*     */ 
/*     */   
/*     */   private Hashtable compileProtoAndSubProtos(Prototype p, String classname, String filename, boolean genmain) throws IOException {
/*  97 */     String luaname = toStandardLuaFileName(filename);
/*  98 */     Hashtable<Object, Object> h = new Hashtable<>();
/*  99 */     JavaGen gen = new JavaGen(p, classname, luaname, genmain);
/* 100 */     insert(h, gen);
/* 101 */     return h;
/*     */   }
/*     */   
/*     */   private void insert(Hashtable<String, byte[]> h, JavaGen gen) {
/* 105 */     h.put(gen.classname, gen.bytecode);
/* 106 */     for (int i = 0, n = (gen.inners != null) ? gen.inners.length : 0; i < n; i++) {
/* 107 */       insert(h, gen.inners[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public LuaFunction load(Prototype p, String name, LuaValue globals) throws IOException {
/* 112 */     String luaname = toStandardLuaFileName(name);
/* 113 */     String classname = toStandardJavaClassName(luaname);
/* 114 */     JavaLoader loader = new JavaLoader();
/* 115 */     return loader.load(p, classname, luaname, globals);
/*     */   }
/*     */   
/*     */   private static String toStandardJavaClassName(String luachunkname) {
/* 119 */     String stub = toStub(luachunkname);
/* 120 */     StringBuffer classname = new StringBuffer();
/* 121 */     for (int i = 0, n = stub.length(); i < n; i++) {
/* 122 */       char c = stub.charAt(i);
/* 123 */       classname.append(((i == 0 && 
/* 124 */           Character.isJavaIdentifierStart(c)) || (i > 0 && Character.isJavaIdentifierPart(c))) ? c : 95);
/*     */     } 
/* 126 */     return classname.toString();
/*     */   }
/*     */   
/*     */   private static String toStandardLuaFileName(String luachunkname) {
/* 130 */     String stub = toStub(luachunkname);
/* 131 */     String filename = stub.replace('.', '/') + ".lua";
/* 132 */     return filename.startsWith("@") ? filename.substring(1) : filename;
/*     */   }
/*     */   
/*     */   private static String toStub(String s) {
/* 136 */     return s.endsWith(".lua") ? s.substring(0, s.length() - 4) : s;
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\luajc\LuaJC.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */