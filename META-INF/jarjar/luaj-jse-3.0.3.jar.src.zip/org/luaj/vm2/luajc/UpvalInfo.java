/*     */ package org.luaj.vm2.luajc;
/*     */ 
/*     */ import org.luaj.vm2.Lua;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpvalInfo
/*     */ {
/*     */   ProtoInfo pi;
/*     */   int slot;
/*     */   int nvars;
/*     */   VarInfo[] var;
/*     */   boolean rw;
/*     */   
/*     */   public UpvalInfo(ProtoInfo pi) {
/*  17 */     this.pi = pi;
/*  18 */     this.slot = 0;
/*  19 */     this.nvars = 1;
/*  20 */     this.var = new VarInfo[] { VarInfo.PARAM(0) };
/*  21 */     this.rw = false;
/*     */   }
/*     */   
/*     */   public UpvalInfo(ProtoInfo pi, int pc, int slot) {
/*  25 */     this.pi = pi;
/*  26 */     this.slot = slot;
/*  27 */     this.nvars = 0;
/*  28 */     this.var = null;
/*  29 */     includeVarAndPosteriorVars(pi.vars[slot][pc]);
/*  30 */     for (int i = 0; i < this.nvars; i++)
/*  31 */       (this.var[i]).allocupvalue = testIsAllocUpvalue(this.var[i]); 
/*  32 */     this.rw = (this.nvars > 1);
/*     */   }
/*     */   
/*     */   private boolean includeVarAndPosteriorVars(VarInfo var) {
/*  36 */     if (var == null || var == VarInfo.INVALID)
/*  37 */       return false; 
/*  38 */     if (var.upvalue == this)
/*  39 */       return true; 
/*  40 */     var.upvalue = this;
/*  41 */     appendVar(var);
/*  42 */     if (isLoopVariable(var))
/*  43 */       return false; 
/*  44 */     boolean loopDetected = includePosteriorVarsCheckLoops(var);
/*  45 */     if (loopDetected)
/*  46 */       includePriorVarsIgnoreLoops(var); 
/*  47 */     return loopDetected;
/*     */   }
/*     */   
/*     */   private boolean isLoopVariable(VarInfo var) {
/*  51 */     if (var.pc >= 0) {
/*  52 */       switch (Lua.GET_OPCODE(this.pi.prototype.code[var.pc])) {
/*     */         case 32:
/*     */         case 35:
/*  55 */           return true;
/*     */       } 
/*     */     }
/*  58 */     return false;
/*     */   }
/*     */   
/*     */   private boolean includePosteriorVarsCheckLoops(VarInfo prior) {
/*  62 */     boolean loopDetected = false;
/*  63 */     for (BasicBlock b : this.pi.blocklist) {
/*  64 */       VarInfo v = this.pi.vars[this.slot][b.pc1];
/*  65 */       if (v == prior) {
/*  66 */         for (int j = 0, m = (b.next != null) ? b.next.length : 0; j < m; j++) {
/*  67 */           BasicBlock b1 = b.next[j];
/*  68 */           VarInfo v1 = this.pi.vars[this.slot][b1.pc0];
/*  69 */           if (v1 != prior) {
/*  70 */             loopDetected |= includeVarAndPosteriorVars(v1);
/*  71 */             if (v1.isPhiVar())
/*  72 */               includePriorVarsIgnoreLoops(v1); 
/*     */           } 
/*     */         } 
/*     */       } else {
/*  76 */         for (int pc = b.pc1 - 1; pc >= b.pc0; pc--) {
/*  77 */           if (this.pi.vars[this.slot][pc] == prior) {
/*  78 */             loopDetected |= includeVarAndPosteriorVars(this.pi.vars[this.slot][pc + 1]);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*  84 */     return loopDetected;
/*     */   }
/*     */   
/*     */   private void includePriorVarsIgnoreLoops(VarInfo poster) {
/*  88 */     for (BasicBlock b : this.pi.blocklist) {
/*  89 */       VarInfo v = this.pi.vars[this.slot][b.pc0];
/*  90 */       if (v == poster) {
/*  91 */         for (int j = 0, m = (b.prev != null) ? b.prev.length : 0; j < m; j++) {
/*  92 */           BasicBlock b0 = b.prev[j];
/*  93 */           VarInfo v0 = this.pi.vars[this.slot][b0.pc1];
/*  94 */           if (v0 != poster)
/*  95 */             includeVarAndPosteriorVars(v0); 
/*     */         } 
/*     */       } else {
/*  98 */         for (int pc = b.pc0 + 1; pc <= b.pc1; pc++) {
/*  99 */           if (this.pi.vars[this.slot][pc] == poster) {
/* 100 */             includeVarAndPosteriorVars(this.pi.vars[this.slot][pc - 1]);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void appendVar(VarInfo v) {
/* 109 */     if (this.nvars == 0) {
/* 110 */       this.var = new VarInfo[1];
/* 111 */     } else if (this.nvars + 1 >= this.var.length) {
/* 112 */       VarInfo[] s = this.var;
/* 113 */       this.var = new VarInfo[this.nvars * 2 + 1];
/* 114 */       System.arraycopy(s, 0, this.var, 0, this.nvars);
/*     */     } 
/* 116 */     this.var[this.nvars++] = v;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 121 */     StringBuffer sb = new StringBuffer();
/* 122 */     sb.append(this.pi.name);
/* 123 */     for (int i = 0; i < this.nvars; i++) {
/* 124 */       sb.append((i > 0) ? "," : " ");
/* 125 */       sb.append(String.valueOf(this.var[i]));
/*     */     } 
/* 127 */     if (this.rw)
/* 128 */       sb.append("(rw)"); 
/* 129 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private boolean testIsAllocUpvalue(VarInfo v) {
/* 133 */     if (v.pc < 0)
/* 134 */       return true; 
/* 135 */     BasicBlock b = this.pi.blocks[v.pc];
/* 136 */     if (v.pc > b.pc0)
/* 137 */       return ((this.pi.vars[this.slot][v.pc - 1]).upvalue != this); 
/* 138 */     if (b.prev == null) {
/* 139 */       v = this.pi.params[this.slot];
/* 140 */       if (v != null && v.upvalue != this)
/* 141 */         return true; 
/*     */     } else {
/* 143 */       for (BasicBlock element : b.prev) {
/* 144 */         v = this.pi.vars[this.slot][element.pc1];
/* 145 */         if (v != null && v.upvalue != this)
/* 146 */           return true; 
/*     */       } 
/*     */     } 
/* 149 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\luajc\UpvalInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */