/*     */ package org.luaj.vm2.luajc;
/*     */ 
/*     */ import org.luaj.vm2.LocVars;
/*     */ import org.luaj.vm2.Lua;
/*     */ import org.luaj.vm2.Prototype;
/*     */ import org.luaj.vm2.Upvaldesc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaGen
/*     */ {
/*     */   public final String classname;
/*     */   public final byte[] bytecode;
/*     */   public final JavaGen[] inners;
/*     */   
/*     */   public JavaGen(Prototype p, String classname, String filename, boolean genmain) {
/*  39 */     this(new ProtoInfo(p, classname), classname, filename, genmain);
/*     */   }
/*     */   
/*     */   private JavaGen(ProtoInfo pi, String classname, String filename, boolean genmain) {
/*  43 */     this.classname = classname;
/*     */ 
/*     */     
/*  46 */     JavaBuilder builder = new JavaBuilder(pi, classname, filename);
/*  47 */     scanInstructions(pi, classname, builder);
/*  48 */     for (int i = 0; i < pi.prototype.locvars.length; i++) {
/*  49 */       LocVars l = pi.prototype.locvars[i];
/*  50 */       builder.setVarStartEnd(i, l.startpc, l.endpc, l.varname.tojstring());
/*     */     } 
/*  52 */     this.bytecode = builder.completeClass(genmain);
/*     */ 
/*     */     
/*  55 */     if (pi.subprotos != null) {
/*  56 */       int n = pi.subprotos.length;
/*  57 */       this.inners = new JavaGen[n];
/*  58 */       for (int j = 0; j < n; j++)
/*  59 */         this.inners[j] = new JavaGen(pi.subprotos[j], (pi.subprotos[j]).name, filename, false); 
/*     */     } else {
/*  61 */       this.inners = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void scanInstructions(ProtoInfo pi, String classname, JavaBuilder builder) {
/*  66 */     Prototype p = pi.prototype;
/*  67 */     int vresultbase = -1;
/*     */     
/*  69 */     for (BasicBlock b0 : pi.blocklist) {
/*     */       
/*  71 */       for (int slot = 0; slot < p.maxstacksize; slot++) {
/*  72 */         int i = b0.pc0;
/*  73 */         boolean c = pi.isUpvalueCreate(i, slot);
/*  74 */         if (c && pi.vars[slot][i].isPhiVar()) {
/*  75 */           builder.convertToUpvalue(i, slot);
/*     */         }
/*     */       } 
/*  78 */       for (int pc = b0.pc0; pc <= b0.pc1; pc++) {
/*     */         int k, narg, i, index0, m; boolean useinvoke; Prototype newp; int j, n, nup; String protoname;
/*  80 */         int up, pc0 = pc;
/*  81 */         int ins = p.code[pc];
/*  82 */         int line = (pc < p.lineinfo.length) ? p.lineinfo[pc] : -1;
/*  83 */         int o = Lua.GET_OPCODE(ins);
/*  84 */         int a = Lua.GETARG_A(ins);
/*  85 */         int b = Lua.GETARG_B(ins);
/*  86 */         int bx = Lua.GETARG_Bx(ins);
/*  87 */         int sbx = Lua.GETARG_sBx(ins);
/*  88 */         int c = Lua.GETARG_C(ins);
/*     */         
/*  90 */         switch (o) {
/*     */           case 5:
/*  92 */             builder.loadUpvalue(b);
/*  93 */             builder.storeLocal(pc, a);
/*     */             break;
/*     */           
/*     */           case 9:
/*  97 */             builder.storeUpvalue(pc, b, a);
/*     */             break;
/*     */           
/*     */           case 11:
/* 101 */             builder.newTable(b, c);
/* 102 */             builder.storeLocal(pc, a);
/*     */             break;
/*     */           
/*     */           case 0:
/* 106 */             builder.loadLocal(pc, b);
/* 107 */             builder.storeLocal(pc, a);
/*     */             break;
/*     */           
/*     */           case 19:
/*     */           case 20:
/*     */           case 21:
/* 113 */             builder.loadLocal(pc, b);
/* 114 */             builder.unaryop(o);
/* 115 */             builder.storeLocal(pc, a);
/*     */             break;
/*     */           
/*     */           case 1:
/* 119 */             builder.loadConstant(p.k[bx]);
/* 120 */             builder.storeLocal(pc, a);
/*     */             break;
/*     */           
/*     */           case 4:
/* 124 */             builder.loadNil();
/* 125 */             for (; b >= 0; a++, b--) {
/* 126 */               if (b > 0)
/* 127 */                 builder.dup(); 
/* 128 */               builder.storeLocal(pc, a);
/*     */             } 
/*     */             break;
/*     */           
/*     */           case 6:
/* 133 */             builder.loadUpvalue(b);
/* 134 */             loadLocalOrConstant(p, builder, pc, c);
/* 135 */             builder.getTable();
/* 136 */             builder.storeLocal(pc, a);
/*     */             break;
/*     */           
/*     */           case 7:
/* 140 */             builder.loadLocal(pc, b);
/* 141 */             loadLocalOrConstant(p, builder, pc, c);
/* 142 */             builder.getTable();
/* 143 */             builder.storeLocal(pc, a);
/*     */             break;
/*     */           
/*     */           case 8:
/* 147 */             builder.loadUpvalue(a);
/* 148 */             loadLocalOrConstant(p, builder, pc, b);
/* 149 */             loadLocalOrConstant(p, builder, pc, c);
/* 150 */             builder.setTable();
/*     */             break;
/*     */           
/*     */           case 10:
/* 154 */             builder.loadLocal(pc, a);
/* 155 */             loadLocalOrConstant(p, builder, pc, b);
/* 156 */             loadLocalOrConstant(p, builder, pc, c);
/* 157 */             builder.setTable();
/*     */             break;
/*     */           
/*     */           case 13:
/*     */           case 14:
/*     */           case 15:
/*     */           case 16:
/*     */           case 17:
/*     */           case 18:
/* 166 */             loadLocalOrConstant(p, builder, pc, b);
/* 167 */             loadLocalOrConstant(p, builder, pc, c);
/* 168 */             builder.binaryop(o);
/* 169 */             builder.storeLocal(pc, a);
/*     */             break;
/*     */           
/*     */           case 12:
/* 173 */             builder.loadLocal(pc, b);
/* 174 */             builder.dup();
/* 175 */             builder.storeLocal(pc, a + 1);
/* 176 */             loadLocalOrConstant(p, builder, pc, c);
/* 177 */             builder.getTable();
/* 178 */             builder.storeLocal(pc, a);
/*     */             break;
/*     */           
/*     */           case 22:
/* 182 */             for (k = b; k <= c; k++)
/* 183 */               builder.loadLocal(pc, k); 
/* 184 */             if (c > b + 1) {
/* 185 */               builder.tobuffer();
/* 186 */               for (k = c; --k >= b;)
/* 187 */                 builder.concatbuffer(); 
/* 188 */               builder.tovalue();
/*     */             } else {
/* 190 */               builder.concatvalue();
/*     */             } 
/* 192 */             builder.storeLocal(pc, a);
/*     */             break;
/*     */           
/*     */           case 3:
/* 196 */             builder.loadBoolean((b != 0));
/* 197 */             builder.storeLocal(pc, a);
/* 198 */             if (c != 0) {
/* 199 */               builder.addBranch(pc, 1, pc + 2);
/*     */             }
/*     */             break;
/*     */           case 23:
/* 203 */             if (a > 0) {
/* 204 */               for (int i1 = a - 1; i1 < pi.openups.length; i1++) {
/* 205 */                 builder.closeUpvalue(pc, i1);
/*     */               }
/*     */             }
/* 208 */             builder.addBranch(pc, 1, pc + 1 + sbx);
/*     */             break;
/*     */           
/*     */           case 24:
/*     */           case 25:
/*     */           case 26:
/* 214 */             loadLocalOrConstant(p, builder, pc, b);
/* 215 */             loadLocalOrConstant(p, builder, pc, c);
/* 216 */             builder.compareop(o);
/* 217 */             builder.addBranch(pc, (a != 0) ? 3 : 2, pc + 2);
/*     */             break;
/*     */           
/*     */           case 27:
/* 221 */             builder.loadLocal(pc, a);
/* 222 */             builder.toBoolean();
/* 223 */             builder.addBranch(pc, (c != 0) ? 3 : 2, pc + 2);
/*     */             break;
/*     */           
/*     */           case 28:
/* 227 */             builder.loadLocal(pc, b);
/* 228 */             builder.toBoolean();
/* 229 */             builder.addBranch(pc, (c != 0) ? 3 : 2, pc + 2);
/* 230 */             builder.loadLocal(pc, b);
/* 231 */             builder.storeLocal(pc, a);
/*     */             break;
/*     */ 
/*     */ 
/*     */           
/*     */           case 29:
/* 237 */             builder.loadLocal(pc, a);
/*     */ 
/*     */             
/* 240 */             narg = b - 1;
/* 241 */             switch (narg) {
/*     */               case 0:
/*     */               case 1:
/*     */               case 2:
/*     */               case 3:
/* 246 */                 for (m = 1; m < b; m++)
/* 247 */                   builder.loadLocal(pc, a + m); 
/*     */                 break;
/*     */               default:
/* 250 */                 builder.newVarargs(pc, a + 1, b - 1);
/* 251 */                 narg = -1;
/*     */                 break;
/*     */               case -1:
/* 254 */                 loadVarargResults(builder, pc, a + 1, vresultbase);
/* 255 */                 narg = -1;
/*     */                 break;
/*     */             } 
/*     */ 
/*     */             
/* 260 */             useinvoke = (narg < 0 || c < 1 || c > 2);
/* 261 */             if (useinvoke) {
/* 262 */               builder.invoke(narg);
/*     */             } else {
/* 264 */               builder.call(narg);
/*     */             } 
/*     */             
/* 267 */             switch (c) {
/*     */               case 1:
/* 269 */                 builder.pop();
/*     */                 break;
/*     */               case 2:
/* 272 */                 if (useinvoke)
/* 273 */                   builder.arg(1); 
/* 274 */                 builder.storeLocal(pc, a);
/*     */                 break;
/*     */               default:
/* 277 */                 for (n = 1; n < c; n++) {
/* 278 */                   if (n + 1 < c)
/* 279 */                     builder.dup(); 
/* 280 */                   builder.arg(n);
/* 281 */                   builder.storeLocal(pc, a + n - 1);
/*     */                 }  break;
/*     */               case 0:
/*     */                 break;
/* 285 */             }  vresultbase = a;
/* 286 */             builder.storeVarresult();
/*     */             break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case 30:
/* 295 */             builder.loadLocal(pc, a);
/*     */ 
/*     */             
/* 298 */             switch (b) {
/*     */               case 1:
/* 300 */                 builder.loadNone();
/*     */                 break;
/*     */               case 2:
/* 303 */                 builder.loadLocal(pc, a + 1);
/*     */                 break;
/*     */               default:
/* 306 */                 builder.newVarargs(pc, a + 1, b - 1);
/*     */                 break;
/*     */               case 0:
/* 309 */                 loadVarargResults(builder, pc, a + 1, vresultbase);
/*     */                 break;
/*     */             } 
/* 312 */             builder.newTailcallVarargs();
/* 313 */             builder.areturn();
/*     */             break;
/*     */           
/*     */           case 31:
/* 317 */             if (c == 1) {
/* 318 */               builder.loadNone();
/*     */             } else {
/* 320 */               switch (b) {
/*     */                 case 0:
/* 322 */                   loadVarargResults(builder, pc, a, vresultbase);
/*     */                   break;
/*     */                 case 1:
/* 325 */                   builder.loadNone();
/*     */                   break;
/*     */                 case 2:
/* 328 */                   builder.loadLocal(pc, a);
/*     */                   break;
/*     */                 default:
/* 331 */                   builder.newVarargs(pc, a, b - 1);
/*     */                   break;
/*     */               } 
/*     */             } 
/* 335 */             builder.areturn();
/*     */             break;
/*     */           
/*     */           case 33:
/* 339 */             builder.loadLocal(pc, a);
/* 340 */             builder.loadLocal(pc, a + 2);
/* 341 */             builder.binaryop(14);
/* 342 */             builder.storeLocal(pc, a);
/* 343 */             builder.addBranch(pc, 1, pc + 1 + sbx);
/*     */             break;
/*     */           
/*     */           case 32:
/* 347 */             builder.loadLocal(pc, a);
/* 348 */             builder.loadLocal(pc, a + 2);
/* 349 */             builder.binaryop(13);
/* 350 */             builder.dup();
/* 351 */             builder.dup();
/* 352 */             builder.storeLocal(pc, a);
/* 353 */             builder.storeLocal(pc, a + 3);
/* 354 */             builder.loadLocal(pc, a + 1);
/* 355 */             builder.loadLocal(pc, a + 2);
/* 356 */             builder.testForLoop();
/* 357 */             builder.addBranch(pc, 2, pc + 1 + sbx);
/*     */             break;
/*     */           
/*     */           case 34:
/* 361 */             builder.loadLocal(pc, a);
/* 362 */             builder.loadLocal(pc, a + 1);
/* 363 */             builder.loadLocal(pc, a + 2);
/* 364 */             builder.invoke(2);
/* 365 */             for (i = 1; i <= c; i++) {
/* 366 */               if (i < c)
/* 367 */                 builder.dup(); 
/* 368 */               builder.arg(i);
/* 369 */               builder.storeLocal(pc, a + 2 + i);
/*     */             } 
/*     */             break;
/*     */           
/*     */           case 35:
/* 374 */             builder.loadLocal(pc, a + 1);
/* 375 */             builder.dup();
/* 376 */             builder.storeLocal(pc, a);
/* 377 */             builder.isNil();
/* 378 */             builder.addBranch(pc, 3, pc + 1 + sbx);
/*     */             break;
/*     */           
/*     */           case 36:
/* 382 */             index0 = (c - 1) * 50 + 1;
/* 383 */             builder.loadLocal(pc, a);
/* 384 */             if (b == 0) {
/* 385 */               int nstack = vresultbase - a + 1;
/* 386 */               if (nstack > 0) {
/* 387 */                 builder.setlistStack(pc, a + 1, index0, nstack);
/* 388 */                 index0 += nstack;
/*     */               } 
/* 390 */               builder.setlistVarargs(index0, vresultbase); break;
/*     */             } 
/* 392 */             builder.setlistStack(pc, a + 1, index0, b);
/* 393 */             builder.pop();
/*     */             break;
/*     */ 
/*     */ 
/*     */           
/*     */           case 37:
/* 399 */             newp = p.p[bx];
/* 400 */             nup = newp.upvalues.length;
/* 401 */             protoname = (pi.subprotos[bx]).name;
/* 402 */             builder.closureCreate(protoname);
/* 403 */             if (nup > 0)
/* 404 */               builder.dup(); 
/* 405 */             builder.storeLocal(pc, a);
/* 406 */             for (up = 0; up < nup; up++) {
/* 407 */               if (up + 1 < nup)
/* 408 */                 builder.dup(); 
/* 409 */               Upvaldesc u = newp.upvalues[up];
/* 410 */               if (u.instack) {
/* 411 */                 builder.closureInitUpvalueFromLocal(protoname, up, pc, u.idx);
/*     */               } else {
/* 413 */                 builder.closureInitUpvalueFromUpvalue(protoname, up, u.idx);
/*     */               } 
/*     */             } 
/*     */             break;
/*     */           case 38:
/* 418 */             if (b == 0) {
/* 419 */               builder.loadVarargs();
/* 420 */               builder.storeVarresult();
/* 421 */               vresultbase = a; break;
/*     */             } 
/* 423 */             for (j = 1; j < b; a++, j++) {
/* 424 */               builder.loadVarargs(j);
/* 425 */               builder.storeLocal(pc, a);
/*     */             } 
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 432 */         builder.onEndOfLuaInstruction(pc0, line);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void loadVarargResults(JavaBuilder builder, int pc, int a, int vresultbase) {
/* 438 */     if (vresultbase <= a) {
/* 439 */       builder.loadVarresult();
/* 440 */       builder.subargs(a + 1 - vresultbase);
/* 441 */     } else if (vresultbase == a) {
/* 442 */       builder.loadVarresult();
/*     */     } else {
/* 444 */       builder.newVarargsVarresult(pc, a, vresultbase - a);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void loadLocalOrConstant(Prototype p, JavaBuilder builder, int pc, int borc) {
/* 449 */     if (borc <= 255) {
/* 450 */       builder.loadLocal(pc, borc);
/*     */     } else {
/* 452 */       builder.loadConstant(p.k[borc & 0xFF]);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\luajc\JavaGen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */