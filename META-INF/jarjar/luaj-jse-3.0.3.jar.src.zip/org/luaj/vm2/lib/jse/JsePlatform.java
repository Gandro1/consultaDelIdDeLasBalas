/*     */ package org.luaj.vm2.lib.jse;
/*     */ 
/*     */ import org.luaj.vm2.Globals;
/*     */ import org.luaj.vm2.LoadState;
/*     */ import org.luaj.vm2.LuaTable;
/*     */ import org.luaj.vm2.LuaValue;
/*     */ import org.luaj.vm2.Varargs;
/*     */ import org.luaj.vm2.compiler.LuaC;
/*     */ import org.luaj.vm2.lib.Bit32Lib;
/*     */ import org.luaj.vm2.lib.CoroutineLib;
/*     */ import org.luaj.vm2.lib.DebugLib;
/*     */ import org.luaj.vm2.lib.PackageLib;
/*     */ import org.luaj.vm2.lib.TableLib;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsePlatform
/*     */ {
/*     */   public static Globals standardGlobals() {
/* 109 */     Globals globals = new Globals();
/* 110 */     globals.load((LuaValue)new JseBaseLib());
/* 111 */     globals.load((LuaValue)new PackageLib());
/* 112 */     globals.load((LuaValue)new Bit32Lib());
/* 113 */     globals.load((LuaValue)new TableLib());
/* 114 */     globals.load((LuaValue)new JseStringLib());
/* 115 */     globals.load((LuaValue)new CoroutineLib());
/* 116 */     globals.load((LuaValue)new JseMathLib());
/* 117 */     globals.load((LuaValue)new JseIoLib());
/* 118 */     globals.load((LuaValue)new JseOsLib());
/* 119 */     globals.load((LuaValue)new LuajavaLib());
/* 120 */     LoadState.install(globals);
/* 121 */     LuaC.install(globals);
/* 122 */     return globals;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Globals debugGlobals() {
/* 135 */     Globals globals = standardGlobals();
/* 136 */     globals.load((LuaValue)new DebugLib());
/* 137 */     return globals;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Varargs luaMain(LuaValue mainChunk, String[] args) {
/* 148 */     Globals g = standardGlobals();
/* 149 */     int n = args.length;
/* 150 */     LuaValue[] vargs = new LuaValue[args.length];
/* 151 */     for (int i = 0; i < n; i++)
/* 152 */       vargs[i] = (LuaValue)LuaValue.valueOf(args[i]); 
/* 153 */     LuaTable luaTable = LuaValue.listOf(vargs);
/* 154 */     luaTable.set("n", n);
/* 155 */     g.set("arg", (LuaValue)luaTable);
/* 156 */     mainChunk.initupvalue1((LuaValue)g);
/* 157 */     return mainChunk.invoke(LuaValue.varargsOf(vargs));
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\lib\jse\JsePlatform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */