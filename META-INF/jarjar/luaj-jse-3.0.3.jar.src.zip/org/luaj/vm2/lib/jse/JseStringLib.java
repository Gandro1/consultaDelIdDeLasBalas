/*    */ package org.luaj.vm2.lib.jse;
/*    */ 
/*    */ import org.luaj.vm2.lib.StringLib;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JseStringLib
/*    */   extends StringLib
/*    */ {
/*    */   protected String format(String src, double x) {
/*    */     String out;
/*    */     try {
/* 34 */       out = String.format(src, new Object[] { Double.valueOf(x) });
/* 35 */     } catch (Throwable e) {
/* 36 */       out = super.format(src, x);
/*    */     } 
/* 38 */     return out;
/*    */   }
/*    */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\lib\jse\JseStringLib.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */