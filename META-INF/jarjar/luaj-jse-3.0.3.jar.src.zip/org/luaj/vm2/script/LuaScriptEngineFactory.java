/*     */ package org.luaj.vm2.script;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.script.ScriptEngine;
/*     */ import javax.script.ScriptEngineFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LuaScriptEngineFactory
/*     */   implements ScriptEngineFactory
/*     */ {
/*  38 */   private static final String[] EXTENSIONS = new String[] { "lua", ".lua" };
/*     */   
/*  40 */   private static final String[] MIMETYPES = new String[] { "text/lua", "application/lua" };
/*     */   
/*  42 */   private static final String[] NAMES = new String[] { "lua", "luaj" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   private final List<String> extensions = Arrays.asList(EXTENSIONS);
/*  50 */   private final List<String> mimeTypes = Arrays.asList(MIMETYPES);
/*  51 */   private final List<String> names = Arrays.asList(NAMES);
/*     */ 
/*     */   
/*     */   public String getEngineName() {
/*  55 */     return getScriptEngine().get("javax.script.engine").toString();
/*     */   }
/*     */   public String getEngineVersion() {
/*  58 */     return getScriptEngine().get("javax.script.engine_version").toString();
/*     */   }
/*     */   public List<String> getExtensions() {
/*  61 */     return this.extensions;
/*     */   }
/*     */   public List<String> getMimeTypes() {
/*  64 */     return this.mimeTypes;
/*     */   }
/*     */   public List<String> getNames() {
/*  67 */     return this.names;
/*     */   }
/*     */   public String getLanguageName() {
/*  70 */     return getScriptEngine().get("javax.script.language").toString();
/*     */   }
/*     */   public String getLanguageVersion() {
/*  73 */     return getScriptEngine().get("javax.script.language_version").toString();
/*     */   }
/*     */   
/*     */   public Object getParameter(String key) {
/*  77 */     return getScriptEngine().get(key).toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMethodCallSyntax(String obj, String m, String... args) {
/*  82 */     StringBuffer sb = new StringBuffer();
/*  83 */     sb.append(obj + ":" + m + "(");
/*  84 */     int len = args.length;
/*  85 */     for (int i = 0; i < len; i++) {
/*  86 */       if (i > 0) {
/*  87 */         sb.append(',');
/*     */       }
/*  89 */       sb.append(args[i]);
/*     */     } 
/*  91 */     sb.append(")");
/*  92 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getOutputStatement(String toDisplay) {
/*  97 */     return "print(" + toDisplay + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getProgram(String... statements) {
/* 102 */     StringBuffer sb = new StringBuffer();
/* 103 */     int len = statements.length;
/* 104 */     for (int i = 0; i < len; i++) {
/* 105 */       if (i > 0) {
/* 106 */         sb.append('\n');
/*     */       }
/* 108 */       sb.append(statements[i]);
/*     */     } 
/* 110 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public ScriptEngine getScriptEngine() {
/* 114 */     return new LuaScriptEngine();
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\script\LuaScriptEngineFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */