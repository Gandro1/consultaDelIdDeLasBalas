/*     */ package org.luaj.vm2.script;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import javax.script.ScriptContext;
/*     */ import javax.script.SimpleScriptContext;
/*     */ import org.luaj.vm2.Globals;
/*     */ import org.luaj.vm2.lib.jse.JsePlatform;
/*     */ import org.luaj.vm2.luajc.LuaJC;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LuajContext
/*     */   extends SimpleScriptContext
/*     */   implements ScriptContext
/*     */ {
/*     */   public final Globals globals;
/*     */   private final InputStream stdin;
/*     */   private final PrintStream stdout;
/*     */   private final PrintStream stderr;
/*     */   
/*     */   public LuajContext() {
/*  63 */     this("true".equals(System.getProperty("org.luaj.debug")), "true".equals(System.getProperty("org.luaj.luajc")));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LuajContext(boolean createDebugGlobals, boolean useLuaJCCompiler) {
/*  81 */     this.globals = createDebugGlobals ? JsePlatform.debugGlobals() : JsePlatform.standardGlobals();
/*  82 */     if (useLuaJCCompiler)
/*  83 */       LuaJC.install(this.globals); 
/*  84 */     this.stdin = this.globals.STDIN;
/*  85 */     this.stdout = this.globals.STDOUT;
/*  86 */     this.stderr = this.globals.STDERR;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setErrorWriter(Writer writer) {
/*  91 */     this.globals.STDERR = (writer != null) ? new PrintStream(new WriterOutputStream(writer)) : this.stderr;
/*     */   }
/*     */   
/*     */   public void setReader(Reader reader) {
/*  95 */     this.globals.STDIN = (reader != null) ? new ReaderInputStream(reader) : this.stdin;
/*     */   }
/*     */   
/*     */   public void setWriter(Writer writer) {
/*  99 */     this.globals.STDOUT = (writer != null) ? new PrintStream(new WriterOutputStream(writer), true) : this.stdout;
/*     */   }
/*     */   
/*     */   static final class WriterOutputStream extends OutputStream {
/*     */     final Writer w;
/*     */     
/*     */     WriterOutputStream(Writer w) {
/* 106 */       this.w = w;
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(int b) throws IOException {
/* 111 */       this.w.write(new String(new byte[] { (byte)b }));
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(byte[] b, int o, int l) throws IOException {
/* 116 */       this.w.write(new String(b, o, l));
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(byte[] b) throws IOException {
/* 121 */       this.w.write(new String(b));
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 126 */       this.w.close();
/*     */     }
/*     */ 
/*     */     
/*     */     public void flush() throws IOException {
/* 131 */       this.w.flush();
/*     */     }
/*     */   }
/*     */   
/*     */   static final class ReaderInputStream extends InputStream {
/*     */     final Reader r;
/*     */     
/*     */     ReaderInputStream(Reader r) {
/* 139 */       this.r = r;
/*     */     }
/*     */ 
/*     */     
/*     */     public int read() throws IOException {
/* 144 */       return this.r.read();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\script\LuajContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */