/*     */ package org.luaj.vm2.script;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import javax.script.AbstractScriptEngine;
/*     */ import javax.script.Bindings;
/*     */ import javax.script.Compilable;
/*     */ import javax.script.CompiledScript;
/*     */ import javax.script.ScriptContext;
/*     */ import javax.script.ScriptEngine;
/*     */ import javax.script.ScriptEngineFactory;
/*     */ import javax.script.ScriptException;
/*     */ import javax.script.SimpleBindings;
/*     */ import org.luaj.vm2.Globals;
/*     */ import org.luaj.vm2.LuaClosure;
/*     */ import org.luaj.vm2.LuaError;
/*     */ import org.luaj.vm2.LuaFunction;
/*     */ import org.luaj.vm2.LuaTable;
/*     */ import org.luaj.vm2.LuaValue;
/*     */ import org.luaj.vm2.Varargs;
/*     */ import org.luaj.vm2.lib.ThreeArgFunction;
/*     */ import org.luaj.vm2.lib.TwoArgFunction;
/*     */ import org.luaj.vm2.lib.jse.CoerceJavaToLua;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LuaScriptEngine
/*     */   extends AbstractScriptEngine
/*     */   implements ScriptEngine, Compilable
/*     */ {
/*     */   private static final String __ENGINE_VERSION__ = "Luaj 0.0";
/*     */   private static final String __NAME__ = "Luaj";
/*     */   private static final String __SHORT_NAME__ = "Luaj";
/*     */   private static final String __LANGUAGE__ = "lua";
/*     */   private static final String __LANGUAGE_VERSION__ = "5.2";
/*     */   private static final String __ARGV__ = "arg";
/*     */   private static final String __FILENAME__ = "?";
/*  72 */   private static final ScriptEngineFactory myFactory = new LuaScriptEngineFactory();
/*     */   
/*     */   private final LuajContext context;
/*     */ 
/*     */   
/*     */   public LuaScriptEngine() {
/*  78 */     this.context = new LuajContext();
/*  79 */     this.context.setBindings(createBindings(), 100);
/*  80 */     setContext(this.context);
/*     */ 
/*     */     
/*  83 */     put("javax.script.language_version", "5.2");
/*  84 */     put("javax.script.language", "lua");
/*  85 */     put("javax.script.engine", "Luaj");
/*  86 */     put("javax.script.engine_version", "Luaj 0.0");
/*  87 */     put("javax.script.argv", "arg");
/*  88 */     put("javax.script.filename", "?");
/*  89 */     put("javax.script.name", "Luaj");
/*  90 */     put("THREADING", null);
/*     */   }
/*     */ 
/*     */   
/*     */   public CompiledScript compile(String script) throws ScriptException {
/*  95 */     return compile(new StringReader(script));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CompiledScript compile(Reader script) throws ScriptException {
/* 101 */     try (InputStream is = new Utf8Encoder(script)) {
/* 102 */       Globals g = this.context.globals;
/* 103 */       LuaFunction f = g.load(script, "script").checkfunction();
/* 104 */       return new LuajCompiledScript(f, g);
/* 105 */     } catch (LuaError lee) {
/* 106 */       throw new ScriptException(lee.getMessage());
/*     */     }
/* 108 */     catch (Exception e) {
/* 109 */       throw new ScriptException("eval threw " + e.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object eval(Reader reader, Bindings bindings) throws ScriptException {
/* 115 */     return ((LuajCompiledScript)compile(reader)).eval(this.context.globals, bindings);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object eval(String script, Bindings bindings) throws ScriptException {
/* 120 */     return eval(new StringReader(script), bindings);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ScriptContext getScriptContext(Bindings nn) {
/* 125 */     throw new IllegalStateException("LuajScriptEngine should not be allocating contexts.");
/*     */   }
/*     */ 
/*     */   
/*     */   public Bindings createBindings() {
/* 130 */     return new SimpleBindings();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object eval(String script, ScriptContext context) throws ScriptException {
/* 135 */     return eval(new StringReader(script), context);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object eval(Reader reader, ScriptContext context) throws ScriptException {
/* 140 */     return compile(reader).eval(context);
/*     */   }
/*     */   
/*     */   public ScriptEngineFactory getFactory() {
/* 144 */     return myFactory;
/*     */   }
/*     */   
/*     */   class LuajCompiledScript extends CompiledScript { final LuaFunction function;
/*     */     final Globals compiling_globals;
/*     */     
/*     */     LuajCompiledScript(LuaFunction function, Globals compiling_globals) {
/* 151 */       this.function = function;
/* 152 */       this.compiling_globals = compiling_globals;
/*     */     }
/*     */     
/*     */     public ScriptEngine getEngine() {
/* 156 */       return LuaScriptEngine.this;
/*     */     }
/*     */     
/*     */     public Object eval() throws ScriptException {
/* 160 */       return eval(LuaScriptEngine.this.getContext());
/*     */     }
/*     */ 
/*     */     
/*     */     public Object eval(Bindings bindings) throws ScriptException {
/* 165 */       return eval(((LuajContext)LuaScriptEngine.this.getContext()).globals, bindings);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object eval(ScriptContext context) throws ScriptException {
/* 170 */       return eval(((LuajContext)context).globals, context.getBindings(100));
/*     */     } Object eval(Globals g, Bindings b) throws ScriptException {
/*     */       LuaClosure luaClosure;
/*     */       LuaFunction luaFunction1;
/* 174 */       g.setmetatable((LuaValue)new LuaScriptEngine.BindingsMetatable(b));
/* 175 */       LuaFunction f = this.function;
/* 176 */       if (f.isclosure()) {
/* 177 */         luaClosure = new LuaClosure((f.checkclosure()).p, (LuaValue)g);
/*     */       } else {
/*     */         try {
/* 180 */           luaFunction1 = (LuaFunction)luaClosure.getClass().newInstance();
/* 181 */         } catch (Exception e) {
/* 182 */           throw new ScriptException(e);
/*     */         } 
/* 184 */         luaFunction1.initupvalue1((LuaValue)g);
/*     */       } 
/* 186 */       return LuaScriptEngine.toJava(luaFunction1.invoke((Varargs)LuaValue.NONE));
/*     */     } }
/*     */ 
/*     */   
/*     */   private final class Utf8Encoder
/*     */     extends InputStream
/*     */   {
/*     */     private final Reader r;
/* 194 */     private final int[] buf = new int[2];
/*     */     private int n;
/*     */     
/*     */     private Utf8Encoder(Reader r) {
/* 198 */       this.r = r;
/*     */     }
/*     */ 
/*     */     
/*     */     public int read() throws IOException {
/* 203 */       if (this.n > 0)
/* 204 */         return this.buf[--this.n]; 
/* 205 */       int c = this.r.read();
/* 206 */       if (c < 128)
/* 207 */         return c; 
/* 208 */       this.n = 0;
/* 209 */       if (c < 2048) {
/* 210 */         this.buf[this.n++] = 0x80 | c & 0x3F;
/* 211 */         return 0xC0 | c >> 6 & 0x1F;
/*     */       } 
/* 213 */       this.buf[this.n++] = 0x80 | c & 0x3F;
/* 214 */       this.buf[this.n++] = 0x80 | c >> 6 & 0x3F;
/* 215 */       return 0xE0 | c >> 12 & 0xF;
/*     */     }
/*     */   }
/*     */   
/*     */   static class BindingsMetatable
/*     */     extends LuaTable
/*     */   {
/*     */     BindingsMetatable(final Bindings bindings) {
/* 223 */       rawset((LuaValue)LuaValue.INDEX, (LuaValue)new TwoArgFunction()
/*     */           {
/*     */             public LuaValue call(LuaValue table, LuaValue key) {
/* 226 */               if (key.isstring()) {
/* 227 */                 return LuaScriptEngine.toLua(bindings.get(key.tojstring()));
/*     */               }
/* 229 */               return rawget(key);
/*     */             }
/*     */           });
/* 232 */       rawset((LuaValue)LuaValue.NEWINDEX, (LuaValue)new ThreeArgFunction()
/*     */           {
/*     */             public LuaValue call(LuaValue table, LuaValue key, LuaValue value) {
/* 235 */               if (key.isstring())
/* 236 */               { String k = key.tojstring();
/* 237 */                 Object v = LuaScriptEngine.toJava(value);
/* 238 */                 if (v == null) {
/* 239 */                   bindings.remove(k);
/*     */                 } else {
/* 241 */                   bindings.put(k, v);
/*     */                 }  }
/* 243 */               else { rawset(key, value); }
/*     */               
/* 245 */               return LuaValue.NONE;
/*     */             }
/*     */           });
/*     */     }
/*     */   }
/*     */   
/*     */   private static LuaValue toLua(Object javaValue) {
/* 252 */     return (javaValue == null) ? LuaValue.NIL : ((javaValue instanceof LuaValue) ? (LuaValue)javaValue : 
/* 253 */       CoerceJavaToLua.coerce(javaValue));
/*     */   }
/*     */   
/*     */   private static Object toJava(LuaValue luajValue) {
/* 257 */     switch (luajValue.type()) {
/*     */       case 0:
/* 259 */         return null;
/*     */       case 4:
/* 261 */         return luajValue.tojstring();
/*     */       case 7:
/* 263 */         return luajValue.checkuserdata(Object.class);
/*     */       case 3:
/* 265 */         return luajValue.isinttype() ? Integer.valueOf(luajValue.toint()) : 
/* 266 */           Double.valueOf(luajValue.todouble());
/*     */     } 
/* 268 */     return luajValue;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object toJava(Varargs v) {
/* 273 */     int n = v.narg();
/* 274 */     switch (n) {
/*     */       case 0:
/* 276 */         return null;
/*     */       case 1:
/* 278 */         return toJava(v.arg1());
/*     */     } 
/* 280 */     Object[] o = new Object[n];
/* 281 */     for (int i = 0; i < n; i++)
/* 282 */       o[i] = toJava(v.arg(i + 1)); 
/* 283 */     return o;
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\org\luaj\vm2\script\LuaScriptEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */