/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import org.luaj.vm2.Globals;
/*     */ import org.luaj.vm2.Print;
/*     */ import org.luaj.vm2.Prototype;
/*     */ import org.luaj.vm2.compiler.DumpState;
/*     */ import org.luaj.vm2.lib.jse.JsePlatform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class luac
/*     */ {
/*     */   private static final String version = "Luaj 0.0Copyright (C) 2009 luaj.org";
/*     */   private static final String usage = "usage: java -cp luaj-jse.jar luac [options] [filenames].\nAvailable options are:\n  -        process stdin\n  -l       list\n  -o name  output to file 'name' (default is \"luac.out\")\n  -p       parse only\n  -s       strip debug information\n  -e       little endian format for numbers\n  -i<n>    number format 'n', (n=0,1 or 4, default=0)\n  -v       show version information\n  -c enc  \tuse the supplied encoding 'enc' for input files\n  --       stop handling options\n";
/*     */   
/*     */   private static void usageExit() {
/*  54 */     System.out.println("usage: java -cp luaj-jse.jar luac [options] [filenames].\nAvailable options are:\n  -        process stdin\n  -l       list\n  -o name  output to file 'name' (default is \"luac.out\")\n  -p       parse only\n  -s       strip debug information\n  -e       little endian format for numbers\n  -i<n>    number format 'n', (n=0,1 or 4, default=0)\n  -v       show version information\n  -c enc  \tuse the supplied encoding 'enc' for input files\n  --       stop handling options\n");
/*  55 */     System.exit(-1);
/*     */   }
/*     */   
/*     */   private boolean list = false;
/*  59 */   private String output = "luac.out";
/*     */   private boolean parseonly = false;
/*     */   private boolean stripdebug = false;
/*     */   private boolean littleendian = false;
/*  63 */   private int numberformat = 0;
/*     */   private boolean versioninfo = false;
/*     */   private boolean processing = true;
/*  66 */   private String encoding = null;
/*     */   
/*     */   public static void main(String[] args) throws IOException {
/*  69 */     new luac(args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private luac(String[] args) throws IOException {
/*     */     try {
/*  77 */       for (int i = 0; i < args.length; i++) {
/*  78 */         if (this.processing && args[i].startsWith("-"))
/*     */         {
/*  80 */           if (args[i].length() > 1)
/*     */           {
/*     */             
/*  83 */             switch (args[i].charAt(1)) {
/*     */               case 'l':
/*  85 */                 this.list = true;
/*     */                 break;
/*     */               case 'o':
/*  88 */                 if (++i >= args.length)
/*  89 */                   usageExit(); 
/*  90 */                 this.output = args[i];
/*     */                 break;
/*     */               case 'p':
/*  93 */                 this.parseonly = true;
/*     */                 break;
/*     */               case 's':
/*  96 */                 this.stripdebug = true;
/*     */                 break;
/*     */               case 'e':
/*  99 */                 this.littleendian = true;
/*     */                 break;
/*     */               case 'i':
/* 102 */                 if (args[i].length() <= 2)
/* 103 */                   usageExit(); 
/* 104 */                 this.numberformat = Integer.parseInt(args[i].substring(2));
/*     */                 break;
/*     */               case 'v':
/* 107 */                 this.versioninfo = true;
/*     */                 break;
/*     */               case 'c':
/* 110 */                 if (++i >= args.length)
/* 111 */                   usageExit(); 
/* 112 */                 this.encoding = args[i];
/*     */                 break;
/*     */               case '-':
/* 115 */                 if (args[i].length() > 2)
/* 116 */                   usageExit(); 
/* 117 */                 this.processing = false;
/*     */                 break;
/*     */               default:
/* 120 */                 usageExit();
/*     */                 break;
/*     */             } 
/*     */           
/*     */           }
/*     */         }
/*     */       } 
/* 127 */       if (this.versioninfo) {
/* 128 */         System.out.println("Luaj 0.0Copyright (C) 2009 luaj.org");
/*     */       }
/*     */ 
/*     */       
/* 132 */       try (OutputStream fos = new FileOutputStream(this.output)) {
/* 133 */         Globals globals = JsePlatform.standardGlobals();
/* 134 */         this.processing = true;
/* 135 */         for (int j = 0; j < args.length; j++) {
/* 136 */           if (!this.processing || !args[j].startsWith("-")) {
/* 137 */             String chunkname = args[j].substring(0, args[j].length() - 4);
/* 138 */             processScript(globals, new FileInputStream(args[j]), chunkname, fos);
/* 139 */           } else if (args[j].length() <= 1) {
/* 140 */             processScript(globals, System.in, "=stdin", fos);
/*     */           } else {
/* 142 */             switch (args[j].charAt(1)) {
/*     */               case 'c':
/*     */               case 'o':
/* 145 */                 j++;
/*     */                 break;
/*     */               case '-':
/* 148 */                 this.processing = false;
/*     */                 break;
/*     */             } 
/*     */           
/*     */           } 
/*     */         } 
/*     */       } 
/* 155 */     } catch (IOException ioe) {
/* 156 */       System.err.println(ioe.toString());
/* 157 */       System.exit(-2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void processScript(Globals globals, InputStream script, String chunkname, OutputStream out) throws IOException {
/*     */     try {
/* 165 */       script = new BufferedInputStream(script);
/*     */ 
/*     */       
/* 168 */       Prototype chunk = (this.encoding != null) ? globals.compilePrototype(new InputStreamReader(script, this.encoding), chunkname) : globals.compilePrototype(script, chunkname);
/*     */ 
/*     */       
/* 171 */       if (this.list) {
/* 172 */         Print.printCode(chunk);
/*     */       }
/*     */       
/* 175 */       if (!this.parseonly) {
/* 176 */         DumpState.dump(chunk, out, this.stripdebug, this.numberformat, this.littleendian);
/*     */       }
/*     */     }
/* 179 */     catch (Exception e) {
/* 180 */       e.printStackTrace(System.err);
/*     */     } finally {
/* 182 */       script.close();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\luac.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */