/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.Vector;
/*     */ import org.luaj.vm2.Globals;
/*     */ import org.luaj.vm2.LuaString;
/*     */ import org.luaj.vm2.LuaTable;
/*     */ import org.luaj.vm2.LuaValue;
/*     */ import org.luaj.vm2.Print;
/*     */ import org.luaj.vm2.Varargs;
/*     */ import org.luaj.vm2.lib.jse.JsePlatform;
/*     */ import org.luaj.vm2.luajc.LuaJC;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class lua
/*     */ {
/*     */   private static final String version = "Luaj 0.0 Copyright (c) 2012 Luaj.org.org";
/*     */   private static final String usage = "usage: java -cp luaj-jse.jar lua [options] [script [args]].\nAvailable options are:\n  -e stat  execute string 'stat'\n  -l name  require library 'name'\n  -i       enter interactive mode after executing 'script'\n  -v       show version information\n  -b      \tuse luajc bytecode-to-bytecode compiler (requires bcel on class path)\n  -n      \tnodebug - do not load debug library by default\n  -p      \tprint the prototype\n  -c enc  \tuse the supplied encoding 'enc' for input files\n  --       stop handling options\n  -        execute stdin and stop handling options";
/*     */   private static Globals globals;
/*     */   
/*     */   private static void usageExit() {
/*  57 */     System.out.println("usage: java -cp luaj-jse.jar lua [options] [script [args]].\nAvailable options are:\n  -e stat  execute string 'stat'\n  -l name  require library 'name'\n  -i       enter interactive mode after executing 'script'\n  -v       show version information\n  -b      \tuse luajc bytecode-to-bytecode compiler (requires bcel on class path)\n  -n      \tnodebug - do not load debug library by default\n  -p      \tprint the prototype\n  -c enc  \tuse the supplied encoding 'enc' for input files\n  --       stop handling options\n  -        execute stdin and stop handling options");
/*  58 */     System.exit(-1);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean print = false;
/*  63 */   private static String encoding = null;
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) throws IOException {
/*  68 */     boolean interactive = (args.length == 0);
/*  69 */     boolean versioninfo = false;
/*  70 */     boolean processing = true;
/*  71 */     boolean nodebug = false;
/*  72 */     boolean luajc = false;
/*  73 */     Vector<String> libs = null;
/*     */     try {
/*     */       int i;
/*  76 */       for (i = 0; i < args.length && 
/*  77 */         processing && args[i].startsWith("-"); i++) {
/*     */ 
/*     */         
/*  80 */         if (args[i].length() <= 1) {
/*     */           break;
/*     */         }
/*     */         
/*  84 */         switch (args[i].charAt(1)) {
/*     */           case 'e':
/*  86 */             if (++i >= args.length) {
/*  87 */               usageExit();
/*     */             }
/*     */             break;
/*     */           case 'b':
/*  91 */             luajc = true;
/*     */             break;
/*     */           case 'l':
/*  94 */             if (++i >= args.length)
/*  95 */               usageExit(); 
/*  96 */             libs = (libs != null) ? libs : new Vector();
/*  97 */             libs.addElement(args[i]);
/*     */             break;
/*     */           case 'i':
/* 100 */             interactive = true;
/*     */             break;
/*     */           case 'v':
/* 103 */             versioninfo = true;
/*     */             break;
/*     */           case 'n':
/* 106 */             nodebug = true;
/*     */             break;
/*     */           case 'p':
/* 109 */             print = true;
/*     */             break;
/*     */           case 'c':
/* 112 */             if (++i >= args.length)
/* 113 */               usageExit(); 
/* 114 */             encoding = args[i];
/*     */             break;
/*     */           case '-':
/* 117 */             if (args[i].length() > 2)
/* 118 */               usageExit(); 
/* 119 */             processing = false;
/*     */             break;
/*     */           default:
/* 122 */             usageExit();
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/* 129 */       if (versioninfo) {
/* 130 */         System.out.println("Luaj 0.0 Copyright (c) 2012 Luaj.org.org");
/*     */       }
/*     */       
/* 133 */       globals = nodebug ? JsePlatform.standardGlobals() : JsePlatform.debugGlobals();
/* 134 */       if (luajc)
/* 135 */         LuaJC.install(globals);  int n;
/* 136 */       for (i = 0, n = (libs != null) ? libs.size() : 0; i < n; i++) {
/* 137 */         loadLibrary(libs.elementAt(i));
/*     */       }
/*     */       
/* 140 */       processing = true;
/* 141 */       for (i = 0; i < args.length; i++) {
/* 142 */         if (!processing || !args[i].startsWith("-")) {
/* 143 */           processScript(new FileInputStream(args[i]), args[i], args, i); break;
/*     */         } 
/* 145 */         if ("-".equals(args[i])) {
/* 146 */           processScript(System.in, "=stdin", args, i);
/*     */           break;
/*     */         } 
/* 149 */         switch (args[i].charAt(1)) {
/*     */           case 'c':
/*     */           case 'l':
/* 152 */             i++;
/*     */             break;
/*     */           case 'e':
/* 155 */             i++;
/* 156 */             processScript(new ByteArrayInputStream(args[i].getBytes()), "string", args, i);
/*     */             break;
/*     */           case '-':
/* 159 */             processing = false;
/*     */             break;
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/* 165 */       if (interactive) {
/* 166 */         interactiveMode();
/*     */       }
/* 168 */     } catch (IOException ioe) {
/* 169 */       System.err.println(ioe.toString());
/* 170 */       System.exit(-2);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void loadLibrary(String libname) throws IOException {
/* 175 */     LuaString luaString = LuaValue.valueOf(libname);
/*     */     
/*     */     try {
/* 178 */       globals.get("require").call((LuaValue)luaString);
/* 179 */     } catch (Exception e) {
/*     */       
/*     */       try {
/* 182 */         LuaValue v = (LuaValue)Class.forName(libname).newInstance();
/* 183 */         v.call((LuaValue)luaString, (LuaValue)globals);
/* 184 */       } catch (Exception f) {
/* 185 */         throw new IOException("loadLibrary(" + libname + ") failed: " + e + "," + f);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void processScript(InputStream script, String chunkname, String[] args, int firstarg) throws IOException {
/*     */     try {
/*     */       LuaValue c;
/*     */       try {
/* 195 */         script = new BufferedInputStream(script);
/*     */         
/* 197 */         c = (encoding != null) ? globals.load(new InputStreamReader(script, encoding), chunkname) : globals.load(script, chunkname, "bt", (LuaValue)globals);
/*     */       } finally {
/* 199 */         script.close();
/*     */       } 
/* 201 */       if (print && c.isclosure())
/* 202 */         Print.print((c.checkclosure()).p); 
/* 203 */       Varargs scriptargs = setGlobalArg(chunkname, args, firstarg, (LuaValue)globals);
/* 204 */       c.invoke(scriptargs);
/* 205 */     } catch (Exception e) {
/* 206 */       LuaValue c; c.printStackTrace(System.err);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Varargs setGlobalArg(String chunkname, String[] args, int i, LuaValue globals) {
/* 211 */     if (args == null)
/* 212 */       return (Varargs)LuaValue.NONE; 
/* 213 */     LuaTable arg = LuaValue.tableOf();
/* 214 */     for (int j = 0; j < args.length; j++)
/* 215 */       arg.set(j - i, (LuaValue)LuaValue.valueOf(args[j])); 
/* 216 */     arg.set(0, (LuaValue)LuaValue.valueOf(chunkname));
/* 217 */     arg.set(-1, (LuaValue)LuaValue.valueOf("luaj"));
/* 218 */     globals.set("arg", (LuaValue)arg);
/* 219 */     return arg.unpack();
/*     */   }
/*     */   
/*     */   private static void interactiveMode() throws IOException {
/* 223 */     BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
/*     */     while (true) {
/* 225 */       System.out.print("> ");
/* 226 */       System.out.flush();
/* 227 */       String line = reader.readLine();
/* 228 */       if (line == null)
/*     */         return; 
/* 230 */       processScript(new ByteArrayInputStream(line.getBytes()), "=stdin", null, 0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\gabri\AppData\Roaming\.minecraft\mods\tacz-1.20.1-1.0.3-all.jar!\META-INF\jarjar\luaj-jse-3.0.3.jar!\lua.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */